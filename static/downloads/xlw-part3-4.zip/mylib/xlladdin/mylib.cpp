#include "mylib.h"
#include <math.h>

double MySqrt(double x)
{
  if (x < 0.)
  {
    throw("#Negative argument");
  }
  return sqrt(x);
}

double SumSqrt(double x, double y)
{
  if (x < 0 || y < 0)
  {
    throw("#Negative argument");
  }
  return sqrt(x) + sqrt(y);
}

MyMatrix Outer1(const MyArray& a)
{
  MyMatrix res(a.size(), a.size());
  for (size_t i = 0; i < a.size(); ++i)
  {
    for (size_t j = 0; j < a.size(); ++j)
    {
      res[i][j] = a[i] * a[j];
    }
  }

  return res;
}

XlfOper SquareNumbers(XlfOper& input)
{
  if( !input.IsMulti() )
  {
    XlfOper res;
    if (input.IsNumber())
    {
      const double x = input.AsDouble();
      res = x * x;
    }
    else
    {
      res = "-";
    }
    return res;
  }

  XlfOper res(input.rows(), input.columns());
  for (size_t i = 0; i < res.rows(); ++i)
  {
    for (size_t j = 0; j < res.columns(); ++j)
    {
      if(input(i,j).IsNumber())
      {
        const double x = input(i, j).AsDouble();
        res(i, j) = x*x;
      }
      else
      {
        res(i, j) = "-";
      }
    }
  }
  return res;
}
