#ifndef _mylib_h_
#define _mylib_h_


#include <xlw/xlw.h>
#include <xlw/MyContainers.h>

using namespace xlw;

//<xlw:libraryname=MyLibrary

double //Square root of an argument
MySqrt(double x //argument
);

double //Sum of square roots of two numbers
SumSqrt(double x, //argument 1
  double y //argument 2
);

MyMatrix // Outer product of array with itself
Outer1(const MyArray& a //array a
);

XlfOper //Squares all numbers and sets all other cells to \"-\"
SquareNumbers(XlfOper& input //input range
);

#endif
