#ifndef _mylib_h_
#define _mylib_h_


#include <xlw/xlw.h>
#include <xlw/MyContainers.h>

using namespace xlw;

//<xlw:libraryname=MyLibrary

double //Square root of an argument
MySqrt(double x //argument
);

double //Sum of square roots of two numbers
//<xlw:threadsafe
SumSqrt(double x, //argument 1
  double y //argument 2
);

MyMatrix // Outer product of array with itself
Outer1(const MyArray& a //array a
);

XlfOper //Squares all numbers and sets all other cells to \"-\"
SquareNumbers(XlfOper& input //input range
);

MyMatrix // Returns matrix with (n-i)^k*(m-j)^k in i,j cell, where n,m - rows, cols
CallingRange(double k //power
);

double // Returns number of iterations performed
//<xlw:time
EscInterrupt(int n //max number of iterations
);

double // Number of minutes since Jan 1, 2000
//<xlw:volatile
SysTime();


#endif
