#ifndef _mylib_h_
#define _mylib_h_


#include <xlw/xlw.h>

//<xlw:libraryname=MyLibrary

double //Square root of an argument
MySqrt(double x //argument
);

#endif
