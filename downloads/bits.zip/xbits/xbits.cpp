#include "xbits.h"
#include "xlw/XlfExcel.h"

#include "func.h"

#include <fstream>
#include <iostream>
#include <string>
#include <cstdio>

using namespace std;
using namespace xlw;

#include "json.hpp"

typedef nlohmann::basic_json<map, vector, string, bool, int, unsigned int> json;

double myfunc(double x)
{
  if (x < 1.e7) // no need to call 64 bit version of the function
  {
    return func(x, nullptr);
  }

  // create json to send to bitsexe
  json j;
  j["function"] = "func";
  j["n"] = x;

  char fname[L_tmpnam_s];
  if (tmpnam_s(fname, L_tmpnam_s))
  {
    throw("# could not create tmp file");
  }
  string inname(fname); //name of json file - input into bitsexe
  ofstream infile(inname);
  if (!infile.is_open()) throw("# could not open tmp file");
  infile << setw(2) << j << endl; // write json to the file
  infile.close();

  // find where exe is located (same directory as xll)
  string exepath = XlfExcel::Instance().GetXllDirectory() + "\\bitsexe.exe";

  if (tmpnam_s(fname, L_tmpnam_s))
  {
    throw("# could not create tmp file");
  }
  string outname(fname);

  // call executable
  string call = exepath + " " + inname + " " + outname;
  system(call.c_str());
  remove(inname.c_str());

  // read results from file
  j.clear();
  ifstream outfile(outname);
  if (!outfile.is_open()) throw("# could not open tmp file");
  outfile >> j;
  remove(outname.c_str());

  // error instead of calculation:
  if (j["err"].is_string())
  {
    throw("# " + j["err"].get<string>());
  }

  //TODO - should remove tmp files even if thrown errors above


  double result = j["result"].get<double>();

  return result;
}