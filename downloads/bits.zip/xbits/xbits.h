#ifndef _xbits_h_
#define _xbits_h_

#include <xlw/xlw.h>

//<xlw:libraryname=xbits

double //test
myfunc(double x //arg
);

#endif
