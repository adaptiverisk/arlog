#include "progress_bar.h"

#include <iostream>

// using one of the answers from stackoverflow:
// http://stackoverflow.com/questions/14539867/how-to-display-a-progress-indicator-in-pure-c-c-cout-printf
void progress_bar(double p)
{
  if (p > 100)
  {
    return;
  }
  int bar_width = 70;
  std::cout << "[";
  int pos = int(bar_width * p * 0.01);
  for (int i = 0; i < bar_width; ++i)
  {
    if (i < pos) std::cout << "=";
    else if (i == pos) std::cout << ">";
    else std::cout << " ";
  }
  std::cout << "] " << int(p) << " %\r";
  if (p == 100)
  {
    std::cout << std::endl;
  }
  std::cout.flush();
}

