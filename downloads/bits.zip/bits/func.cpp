#include "func.h"

#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;

double func(double x, void(*progress)(double))
{
  size_t n = size_t(x);
  vector<double> vec(n);

  int target_percent = 0;
  // init random seed
  srand(0);
  // populating vec 1 to 50 % work
  for (size_t i = 0; i < n; ++i)
  {
    vec[i] = rand() % 10 + 1; // random between 1 and 10
    if (progress != nullptr && target_percent * n <= i * 50)
    {
      int done_percent = int(i*(50.0 / n));
      target_percent = max(done_percent, target_percent) + 1;
      progress(done_percent);
    }
  }

  // calculating average 51 to 100% work
  double total = 0.0;
  target_percent = 0;
  for (size_t i = 0; i < n; ++i)
  {
    total += vec[i];
    if (progress != nullptr && target_percent * n <= i * 50)
    {
      int done_percent = int(i*(50.0 / n));
      target_percent = max(done_percent, target_percent) + 1;
      progress(done_percent + 50);
    }
  }
  if(progress != nullptr) progress(100);
  return total / n;
}

