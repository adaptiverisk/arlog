#ifndef _func_h_
#define _func_h_

// mean of random numbers
// reports progress through progress callback with argument from 0 to 1
double func(double x, void(*progress)(double));

#endif
