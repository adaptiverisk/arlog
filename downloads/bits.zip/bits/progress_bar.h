#ifndef progress_bar__
#define progress_bar__

void progress_bar(double p);

#endif // !progress_bar__
