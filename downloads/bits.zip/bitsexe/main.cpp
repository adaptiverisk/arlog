#include "json.hpp"
#include "func.h"
#include "progress_bar.h"

typedef nlohmann::basic_json<std::map, std::vector, std::string,
  bool, int, unsigned int> json;

#include <fstream>
#include <iostream>
#include <cstring>

using namespace std;

// arguments: names of input and output files
// input file should be valid json file and output file should not exist
// error code: 1 - bad arguments
int main(int argc, char *argv[])
{
  // check number of arguments
  if (argc < 3)
  {
    cout << "#Err: need input and output file names as arguments";
    return 1;
  }

  // read in json file
  json j;
  {
    ifstream infile(argv[1]);
    if (!infile.is_open()) return 2;
    infile >> j;
  }

  // open output file
  ofstream outfile(argv[2]);
  if (!outfile.is_open()) return 3;
  outfile << setw(2);

  json jout;

  // check which function to run
  if (j["function"] != "func")
  {
    jout["err"] = "invalid function name";
    outfile << jout << endl;
    return 1;
  }

  double result;
  string name; // to simplify building an error (especially when many args)
  try
  {
    auto n = j[name = "n"].get<double>();
    // check argument
    if (n < 0) throw domain_error("n should be positive");

    // now call our function
    result = func(n, &progress_bar);
  }
  catch (domain_error e)
  {
    jout["err"] = "[" + name + "]" + e.what();
    outfile << jout << endl;
    return 1;
  }

  jout["result"] = result;
  outfile << jout << endl;
  return 0;
}