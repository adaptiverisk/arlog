#include "func.h"
#include "progress_bar.h"

#include "catch.hpp"

TEST_CASE("func", "[func]")
{
  double res = func(1e9, &progress_bar);
  REQUIRE(res == Approx(1));
}