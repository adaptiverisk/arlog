import unittest
import xlwings as xw
import os
import time

# this test might fail to close Excel if it crashes


class Test_xll(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        try:
            cls.app = xw.App(visible=False)
            if not os.path.exists("tests.xlsx"):
                wb = cls.app.books.open("tests.csv")
                wb.save("tests.xlsx")
                wb.close()
            # cls.app.visible = True # for debugging
            head, tail = os.path.split(script_dir)
            xllpath = os.path.join(head, "x64\\Release\\arx.xll")
            cls.app.api.RegisterXLL(xllpath)
            cls.wb = cls.app.books.open("tests.csv")
            cls.app.api.CalculateFull()
            time.sleep(0.5)
            calced = False
            for i in range(100):
                if cls.wb.app.api.CalculationState == 0:
                    calced = True
                    break
                time.sleep(0.5)
                if not calced:
                    raise Exception("Excel did not calculate")
        except Exception as e:
            cls.tearDownClass()
            raise unittest.SkipTest("exception: " + str(e))

    @classmethod
    def tearDownClass(cls) -> None:
        cls.app.quit()

    def test_arx_testing(self):
        sheet = self.wb.sheets[0]
        v = sheet.range("B3").value
        # if this fails make sure that x64\Release xll is compiled
        self.assertEqual(sheet.range("B3").value, 6)