import unittest
import pandas as pd
import numpy as np
import arx as a
import datetime as dt
from numpy.testing import assert_array_equal
from pandas.testing import assert_frame_equal


class Test_testing(unittest.TestCase):
    def test_testing(self):
        res = a.testing(2)
        self.assertEqual(res, 6.0)


class Test_date(unittest.TestCase):
    def test_timestamp(self):
        res = a.t_dates(pd.Timestamp("2023-01-01"))
        self.assertEqual(res, 44928.0)

    def test_datetime(self):
        res = a.t_dates(dt.datetime(2023, 1, 1))
        self.assertEqual(res, 44928.0)

    def test_date(self):
        res = a.t_dates(dt.date(2023, 1, 1))
        self.assertEqual(res, 44928.0)


class Test_or_na_date(unittest.TestCase):
    def test_timestamp(self):
        res = a.t_or_na_date(pd.Timestamp("2023-01-01"))
        self.assertEqual(res, 44928.0)

    def test_datetime(self):
        res = a.t_or_na_date("bad")
        self.assertEqual(res, -1)


class Test_or_na_string(unittest.TestCase):
    def test_1(self):
        res = a.t_or_na_string("blah", snone="")
        self.assertEqual(res, "blah : blue : ")

    def test_2(self):
        res = a.t_or_na_string("blah", "yes", "2")
        self.assertEqual(res, "blah : yes : 2")

    def test_3(self):
        res = a.t_or_na_string("blah", "yes")
        self.assertEqual(res, -2)


class Test_or_vec_date(unittest.TestCase):
    def test_1(self):
        res = a.t_or_vec_date(pd.Timestamp("2023-01-01"))
        self.assertEqual(res, 44927.0)

    def test_2(self):
        res = a.t_or_vec_date("bad")
        self.assertEqual(res, -2)

    def test_3(self):
        x = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        res = a.t_or_vec_date(x)
        self.assertEqual(res, -1)
        # self.assertEqual(0, -1)

    def test_4(self):
        res = a.t_or_vec_date(dt.datetime(2023, 1, 1))
        self.assertEqual(res, 44927.0)

    def test_5(self):
        dates = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        res = a.t_or_vec_date(dates, pd.Timestamp("2023-03-01"))
        assert_array_equal(res, [[44927.0], [44958.0], [44986.0]])


class Test_or_vec_int(unittest.TestCase):
    def test_1(self):
        res = a.t_or_vec_int(2)
        assert_array_equal(res, [[2], [5]])

    def test_2(self):
        res = a.t_or_vec_int(np.array("bad"))
        self.assertEqual(res, -2)

    def test_3(self):
        res = a.t_or_vec_int(np.array([1, 2]))
        assert_array_equal(res, [[1], [2], [5]])

    def test_4(self):
        res = a.t_or_vec_int(1, 2)
        assert_array_equal(res, [[1], [2]])

    def test_5(self):
        res = a.t_or_vec_int(np.array([1, 2]), 3)
        assert_array_equal(res, [[1], [2], [3]])


class Test_vec_date(unittest.TestCase):
    def test_1(self):
        res = a.t_vec_date(pd.Timestamp("2023-01-01"))
        self.assertEqual(res, 44927.0)

    def test_2(self):
        res = a.t_vec_date("bad")
        self.assertEqual(res, -2)

    def test_3(self):
        x = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        res = a.t_vec_date(x)
        assert_array_equal(res, -1)

    def test_4(self):
        res = a.t_vec_date(dt.datetime(2023, 1, 1))
        self.assertEqual(res, 44927.0)

    def test_5(self):
        dates = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        res = a.t_vec_date(dates, pd.Timestamp("2023-03-01"))
        assert_array_equal(res, [[44927.0], [44958.0], [44986.0]])


class Test_vec_int(unittest.TestCase):
    def test_1(self):
        res = a.t_vec_int(2)
        assert_array_equal(res, [[2], [5]])

    def test_2(self):
        res = a.t_vec_int(np.array("bad"))
        self.assertEqual(res, -2)

    def test_3(self):
        res = a.t_vec_int(np.array([1, 2]))
        assert_array_equal(res, [[1], [2], [5]])

    def test_4(self):
        res = a.t_vec_int(1, 2)
        assert_array_equal(res, [[1], [2]])

    def test_5(self):
        res = a.t_vec_int(np.array([1, 2]), 3)
        assert_array_equal(res, [[1], [2], [3]])


class Test_mat_rows(unittest.TestCase):
    def test_scalar(self):
        res = a.t_mat_rows(2)
        self.assertEqual(res, 1)

    def test_np_pd(self):
        dates = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        df = pd.DataFrame(
            {"A": [1, 2, np.nan], "B": [5, np.nan, np.nan], "C": [1, 2, 3]}
        )
        res = a.t_mat_rows(dates, df)
        self.assertEqual(res, 6)


class Test_mat_rows1(unittest.TestCase):
    def test_1(self):
        df = pd.DataFrame(
            {"A": [1, 2, np.nan], "B": [5, np.nan, np.nan], "C": [1, 2, 3]}
        )
        res = a.t_mat_rows1(df)
        self.assertEqual(res, 2)


class Test_mat_cols(unittest.TestCase):
    def test_scalar(self):
        res = a.t_mat_cols(2)
        self.assertEqual(res, 1)

    def test_np_pd(self):
        dates = np.array(["2023-01-01", "2023-02-01"], dtype="datetime64")
        df = pd.DataFrame(
            {"A": [1, 2, np.nan], "B": [5, np.nan, np.nan], "C": [1, 2, 3]}
        )
        res = a.t_mat_cols(dates, df)
        self.assertEqual(res, 8)


class Test_df(unittest.TestCase):
    def test_df(self):
        df = pd.DataFrame(
            {
                "A": [1, 2, np.nan],
                "B": ["a", "b", "c"],
                "C": [True, True, False],
            }
        )
        res = a.t_df(df)
        assert_frame_equal(
            res,
            pd.DataFrame(
                {
                    "dtype": ["num", "str", "bool"],
                    "irow": [0, 1, 2],
                    "es": [40000.0, 40001.0, 40002.0],
                },
                [
                    pd.Timestamp("2009-07-06"),
                    pd.Timestamp("2009-07-07"),
                    pd.Timestamp("2009-07-08"),
                ],
            ),
        )