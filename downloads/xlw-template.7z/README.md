# Rename
To set name of your project run:
>rename.bat new_name

# Initialize git
> git init

# Python
- To build arx-py and run tests in arx-tests-py and arx-tests-integr setup a 
  conda environment - say xlw: conda create -n xlw python=3.12
- Add the following packages (pip install pkg-name): numpy, pandas, xlwings
- Activate the conda environment (in cmd: conda activate xlw)
- Run in cmd: where python - first line shows path to this environment
- Adjust arx-py\python-env.props to reflect that path (CONDA_PREFIX variable)
- Make sure same environment is selected when running arx-tests-integr: 

# First build
Run build as follows (select Release, x64 - should be same bitness as python in 
xlw environment and Excel)
- arx
- arx-tests (and run - should pass all tests)
- arx-py
- arx-tests-integr (and run - should pass all tests)

# Base (xll) project (arx)
- Two files processed by InterfaceGenerator:
    - info.h - creates arx__help function that returns version and last 
      compilation time
    - arx.h - all other interface functions. Note - don't include this file in
      cpp files to reduce compilation time - any change will require 
      recompilation of all cpp files. Instead just define functions in arx.h 
      and implement them in any cpp file.
- To debug, select Debug and hit F5. Excel will start and you can use the 
  funcitons in the xll. Set breakpoints in the code and they will be hit.
- At the start there are two cpp files, but you can add any number of them
  to split the code into smaller parts.
- The InterfaceGenerator creates xlwarx.cpp and xlwinfo.cpp
- Release xll uses static linking, so to distribute just copy to the user - no
  need to install anything else or deal with dlls.
- Debug xll uses dynamic linking to reduce size and speed up compilation.

# Unit tests (arx-tests)
- We use cpp doctest for unit testing. Tests are defined within the code's
  cpp files themselves. This keeps the tests close to the code and makes it
  possible to test private functions.
- The defined tests are ignored in xll builds.
- To run tests, select arx-tests as startup project and hit F5.
- To run specific test add command argument in Debugging project property, 
  e.g.: -tc "arx_testing"
- If you add new cpp file to arx project, you need to CTRL+drag it to arx-tests
  project as well.

# Python module project (arx-py)

# Integration tests driven by python (arx-tests-integr)