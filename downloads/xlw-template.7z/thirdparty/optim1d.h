#pragma once

#include <utility> // swap
#include <cmath> // HUGE_VAL
#include <cfloat> // DBL_EPSILON
#include <algorithm> // max

#define GOLDEN    1.61803398874989484820458683437
#define CGOLDEN (2 - GOLDEN)
#define MAXNUM HUGE_VAL
#define MACHEP DBL_EPSILON

/* --------- internal functions ------------ */
template<class F> // double -> double
double eval_funcT(F &f, double x, double lb, double ub, int *eval_num)
{
	if (x > ub || x < lb)
	{
		return HUGE_VAL;
	}
	++(*eval_num);
	return f(x);
}

/*
' Given two points (a, b) this function finds a triplet (a, b, c)
' such that:
'
' 1) a < b < c
' 2) a, b, c are within the golden ratio
' 3) f(b) < f(a) and f(b) < f(c).
'
' The corresponding function values are returned in fa, fb, fc
*/
template<class F>
int min_brack_constrT(F &f,
	double *a, double *b, double *c,
	double *fa, double *fb, double *fc,
	int *eval_num, int max_eval, double lb, double ub)
{
	if (*a > *b) std::swap(*a, *b);

	*fa = eval_funcT(f, *a, lb, ub, eval_num);
	*fb = eval_funcT(f, *b, lb, ub, eval_num);

	if (*fb > *fa)
	{
		std::swap(*a, *b);
		std::swap(*fa, *fb);
	}

	*c = *b + GOLDEN * (*b - *a);
	*fc = eval_funcT(f, *c, lb, ub, eval_num);

	while (*fc < *fb && *eval_num < max_eval)
	{
		*a = *b;
		*b = *c;
		*fa = *fb;
		*fb = *fc;
		*c = *b + GOLDEN * (*b - *a);
		*fc = eval_funcT(f, *c, lb, ub, eval_num);
	}

	if (*a > *c)
	{
		std::swap(a, c);
		std::swap(fa, fc);
	}

	if (*a >= *b || *b >= *c
		|| *fb >= *fa || *fb >= *fc)
	{
		return -1; /* failed to bracket with max_eval */
	}
	else
	{
		return 0; /* bracketed */
	}
}

/* --------- end: internal functions ------------ */

/*!
\brief minimize f(x) subject to constraint lb <= x <= ub

\param f function to minimize
\param x_accuracy accuracy goal for solution
\param a first initial point
\param b second initial point
\param lb lower bound of domain
\param ub upper bound of domain
\param eval_num [out] contains actual number of function evaluation on return
\param max_eval maximal number of function evaluations
\param xmin [out] location of minimum
\param ymin [out] value at minimum

\return 0 if converged, -1 otherwise

*/
template<class F>
int gold_search_constrT(F &f, double x_accuracy, double a, double b,
	double lb, double ub, int *eval_num, int max_eval,
	double *xmin, double *ymin)
{
	const double tol = std::max(x_accuracy, sqrt(DBL_EPSILON));
	double aa = a, bb = b, c, fa, fb, fc, x0, x1, x2, x3, f1, f2;
	*eval_num = 0;

	if (min_brack_constrT(f, &aa, &bb, &c, &fa, &fb, &fc, eval_num,
		max_eval - 2, lb, ub) != 0)
	{
		return -1;
	}

	x0 = aa;
	x3 = c;
	if ((c - bb) > (bb - aa))
	{
		x1 = bb;
		x2 = bb + CGOLDEN * (c - bb);
		f1 = fb;
		f2 = eval_funcT(f, x2, lb, ub, eval_num);
	}
	else
	{
		x1 = bb - CGOLDEN * (bb - aa);
		x2 = bb;
		f1 = eval_funcT(f, x1, lb, ub, eval_num);
		f2 = fb;
	}

	while (*eval_num <= max_eval &&
		fabs(x3 - x0) > tol*std::max(1., fabs(x1) + fabs(x2)))
	{
		if (f2 < f1)
		{
			x0 = x1;
			x1 = x2;
			f1 = f2;
			x2 = x1 + CGOLDEN * (x3 - x1);
			f2 = eval_funcT(f, x2, lb, ub, eval_num);
		}
		else
		{
			x3 = x2;
			x2 = x1;
			f2 = f1;
			x1 = x2 - CGOLDEN * (x2 - x0);
			f1 = eval_funcT(f, x1, lb, ub, eval_num);
		}
	}

	if (f1 < f2)
	{
		*xmin = x1;
		*ymin = f1;
	}
	else
	{
		*xmin = x2;
		*ymin = f2;
	}

	if (*eval_num >= max_eval)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}

