put the following right after 
#ifndef DOCTEST_LIBRARY_INCLUDED
#define DOCTEST_LIBRARY_INCLUDED

#include <vector>
#include <ostream>
#include <type_traits>

template <typename T>
inline std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec) {
    os << "{";
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        os << " " << *it;
        if (it + 1 != vec.end()) {
            os << ",";
        }
    }
    os << " }";
    return os;
}

template <>
inline std::ostream& operator<<(std::ostream& os, const std::vector<std::string>& vec) {
    os << "{";
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        os << " \"" << *it << "\"";
        if (it + 1 != vec.end()) {
            os << ",";
        }
    }
    os << " }";
    return os;
}

template <>
inline std::ostream& operator<<(std::ostream& os, const std::vector<char>& vec) {
    os << "{";
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        os << " '" << *it << "'";
        if (it + 1 != vec.end()) {
            os << ",";
        }
    }
    os << " }";
    return os;
}