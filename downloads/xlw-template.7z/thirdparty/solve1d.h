#pragma once

#include <algorithm>

/**
\brief  Bracket solution. if bounds = true, xMin and xMax contain
bounds of interval where to search. F should implement
operator()
*/
template <class F> void bracket_solution(F& f,
  const double x,
  const double step,
  const double accuracy,
  double& xmin,
  double& xmax,
  bool bounds = false)
{
  const double epsilon = 1.e-8;
  const double growth_factor = 1.6;
  const int max_evals = 100;

  int flipflop = -1;
  int evaluation_num = 0;
  double xxmin = xmin, xxmax = xmax;
  double fxmin, fxmax = f(x);

  if (fxmax > 0.0)
  {
    xmin = x - step;
    if (bounds) xmin = std::max(xmin, xxmin);
    fxmin = f(xmin);
    xmax = x;
    if (bounds) xmax = std::min(xmax, xxmax);
  }
  else
  {
    xmin = x;
    if (bounds) xmin = std::max(xmin, xxmin);
    fxmin = fxmax;
    xmax = x + step;
    if (bounds) xmax = std::min(xmax, xxmax);
    fxmax = f(xmax);
  }

  evaluation_num = 2;
  while (evaluation_num <= max_evals)
  {
    if (fxmin * fxmax <= 0.0)
    {
      return;
    }
    const double xacc1 = 2.0 * epsilon * fabs(xmin) + 0.5 * accuracy;
    const double xmid = 0.5 * (xmax - xmin);
    if (fabs(xmid) <= xacc1 || fxmin == 0.0)
    {
      return;
    }

    if (fabs(fxmin) < fabs(fxmax))
    {
      xmin = xmin + growth_factor * (xmin - xmax);
      if (bounds) xmin = std::max(xmin, xxmin);
      fxmin = f(xmin);
    }
    else if (fabs(fxmin) > fabs(fxmax))
    {
      xmax = xmax + growth_factor * (xmax - xmin);
      if (bounds) xmax = std::min(xmax, xxmax);
      fxmax = f(xmax);
    }
    else if (flipflop == -1)
    {
      xmin = xmin + growth_factor * (xmin - xmax);
      if (bounds) xmin = std::max(xmin, xxmin);
      fxmin = f(xmin);
      ++evaluation_num;
      flipflop = 1;
    }
    else if (flipflop == 1)
    {
      xmax = xmax + growth_factor * (xmax - xmin);
      if (bounds) xmax = std::min(xmax, xxmax);
      fxmax = f(xmax);
      flipflop = -1;
    }
    ++evaluation_num;
  }

  return;
}


/**
\brief  Solve newton safe. F should implement operator() and derivative()
*/
template <class F> double solve_newton_safe(F& f,
  double xaccuracy,
  double xmin,
  double xmax,
  double x0)
{
  const double fxmin = f(xmin);
  const double fxmax = f(xmax);

  if (fxmin * fxmax > 0)
  {
    return -1.e50;
  }

  const int max_evals = 100;

  double root = x0;
  int evaluation_num = 0;

  double froot, dfroot, dx, dxold;
  double xh, xl;

  // Orient the search so that f(xl) < 0
  if (fxmin < 0.0)
  {
    xl = xmin;
    xh = xmax;
  }
  else
  {
    xh = xmin;
    xl = xmax;
  }

  // the "step size before last"
  dxold = xmax - xmin;
  // it was dxold=std::fabs(xMax_-xMin_); in Numerical Recipes
  // here (xMax_-xMin_ > 0) is verified in the constructor

  // and the last step
  dx = dxold;

  froot = f(root);
  dfroot = f.derivative(root);
  ++evaluation_num;

  while (evaluation_num <= max_evals)
  {
    // Bisect if (out of range || not decreasing fast enough)
    if ((((root - xh) * dfroot - froot) * ((root - xl) * dfroot - froot) > 0.0)
      || (fabs(2.0 * froot) > fabs(dxold * dfroot)))
    {

      dxold = dx;
      dx = 0.5 * (xh - xl);
      root = xl + dx;
    }
    else
    {
      dxold = dx;
      dx = froot / dfroot;
      root -= dx;
    }
    // Convergence criterion
    if (fabs(dx) < xaccuracy)
    {
      return root;
    }
    froot = f(root);
    dfroot = f.derivative(root);
    ++evaluation_num;
    if (froot < 0.0)
    {
      xl = root;
    }
    else
    {
      xh = root;
    }
  }
  return -1.e50;
}

// operator(x,&df) returns also a derivative as second argument, also need
// operator(x) which returns function value
template <class F> double solve_newton_safe1(F& f,
  double xaccuracy,
  double xmin,
  double xmax,
  double x0)
{
  const double fxmin = f(xmin);
  const double fxmax = f(xmax);

  if (fxmin * fxmax > 0)
  {
    return -1.e50;
  }

  const int max_evals = 100;

  double root = x0;
  int evaluation_num = 0;

  double froot, dfroot, dx, dxold;
  double xh, xl;

  // Orient the search so that f(xl) < 0
  if (fxmin < 0.0)
  {
    xl = xmin;
    xh = xmax;
  }
  else
  {
    xh = xmin;
    xl = xmax;
  }

  // the "step size before last"
  dxold = xmax - xmin;
  // it was dxold=std::fabs(xMax_-xMin_); in Numerical Recipes
  // here (xMax_-xMin_ > 0) is verified in the constructor

  // and the last step
  dx = dxold;

  froot = f(root, dfroot);
  ++evaluation_num;

  while (evaluation_num <= max_evals)
  {
    // Bisect if (out of range || not decreasing fast enough)
    if ((((root - xh) * dfroot - froot) * ((root - xl) * dfroot - froot) > 0.0)
      || (fabs(2.0 * froot) > fabs(dxold * dfroot)))
    {
      dxold = dx;
      dx = 0.5 * (xh - xl);
      root = xl + dx;
    }
    else
    {
      dxold = dx;
      dx = froot / dfroot;
      root -= dx;
    }
    // Convergence criterion
    if (fabs(dx) < xaccuracy)
    {
      return root;
    }
    froot = f(root, dfroot);
    evaluation_num++;
    if (froot < 0.0)
    {
      xl = root;
    }
    else
    {
      xh = root;
    }
  }
  return -1.e50;
}


/**
\brief  Solve brent. The implementation of the algorithm was inspired by
Press, Teukolsky, Vetterling, and Flannery, "Numerical Recipes in C",
2nd edition, Cambridge University Press.
*/
template <class F> double solve_brent(F& f,
  double xaccuracy,
  double xmin,
  double xmax,
  double x0)
{
  const double epsilon = 1.e-8;
  double fxmin = f(xmin);
  double fxmax = f(xmax);

  double xacc1 = 2.0 * epsilon * fabs(xmin) + 0.5 * xaccuracy;
  double xmid = 0.5 * (xmax - xmin);
  if (fabs(xmid) <= xacc1 || fxmin == 0.0)
  {
    return xmin;
  }
  if (fxmin * fxmax > 0)
  {
    return -1.e50;
  }

  const int max_evals = 100;

  int evaluation_num = 0;
  double root = x0;

  double min1, min2;
  double froot, p, q, r, s;
  // dummy assignments to avoid compiler warning
  double d = 0.0, e = 0.0;

  root = xmax;
  froot = fxmax;
  while (evaluation_num <= max_evals)
  {
    if ((froot > 0.0 && fxmax > 0.0) ||
      (froot < 0.0 && fxmax < 0.0))
    {
      xmax = xmin;
      fxmax = fxmin;
      e = d = root - xmin;
    }
    if (fabs(fxmax) < fabs(froot))
    {
      xmin = root;
      root = xmax;
      xmax = xmin;
      fxmin = froot;
      froot = fxmax;
      fxmax = fxmin;
    }
    // Convergence check
    xacc1 = 2.0 * epsilon * fabs(root) + 0.5 * xaccuracy;
    xmid = 0.5 * (xmax - root);
    if (fabs(xmid) <= xacc1 || froot == 0.0)
    {
      return root;
    }
    if (fabs(e) >= xacc1 &&
      fabs(fxmin) > fabs(froot))
    {

      // Attempt inverse quadratic interpolation
      s = froot / fxmin;
      if (xmin == xmax)
      {
        p = 2.0 * xmid * s;
        q = 1.0 - s;
      }
      else
      {
        q = fxmin / fxmax;
        r = froot / fxmax;
        p = s * (2.0 * xmid * q * (q - r) - (root - xmin) * (r - 1.0));
        q = (q - 1.0) * (r - 1.0) * (s - 1.0);
      }
      if (p > 0.0)
      {
        q = -q;  // Check whether in bounds
      }
      p = fabs(p);
      min1 = 3.0 * xmid * q - fabs(xacc1 * q);
      min2 = fabs(e * q);
      if (2.0 * p < (min1 < min2 ? min1 : min2))
      {
        e = d;                // Accept interpolation
        d = p / q;
      }
      else
      {
        d = xmid;  // Interpolation failed, use bisection
        e = d;
      }
    }
    else
    {
      // Bounds decreasing too slowly, use bisection
      d = xmid;
      e = d;
    }
    xmin = root;
    fxmin = froot;
    if (fabs(d) > xacc1)
    {
      root += d;
    }
    else
    {
      root += (xmid >= 0 ? fabs(xacc1) : -fabs(xacc1));
    }
    froot = f(root);
    ++evaluation_num;
  }
  return root;
}
