#include<xlw/DataFrame.h> 
#define l78 using
#define l70 namespace
#define ln xlw
#define l86 std
#define lx static
#define lr inline
#define lg df_type
#define le const
#define lv XlfOper
#define lj if
#define l46 is
#define l2 double
#define lc return
#define l24 t_num
#define l18 string
#define l23 t_str
#define lu bool
#define l34 t_bool
#define l11 t_unknown
#define lq template
#define l19 typename
#define l82 struct
#define lb int
#define l53 rows
#define l9 cols
#define lt for
#define l20 auto
#define l94 floor
#define l75 fabs
#define l71 to_string
#define l6 void
#define ld Series
#define lz type_
#define l35 num_
#define l36 clear
#define l28 str_
#define l37 bol_
#define l32 missing
#define l0 v
#define l72 continue
#define l51 SetError
#define l55 xlerrNA
#define l39 else
#define l59 resize
#define l88 try
#define l91 as
#define l87 catch
#define l69 insert
#define l61 true
#define l1 len
#define l92 min
#define l58 switch
#define l3 case
#define l38 break
#define l52 default
#define l81 max
#define l89 size_t
#define l54 size
#define lw vector
#define l21 this
#define l74 empty
#define l41 throw
#define l56 DataFrame
#define l65 runtime_error
#define l22 columns
#define l64 false
#define l40 index
#define l43 data
#define l67 emplace_back
#define l84 to_xl
#define l25 ToXlMode
#define l66 Data
#define l93 DataIndex
#define l90 DataColumns
#define l80 All
#define l83 idx_name
l78 l70 ln;l78 l70 l86;lx lr lg l73(le lv&lh){lj(lh.l46<l2>())lc lg::
l24;lj(lh.l46<l18>())lc lg::l23;lj(lh.l46<lu>())lc lg::l34;lc lg::l11
;}lq<l19 lo>lr lg l30(){lc lg::l11;}lq<>lr lg l30<l2>(){lc lg::l24;}
lq<>lr lg l30<l18>(){lc lg::l23;}lq<>lr lg l30<lu>(){lc lg::l34;}l82
l31{lb l17;lb l8;lb l15;lb l5;};lx lr l31 l47(le lv&lp,lb lf,lb ll,lu
l63){lj(l63)lc{ll,lp.l53()-ll,lf,lf>=lp.l9()?0:1};lc{lf,lf>=lp.l53()?
0:1,ll,lp.l9()-ll};}lx lr lg l79(le lv&lp,le l31&li){lt(lb l12=li.l17
;l12<li.l17+li.l8;++l12)lt(lb l13=li.l15;l13<li.l15+li.l5;++l13){l20
l50=l73(lp(l12,l13));lj(l50!=lg::l11)lc l50;}lc lg::l11;}lx lr l18 l85
(l2 lh){lj(l94(l75(lh))==l75(lh))lc l71((lb)lh);lc l71(lh);}lx lr l6
l33(ld&la){la.lz=lg::l11;la.l35.l36();la.l28.l36();la.l37.l36();la.
l32.l36();}lq<l19 lo>l6 ly(ld&la){l33(la);la.lz=l30<lo>();}lq<l19 lo>
l6 l45(le ld&la,lv&lh,le l31&lm,lb lk){lb l14=0;le l20&l68=la.l0<lo>(
);lt(lb lf=lm.l17;lf<lm.l17+lm.l8;++lf)lt(lb ls=lm.l15;ls<lm.l15+lm.
l5;++ls){lj(l14>=lk)lc;lh(lf,ls)=l68[l14];++l14;}lj(lm.l8==1){lt(l20
lf:la.l32){lj(lf>=lk)l72;lh(lm.l17,lm.l15+lf).l51(l55);}}l39{lt(l20 lf
:la.l32){lj(lf>=lk)l72;lh(lm.l17+lf,lm.l15).l51(l55);}}lc;}lq<l19 lo>
l6 l44(ld&la,le lv&lp,le l31&li){ly<lo>(la);l20&l57=la.l0<lo>();l57.
l59(li.l8*li.l5);lb l14=0;lt(lb l12=0;l12<li.l8;++l12)lt(lb l13=0;l13
<li.l5;++l13){l88{l57[l14]=lp(li.l17+l12,li.l15+l13).l91<lo>();}l87(
...){la.l32.l69(l14);}++l14;}}lx lr lb l27(le ld&la,lv&lh,lb lf,lb ll
=1,lu l7=l61){lj(la.lz==lg::l11)lc 0;l20 lm=l47(lh,lf,ll,l7);lb l62=
la.l1();lb lk=l92(lm.l5*lm.l8,l62);l58(la.lz){l3 lg::l24:l45<l2>(la,
lh,lm,lk);l38;l3 lg::l23:l45<l18>(la,lh,lm,lk);l38;l3 lg::l34:l45<lu>
(la,lh,lm,lk);l38;l52:l38;}lc l81(l62-lk,0);}lx lr lv l27(le ld&la,lu
l7=l61){lv l49(l7?la.l1():1,l7?1:la.l1());l27(la,l49,0,0,l7);lc l49;}
lx lr l6 l77(ld&la){lt(lb lf=0;lf<la.l1();++lf)la.l32.l69(lf);}lx lr
l89 l48(le ld&la){l58(la.lz){l3 lg::l24:lc la.l35.l54();l3 lg::l23:lc
la.l28.l54();l3 lg::l34:lc la.l37.l54();l52:lc 0;}}lx l6 ly(ld&la,le
lv&lp,lb lf,lb ll=1,lu l7=l61,lb lk=-1){lj(lk==0||lp.l46<l6>()){l33(
la);lc;}l20 li=l47(lp,lf,ll,l7);lj(lk>0){lj(li.l5!=1){lj(li.l5>lk)li.
l5=lk;}l39{lj(li.l8>lk)li.l8=lk;}}la.lz=l79(lp,li);l58(la.lz){l3 lg::
l24:l44<l2>(la,lp,li);lc;l3 lg::l23:l44<l18>(la,lp,li);lc;l3 lg::l34:
l44<lu>(la,lp,li);lc;l3 lg::l11:la.lz=lg::l23;la.l28.l36();la.l28.l59
(li.l8*li.l5,"");l77(la);lc;l52:l33(la);lc;}}lx lr l6 ly(ld&la,lb lk,
l2 lh=0.0){l33(la);la.lz=lg::l24;la.l35.l59(lk,lh);}lq<l19 lo>l6 ly(
ld&la,le lw<lo>&l16){la.lz=l30<lo>();la.l0<lo>()=l16;}lx lr l6 ly(ld&
la,le ld&l76){la=l76;}ln::ld::ld(le lv&lh,lb lf,lb ll,lu l7,lb lk){ly
( *l21,lh,lf,ll,l7,lk);}ln::ld::ld(lb lk,l2 lh){ly( *l21,lk,lh);}ln::
ld::ld(le lw<l2>&l16){ly( *l21,l16);}ln::ld::ld(le lw<l18>&l16){ly( *
l21,l16);}ln::ld::ld(le lw<lu>&l16){ly( *l21,l16);}lu ln::ld::l74()le
{lc lz==lg::l11||l48( *l21)==0;}lb ln::ld::l1()le{lc(lb)l48( *l21);}
lq<l19 lo>le lw<lo>&ln::ld::l0()le{l41("\x23\x20\x62\x61\x64\x20\x74"
"\x79\x70\x65");}lq<>le lw<l2>&ln::ld::l0()le{lc l35;}lq<>le lw<l18>&
ln::ld::l0()le{lc l28;}lq<>le lw<lu>&ln::ld::l0()le{lc l37;}lq<l19 lo
>lw<lo>&ln::ld::l0(){l41("\x23\x20\x62\x61\x64\x20\x74\x79\x70\x65");
}lq<>lw<l2>&ln::ld::l0(){lc l35;}lq<>lw<l18>&ln::ld::l0(){lc l28;}lq<
>lw<lu>&ln::ld::l0(){lc l37;}ln::l56::l56(le lv&lh,le ld*l9,le ld*l26
){lb l4=l9?0:1;lb ll=l26?0:1;lj(l9&&l9->l1()!=lh.l9()-ll)l41 l65(""
"\x63\x6f\x6c\x75\x6d\x6e\x73\x20\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f"
"\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68\x20\x64\x61\x74\x61"
);lj(l26&&l26->l1()!=lh.l53()-l4)l41 l65("\x69\x6e\x64\x65\x78\x20"
"\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d"
"\x61\x74\x63\x68\x20\x64\x61\x74\x61");lj(l9)l22= *l9;l39 l22=ld(lh,
0,ll,l64);lj(l26)l40= *l26;l39 l40=ld(lh,0,l4);lj(l22.l1()==0)lc;l43.
l67(lh,ll,l4);lt(lb lf=1;lf<l22.l1();++lf)l43.l67(lh,lf+ll,l4);}lv ln
::l56::l84(l25 l29)le{lb l60=l40.l1();lb l42=l22.l1();lb l4=l29==l25
::l66||l29==l25::l93?0:1;lb ll=l29==l25::l66||l29==l25::l90?0:1;lv l10
(l60+l4,l42+ll);lj(l29==l25::l80)l10(0,0)=l83;lj(l4==1)l27(l22,l10,0,
1,l64);lj(ll==1)l27(l40,l10,0);lj(l43.l74()){lt(lb lf=0;lf<l60;++lf)lt
(lb ls=0;ls<l42;++ls)l10(lf+l4,ls+ll).l51(l55);lc l10;}lt(lb ls=0;ls<
l42;++ls)l27(l43[ls],l10,ls+ll,l4);lc l10;}
