#include<xlw/DataFrame.h>
#define l77 using
#define l69 namespace
#define l94 xlw
#define l85 std
#define lw static
#define lq inline
#define lg df_type
#define le const
#define ls XlfOper
#define lj if
#define l45 is
#define l1 double
#define lc return
#define l23 t_num
#define l17 string
#define l22 t_str
#define lu bool
#define l30 t_bool
#define l9 t_unknown
#define lp template
#define l18 typename
#define l81 struct
#define lb int
#define l52 rows
#define l8 cols
#define lt for
#define l19 auto
#define l86 floor
#define l74 fabs
#define l70 to_string
#define l6 void
#define ld Series
#define l0 type_
#define l34 num_
#define l35 clear
#define l27 str_
#define l36 bol_
#define l32 missing
#define ly v
#define l71 continue
#define l50 SetError
#define l53 xlerrNA
#define l38 else
#define l58 resize
#define l88 try
#define l91 as
#define l87 catch
#define l68 insert
#define l60 true
#define lz len
#define l92 min
#define l57 switch
#define l2 case
#define l37 break
#define l51 default
#define l80 max
#define l89 size_t
#define l54 size
#define lv vector
#define l20 this
#define l73 empty
#define l40 throw
#define l55 DataFrame
#define l64 runtime_error
#define l21 columns
#define l63 false
#define l39 index
#define l42 data
#define l66 emplace_back
#define l84 to_xl
#define l24 ToXlMode
#define l65 Data
#define l93 DataIndex
#define l90 DataColumns
#define l79 All
#define l83 idx_name
l77 l69 l94;l77 l69 l85;lw lq lg l72(le ls&lh){lj(lh.l45<l1>())lc lg
::l23;lj(lh.l45<l17>())lc lg::l22;lj(lh.l45<lu>())lc lg::l30;lc lg::
l9;}lp<l18 ln>lq lg l29(){lc lg::l9;}lp<>lq lg l29<l1>(){lc lg::l23;}
lp<>lq lg l29<l17>(){lc lg::l22;}lp<>lq lg l29<lu>(){lc lg::l30;}l81
l31{lb l16;lb l7;lb l13;lb l4;};lw lq l31 l46(le ls&lo,lb lf,lb ll,lu
l62){lj(l62)lc{ll,lo.l52()-ll,lf,lf>=lo.l8()?0:1};lc{lf,lf>=lo.l52()?
0:1,ll,lo.l8()-ll};}lw lq lg l78(le ls&lo,le l31&li){lt(lb l15=li.l16
;l15<li.l16+li.l7;++l15)lt(lb l10=li.l13;l10<li.l13+li.l4;++l10){l19
l49=l72(lo(l15,l10));lj(l49!=lg::l9)lc l49;}lc lg::l9;}lw lq l17 l82(
l1 lh){lj(l86(l74(lh))==l74(lh))lc l70((lb)lh);lc l70(lh);}lw lq l6
l33(ld&la){la.l0=lg::l9;la.l34.l35();la.l27.l35();la.l36.l35();la.l32
.l35();}lp<l18 ln>l6 lx(ld&la){l33(la);la.l0=l29<ln>();}lp<l18 ln>l6
l44(le ld&la,ls&lh,le l31&lm,lb lk){lb l11=0;le l19&l67=la.ly<ln>();
lt(lb lf=lm.l16;lf<lm.l16+lm.l7;++lf)lt(lb lr=lm.l13;lr<lm.l13+lm.l4;
++lr){lj(l11>=lk)lc;lh(lf,lr)=l67[l11];++l11;}lj(lm.l7==1){lt(l19 lf:
la.l32){lj(lf>=lk)l71;lh(lm.l16,lm.l13+lf).l50(l53);}}l38{lt(l19 lf:
la.l32){lj(lf>=lk)l71;lh(lm.l16+lf,lm.l13).l50(l53);}}lc;}lp<l18 ln>
l6 l43(ld&la,le ls&lo,le l31&li){lx<ln>(la);l19&l56=la.ly<ln>();l56.
l58(li.l7*li.l4);lb l11=0;lt(lb l15=0;l15<li.l7;++l15)lt(lb l10=0;l10
<li.l4;++l10){l88{l56[l11]=lo(li.l16+l15,li.l13+l10).l91<ln>();}l87(
...){la.l32.l68(l11);}++l11;}}lw lq lb l26(le ld&la,ls&lh,lb lf,lb ll
=1,lu l3=l60){lj(la.l0==lg::l9)lc 0;l19 lm=l46(lh,lf,ll,l3);lb l61=la
.lz();lb lk=l92(lm.l4*lm.l7,l61);l57(la.l0){l2 lg::l23:l44<l1>(la,lh,
lm,lk);l37;l2 lg::l22:l44<l17>(la,lh,lm,lk);l37;l2 lg::l30:l44<lu>(la
,lh,lm,lk);l37;l51:l37;}lc l80(l61-lk,0);}lw lq ls l26(le ld&la,lu l3
=l60){ls l48(l3?la.lz():1,l3?1:la.lz());l26(la,l48,0,0,l3);lc l48;}lw
lq l6 l76(ld&la){lt(lb lf=0;lf<la.lz();++lf)la.l32.l68(lf);}lw lq l89
l47(le ld&la){l57(la.l0){l2 lg::l23:lc la.l34.l54();l2 lg::l22:lc la.
l27.l54();l2 lg::l30:lc la.l36.l54();l51:lc 0;}}lw l6 lx(ld&la,le ls&
lo,lb lf,lb ll=1,lu l3=l60,lb lk=-1){lj(lk==0||lo.l45<l6>()){l33(la);
lc;}l19 li=l46(lo,lf,ll,l3);lj(lk>0){lj(li.l4!=1){lj(li.l4>lk)li.l4=
lk;}l38{lj(li.l7>lk)li.l7=lk;}}la.l0=l78(lo,li);l57(la.l0){l2 lg::l23
:l43<l1>(la,lo,li);lc;l2 lg::l22:l43<l17>(la,lo,li);lc;l2 lg::l30:l43
<lu>(la,lo,li);lc;l2 lg::l9:la.l0=lg::l22;la.l27.l35();la.l27.l58(li.
l7*li.l4,"");l76(la);lc;l51:l33(la);lc;}}lw lq l6 lx(ld&la,lb lk,l1 lh
=0.0){l33(la);la.l0=lg::l23;la.l34.l58(lk,lh);}lp<l18 ln>l6 lx(ld&la,
le lv<ln>&l14){la.l0=l29<ln>();la.ly<ln>()=l14;}lw lq l6 lx(ld&la,le
ld&l75){la=l75;}ld::ld(le ls&lh,lb lf,lb ll,lu l3,lb lk){lx( *l20,lh,
lf,ll,l3,lk);}ld::ld(lb lk,l1 lh){lx( *l20,lk,lh);}ld::ld(le lv<l1>&
l14){lx( *l20,l14);}ld::ld(le lv<l17>&l14){lx( *l20,l14);}ld::ld(le lv
<lu>&l14){lx( *l20,l14);}lu ld::l73()le{lc l0==lg::l9||l47( *l20)==0;
}lb ld::lz()le{lc(lb)l47( *l20);}lp<l18 ln>le lv<ln>&ld::ly()le{l40(""
"\x23\x20\x62\x61\x64\x20\x74\x79\x70\x65");}lp<>le lv<l1>&ld::ly()le
{lc l34;}lp<>le lv<l17>&ld::ly()le{lc l27;}lp<>le lv<lu>&ld::ly()le{
lc l36;}lp<l18 ln>lv<ln>&ld::ly(){l40("\x23\x20\x62\x61\x64\x20\x74"
"\x79\x70\x65");}lp<>lv<l1>&ld::ly(){lc l34;}lp<>lv<l17>&ld::ly(){lc
l27;}lp<>lv<lu>&ld::ly(){lc l36;}l55::l55(le ls&lh,le ld*l8,le ld*l25
){lb l5=l8?0:1;lb ll=l25?0:1;lj(l8&&l8->lz()!=lh.l8()-ll)l40 l64(""
"\x63\x6f\x6c\x75\x6d\x6e\x73\x20\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f"
"\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68\x20\x64\x61\x74\x61"
);lj(l25&&l25->lz()!=lh.l52()-l5)l40 l64("\x69\x6e\x64\x65\x78\x20"
"\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d"
"\x61\x74\x63\x68\x20\x64\x61\x74\x61");lj(l8)l21= *l8;l38 l21=ld(lh,
0,ll,l63);lj(l25)l39= *l25;l38 l39=ld(lh,0,l5);lj(l21.lz()==0)lc;l42.
l66(lh,ll,l5);lt(lb lf=1;lf<l21.lz();++lf)l42.l66(lh,lf+ll,l5);}ls l55
::l84(l24 l28)le{lb l59=l39.lz();lb l41=l21.lz();lb l5=l28==l24::l65
||l28==l24::l93?0:1;lb ll=l28==l24::l65||l28==l24::l90?0:1;ls l12(l59
+l5,l41+ll);lj(l28==l24::l79)l12(0,0)=l83;lj(l5==1)l26(l21,l12,0,1,
l63);lj(ll==1)l26(l39,l12,0);lj(l42.l73()){lt(lb lf=0;lf<l59;++lf)lt(
lb lr=0;lr<l41;++lr)l12(lf+l5,lr+ll).l50(l53);lc l12;}lt(lb lr=0;lr<
l41;++lr)l26(l42[lr],l12,lr+ll,l5);lc l12;}
