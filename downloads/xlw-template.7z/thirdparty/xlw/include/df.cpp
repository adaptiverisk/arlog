#include"df.h"
#include"dfxl.h"
#include<memory>
#include<string>
#include<vector>
#include<algorithm>
#include<sstream>
#include<unordered_set>
#include<utility>
#include<xlw/xl.h>
#include<cassert>
#include<iostream>
#include<map>
#include<numeric>
#include<random>
#include<regex>
#include<set>
#define l241 namespace
#define l98 xlw
#define l267 class
#define l219 public
#define l790 virtual
#define l84 default
#define l24 std
#define l15 string
#define l121 to_string
#define l2 const
#define l129 unique_ptr
#define l16 double
#define l426 override
#define l3 return
#define l64 template
#define l100 typename
#define l7 T
#define l26 BinaryOp
#define l79 inline
#define l35 throw
#define l41 runtime_error
#define l55 op
#define l80 switch
#define l27 case
#define l254 Add
#define l288 Subtract
#define l350 RSubtract
#define l284 Multiply
#define l287 Divide
#define l344 RDivide
#define l289 Power
#define l358 RPower
#define l279 Modulo
#define l364 RModulo
#define l144 Min
#define l142 Max
#define l214 LessThan
#define l211 LessThanOrEqual
#define l207 GreaterThan
#define l206 GreaterThanOrEqual
#define l205 Equal
#define l212 NotEqual
#define l280 And
#define l286 Or
#define l496 pow
#define l605 fmod
#define l294 min
#define l333 max
#define l18 bool
#define l644 str2binary_op
#define l39 str
#define l266 BinaryOpNode
#define l159 move
#define l362 UnaryOpNode
#define l299 UnaryOp
#define l22 vector
#define l4 int
#define l10 size
#define l173 pair
#define l150 step
#define l9 auto
#define l63 find
#define l1 if
#define l258 npos
#define l499 istringstream
#define l557 stringstream
#define l47 while
#define l765 getline
#define l56 push_back
#define l62 empty
#define l33 else
#define l174 first
#define l169 second
#define l517 stoi
#define l25 index
#define l122 unordered_set
#define l11 for
#define l94 size_t
#define l40 end
#define l70 insert
#define l69 continue
#define l101 reserve
#define l28 break
#define l140 clear
#define l399 is_sorted
#define l72 begin
#define l610 upper_bound
#define l424 distance
#define l444 prev
#define l165 numeric_limits
#define l497 infinity
#define l171 back
#define l425 str_split
#define l237 char
#define l509 trim
#define l306 condition_double_str
#define l6 XlfOper
#define l834 str2xl
#define l327 xl2str
#define l57 false
#define l428 xl_err
#define l30 idx
#define l49 using
#define l816 tokenStream
#define l913 find_first_not_of
#define l590 find_last_not_of
#define l232 substr
#define l443 SetError
#define l377 xlerrNA
#define l201 start
#define l213 erase
#define l587 find_if
#define l536 unsigned
#define l472 isspace
#define l782 rbegin
#define l729 rend
#define l818 base
#define l433 make_pair
#define l82 rows
#define l44 cols
#define l43 true
#define l320 try
#define l14 v
#define l500 stod
#define l340 catch
#define l701 pop_back
#define l519 append
#define l318 floor
#define l690 fabs
#define l139 static
#define l34 is
#define l36 as
#define l540 IsError
#define l926 AsString
#define l191 IsMulti
#define l21 data
#define l200 quiet_NaN
#define l208 mean
#define l869 accumulate
#define l689 sqrt
#define l857 struct
#define l152 sort
#define l564 lower_bound
#define l319 abs
#define l743 iota
#define l672 Negate
#define l569 Not
#define l860 private
#define l50 void
#define l224 make_unique
#define l830 isdigit
#define l938 isalpha
#define l1044 isalnum
#define l666 front
#define l792 op1d2str
#define l105 Op1d
#define l669 IdxMin
#define l677 IdxMax
#define l643 Mean
#define l769 Sem
#define l758 Median
#define l757 Skew
#define l682 Kurt
#define l703 Std
#define l645 Var
#define l355 Sum
#define l351 Prod
#define l852 NUnique
#define l886 Count
#define l136 FillMethod
#define l462 str2fill_method
#define l562 Ffill
#define l750 Bfill
#define l513 Nearest
#define l359 None
#define l260 BoundsInclusion
#define l894 str2bounds_inclusion
#define l635 Both
#define l825 Neither
#define l508 Left
#define l450 Right
#define l731 idx_flatten
#define l1039 operator
#define l13 DataVector
#define l12 missing
#define l51 type_
#define l20 df_type
#define l45 num
#define l53 do
#define l75 bol
#define l210 init
#define l246 set_type
#define l1062 t_type
#define l870 get_non_missing
#define l54 num_
#define l396 replace_na
#define l301 convert2type
#define l99 str_
#define l95 bol_
#define l198 is_increasing
#define l89 constexpr
#define l153 unk
#define l525 xl_type
#define l81 resize
#define l42 this
#define l199 set_all_na
#define l29 len
#define l163 at
#define l90 loc
#define l46 to_xl
#define l760 idx_all
#define l863 idx2mask
#define l893 mask2idx
#define l91 iat
#define l968 out_of_range
#define l506 Unknown
#define l125 iloc
#define l216 fill_na
#define l128 count
#define l432 greater
#define l297 unordered_map
#define l177 assert
#define l93 type
#define l74 loc_idx
#define l427 is_decreasing
#define l615 loc_multi_idx
#define l725 filter_idx
#define l180 regex
#define l106 nullptr
#define l245 isin
#define l853 has_substr
#define l593 match_regex
#define l473 at_time
#define l273 time
#define l502 between_time
#define l17 DataFrame
#define l451 first_non_na_idx
#define l534 min_idx
#define l614 max_idx
#define l255 freq
#define l851 top
#define l1049 Error
#define l560 distinct_count
#define l711 or_op
#define l583 pattern
#define l1022 regex_search
#define l786 filter_mask
#define l746 na_mask
#define l345 round
#define l68 Op
#define l117 bin_op
#define l461 type_name
#define l906 add
#define l871 subtract
#define l896 rsubtract
#define l846 divide
#define l922 rdivide
#define l835 multiply
#define l903 power
#define l917 rpower
#define l827 modulo
#define l899 rmodulo
#define l873 and_op
#define l789 comp
#define l454 invalid_argument
#define l983 eq
#define l1021 neq
#define l967 lt
#define l970 le
#define l980 gt
#define l981 ge
#define l183 binary_op
#define l838 not_op
#define l874 negation_op
#define l815 unary_op
#define l597 dot
#define l747 sum_prod
#define l332 diff
#define l514 corr
#define l235 isnan
#define l471 cov
#define l406 combine_first
#define l625 update
#define l337 all
#define l889 any
#define l657 clip
#define l158 dropna
#define l392 nunique
#define l167 CumOp
#define l215 cum
#define l369 cur
#define l626 pct_change
#define l482 shift
#define l733 describe_rows
#define l478 describe
#define l356 quantile
#define l157 rank
#define l495 static_cast
#define l739 enum
#define l727 kurt_skew
#define l195 op1d
#define l501 mode
#define l895 stable_sort
#define l310 set
#define l999 emplace
#define l662 rename
#define l680 truncate
#define l234 replace
#define l720 el_comp
#define l1009 minor_size
#define l653 major_size
#define l561 el
#define l156 sel
#define l23 columns
#define l114 _row_type
#define l367 emplace_back
#define l252 sel_col
#define l181 drop
#define l744 drop_col
#define l256 row
#define l363 ToXlMode
#define l633 Data
#define l956 DataIndex
#define l1016 DataColumns
#define l960 All
#define l244 is_df
#define l417 val_cols
#define l253 select_dtypes
#define l793 remove_dtypes
#define l512 reset_index
#define l552 where
#define l19 df
#define l412 dynamic_cast
#define l438 get
#define l415 eval
#define l904 query
#define l849 bin_op_to
#define l1032 combine_first_no_expand
#define l877 corrwith
#define l761 flatten
#define l890 AsDoubleVector
#define l650 add_presufix
#define l973 reverse
#define l565 unique_idx
#define l1058 dupl_idx
#define l829 drop_duplicates
#define l892 duplicated
#define l866 filter
#define l599 reindex
#define l713 sample
#define l925 mt19937
#define l813 discrete_distribution
#define l802 swap
#define l660 fillna
#define l683 get_col_values
#define l687 row_comp
#define l927 get_union_idx
#define l190 map
#define l550 get_multi_union_idx
#define l705 join
#define l858 asof
#define l916 df_T
#define l1057 df_transpose
#define l928 df_index
#define l1030 df_columns
#define l1012 df_info
#define l978 df_at
#define l997 df_iat
#define l577 df_iloc
#define l446 df_loc
#define l993 df_shape
#define l995 df_head
#define l1040 df_tail
#define l842 from_name
#define l945 df_select_dtypes
#define l821 df_size
#define l998 df_empty
#define l977 df_insert
#define l996 df_isin
#define l971 df_where
#define l1025 df_mask
#define l929 df_query
#define l936 df_add
#define l1033 df_sub
#define l950 df_rsub
#define l1001 df_mul
#define l1056 df_div
#define l1028 df_rdiv
#define l1059 df_mod
#define l955 df_rmod
#define l974 df_pow
#define l1023 df_rpow
#define l930 df_or
#define l1024 df_and
#define l989 df_dot
#define l940 df_lt
#define l963 df_gt
#define l943 df_le
#define l964 df_ge
#define l934 df_ne
#define l966 df_eq
#define l1005 df_combine_first
#define l953 df_abs
#define l1034 df_all
#define l1017 df_any
#define l1036 df_clip
#define l972 df_corr
#define l947 df_corrwith
#define l951 df_count
#define l990 df_cov
#define l1053 df_cummax
#define l948 df_cummin
#define l988 df_cumprod
#define l1045 df_cumsum
#define l958 df_describe
#define l1020 df_diff
#define l822 find_first_of
#define l905 strchr
#define l664 df_eval
#define l823 df_kurt
#define l985 df_kurtosis
#define l1061 df_max
#define l1013 df_min
#define l976 df_mean
#define l935 df_median
#define l878 df_prod
#define l949 df_product
#define l946 df_sem
#define l994 df_skew
#define l1031 df_sum
#define l1038 df_std
#define l1048 df_var
#define l1050 df_idxmax
#define l1015 df_idxmin
#define l941 df_mode
#define l1019 df_pct_change
#define l1008 df_quantile
#define l1014 df_rank
#define l931 df_round
#define l969 df_nunique
#define l1052 df_add_prefix
#define l1046 df_add_suffix
#define l1041 df_at_time
#define l1006 df_between_time
#define l984 df_drop
#define l942 df_drop_duplicates
#define l1043 df_duplicated
#define l1011 df_equals
#define l986 df_filter
#define l1055 df_reindex
#define l957 df_reindex_like
#define l937 df_rename
#define l1018 df_reset_index
#define l1063 df_sample
#define l952 df_set_index
#define l1029 df_take
#define l1027 df_truncate
#define l939 df_dropna
#define l1002 df_bfill
#define l770 df_fillna
#define l1037 df_ffill
#define l844 df_isna
#define l1054 df_isnull
#define l850 df_notna
#define l962 df_notnull
#define l1047 df_replace
#define l933 df_sort_values
#define l965 df_sort_index
#define l987 df_nlargest
#define l1035 df_nsmallest
#define l1003 df_join
#define l1010 df_merge
#define l959 df_update
#define l954 df_asof
#define l1007 df_shift
#define l918 df_B
#define l1051 is_bool_df
#define l961 df_to_numpy
#pragma once
#pragma once
l241 l98{l267 l111{l219:l790~l111()=l84;l790 l24::l15 l121()l2=0;};
l24::l129<l111>l767(l2 l24::l15&l277);l267 l430:l219 l111{l219:l430(
l16 l52):l52(l52){}l16 l52;l24::l15 l121()l2 l426;};l267 l477:l219
l111{l219:l477(l2 l24::l15&l52):l52(l52){}l24::l15 l52;l24::l15 l121(
)l2 l426{l3"\x27"+l52+"\x27";}};l267 l409:l219 l111{l219:l409(l2 l24
::l15&l290):l290(l290){}l24::l15 l290;l24::l15 l121()l2 l426{l3"\x60"
+l290+"\x60";}};l64<l100 l7,l26 l891>l7 l79 l126(l7 l8,l7 l58){l35 l24
::l41("\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x62\x69\x6e\x61\x72\x79\x20"
"\x6f\x70\x65\x72\x61\x74\x6f\x72");}l64<l100 l7>l7 l79 l401(l7 l8,l7
l58,l26 l55){l80(l55){l27 l26::l254:l3 l126<l7,l26::l254>(l8,l58);l27
l26::l288:l3 l126<l7,l26::l288>(l8,l58);l27 l26::l350:l3 l126<l7,l26
::l350>(l8,l58);l27 l26::l284:l3 l126<l7,l26::l284>(l8,l58);l27 l26::
l287:l3 l126<l7,l26::l287>(l8,l58);l27 l26::l344:l3 l126<l7,l26::l344
>(l8,l58);l27 l26::l289:l3 l126<l7,l26::l289>(l8,l58);l27 l26::l358:
l3 l126<l7,l26::l358>(l8,l58);l27 l26::l279:l3 l126<l7,l26::l279>(l8,
l58);l27 l26::l364:l3 l126<l7,l26::l364>(l8,l58);l27 l26::l144:l3 l126
<l7,l26::l144>(l8,l58);l27 l26::l142:l3 l126<l7,l26::l142>(l8,l58);
l27 l26::l214:l3 l126<l7,l26::l214>(l8,l58);l27 l26::l211:l3 l126<l7,
l26::l211>(l8,l58);l27 l26::l207:l3 l126<l7,l26::l207>(l8,l58);l27 l26
::l206:l3 l126<l7,l26::l206>(l8,l58);l27 l26::l205:l3 l126<l7,l26::
l205>(l8,l58);l27 l26::l212:l3 l126<l7,l26::l212>(l8,l58);l27 l26::
l280:l3 l126<l7,l26::l280>(l8,l58);l27 l26::l286:l3 l126<l7,l26::l286
>(l8,l58);l84:l35 l24::l41("\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x62\x69"
"\x6e\x61\x72\x79\x20\x6f\x70\x65\x72\x61\x74\x6f\x72");}}l64<>l16 l79
l126<l16,l26::l254>(l16 l8,l16 l58){l3 l8+l58;}l64<>l24::l15 l79 l126
<l24::l15,l26::l254>(l24::l15 l8,l24::l15 l58){l3 l8+l58;}l64<>l16 l79
l126<l16,l26::l288>(l16 l8,l16 l58){l3 l8-l58;}l64<>l16 l79 l126<l16,
l26::l350>(l16 l8,l16 l58){l3 l58-l8;}l64<>l16 l79 l126<l16,l26::l284
>(l16 l8,l16 l58){l3 l8*l58;}l64<>l16 l79 l126<l16,l26::l287>(l16 l8,
l16 l58){l3 l8/l58;}l64<>l16 l79 l126<l16,l26::l344>(l16 l8,l16 l58){
l3 l58/l8;}l64<>l16 l79 l126<l16,l26::l289>(l16 l8,l16 l58){l3 l496(
l8,l58);}l64<>l16 l79 l126<l16,l26::l358>(l16 l8,l16 l58){l3 l496(l58
,l8);}l64<>l16 l79 l126<l16,l26::l279>(l16 l8,l16 l58){l3 l605(l8,l58
);}l64<>l16 l79 l126<l16,l26::l364>(l16 l8,l16 l58){l3 l605(l58,l8);}
l64<>l16 l79 l126<l16,l26::l144>(l16 l8,l16 l58){l3 l24::l294(l8,l58);
}l64<>l16 l79 l126<l16,l26::l142>(l16 l8,l16 l58){l3 l24::l333(l8,l58
);}l64<>l18 l79 l126<l18,l26::l280>(l18 l8,l18 l58){l3 l8&&l58;}l64<>
l18 l79 l126<l18,l26::l286>(l18 l8,l18 l58){l3 l8||l58;}l64<l100 l7,
l26 l891>l18 l79 l185(l7 l8,l7 l58){l35 l24::l41("\x55\x6e\x6b\x6e"
"\x6f\x77\x6e\x20\x62\x69\x6e\x61\x72\x79\x20\x6f\x70\x65\x72\x61\x74"
"\x6f\x72");}l64<l100 l7>l18 l79 l944(l7 l8,l7 l58,l26 l55){l80(l55){
l27 l26::l214:l3 l185<l7,l26::l214>(l8,l58);l27 l26::l211:l3 l185<l7,
l26::l211>(l8,l58);l27 l26::l207:l3 l185<l7,l26::l207>(l8,l58);l27 l26
::l206:l3 l185<l7,l26::l206>(l8,l58);l27 l26::l205:l3 l185<l7,l26::
l205>(l8,l58);l27 l26::l212:l3 l185<l7,l26::l212>(l8,l58);l84:l35 l24
::l41("\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x62\x69\x6e\x61\x72\x79\x20"
"\x6f\x70\x65\x72\x61\x74\x6f\x72");}}l64<>l18 l79 l185<l16,l26::l214
>(l16 l8,l16 l58){l3 l8<l58;}l64<>l18 l79 l185<l16,l26::l211>(l16 l8,
l16 l58){l3 l8<=l58;}l64<>l18 l79 l185<l16,l26::l207>(l16 l8,l16 l58){
l3 l8>l58;}l64<>l18 l79 l185<l16,l26::l206>(l16 l8,l16 l58){l3 l8>=
l58;}l64<>l18 l79 l185<l16,l26::l205>(l16 l8,l16 l58){l3 l8==l58;}l64
<>l18 l79 l185<l16,l26::l212>(l16 l8,l16 l58){l3 l8!=l58;}l64<>l18 l79
l185<l24::l15,l26::l214>(l24::l15 l8,l24::l15 l58){l3 l8<l58;}l64<>
l18 l79 l185<l24::l15,l26::l211>(l24::l15 l8,l24::l15 l58){l3 l8<=l58
;}l64<>l18 l79 l185<l24::l15,l26::l207>(l24::l15 l8,l24::l15 l58){l3
l8>l58;}l64<>l18 l79 l185<l24::l15,l26::l206>(l24::l15 l8,l24::l15 l58
){l3 l8>=l58;}l64<>l18 l79 l185<l24::l15,l26::l205>(l24::l15 l8,l24::
l15 l58){l3 l8==l58;}l64<>l18 l79 l185<l24::l15,l26::l212>(l24::l15 l8
,l24::l15 l58){l3 l8!=l58;}l26 l644(l2 l24::l15&l39);l79 l18 l832(l26
l55){l3 l55==l26::l214||l55==l26::l211||l55==l26::l207||l55==l26::
l206||l55==l26::l205||l55==l26::l212;}l267 l266:l219 l111{l219:l266(
l26 l55,l24::l129<l111>l87,l24::l129<l111>l127):l55(l55),l87(l159(l87
)),l127(l159(l127)){}l26 l55;l24::l129<l111>l87;l24::l129<l111>l127;
l24::l15 l121()l2 l426;};l267 l362:l219 l111{l219:l362(l299 l55,l24::
l129<l111>l110):l55(l55),l110(l159(l110)){}l299 l55;l24::l129<l111>
l110;l24::l15 l121()l2 l426;};l267 l440:l219 l111{l219:l440(l24::l129
<l111>l110,l24::l22<l24::l129<l111>>l240):l110(l159(l110)),l240(l159(
l240)){}l24::l129<l111>l110;l24::l22<l24::l129<l111>>l240;l24::l15
l121()l2 l426;};}
#pragma once
l241 l98{l24::l22<l4>l779(l4 l10,l24::l15 l182);l64<l100 l7>l24::l173
<l7,l7>l652(l24::l173<l7,l7>l218,l2 l24::l15&l620,l4&l150){l9 l898=
l620.l63("\x3a");l1(l898==l24::l15::l258){l150=1;l7 l149;l24::l499(
l620)>>l149;l3{l149,l149};}l24::l557 l203(l620);l24::l15 l435;l24::
l22<l24::l15>l271;l47(l24::l765(l203,l435,':')){l271.l56(l435);}l7
l607,l608;l1(l271.l10()>0&&!l271[0].l62()){l24::l499(l271[0])>>l607;}
l33{l607=l218.l174;}l1(l271.l10()>1&&!l271[1].l62()){l24::l499(l271[1
])>>l608;}l33{l608=l218.l169;}l1(l271.l10()>2&&!l271[2].l62()){l150=
l24::l517(l271[2]);l1(l150<=0){l150=1;}}l33{l150=1;}l3{l607,l608};}
l64<l100 l7>l24::l22<l4>l908(l2 l24::l22<l7>&l25,l2 l24::l173<l7,l7>&
l218,l4 l150){l1(l150<=0)l35("\x62\x61\x64\x20\x73\x74\x65\x70");l24
::l122<l7>l549;l11(l94 l0=0;l0<l25.l10();++l0){l1(l549.l63(l25[l0])==
l549.l40()){l549.l70(l25[l0]);l69;}l1(l25[l0-1]==l25[l0])l69;l33 l35(""
"\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x20\x6c\x61\x62\x65\x6c\x73\x20"
"\x69\x6e\x20\x69\x6e\x64\x65\x78");}l24::l22<l4>l5;l4 l37=(l4)l25.
l10();l5.l101(l37);l4 l0=0;l11(;l0<l37;++l0){l1(l25[l0]==l218.l174)l28
;}l1(l0==l37){l5.l56(-1);l3 l5;}l11(;l0<l37;++l0){l5.l56(l0);l1(l25[
l0]==l218.l169){l1(l0<l37-1&&l25[l0+1]==l218.l169)l69;l28;}}l1(l0==
l37){l5.l140();l5.l56(-1);l3 l5;}l1(l150>1){l24::l22<l4>l88;l88.l101(
l5.l10());l11(l94 l0=0;l0<l5.l10();l0+=l150)l88.l56(l5[l0]);l3 l88;}
l3 l5;}l64<l100 l7>l24::l22<l4>l875(l2 l24::l22<l7>&l25,l2 l24::l173<
l7,l7>&l218,l4 l150){l24::l22<l4>l5;l1(l218.l174>=l218.l169)l35("\x73"
"\x74\x61\x72\x74\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x6d"
"\x61\x6c\x6c\x65\x72\x20\x74\x68\x61\x6e\x20\x65\x6e\x64");l1(!l24::
l399(l25.l72(),l25.l40()))l35("\x4c\x61\x62\x65\x6c\x73\x20\x61\x72"
"\x65\x20\x6e\x6f\x74\x20\x69\x6e\x20\x69\x6e\x64\x65\x78\x20\x61\x6e"
"\x64\x20\x69\x6e\x64\x65\x78\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x6f"
"\x72\x74\x65\x64");l4 l86=-1;{l9 l124=l24::l610(l25.l72(),l25.l40(),
l218.l174);l1(l124==l25.l40())l3 l5;l86=(l4)l24::l424(l25.l72(),l124);
}l4 l272=-1;{l9 l124=l24::l610(l25.l72(),l25.l40(),l218.l169);l1(l124
==l25.l72())l35("\x73\x74\x61\x72\x74\x20\x73\x68\x6f\x75\x6c\x64\x20"
"\x62\x65\x20\x73\x6d\x61\x6c\x6c\x65\x72\x20\x74\x68\x61\x6e\x20\x65"
"\x6e\x64");l272=(l4)l24::l424(l25.l72(),l444(l124));}l1(l272<l86)l3
l5;l1(l150<=0)l35("\x62\x61\x64\x20\x73\x74\x65\x70");l5.l101(l25.l10
());l11(l4 l0=l86;l0<=l272;l0+=l150){l5.l56(l0);}l3 l5;}l64<l100 l7>
l24::l173<l7,l7>l527(){l35("\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d"
"\x65\x6e\x74\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x74\x79"
"\x70\x65");}l64<>l79 l24::l173<l16,l16>l527(){l3{-l24::l165<l16>::
l497(),l24::l165<l16>::l497()};}l64<>l79 l24::l173<l24::l15,l24::l15>
l527(){l2 l24::l15 l775(1,'\0');l2 l24::l15 l737("\xf4\x8f\xbf\xbf");
l3{l775,l737};}l64<l100 l7>l24::l22<l4>l749(l2 l24::l22<l7>&l25,l2 l24
::l15&l182){l24::l22<l4>l5;l1(l25.l62())l3 l5;l4 l150;l9 l218=l652<l7
>({l25[0],l25.l171()},l182,l150);l5=l908(l25,l218,l150);l1(l5.l10()!=
1||l5[0]!=-1)l3 l5;l218=l652(l527<l7>(),l182,l150);l3 l875(l25,l218,
l150);}}
#pragma once
l241 l98{l24::l22<l24::l15>l425(l2 l24::l15&l67,l237 l704);l24::l15
l509(l2 l24::l15&l39);l24::l15 l671(l2 l24::l15&l39);l24::l15 l667(
l24::l15 l39);l24::l15 l306(l24::l15 l39);l24::l15 l529(l16 l59);l6
l834(l2 l24::l15&l764,l237 l341='\t');l24::l15 l327(l2 l6&l8,l237 l341
='\t');l24::l22<l24::l15>l420(l6 l8,l18 l699=l57,l18 l659=l57,l237
l341='\t');l6 l428();l24::l22<l4>l523(l2 l6&l103,l4 l10);l24::l22<l4>
l441(l2 l6&l103,l4 l10);l24::l22<l4>l715(l2 l24::l22<l4>&l30,l4 l10);
l16 l780(l2 l24::l22<l16>&l8);l16 l762(l2 l24::l22<l16>&l8);l24::l22<
l4>l759(l2 l24::l22<l16>&l8,l2 l24::l22<l16>&l52);l24::l22<l4>l756(l4
l37);}
l49 l241 l24;l49 l241 l98;l22<l15>l98::l425(l2 l15&l67,l237 l704){l22
<l15>l717;l15 l435;l499 l816(l67);l47(l765(l816,l435,l704)){l717.l56(
l435);}l3 l717;}l15 l98::l509(l2 l15&l39){l94 l174=l39.l913(' ');l1(
l24::l15::l258==l174)l3 l39;l94 l864=l39.l590(' ');l3 l39.l232(l174,(
l864-l174+1));}l6 l98::l428(){l6 l5;l5.l443(l377);l3 l5;}l15 l919(l2
l15&l39){l2 l15 l681="\n\r";l94 l201=l39.l913(l681);l94 l40=l39.l590(
l681);l1(l201==l15::l258)l3"";l3 l39.l232(l201,l40-l201+1);}l24::l173
<l24::l15,l24::l15>l1026(l2 l24::l15&l39,l4 l119){l24::l15 l233=l39.
l232(0,l119);l24::l15 l227=l39.l232(l119);l233.l213(l233.l72(),l24::
l587(l233.l72(),l233.l40(),[](l536 l237 l376){l3!l24::l472(l376);}));
l233.l213(l24::l587(l233.l782(),l233.l729(),[](l536 l237 l376){l3!l24
::l472(l376);}).l818(),l233.l40());l227.l213(l227.l72(),l24::l587(
l227.l72(),l227.l40(),[](l536 l237 l376){l3!l24::l472(l376);}));l227.
l213(l24::l587(l227.l782(),l227.l729(),[](l536 l237 l376){l3!l24::
l472(l376);}).l818(),l227.l40());l3 l24::l433(l233,l227);}l6 l98::
l834(l2 l15&l764,l237 l341){l9 l466=l425(l919(l764),'\n');l1(l466.l62
())l3 l6();l9 l226=l425(l466[0],l341);l1(l226.l62())l3 l6();l6 l5((l4
)l466.l10(),(l4)l226.l10());l11(l4 l0=0;l0<l5.l82();++l0){l226=l425(
l466[l0],l341);l1((l4)l226.l10()!=l5.l44())l3 l6();l11(l4 l31=0;l31<
l5.l44();++l31){l1(l226[l31]=="\x23\x4e\x2f\x41"){l5(l0,l31).l443(
l377);l69;}l1(l226[l31]=="\x46\x41\x4c\x53\x45"){l5(l0,l31)=l57;l69;}
l1(l226[l31]=="\x54\x52\x55\x45"){l5(l0,l31)=l43;l69;}l320{l16 l14=
l500(l226[l31]);l5(l0,l31)=l14;}l340(...){l5(l0,l31)=l226[l31];}}}l3
l5;}l15 l98::l671(l2 l15&l39){l1(l39.l62()||l39.l171()!='0')l3 l39;l1
(l39.l63('.')==l15::l258)l3 l39;l94 l40=l39.l590('0');l1(l40==l15::
l258)l3"\x30";l15 l628=l39.l232(0,l40+1);l1(l628.l171()=='.')l628.
l701();l3 l628;}l15 l98::l667(l15 l39){l1(l39.l62()||l39.l171()!='9')l3
l39;l4 l324=(l4)l39.l63('.');l1(l324==l15::l258)l3 l39;l18 l612=l39[0
]=='-';l1(l612){l39.l213(0,l612?1:0);--l324;}l1(l39[0]=='.'){l39.l70(
0,"\x30");++l324;}l39.l213(l324,1);l94 l40=l39.l590('9');l1(l40==l15
::l258){l39="\x31";++l324;}l33{++l39[l40];l39=l39.l232(0,l40+1);}l1((
l4)l39.l10()<=l324)l39.l519(l324-l39.l10(),'0');l33 l39.l70(l324,""
"\x2e");l1(l612)l39.l70(0,"\x2d");l3 l39;}l15 l98::l306(l15 l39){l320
{l9 l14=l500(l39);l1(l39.l171()=='9')l3 l667(l39);l1(l39.l171()=='0')l3
l671(l39);l3 l39;}l340(...){l3 l39;}}l15 l98::l529(l16 l14){l1(l318(
l690(l14))==l690(l14))l3 l121((l4)l14);l3 l306(l121(l14));}l139 l79
l15 l901(l6 l8){l1(l8.l34<l16>()){l16 l14=l8.l36<l16>();l1(l318(l14)==
l14)l3 l121((l4)l14);l3 l306(l121(l14));}l1(l8.l34<l4>())l3 l121(l8.
l36<l4>());l1(l8.l34<l18>())l3 l8.l36<l18>()?"\x54\x52\x55\x45":"\x46"
"\x41\x4c\x53\x45";l1(l8.l34<l15>())l3 l8.l36<l15>();l1(l8.l540()){
l320{l3 l8.l926();}l340(...){}}l3"\x23\x4e\x2f\x41";}l24::l22<l24::
l15>l98::l420(l98::l6 l8,l18 l699,l18 l659,l237 l341){l1(l8.l82()==0)l3
{"\x30"};l4 l86=l659?1:0;l1(l8.l82()<=l86)l3{""};l4 l164=l699?1:0;l1(
l8.l44()<=l164)l3{""};l24::l22<l24::l15>l5;l5.l101(l8.l82());l11(l4 l0
=l86;l0<l8.l82();++l0){l15 l67;l11(l4 l31=l164;l31<l8.l44();++l31){
l67+=l901(l8(l0,l31));l67+=l341;}l67.l701();l5.l56(l67);}l3 l5;}l15
l98::l327(l2 l6&l8,l237 l341){l24::l557 l203;l11(l2 l9&l226:l420(l8))l203
<<l226<<'\n';l9 l5=l203.l39();l5.l701();l3 l5;}l22<l4>l98::l523(l2 l6
&l103,l4 l10){l22<l4>l30;l1(!l103(0,0).l34<l18>())l3 l30;l30.l101(l10
);l22<l18>l160;l160.l101(l10);l11(l4 l0=0;l0<l103.l82();++l0)l11(l4
l31=0;l31<l103.l44();++l31){l1(!l103(l0,l31).l34<l18>())l35("\x23\x20"
"\x62\x61\x64\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20\x6d\x61\x73\x6b");
l160.l56(l103(l0,l31).l36<l18>());}l1((l4)l160.l10()!=l10)l35("\x23"
"\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20\x6d\x61\x73\x6b\x20\x6f\x66\x20"
"\x77\x72\x6f\x6e\x67\x20\x73\x69\x7a\x65");l11(l4 l0=0;l0<l10;++l0)l1
(l160[l0])l30.l56(l0);l3 l30;}l22<l4>l98::l441(l2 l6&l103,l4 l10){l1(
l103.l191()){l22<l4>l30=l523(l103,l10);l1(!l30.l62())l3 l30;l1(l103(0
,0).l34<l16>()){l30.l101(l10);l11(l4 l0=0;l0<l103.l82();++l0)l11(l4
l31=0;l31<l103.l44();++l31){l1(!l103(l0,l31).l34<l16>())l35("\x23\x20"
"\x62\x61\x64\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20\x6d\x61\x73\x6b");
l30.l56(l103(l0,l31).l36<l4>());}l3 l30;}l35("\x23\x20\x6e\x65\x69"
"\x74\x68\x65\x72\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x69\x6e\x64\x65"
"\x78\x65\x73\x20\x6e\x6f\x72\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20\x6d"
"\x61\x73\x6b");}l22<l4>l30;l30.l101(l10);l1(l103.l34<l16>()){l30.l56
(l103.l36<l4>());l3 l30;}l1(l103.l34<l15>()){l9 l182=l103.l36<l15>();
l30=l779(l10,l182);l3 l30;}l35("\x23\x20\x62\x61\x64\x20\x70\x6f\x73"
"\x69\x74\x69\x6f\x6e\x20\x73\x70\x65\x63\x69\x66\x69\x63\x61\x74\x69"
"\x6f\x6e");}l24::l22<l4>l98::l715(l2 l24::l22<l4>&l30,l4 l10){l24::
l22<l4>l5;l5.l101(l10);l122<l4>l67(l30.l72(),l30.l40());l11(l4 l0=0;
l0<l10;++l0)l1(l67.l63(l0)==l67.l40())l5.l56(l0);l3 l5;}l16 l98::l780
(l2 l24::l22<l16>&l21){l4 l37=(l4)l21.l10();l1(l37<=3)l3 l165<l16>::
l200();l16 l208=l24::l869(l21.l72(),l21.l40(),0.0)/l37;l16 l296=0.0;
l16 l353=0.0;l11(l2 l9&l8:l21){l9 l278=l8-l208;l278*=l278;l296+=l278;
l278*=l278;l353+=l278;}l296*=l296;l353/=l296;l353*=l37* (l37+1);l353
-=3* (l37-1);l353*=(l37-1);l353/=(l37-2) * (l37-3);l3 l353;}l16 l98::
l762(l2 l24::l22<l16>&l21){l4 l37=(l4)l21.l10();l1(l37<=2)l3 l165<l16
>::l200();l16 l208=l24::l869(l21.l72(),l21.l40(),0.0)/l37;l16 l296=
0.0;l16 l383=0.0;l11(l2 l9&l8:l21){l9 l278=l8-l208;l9 l584=l278*l278;
l296+=l584;l584*=l278;l383+=l584;}l383/=l296;l296/=l37-1;l383/=l689(
l296);l383*=l37;l383/=l37-2;l3 l383;}l857 l481{l16 l52;l4 l504;};l22<
l4>l98::l759(l2 l22<l16>&l8,l2 l22<l16>&l14){l22<l481>l325;l11(l4 l0=
0;l0<l8.l10();++l0){l325.l56({l8[l0],l0});}l152(l325.l72(),l325.l40(),
[](l2 l481&l141,l2 l481&l166){l3 l141.l52<l166.l52;});l22<l4>l162(l14
.l10());l11(l4 l0=0;l0<l14.l10();l0++){l9 l124=l564(l325.l72(),l325.
l40(),l14[l0],[](l2 l481&l141,l16 l166){l3 l141.l52<l166;});l1(l124==
l325.l40())l162[l0]=l325.l171().l504;l33 l1(l124==l325.l72()||l124->
l52==l14[l0])l162[l0]=l124->l504;l33{l9 l656=l444(l124);l1(l319(l656
->l52-l14[l0])<=l319(l124->l52-l14[l0]))l162[l0]=l656->l504;l33 l162[
l0]=l124->l504;}}l3 l162;}l22<l4>l98::l756(l4 l37){l22<l4>l5(l37);
l743(l5.l72(),l5.l40(),0);l3 l5;}l49 l241 l24;l49 l241 l98;l15 l430::
l121()l2{l557 l203;l203<<l52;l3 l203.l39();}l15 l266::l121()l2{l15
l176;l80(l55){l27 l26::l254:l176="\x2b";l28;l27 l26::l288:l176="\x2d"
;l28;l27 l26::l284:l176="\x2a";l28;l27 l26::l287:l176="\x2f";l28;l27
l26::l289:l176="\x5e";l28;l27 l26::l279:l176="\x25";l28;l27 l26::l214
:l176="\x3c";l28;l27 l26::l211:l176="\x3c\x3d";l28;l27 l26::l207:l176
="\x3e";l28;l27 l26::l206:l176="\x3e\x3d";l28;l27 l26::l205:l176=""
"\x3d\x3d";l28;l27 l26::l212:l176="\x21\x3d";l28;l27 l26::l280:l176=""
"\x26\x26";l28;l27 l26::l286:l176="\x7c\x7c";l28;}l3"\x28"+l87->l121(
)+"\x20"+l176+"\x20"+l127->l121()+"\x29";}l26 l98::l644(l2 l24::l15&
l39){l1(l39=="\x2b")l3 l26::l254;l1(l39=="\x2d")l3 l26::l288;l1(l39==""
"\x2a")l3 l26::l284;l1(l39=="\x2f")l3 l26::l287;l1(l39=="\x5e"||l39==""
"\x2a\x2a")l3 l26::l289;l1(l39=="\x25")l3 l26::l279;l1(l39=="\x3c")l3
l26::l214;l1(l39=="\x3c\x3d")l3 l26::l211;l1(l39=="\x3e")l3 l26::l207
;l1(l39=="\x3e\x3d")l3 l26::l206;l1(l39=="\x3d\x3d")l3 l26::l205;l1(
l39=="\x21\x3d")l3 l26::l212;l1(l39=="\x26\x26"||l39=="\x61\x6e\x64")l3
l26::l280;l1(l39=="\x7c\x7c"||l39=="\x6f\x72")l3 l26::l286;l35 l24::
l41("\x49\x6e\x76\x61\x6c\x69\x64\x20\x62\x69\x6e\x61\x72\x79\x20\x6f"
"\x70\x65\x72\x61\x74\x6f\x72\x3a\x20"+l39);}l15 l362::l121()l2{l15
l176;l80(l55){l27 l299::l672:l176="\x2d";l28;l27 l299::l569:l176=""
"\x21";l28;}l3 l176+l110->l121();}l15 l440::l121()l2{l557 l203;l203<<
l110->l121()<<"\x20\x69\x6e\x20\x5b";l11(l94 l0=0;l0<l240.l10();++l0){
l203<<l240[l0]->l121();l1(l0!=l240.l10()-1){l203<<"\x2c\x20";}}l203<<""
"\x5d";l3 l203.l39();}l267 l217{l219:l217(l2 l15&l277):l277(l277),
l119(0){}l129<l111>l735();l860:l15 l277;l94 l119;l237 l118(l4 l37=0)l2
{l1(l119+l37>=l277.l10())l3'\0';l3 l277[l119+l37];}l237 l309(){l3 l277
[l119++];}l50 l151(){l47(l472(l118())){l309();}}l129<l111>l574(){l3
l686();}l129<l111>l686();l129<l111>l624();l129<l111>l627();l129<l111>
l518();l129<l111>l555();l129<l111>l592();l129<l111>l559();l129<l111>
l551();l129<l111>l414();l16 l787();l15 l753();l15 l777();};l129<l111>
l217::l735(){l9 l162=l574();l151();l1(l119!=l277.l10())l35 l41("\x55"
"\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x68\x61\x72\x61\x63\x74"
"\x65\x72\x73\x20\x61\x74\x20\x65\x6e\x64\x20\x6f\x66\x20\x69\x6e\x70"
"\x75\x74");l3 l162;}l129<l111>l217::l686(){l9 l87=l624();l11(;;){
l151();l1((l118()=='|'&&l118(1)=='|')||(l118()=='o'&&l118(1)=='r')){
l119+=2;l151();l9 l127=l624();l87=l224<l266>(l26::l286,l159(l87),l159
(l127));}l33 l28;}l3 l87;}l129<l111>l217::l624(){l9 l87=l627();l11(;;
){l151();l9 l66=l118();l9 l335=l118(1);l1((l66=='&'&&l335=='&')||(l66
=='a'&&l335=='n'&&l118(2)=='d')){l119+=l66=='a'?3:2;l151();l9 l127=
l627();l87=l224<l266>(l26::l280,l159(l87),l159(l127));}l33 l28;}l3 l87
;}l129<l111>l217::l627(){l9 l87=l518();l11(;;){l151();l26 l55;l9 l66=
l118();l9 l335=l118(1);l1(l66=='='&&l335=='='){l119+=2;l55=l26::l205;
}l33 l1(l66=='!'&&l335=='='){l119+=2;l55=l26::l212;}l33 l28;l151();l9
l127=l518();l87=l224<l266>(l55,l159(l87),l159(l127));}l3 l87;}l129<
l111>l217::l518(){l9 l87=l555();l11(;;){l151();l26 l55;l9 l66=l118();
l9 l335=l118(1);l1(l66=='<'&&l335=='='){l119+=2;l55=l26::l211;}l33 l1
(l66=='>'&&l335=='='){l119+=2;l55=l26::l206;}l33 l1(l66=='<'){++l119;
l55=l26::l214;}l33 l1(l66=='>'){++l119;l55=l26::l207;}l33 l28;l151();
l9 l127=l555();l87=l224<l266>(l55,l159(l87),l159(l127));}l3 l87;}l129
<l111>l217::l555(){l9 l87=l592();l11(;;){l151();l26 l55;l9 l66=l118();
l1(l66=='+'){++l119;l55=l26::l254;}l33 l1(l66=='-'){++l119;l55=l26::
l288;}l33 l28;l151();l9 l127=l592();l87=l224<l266>(l55,l159(l87),l159
(l127));}l3 l87;}l129<l111>l217::l592(){l9 l87=l559();l11(;;){l151();
l26 l55;l9 l66=l118();l1(l66=='*'){++l119;l55=l26::l284;}l33 l1(l66==
'/'){++l119;l55=l26::l287;}l33 l1(l66=='%'){++l119;l55=l26::l279;}l33
l28;l151();l9 l127=l559();l87=l224<l266>(l55,l159(l87),l159(l127));}
l3 l87;}l129<l111>l217::l559(){l9 l87=l551();l151();l1(l118()=='*'&&
l118(1)=='*'){l119+=2;l151();l9 l127=l551();l87=l224<l266>(l26::l289,
l159(l87),l159(l127));}l3 l87;}l129<l111>l217::l551(){l151();l9 l66=
l118();l1(l66=='-'){++l119;l151();l9 l110=l414();l3 l224<l362>(l299::
l672,l159(l110));}l33 l1(l66=='!'){++l119;l151();l9 l110=l414();l3
l224<l362>(l299::l569,l159(l110));}l33 l1(l66=='n'&&l118(1)=='o'&&
l118(2)=='t'){l119+=3;l151();l9 l110=l414();l3 l224<l362>(l299::l569,
l159(l110));}l33 l3 l414();}l129<l111>l217::l414(){l151();l9 l66=l118
();l1(l830(l118())){l16 l52=l787();l3 l224<l430>(l52);}l33 l1(l66==
'\''){l15 l52=l753();l3 l224<l477>(l52);}l33 l1(l938(l66)||l66=='_'||
l66=='`'){l15 l290=l777();l151();l1(l118()=='i'&&l118(1)=='n'){l119+=
2;l151();l1(l118()!='[')l35 l41("\x45\x78\x70\x65\x63\x74\x65\x64\x20"
"\x5b");++l119;l22<l129<l111>>l240;l1(l118()!=']'){l11(;;){l240.l56(
l574());l151();l1(l118()==']')l28;l1(l118()!=',')l35 l41("\x45\x78"
"\x70\x65\x63\x74\x65\x64\x20\x2c\x20\x6f\x72\x20\x5d");++l119;}}++
l119;l3 l224<l440>(l224<l409>(l290),l159(l240));}l33 l3 l224<l409>(
l290);}l33 l1(l66=='('){++l119;l9 l110=l574();l151();l1(l118()!=')')l35
l41("\x45\x78\x70\x65\x63\x74\x65\x64\x20\x29");++l119;l3 l110;}l33 l1
(l66=='\0')l35 l41("\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65"
"\x6e\x64\x20\x6f\x66\x20\x69\x6e\x70\x75\x74");l33 l35 l41(l15("\x55"
"\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x68\x61\x72\x61\x63\x74"
"\x65\x72\x3a\x20")+l66);}l16 l217::l787(){l15 l39;l9 l66=l118();l47(
l830(l66)||l66=='.'){l39.l56(l309());l66=l118();}l3 l500(l39);}l15
l217::l753(){l15 l39;l237 l774=l309();l9 l66=l118();l47(l66!=l774||(
l119>0&&l66==l774&&l118(-1)=='\\')){l1(l66=='\0')l35 l41("\x53\x74"
"\x72\x69\x6e\x67\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x63\x6c\x6f\x73"
"\x69\x6e\x67\x20\x27");l39.l56(l309());l66=l118();}l309();l3 l39;}
l15 l217::l777(){l15 l39;l9 l66=l118();l1(l66=='`'){l309();l66=l118();
l47(l66!='`'){l1(l66=='\0')l35 l41("\x49\x64\x65\x6e\x74\x69\x66\x69"
"\x65\x72\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x63\x6c\x6f\x73\x69\x6e"
"\x67\x20\x60");l39.l56(l309());l66=l118();}l309();}l33 l47(l1044(
l118())||l118()=='_'){l39.l56(l309());}l3 l39;}l129<l111>l98::l767(l2
l15&l277){l217 l66(l277);l3 l66.l735();}l49 l241 l24;l49 l241 l98;l22
<l4>l98::l779(l4 l10,l15 l182){l1(l182.l666()=='['&&l182.l171()==']'){
l182=l182.l232(1,l182.l10()-2);}l4 l201=0;l4 l403=l10;l4 l150=1;l9
l408=l182.l63("\x3a");l1(l408==l15::l258){l1(l182.l62())l35("\x62\x61"
"\x64\x20\x73\x6c\x69\x63\x65");l201=l517(l182);l403=l201+1;}l33{l9
l526=l182.l63("\x3a",l408+1);l15 l661=l182.l232(0,l408);l15 l674=l182
.l232(l408+1,l526-l408-1);l15 l719=l526!=l15::l258?l182.l232(l526+1):""
;l150=l719.l62()?1:l517(l719);l201=l661.l62()?((l150>0)?0:l10-1):l517
(l661);l403=l674.l62()?((l150>0)?l10:-l10-1):l517(l674);}l1(l201<0)l201
+=l10;l1(l403<0)l403+=l10;l22<l4>l162;l1(l150>0){l11(l4 l0=l201;l0<
l403;l0+=l150){l1(l0>=0&&l0<l10)l162.l56(l0);}}l33{l11(l4 l0=l201;l0>
l403;l0+=l150){l1(l0>=0&&l0<l10)l162.l56(l0);}}l3 l162;}l2 l15 l775(1
,'\0');l2 l15 l737("\xf4\x8f\xbf\xbf");l2 l16 l1060=-l165<l16>::l497(
);l2 l16 l932=l165<l16>::l497();l49 l241 l24;l49 l241 l98;l15 l98::
l792(l105 l55){l80(l55){l27 l105::l144:l3"\x6d\x69\x6e";l27 l105::
l142:l3"\x6d\x61\x78";l27 l105::l669:l3"\x69\x6d\x69\x6e";l27 l105::
l677:l3"\x69\x6d\x61\x78";l27 l105::l643:l3"\x6d\x65\x61\x6e";l27 l105
::l769:l3"\x73\x65\x6d";l27 l105::l758:l3"\x6d\x65\x64\x69\x61\x6e";
l27 l105::l757:l3"\x73\x6b\x65\x77";l27 l105::l682:l3"\x6b\x75\x72"
"\x74";l27 l105::l703:l3"\x73\x74\x64";l27 l105::l645:l3"\x76\x61\x72"
;l27 l105::l355:l3"\x73\x75\x6d";l27 l105::l351:l3"\x70\x72\x6f\x64";
l27 l105::l852:l3"\x6e\x75\x6e\x69\x71\x75\x65";l27 l105::l886:l3""
"\x63\x6f\x75\x6e\x74";l84:l3"\x75\x6e\x6b\x6e\x6f\x77\x6e";}}l136 l98
::l462(l2 l15&l67){l1(l67==""||l67=="\x70\x61\x64"||l67=="\x66\x66"
"\x69\x6c\x6c")l3 l136::l562;l1(l67=="\x62\x66\x69\x6c\x6c"||l67==""
"\x62\x61\x63\x6b\x66\x69\x6c\x6c")l3 l136::l750;l1(l67=="\x6e\x65"
"\x61\x72\x65\x73\x74")l3 l136::l513;l3 l136::l359;}l260 l98::l894(l2
l15&l67){l1(l67==""||l67=="\x62\x6f\x74\x68")l3 l260::l635;l1(l67==""
"\x6e\x65\x69\x74\x68\x65\x72")l3 l260::l825;l1(l67=="\x6c\x65\x66"
"\x74")l3 l260::l508;l1(l67=="\x72\x69\x67\x68\x74")l3 l260::l450;l3
l260::l635;}l22<l4>l98::l731(l2 l22<l22<l4>>&l30,l22<l4>&l489){l22<l4
>l5;l5.l101(l30.l10());l489.l140();l489.l101(l30.l10());l11(l4 l0=0;
l0<(l4)l30.l10();++l0){l1(l30[l0].l62()){l5.l56(-1);l489.l56(l0);}l11
(l9 l31:l30[l0]){l5.l56(l31);l489.l56(l0);}}l3 l5;}l18 l98::l1039==(
l2 l13&l380,l2 l13&l448){l1(l380.l12!=l448.l12)l3 l57;l1(l380.l51!=
l448.l51)l3 l57;l80(l380.l51){l27 l20::l45:{l49 l7=l16;l53{l3 l380.
l14<l7>()==l448.l14<l7>();}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;
l53{l3 l380.l14<l7>()==l448.l14<l7>();}l47(0);l28;}l27 l20::l75:{l49
l7=l18;l53{l3 l380.l14<l7>()==l448.l14<l7>();}l47(0);l28;}l84:l28;};
l3 l57;}l64<l100 l7>l50 l210(l13&l73){l73.l140();l73.l246(l1062<l7>());
}l24::l22<l16>l13::l870()l2{l1(l51!=l20::l45)l3 l24::l22<l16>();l24::
l22<l16>l5;l5.l101(l54.l10()-l12.l10());l11(l4 l0=0;l0<(l4)l54.l10();
++l0)l1(l12.l63(l0)==l12.l40())l5.l56(l54[l0]);l3 l5;}l64<l100 l7>l50
l13::l396(l2 l7&l149,l18 l824){l9&l60=l14<l7>();l11(l9 l0:l12)l60[l0]
=l149;l1(l824)l12.l140();}l64 l50 l13::l396<l16>(l2 l16&,l18);l64 l50
l13::l396<l15>(l2 l15&,l18);l64 l50 l13::l396<l18>(l2 l18&,l18);l50
l13::l301(l20 l168){l1(l168==l51)l3;l80(l168){l27 l20::l45:l1(l51==
l20::l39){l9&l60=l14<l16>();l11(l4 l0=0;l0<(l4)l99.l10();++l0){l320{
l60.l56(l500(l99[l0]));}l340(...){l60.l56(0);l12.l70(l0);}}l99.l140();
}l33 l1(l51==l20::l75){l9&l60=l14<l16>();l11(l9 l166:l95)l60.l56(l166
?1.:0.);l95.l140();}l28;l27 l20::l39:l1(l51==l20::l45){l9&l60=l14<l15
>();l11(l9 l59:l54)l60.l56(l529(l59));l54.l140();}l33 l1(l51==l20::
l75){l9&l60=l14<l15>();l11(l9 l166:l95)l60.l56(l166?"\x54\x52\x55\x45"
:"\x46\x41\x4c\x53\x45");l95.l140();}l28;l27 l20::l75:l1(l51==l20::
l45){l9&l60=l14<l18>();l11(l9 l59:l54)l60.l56(l59!=0.);l54.l140();}
l33 l1(l51==l20::l39){l9&l60=l14<l18>();l11(l9&l67:l99)l60.l56(!l67.
l62()&&l67!="\x46\x41\x4c\x53\x45");l99.l140();}l28;l84:l28;}l51=l168
;}l94 l13::l10()l2{l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l14<l7>().
l10();}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3 l14<l7>().l10
();}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l14<l7>().l10();}l47(
0);l28;}l84:l28;};l3 0;}l64<l18 l198,l100 l7>l18 l992(l2 l22<l7>&l14,
l2 l122<l4>&l12){l1(l14.l62())l3 l43;l4 l86=-1;l11(l4 l0=0;l0<(l4)l14
.l10();++l0){l1(l12.l63(l0)==l12.l40()){l86=l0;l28;}}l1(l86<0)l3 l43;
l7 l444=l14[l86];l11(l4 l0=l86+1;l0<(l4)l14.l10();++l0){l1 l89(l198){
l1(l14[l0]<=l444)l3 l57;}l33{l1(l14[l0]>=l444)l3 l57;}l444=l14[l0];}
l3 l43;}l50 l13::l140(){l51=l20::l153;l54.l140();l99.l140();l95.l140(
);l12.l140();}l857 l511{l4 l360;l4 l221;l4 l348;l4 l202;};l139 l79
l511 l684(l2 l6&l172,l4 l0,l4 l164,l18 l295){l1(l295)l3{l164,l172.l82
()-l164,l0,l0>=l172.l44()?0:1};l3{l0,l0>=l172.l82()?0:1,l164,l172.l44
()-l164};}l139 l79 l20 l798(l2 l6&l172,l2 l511&l148){l11(l4 l88=l148.
l360;l88<l148.l360+l148.l221;++l88)l11(l4 l48=l148.l348;l48<l148.l348
+l148.l202;++l48){l9 l168=l525(l172(l88,l48));l1(l168!=l20::l153)l3
l168;}l3 l20::l153;}l64<l100 l7>l50 l532(l13&l73,l2 l6&l172,l2 l511&
l148){l210<l7>(l73);l9&l14=l73.l14<l7>();l14.l81(l148.l221*l148.l202);
l4 l38=0;l11(l4 l88=0;l88<l148.l221;++l88)l11(l4 l48=0;l48<l148.l202;
++l48){l320{l14[l38]=l172(l148.l360+l88,l148.l348+l48).l36<l7>();}
l340(...){l73.l12.l70(l38);}++l38;}}l50 l13::l210(l2 l6&l172,l4 l0,l4
l164,l18 l295,l4 l37){l1(l37==0||l172.l34<l50>()){l140();l3;}l9 l148=
l684(l172,l0,l164,l295);l1(l37>0){l1(l148.l202!=1){l1(l148.l202>l37)l148
.l202=l37;}l33{l1(l148.l221>l37)l148.l221=l37;}}l51=l798(l172,l148);
l80(l51){l27 l20::l45:{l49 l7=l16;l53{l532<l7>( *l42,l172,l148);l3;}
l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l532<l7>( *l42,l172,
l148);l3;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l532<l7>( *l42,
l172,l148);l3;}l47(0);l28;}l84:l28;};l51=l20::l39;l99.l140();l99.l81(
l148.l221*l148.l202,"");l199();l3;}l50 l13::l210(l4 l37,l16 l8){l140(
);l51=l20::l45;l54.l81(l37,l8);}l64<l100 l7>l50 l611(l22<l7>&l14,l4
l37,l18 l378){l1(l378&&!l14.l62()&&l37>(l4)l14.l10())l14.l81(l37,l14.
l171());l33 l14.l81(l37);}l50 l13::l81(l4 l379,l18 l378){l4 l37=l29();
l80(l51){l27 l20::l45:{l49 l7=l16;l53{l611(l14<l7>(),l379,l378);}l47(
0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l611(l14<l7>(),l379,l378);}
l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l611(l14<l7>(),l379,l378);}
l47(0);l28;}l84:l28;};l1((l37>0&&l12.l63(l37-1)!=l12.l40())||!l378){
l11(l4 l0=l37;l0<l379;++l0)l12.l70(l0);}l1(l37>l379){l11(l9 l124=l12.
l72();l124!=l12.l40();){l1( *l124>=l379)l124=l12.l213(l124);l33++l124
;}}}l64<l100 l7>l18 l556(l2 l13&l141,l2 l13&l166){l2 l9&l801=l141.l14
<l7>();l2 l9&l799=l166.l14<l7>();l122<l7>l576;l11(l4 l0=0;l0<l141.l29
();++l0)l1(l141.l12.l63(l0)==l141.l12.l40())l576.l70(l801.l163(l0));
l11(l4 l0=0;l0<l166.l29();++l0)l1(l166.l12.l63(l0)==l166.l12.l40()&&
l576.l63(l799.l163(l0))!=l576.l40())l3 l43;l3 l57;}l50 l13::l70(l4 l90
,l2 l13&l73,l18 l315){l1(l73.l10()==0)l3;l1(l51==l20::l153&&l90==0){ *
l42=l73;l3;}l1(l90<0||l90>l29())l35 l41("\x69\x6e\x76\x61\x6c\x69\x64"
"\x20\x6c\x6f\x63\x61\x74\x69\x6f\x6e");l1(l73.l51!=l51)l35 l41("\x74"
"\x79\x70\x65\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x73\x61\x6d\x65"
);l1(!l315){l1(!l12.l62()&&!l73.l12.l62())l35 l41("\x66\x6f\x75\x6e"
"\x64\x20\x4e\x41\x20\x64\x75\x70\x6c\x69\x63\x61\x74\x65\x73");l18
l469=l43;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l469=l556<l7>( *l42,
l73);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l469=l556<l7>( *
l42,l73);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l469=l556<l7>( *
l42,l73);}l47(0);l28;}l84:l28;};l1(l469)l35 l41("\x68\x61\x76\x65\x20"
"\x64\x75\x70\x6c\x69\x63\x61\x74\x65\x73");}l4 l37=l73.l29();l122<l4
>l783;l11(l9 l0:l12)l783.l70(l0>=l90?l0+l37:l0);l11(l9 l0:l73.l12)l783
.l70(l0+l90);l80(l51){l27 l20::l45:{l49 l7=l16;l53{l14<l7>().l70(l14<
l7>().l72()+l90,l73.l14<l7>().l72(),l73.l14<l7>().l40());}l47(0);l28;
}l27 l20::l39:{l49 l7=l24::l15;l53{l14<l7>().l70(l14<l7>().l72()+l90,
l73.l14<l7>().l72(),l73.l14<l7>().l40());}l47(0);l28;}l27 l20::l75:{
l49 l7=l18;l53{l14<l7>().l70(l14<l7>().l72()+l90,l73.l14<l7>().l72(),
l73.l14<l7>().l40());}l47(0);l28;}l84:l28;};}l64<l100 l7>l50 l548(l6&
l8,l2 l511&l192,l2 l13&l14,l4 l37){l4 l38=0;l2 l9&l60=l14.l14<l7>();
l11(l4 l0=l192.l360;l0<l192.l360+l192.l221;++l0)l11(l4 l31=l192.l348;
l31<l192.l348+l192.l202;++l31){l1(l38>=l37)l3;l8(l0,l31)=l60[l38];++
l38;}l1(l192.l221==1){l11(l9 l0:l14.l12){l1(l0>=l37)l69;l8(l192.l360,
l192.l348+l0).l443(l377);}}l33{l11(l9 l0:l14.l12){l1(l0>=l37)l69;l8(
l192.l360+l0,l192.l348).l443(l377);}}l3;}l4 l13::l46(l6&l8,l4 l0,l4
l164,l18 l295)l2{l1(l51==l20::l153)l3 0;l4 l303=l29();l1(!l8.l191()&&
l303==1&&l0==0&&l164==0){l1(l12.l63(0)!=l12.l40())l8.l443(l377);l33
l80(l51){l27 l20::l45:{l49 l7=l16;l53{l8=l14<l7>()[0];}l47(0);l28;}
l27 l20::l39:{l49 l7=l24::l15;l53{l8=l14<l7>()[0];}l47(0);l28;}l27 l20
::l75:{l49 l7=l18;l53{l8=l14<l7>()[0];}l47(0);l28;}l84:l28;};l3 0;}l9
l192=l684(l8,l0,l164,l295);l4 l37=l24::l294(l192.l202*l192.l221,l303);
l80(l51){l27 l20::l45:{l49 l7=l16;l53{l548<l7>(l8,l192, *l42,l37);}
l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l548<l7>(l8,l192, *l42,
l37);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l548<l7>(l8,l192, *l42
,l37);}l47(0);l28;}l84:l28;};l3 l24::l333(l303-l37,0);}l6 l13::l46(
l18 l295)l2{l6 l651(l295?l29():1,l295?1:l29());l46(l651,0,0,l295);l3
l651;}l64<l100 l7>l4 l395(l2 l13&l73,l2 l6&l8){l9 l291=l8.l36<l7>();
l9&l14=l73.l14<l7>();l11(l4 l0=0;l0<(l4)l14.l10();++l0){l1(l291==l14.
l163(l0)&&l73.l12.l63(l0)==l73.l12.l40())l3 l0;}l3-1;}l4 l13::l30(l2
l6&l8)l2{l9 l291=l525(l8);l1(l291==l20::l153){l1(l12.l62())l3-1;l3*
l12.l72();}l1(l51!=l291)l3-1;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3
l395<l7>( *l42,l8);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3
l395<l7>( *l42,l8);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l395<
l7>( *l42,l8);}l47(0);l28;}l84:l28;};l3-1;}l64<l100 l7>l22<l4>l530(l2
l13&l73,l2 l6&l8){l22<l4>l5;l5.l101(l73.l10());l9 l291=l8.l36<l7>();
l9&l14=l73.l14<l7>();l11(l4 l0=0;l0<(l4)l14.l10();++l0){l1(l291==l14.
l163(l0)&&l73.l12.l63(l0)==l73.l12.l40())l5.l56(l0);}l3 l5;}l24::l22<
l4>l13::l760(l2 l6&l8)l2{l9 l291=l525(l8);l1(l291==l20::l153){l1(l12.
l62())l3{};l3{ *l12.l72()};}l1(l51!=l291)l3{};l80(l51){l27 l20::l45:{
l49 l7=l16;l53{l3 l530<l7>( *l42,l8);}l47(0);l28;}l27 l20::l39:{l49 l7
=l24::l15;l53{l3 l530<l7>( *l42,l8);}l47(0);l28;}l27 l20::l75:{l49 l7
=l18;l53{l3 l530<l7>( *l42,l8);}l47(0);l28;}l84:l28;};l3{};}l4 l13::
l30(l2 l24::l15&l8)l2{l80(l51){l27 l20::l45:{l49 l7=l16;l9 l189=l500(
l8);l53{l3 l395<l7>( *l42,l6(l189));}l47(0);l28;}l27 l20::l39:{l49 l7
=l24::l15;l9 l189=l8;l53{l3 l395<l7>( *l42,l6(l189));}l47(0);l28;}l27
l20::l75:{l49 l7=l18;l9 l189=l8=="\x54\x52\x55\x45"||l8=="\x74\x72"
"\x75\x65";l53{l3 l395<l7>( *l42,l6(l189));}l47(0);l28;}l84:l28;};l3-
1;}l13 l13::l863(l2 l22<l4>&l30,l18 l724)l2{l122<l4>l716(l30.l72(),
l30.l40());l13 l160;l160.l51=l20::l75;l160.l95.l81(l29());l11(l4 l0=0
;l0<l29();++l0)l160.l95[l0]=l716.l63(l0)!=l716.l40()?l724:!l724;l3
l160;}l24::l22<l4>l13::l893(l18 l814,l18 l621)l2{l1(l51!=l20::l75)l3{
};l22<l4>l5;l5.l101(l10());l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)!=
l12.l40()){l1(!l621)l5.l56(l0);l69;}l18 l14=l95[l0];l1(!l814)l14=!l14
;l1(l14)l5.l56(l0);}l3 l5;}l6 l13::l91(l4 l0)l2{l1(l51==l20::l153||l0
<0||l0>=l29()||l12.l63(l0)!=l12.l40())l3 l428();l80(l51){l27 l20::l45
:{l49 l7=l16;l53{l3 l14<l7>()[l0];}l47(0);l28;}l27 l20::l39:{l49 l7=
l24::l15;l53{l3 l14<l7>()[l0];}l47(0);l28;}l27 l20::l75:{l49 l7=l18;
l53{l3 l14<l7>()[l0];}l47(0);l28;}l84:l28;};l3 l428();}l50 l13::l91(
l4 l0,l2 l98::l6&l8,l26 l55){l1(l51==l20::l153)l35 l41("\x69\x6e\x63"
"\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x74\x79\x70\x65\x73");l1(l0
<0||l0>=l29())l35 l968("\x69\x6e\x64\x65\x78\x20\x6f\x75\x74\x20\x6f"
"\x66\x20\x72\x61\x6e\x67\x65");l1(l8.l34<l50>()||l8.l540()){l12.l70(
l0);l3;}l1(l55==l26::l506){l320{l80(l51){l27 l20::l45:{l49 l7=l16;l9
l189=l8.l36<l7>();l53{l14<l7>()[l0]=l189;}l47(0);l28;}l27 l20::l39:{
l49 l7=l24::l15;l9 l189=l327(l8);l53{l14<l7>()[l0]=l189;}l47(0);l28;}
l27 l20::l75:{l49 l7=l18;l9 l189=l8.l36<l7>();l53{l14<l7>()[l0]=l189;
}l47(0);l28;}l84:l28;};l12.l213(l0);}l340(...){l35 l41("\x63\x6f\x75"
"\x6c\x64\x20\x6e\x6f\x74\x20\x61\x73\x73\x69\x67\x6e");}}l33{l320{
l80(l51){l27 l20::l45:{l49 l7=l16;l9 l189=l8.l36<l7>();l53{l14<l7>()[
l0]=l401((l7)l14<l7>()[l0],l189,l55);}l47(0);l28;}l27 l20::l39:{l49 l7
=l24::l15;l9 l189=l327(l8);l53{l14<l7>()[l0]=l401((l7)l14<l7>()[l0],
l189,l55);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l9 l189=l8.l36<l7>();
l53{l14<l7>()[l0]=l401((l7)l14<l7>()[l0],l189,l55);}l47(0);l28;}l84:
l28;};l12.l213(l0);}l340(...){l35 l41("\x63\x6f\x75\x6c\x64\x20\x6e"
"\x6f\x74\x20\x61\x73\x73\x69\x67\x6e");}}}l50 l13::l91(l4 l0,l2 l13&
l73,l4 l382){l1(l73.l51!=l51||l73.l12.l63(l382)!=l73.l12.l40()||l382<
0||l382>=l73.l29()){l12.l70(l0);l3;}l12.l213(l0);l80(l51){l27 l20::
l45:{l49 l7=l16;l53{l14<l7>()[l0]=l73.l14<l7>()[l382];l3;}l47(0);l28;
}l27 l20::l39:{l49 l7=l24::l15;l53{l14<l7>()[l0]=l73.l14<l7>()[l382];
l3;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l14<l7>()[l0]=l73.l14<l7
>()[l382];l3;}l47(0);l28;}l84:l28;};}l13 l13::l125(l2 l22<l4>&l30,l2
l6*l8)l2{l13 l5;l5.l51=l51;l1(l51==l20::l153)l3 l5;l22<l4>l25;l25.
l101(l30.l10());l11(l4 l0=0;l0<(l4)l30.l10();++l0){l9 l38=l30[l0];l1(
l38<0||l38>=l29()||l12.l63(l38)!=l12.l40()){l5.l12.l70(l0);l25.l56(0);
}l33 l25.l56(l38);}l80(l51){l27 l20::l45:{l49 l7=l16;l53{l5.l14<l7>().
l101(l25.l10());l11(l9 l0:l25)l5.l14<l7>().l56(l14<l7>()[l0]);}l47(0);
l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l5.l14<l7>().l101(l25.l10());
l11(l9 l0:l25)l5.l14<l7>().l56(l14<l7>()[l0]);}l47(0);l28;}l27 l20::
l75:{l49 l7=l18;l53{l5.l14<l7>().l101(l25.l10());l11(l9 l0:l25)l5.l14
<l7>().l56(l14<l7>()[l0]);}l47(0);l28;}l84:l28;};l1(l8){l11(l4 l0=0;
l0<(l4)l30.l10();++l0){l9 l38=l30[l0];l1(l38<0||l38>=l29())l5.l91(l0,
 *l8);}}l3 l5;}l50 l13::l216(l2 l6&l8,l4 l109){l9 l820=l12;l4 l128=0;
l4 l879=l109>0?l109:(l4)l12.l10();l11(l9 l0:l820){l91(l0,l8);++l128;
l1(l128>=l879)l28;}}l50 l695(l13&l108,l136 l102,l4 l109,l2 l122<l4>
l397){l22<l4>l30(l397.l72(),l397.l40());l1(l102==l136::l562){l152(l30
.l72(),l30.l40());l11(l9 l0:l30){l11(l4 l31=1;l31<=(l109>0?l24::l294(
l109,l0):l0);++l31){l4 l38=l0-l31;l1(l397.l63(l38)!=l397.l40())l69;
l108.l91(l0,l108,l38);l28;}}}l33 l1(l102==l136::l750){l152(l30.l72(),
l30.l40(),l432<l4>());l11(l9 l0:l30){l11(l4 l31=1;l31<=(l109>0?l24::
l294(l109,l108.l29()-l0-1):l108.l29()-l0-1);++l31){l4 l38=l0+l31;l1(
l397.l63(l38)!=l397.l40())l69;l108.l91(l0,l108,l38);l28;}}}}l50 l13::
l216(l136 l311,l4 l109){l1(l12.l62()||l311==l136::l359)l3;l695( *l42,
l311,l109,l12);}l50 l13::l199(){l11(l4 l0=0;l0<l29();++l0)l12.l70(l0);
}l64<l100 l7>l22<l4>l490(l2 l22<l7>&l108,l2 l22<l7>&l90,l18 l371=l57){
l297<l7,l4>l334;l11(l4 l0=0;l0<(l4)l108.l10();++l0){l1(l334.l128(l108
[l0])>0)l35("\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x20\x6b\x65\x79\x20"
"\x64\x65\x74\x65\x63\x74\x65\x64");l334[l108[l0]]=l0;}l22<l4>l5;l5.
l101(l90.l10());l11(l2 l9&l887:l90){l9 l38=l334.l63(l887);l1(l38==
l334.l40()){l1(!l371)l35("\x23\x20\x6b\x65\x79\x20\x65\x72\x72\x6f"
"\x72");l5.l56(-1);}l33 l5.l56(l38->l169);}l3 l5;}l22<l4>l748(l2 l22<
l16>&l14,l16 l386){l177(l386>0);l22<l4>l5;l5.l101(l14.l10());l11(l9&
l8:l14)l5.l56(l4(l8/l386));l3 l5;}l64<l100 l7>l79 l4 l848(l2 l22<l7>&
l14,l2 l7&l52,l18 l198){l9 l124=l198?l564(l14.l72(),l14.l40(),l52):
l610(l14.l72(),l14.l40(),l52,l24::l432<l7>());l1(l124==l14.l72()&& *
l124!=l52)l3-1;l33 l1(l124!=l14.l72()&&(l124==l14.l40()|| *l124!=l52))l3
(l4)l424(l14.l72(),l124-1);l33 l3(l4)l424(l14.l72(),l124);}l64<l100 l7
>l79 l4 l920(l2 l22<l7>&l14,l2 l7&l52,l18 l198){l9 l124=l198?l610(l14
.l72(),l14.l40(),l52):l564(l14.l72(),l14.l40(),l52,l24::l432<l7>());
l1(l124==l14.l40())l3-1;l33 l3(l4)l424(l14.l72(),l124);}l64<l100 l7>
l79 l50 l539(l2 l22<l7>&l8,l2 l22<l7>&l58,l22<l4>&l30){l18 l198=l8.
l666()<=l8.l171();l11(l94 l0=0;l0<l58.l10();++l0){l1(l30[l0]==-1)l30[
l0]=l848(l8,l58[l0],l198);}}l64<l100 l7>l79 l50 l553(l2 l22<l7>&l8,l2
l22<l7>&l58,l22<l4>&l30){l18 l198=l8.l666()<=l8.l171();l11(l24::l94 l0
=0;l0<l58.l10();++l0){l1(l30[l0]==-1)l30[l0]=l920(l8,l58[l0],l198);}}
l79 l22<l4>&l812(l2 l13&l8,l2 l13&l58,l22<l4>&l30){l80(l8.l93()){l27
l20::l45:{l49 l7=l16;l53{l539(l8.l14<l7>(),l58.l14<l7>(),l30);l3 l30;
}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l539(l8.l14<l7>(),l58.
l14<l7>(),l30);l3 l30;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l539(
l8.l14<l7>(),l58.l14<l7>(),l30);l3 l30;}l47(0);l28;}l84:l28;};l3 l30;
}l79 l22<l4>&l888(l2 l13&l8,l2 l13&l58,l22<l4>&l30){l80(l8.l93()){l27
l20::l45:{l49 l7=l16;l53{l553(l8.l14<l7>(),l58.l14<l7>(),l30);l3 l30;
}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l553(l8.l14<l7>(),l58.
l14<l7>(),l30);l3 l30;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l553(
l8.l14<l7>(),l58.l14<l7>(),l30);l3 l30;}l47(0);l28;}l84:l28;};l3 l30;
}l79 l22<l4>&l836(l2 l13&l8,l2 l13&l58,l22<l4>&l30){l1(l8.l93()!=l20
::l45)l35 l41("\x6e\x65\x61\x72\x65\x73\x74\x20\x63\x61\x6e\x20\x62"
"\x65\x20\x75\x73\x65\x64\x20\x6f\x6e\x6c\x79\x20\x77\x69\x74\x68\x20"
"\x6e\x75\x6d\x65\x72\x69\x63\x61\x6c\x20\x76\x65\x63\x74\x6f\x72\x73"
);l9 l697=l759(l8.l54,l58.l54);l177(l697.l10()==l30.l10());l11(l94 l0
=0;l0<l30.l10();++l0)l1(l30[l0]<0)l30[l0]=l697[l0];l3 l30;}l22<l4>l13
::l74(l2 l13&l90,l18 l371,l16 l239,l136 l102,l4 l109)l2{l1( *l42==l90
)l3 l756(l29());l1(!l12.l62()||!l90.l12.l62())l35 l41("\x6c\x6f\x63"
"\x5f\x69\x64\x78\x20\x77\x6f\x72\x6b\x73\x20\x6f\x6e\x6c\x79\x20\x6f"
"\x6e\x20\x76\x65\x63\x74\x6f\x72\x73\x20\x77\x69\x74\x68\x6f\x75\x74"
"\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x73");l22<
l4>l5;l1(l51!=l90.l51){l5.l81(l90.l10(),-1);l3 l5;}l80(l51){l27 l20::
l45:l5=l239>0?l490(l748(l54,l239),l748(l90.l54,l239),l371):l490(l54,
l90.l54,l371);l28;l27 l20::l39:l5=l490(l99,l90.l99,l371);l28;l27 l20
::l75:l5=l490(l95,l90.l95,l371);l28;l84:l28;}l1(!l371)l3 l5;l1(l102==
l136::l359)l3 l5;l9 l788=l198();l9 l867=l427();l1(!l788&&!l867)l35 l41
("\x76\x65\x63\x74\x6f\x72\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65"
"\x20\x6d\x6f\x6e\x6f\x74\x6f\x6e\x6f\x75\x73");l80(l102){l27 l136::
l750:l3 l888( *l42,l90,l5);l27 l136::l562:l3 l812( *l42,l90,l5);l27
l136::l513:l3 l836( *l42,l90,l5);l84:l3 l5;}}l64<l100 l7>l22<l22<l4>>
l613(l2 l22<l7>&l108,l2 l122<l4>&l578,l2 l22<l7>&l90,l2 l122<l4>&l726
){l297<l7,l22<l4>>l334;l11(l4 l0=0;l0<(l4)l108.l10();++l0){l1(l578.
l128(l0)>0)l69;l334[l108[l0]].l56(l0);}l22<l22<l4>>l5;l5.l101(l90.l10
());l22<l4>l12{l578.l72(),l578.l40()};l11(l4 l0=0;l0<(l4)l90.l10();++
l0){l1(l726.l63(l0)!=l726.l40()){l5.l56(l12);l69;}l9 l38=l334.l63(l90
[l0]);l1(l38==l334.l40())l5.l56({});l33 l5.l56(l38->l169);}l3 l5;}l22
<l22<l4>>l13::l615(l2 l13&l90)l2{l1(l51!=l90.l51){l22<l22<l4>>l5;l5.
l81(l90.l10());l3 l5;}l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l613(
l14<l7>(),l12,l90.l14<l7>(),l90.l12);}l47(0);l28;}l27 l20::l39:{l49 l7
=l24::l15;l53{l3 l613(l14<l7>(),l12,l90.l14<l7>(),l90.l12);}l47(0);
l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l613(l14<l7>(),l12,l90.l14<l7>(),
l90.l12);}l47(0);l28;}l84:l28;};l3{};}l18 l13::l198()l2{l1(!l12.l62())l3
l57;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l399(l14<l7>().l72(),l14
<l7>().l40());}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3 l399(
l14<l7>().l72(),l14<l7>().l40());}l47(0);l28;}l27 l20::l75:{l49 l7=
l18;l53{l3 l399(l14<l7>().l72(),l14<l7>().l40());}l47(0);l28;}l84:l28
;};l3 l57;}l18 l13::l427()l2{l1(!l12.l62())l3 l57;l80(l51){l27 l20::
l45:{l49 l7=l16;l53{l3 l399(l14<l7>().l72(),l14<l7>().l40(),l432<l7>(
));}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3 l399(l14<l7>().
l72(),l14<l7>().l40(),l432<l7>());}l47(0);l28;}l27 l20::l75:{l49 l7=
l18;l53{l3 l399(l14<l7>().l72(),l14<l7>().l40(),l432<l7>());}l47(0);
l28;}l84:l28;};l3 l57;}l64<l100 l7>l4 l603(l2 l22<l7>&l14,l7 l8,l18
l184){l1(l14.l62())l3-1;l7 l130=l14[0];l1(l184){l4 l5=l8<l130?-1:0;
l11(l4 l0=1;l0<(l4)l14.l10();++l0){l1(l14[l0]<=l130)l3-2;l130=l14[l0]
;l1(l8>=l130)l5=l0;}l3 l5;}l33{l4 l5=l8<=l130?0:-1;l11(l4 l0=1;l0<(l4
)l14.l10();++l0){l1(l14[l0]<=l130)l3-2;l130=l14[l0];l1(l5<0&&l8<=l130
)l5=l0;}l3 l5;}}l64<l100 l7>l4 l575(l2 l22<l7>&l14,l7 l8,l18 l184){l1
(l14.l62())l3-1;l7 l130=l14.l171();l4 l37=(l4)l14.l10();l1(l184){l4 l5
=l8<l130?-1:l37-1;l11(l4 l0=1;l0<l37;++l0){l4 l38=l37-1-l0;l1(l14[l38
]<=l130)l3-2;l130=l14[l38];l1(l8>=l130)l5=l38;}l3 l5;}l33{l4 l5=l8<=
l130?l37-1:-1;l11(l4 l0=1;l0<l37;++l0){l4 l38=l37-1-l0;l1(l14[l38]<=
l130)l3-2;l130=l14[l38];l1(l5<0&&l8<=l130)l5=l38;}l3 l5;}}l4 l13::
l198(l2 l13&l8,l18 l184)l2{l1(l51!=l8.l51)l35 l41("\x75\x6e\x65\x71"
"\x75\x61\x6c\x20\x74\x79\x70\x65\x73");l1(l8.l10()!=1||!l8.l12.l62())l35
l41("\x62\x61\x64\x20\x76\x61\x6c\x75\x65");l1(!l12.l62())l35 l41(""
"\x73\x68\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x68\x61\x76\x65\x20\x4e"
"\x41\x73");l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l603(l14<l7>(),
l8.l14<l7>()[0],l184);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{
l3 l603(l14<l7>(),l8.l14<l7>()[0],l184);}l47(0);l28;}l27 l20::l75:{
l49 l7=l18;l53{l3 l603(l14<l7>(),l8.l14<l7>()[0],l184);}l47(0);l28;}
l84:l28;};l3-2;}l4 l13::l427(l2 l13&l8,l18 l184)l2{l1(l51!=l8.l51)l35
l41("\x75\x6e\x65\x71\x75\x61\x6c\x20\x74\x79\x70\x65\x73");l1(l8.l10
()!=1||!l8.l12.l62())l35 l41("\x62\x61\x64\x20\x76\x61\x6c\x75\x65");
l1(!l12.l62())l35 l41("\x73\x68\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20"
"\x68\x61\x76\x65\x20\x4e\x41\x73");l80(l51){l27 l20::l45:{l49 l7=l16
;l53{l3 l575(l14<l7>(),l8.l14<l7>()[0],l184);}l47(0);l28;}l27 l20::
l39:{l49 l7=l24::l15;l53{l3 l575(l14<l7>(),l8.l14<l7>()[0],l184);}l47
(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l575(l14<l7>(),l8.l14<l7>()[
0],l184);}l47(0);l28;}l84:l28;};l3-2;}l22<l4>l13::l725(l2 l13*l259,l2
l15*l316,l2 l15*l180)l2{l1(l4(l259==l106)+l4(l316==l106)+l4(l180==
l106)!=2)l35 l41("\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x6f\x66\x20"
"\x69\x74\x65\x6d\x73\x2c\x20\x6c\x69\x6b\x65\x2c\x20\x72\x65\x67\x65"
"\x78\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x75\x73\x65\x64");
l1(l259)l3 l245( *l259,l57).l893(l12.l62());l1(l316)l3 l853( *l316);
l1(l180)l3 l593( *l180);l3{};}l24::l22<l4>l13::l473(l16 l273,l16 l154
)l2{l1(l273<0||l154<0)l35("\x74\x69\x6d\x65\x20\x61\x6e\x64\x20\x64"
"\x74\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x6e\x6f\x6e\x2d\x6e"
"\x65\x67\x61\x74\x69\x76\x65");l273-=l318(l273);l1(l51!=l20::l45)l35
("\x61\x74\x5f\x74\x69\x6d\x65\x20\x69\x73\x20\x6f\x6e\x6c\x79\x20"
"\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x75\x6d"
"\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");l4 l37=l29();l22<
l4>l5;l5.l101(l37);l11(l4 l0=0;l0<l37;++l0){l1(l12.l63(l0)==l12.l40()&&
l690(l54[l0]-l318(l54[l0])-l273)<=l154)l5.l56(l0);}l3 l5;}l24::l22<l4
>l13::l502(l16 l265,l16 l270,l260 l370,l16 l154)l2{l1(l265<0||l270<0)l35
("\x74\x69\x6d\x65\x31\x20\x61\x6e\x64\x20\x74\x69\x6d\x65\x32\x20"
"\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x6e\x6f\x6e\x2d\x6e\x65\x67"
"\x61\x74\x69\x76\x65");l265-=l318(l265);l270-=l318(l270);l1(l265>
l270)l3{};l1(l51!=l20::l45)l35("\x62\x65\x74\x77\x65\x65\x6e\x5f\x74"
"\x69\x6d\x65\x20\x69\x73\x20\x6f\x6e\x6c\x79\x20\x73\x75\x70\x70\x6f"
"\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x75\x6d\x65\x72\x69\x63\x20"
"\x76\x65\x63\x74\x6f\x72\x73");l1(l154<0)l35("\x64\x74\x20\x73\x68"
"\x6f\x75\x6c\x64\x20\x62\x65\x20\x6e\x6f\x6e\x2d\x6e\x65\x67\x61\x74"
"\x69\x76\x65");l4 l37=l29();l22<l4>l5;l5.l101(l37);l80(l370){l27 l260
::l635:l11(l4 l0=0;l0<l37;++l0){l1(l12.l63(l0)==l12.l40()){l16 l168=
l54[l0]-l318(l54[l0]);l1(l168>=l265-l154&&l168<=l270+l154)l5.l56(l0);
}}l3 l5;l27 l260::l508:l11(l4 l0=0;l0<l37;++l0){l1(l12.l63(l0)==l12.
l40()){l16 l168=l54[l0]-l318(l54[l0]);l1(l168>=l265-l154&&l168<l270-
l154)l5.l56(l0);}}l3 l5;l27 l260::l450:l11(l4 l0=0;l0<l37;++l0){l1(
l12.l63(l0)==l12.l40()){l16 l168=l54[l0]-l318(l54[l0]);l1(l168>l265+
l154&&l168<=l270+l154)l5.l56(l0);}}l3 l5;l27 l260::l825:l11(l4 l0=0;
l0<l37;++l0){l1(l12.l63(l0)==l12.l40()){l16 l168=l54[l0]-l318(l54[l0]
);l1(l168>l265+l154&&l168<l270-l154)l5.l56(l0);}}l3 l5;l84:l3 l5;}}
l18 l833(l2 l6&l67){l1(l67.l34<l15>()){l9 l203=l67.l36<l15>();l3 l203
.l63(':')!=l15::l258;}l3 l57;}l22<l4>l13::l74(l2 l6&l103,l13*l393,
l297<l4,l4> *l485)l2{l1(l393)l393->l140();l1(l485)l485->l140();l4 l37
=l29();l22<l4>l5;l1(l103.l34<l50>()){l5.l81(l37);l11(l4 l0=0;l0<l37;
++l0)l5[l0]=l0;l3 l5;}l1(l51==l20::l153)l3 l5;l1(l833(l103)){l80(l51){
l27 l20::l45:l3 l749(l54,l103.l36<l15>());l27 l20::l39:l3 l749(l99,
l103.l36<l15>());l84:l35("\x20\x62\x61\x64\x20\x76\x61\x6c\x75\x65");
}}l5=l523(l103,l37);l1(!l5.l62())l3 l5;l1(l103.l44()==1||l103.l82()==
1){l13 l90(l103,0,0,l103.l44()==1);l9 l5=l74(l90,l43);l1(l393){l177(
l485);l393->l51=l90.l51;l11(l4 l0=0;l0<l90.l29();++l0){l1(l5[l0]>=0)l69
;l393->l56(l90,l0);( *l485)[l0]=l393->l29()-1;}}l3 l5;}l1(l103.l82()>
1&&l103.l44()==2&&l103(1,1).l34<l18>()){l17 l160(l103);l1(l160.l25.
l51!=l51)l35("\x23\x20\x6b\x65\x79\x20\x65\x72\x72\x6f\x72");l1(l160.
l21.l62()||l160.l21[0].l51!=l20::l75)l35("\x23\x20\x6b\x65\x79\x20"
"\x65\x72\x72\x6f\x72");l9 l125=l74(l160.l25,l43);l5.l81(0);l5.l101(
l125.l10());l11(l4 l0=0;l0<l160.l25.l29();++l0){l1(l125[l0]<0)l69;l1(
l160.l21[0].l95[l0])l5.l56(l125[l0]);}l3 l5;}l35("\x23\x20\x62\x61"
"\x64\x20\x76\x61\x6c\x75\x65");}l4 l13::l451()l2{l4 l37=l29();l1(l37
==(l4)l12.l10())l3-1;l4 l5=0;l47(l12.l63(l5)!=l12.l40()&&l5<l37){++l5
;}l1(l5>=l37)l3-1;l3 l5;}l64<l100 l7,l18 l897=l43>l4 l400(l2 l13&l73){
l2 l22<l7>&l14=l73.l14<l7>();l4 l37=(l4)l14.l10();l4 l86=l73.l451();
l1(l86<0)l3-1;l4 l5=l86;l7 l238=l14.l163(l86);l11(l4 l0=l86+1;l0<l37;
++l0){l1(l73.l12.l63(l0)!=l73.l12.l40())l69;l2 l7 l479=l14.l163(l0);
l1 l89(l897){l1(l479<l238){l238=l479;l5=l0;}}l33{l1(l479>l238){l238=
l479;l5=l0;}}}l3 l5;}l4 l13::l534()l2{l80(l51){l27 l20::l45:{l49 l7=
l16;l53{l3 l400<l7>( *l42);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15
;l53{l3 l400<l7>( *l42);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3
l400<l7>( *l42);}l47(0);l28;}l84:l28;};l3-1;}l4 l13::l614()l2{l80(l51
){l27 l20::l45:{l49 l7=l16;l53{l9 l0=(l400<l7,l57>( *l42));l3 l0;}l47
(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l9 l0=(l400<l7,l57>( *l42));
l3 l0;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l9 l0=(l400<l7,l57>( *
l42));l3 l0;}l47(0);l28;}l84:l28;};l3-1;}l64<l100 l7>l4 l580(l2 l13&
l73){l2 l9&l14=l73.l14<l7>();l122<l7>l649;l11(l4 l0=0;l0<(l4)l14.l10(
);++l0){l1(l73.l12.l63(l0)==l73.l12.l40())l649.l70(l14[l0]);}l3(l4)l649
.l10();}l64<l100 l7>l7 l387(l2 l13&l73,l4&l255){l2 l9&l14=l73.l14<l7>
();l297<l7,l4>l388;l11(l4 l0=0;l0<(l4)l14.l10();++l0){l1(l73.l12.l63(
l0)==l73.l12.l40())l388[l14[l0]]++;}l4 l313=0;l7 l5=l7();l11(l2 l9&[
l146,l14]:l388){l1(l14>l313){l313=l14;l5=l146;}}l255=l313;l3 l5;}l98
::l6 l13::l851()l2{l4 l255=0;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3
l387<l7>( *l42,l255);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{
l3 l387<l7>( *l42,l255);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3
l387<l7>( *l42,l255);}l47(0);l28;}l84:l28;};l3 l6::l1049(l377);}l4 l13
::l255()l2{l4 l255=0;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l387<l7>( *
l42,l255);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l387<l7>( *
l42,l255);}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l387<l7>( *l42,
l255);}l47(0);l28;}l84:l28;};l3 l255;}l4 l13::l560()l2{l80(l51){l27
l20::l45:{l49 l7=l16;l53{l3 l580<l7>( *l42);}l47(0);l28;}l27 l20::l39
:{l49 l7=l24::l15;l53{l3 l580<l7>( *l42);}l47(0);l28;}l27 l20::l75:{
l49 l7=l18;l53{l3 l580<l7>( *l42);}l47(0);l28;}l84:l28;};l3 0;}l64<
l100 l7>l50 l531(l22<l18>&l5,l2 l22<l7>&l8,l2 l22<l7>&l14,l2 l122<l4>
&l292,l2 l122<l4>&l312,l18 l410){l5.l81(l8.l10());l1(l410){l11(l4 l0=
0;l0<(l4)l8.l10();++l0){l1(l292.l63(l0)!=l292.l40()){l5[l0]=l312.l128
(l0)!=0;l69;}l1(l312.l63(l0)!=l312.l40()){l5[l0]=l57;l69;}l5[l0]=l0<
l14.l10()&&l8[l0]==l14[l0];}}l33{l122<l7>l60;l11(l4 l0=0;l0<(l4)l14.
l10();++l0){l1(l312.l63(l0)!=l312.l40())l69;l60.l70(l14[l0]);}l11(l4
l0=0;l0<(l4)l8.l10();++l0){l1(l292.l63(l0)!=l292.l40()){l5[l0]=!l312.
l62();l69;}l5[l0]=l60.l63(l8[l0])!=l60.l40();}}}l13 l13::l245(l2 l13&
l120,l18 l410)l2{l13 l5;l5.l51=l20::l75;l5.l95.l81(l10(),l57);l1(l120
.l51!=l51)l3 l5;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l531(l5.l95,l14
<l7>(),l120.l14<l7>(),l12,l120.l12,l410);l3 l5;}l47(0);l28;}l27 l20::
l39:{l49 l7=l24::l15;l53{l531(l5.l95,l14<l7>(),l120.l14<l7>(),l12,
l120.l12,l410);l3 l5;}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l531(
l5.l95,l14<l7>(),l120.l14<l7>(),l12,l120.l12,l410);l3 l5;}l47(0);l28;
}l84:l28;};l3 l5;}l64<l100 l7>l50 l568(l22<l18>&l5,l2 l22<l7>&l8,l2
l22<l7>&l14,l2 l122<l4>&l292,l2 l122<l4>&l312,l2 l22<l4>&l30){l5.l140
();l5.l81(l8.l10(),l57);l4 l37=(l4)l8.l10();l4 l541=(l4)l14.l10();l11
(l4 l0=0;l0<(l4)l30.l10();++l0){l4 l38=l30[l0];l1(l38<0||l38>=l37)l69
;l1(l0>=l541)l28;l1(l312.l63(l0)!=l312.l40()){l5[l38]=l292.l63(l38)!=
l292.l40();l69;}l1(l292.l63(l38)!=l292.l40())l69;l5[l38]=l8[l38]==l14
[l0];}}l13 l13::l245(l2 l13&l120,l2 l22<l4>&l30)l2{l13 l5;l5.l51=l20
::l75;l5.l95.l81(l10(),l57);l1(l120.l51!=l51)l3 l5;l80(l51){l27 l20::
l45:{l49 l7=l16;l53{l568(l5.l95,l14<l7>(),l120.l14<l7>(),l12,l120.l12
,l30);l3 l5;}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l568(l5.
l95,l14<l7>(),l120.l14<l7>(),l12,l120.l12,l30);l3 l5;}l47(0);l28;}l27
l20::l75:{l49 l7=l18;l53{l568(l5.l95,l14<l7>(),l120.l14<l7>(),l12,
l120.l12,l30);l3 l5;}l47(0);l28;}l84:l28;};l3 l5;}l13 l13::l245(l2 l22
<l13>&l131)l2{l1(l131.l62())l3 l13(l22<l18>(l10(),l57));l9 l5=l245(
l131[0],l43);l11(l94 l0=1;l0<l131.l10();++l0)l5=l5.l711(l245(l131[l0]
,l43));l3 l5;}l24::l22<l4>l13::l853(l2 l24::l15&l232)l2{l9 l73=l42;
l13 l61;l1(l51!=l20::l39){l61= *l42;l61.l301(l20::l39);l73=&l61;}l22<
l4>l5;l5.l101(l10());l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)!=l12.
l40())l69;l1(l73->l99[l0].l63(l232)!=l15::l258)l5.l56(l0);}l3 l5;}l79
l18 l795(l2 l15&l8,l2 l180&l583){l24::l499 l921(l8);l24::l15 l226;l47
(l24::l765(l921,l226)){l1(l24::l1022(l226,l583))l3 l43;}l3 l57;}l24::
l22<l4>l13::l593(l2 l24::l15&l507)l2{l9 l73=l42;l13 l61;l1(l51!=l20::
l39){l61= *l42;l61.l301(l20::l39);l73=&l61;}l22<l4>l5;l5.l101(l10());
l180 l583(l507);l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)!=l12.l40())l69
;l1(l795(l73->l99[l0],l583))l5.l56(l0);}l3 l5;}l13 l13::l786(l2 l13&
l160)l2{l1(l160.l93()!=l20::l75)l35 l41("\x4d\x61\x73\x6b\x20\x73\x68"
"\x6f\x75\x6c\x64\x20\x62\x65\x20\x62\x6f\x6f\x6c\x65\x61\x6e");l1(
l160.l10()!=l10())l35 l41("\x4d\x61\x73\x6b\x20\x69\x73\x20\x6e\x6f"
"\x74\x20\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x73\x69\x7a\x65"
);l22<l4>l30;l30.l101(l10());l11(l4 l0=0;l0<l29();++l0){l1(l160.l95[
l0])l30.l56(l0);}l9 l14= *l42;l14.l12.l70(l160.l12.l72(),l160.l12.l40
());l3 l14.l125(l30);}l13 l13::l746(l18 l776)l2{l13 l5;l5.l51=l20::
l75;l5.l95.l81(l10(),!l776);l11(l9 l0:l12)l5.l95[l0]=l776;l3 l5;}l139
l79 l122<l4>l811(l2 l13&l375,l2 l13&l658){l122<l4>l5;l11(l9 l0:l375.
l12)l1(l658.l12.l63(l0)!=l658.l12.l40())l5.l70(l0);l3 l5;}l64<l100...
>l79 l89 l18 l503=l57;l139 l79 l18 l429(l16 l52){l3 l24::l345(l52)==
l52;}l139 l79 l18 l763(l16&l5,l16 l8,l16 l58){l1(l8<0&&!l429(l58))l3
l57;l1(l8==0&&l58<0)l3 l57;l5=l496(l8,l58);l3 l43;}l64<l26 l68,l100 l7
>l79 l50 l642(l7&l5,l2 l7&l8,l4 l0,l122<l4>&l12){l1 l89(l68==l26::
l254){l5+=l8;}l33 l1 l89(l68==l26::l288){l5-=l8;}l33 l1 l89(l68==l26
::l350){l5=l8-l5;}l33 l1 l89(l68==l26::l284){l5*=l8;}l33 l1 l89(l68==
l26::l287){l1(l8==0)l12.l70(l0);l33 l5/=l8;}l33 l1 l89(l68==l26::l344
){l1(l5==0)l12.l70(l0);l33 l5=l8/l5;}l33 l1 l89(l68==l26::l289){l1(!
l763(l5,l5,l8))l12.l70(l0);}l33 l1 l89(l68==l26::l358){l1(!l763(l5,l8
,l5))l12.l70(l0);}l33 l1 l89(l68==l26::l279){l1(l8==0)l12.l70(l0);l33
{l1(l429(l5)&&l429(l8))l5=(l4)l5%(l4)l8;l33 l5=l605(l5,l8);}}l33 l1
l89(l68==l26::l364){l1(l5==0)l12.l70(l0);l33{l1(l429(l5)&&l429(l8))l5
=(l4)l8%(l4)l5;l33 l5=l605(l8,l5);}}l33 l1 l89(l68==l26::l280){l5=l5
&&l8;}l33 l1 l89(l68==l26::l286){l5=l5||l8;}l33 l1 l89(l68==l26::l144
){l5=l294(l5,l8);}l33 l1 l89(l68==l26::l142){l5=l333(l5,l8);}l33{l604
(l503<l68>,"\x4e\x6f\x6e\x20\x72\x65\x67\x75\x6c\x61\x72\x20\x62\x69"
"\x6e\x61\x72\x79\x20\x6f\x70");}}l64<l26 l68,l100 l7>l139 l79 l50
l640(l22<l7>&l5,l2 l7&l8,l4 l0,l122<l4>&l12){l642<l68>(l5[l0],l8,l0,
l12);}l64<l26 l68>l139 l79 l50 l640(l22<l18>&l5,l2 l18&l8,l4 l0,l122<
l4>&l12){l18 l88=l5[l0];l642<l68>(l88,l8,l0,l12);l5[l0]=l88;}l64<l26
l68,l100 l7>l50 l117(l22<l7>&l5,l2 l22<l7>&l14,l122<l4>&l12){l1(l14.
l10()>1&&l5.l10()!=l14.l10())l35 l41("\x43\x61\x6e\x6e\x6f\x74\x20"
"\x64\x6f\x20\x62\x69\x6e\x61\x72\x79\x20\x6f\x70\x20\x6f\x6e\x20\x76"
"\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20\x64\x69\x66\x66\x65\x72\x65"
"\x6e\x74\x20\x73\x69\x7a\x65\x73");l18 l317=l14.l10()==1;l11(l4 l0=0
;l0<(l4)l5.l10();++l0){l7 l8=l317?l14[0]:l14[l0];l640<l68>(l5,l8,l0,
l12);}}l64<l26 l68>l15 l700(){l1 l89(l68==l26::l254){l3"\x61\x64\x64"
;}l33 l1 l89(l68==l26::l288){l3"\x73\x75\x62\x74\x72\x61\x63\x74";}
l33 l1 l89(l68==l26::l350){l3"\x72\x65\x76\x65\x72\x73\x65\x20\x73"
"\x75\x62\x74\x72\x61\x63\x74";}l33 l1 l89(l68==l26::l284){l3"\x6d"
"\x75\x6c\x74\x69\x70\x6c\x79";}l33 l1 l89(l68==l26::l287){l3"\x64"
"\x69\x76\x69\x64\x65";}l33 l1 l89(l68==l26::l344){l3"\x72\x65\x76"
"\x65\x72\x73\x65\x20\x64\x69\x76\x69\x64\x65";}l33 l1 l89(l68==l26::
l289){l3"\x74\x61\x6b\x65\x20\x70\x6f\x77\x65\x72\x20\x6f\x66";}l33 l1
l89(l68==l26::l358){l3"\x74\x61\x6b\x65\x20\x72\x65\x76\x65\x72\x73"
"\x65\x20\x70\x6f\x77\x65\x72\x20\x6f\x66";}l33 l1 l89(l68==l26::l279
){l3"\x74\x61\x6b\x65\x20\x6d\x6f\x64\x75\x6c\x6f\x20\x6f\x66";}l33 l1
l89(l68==l26::l364){l3"\x74\x61\x6b\x65\x20\x72\x65\x76\x65\x72\x73"
"\x65\x20\x6d\x6f\x64\x75\x6c\x6f\x20\x6f\x66";}l33 l1 l89(l68==l26::
l280){l3"\x74\x61\x6b\x65\x20\x61\x6e\x64\x20\x6f\x66";}l33 l1 l89(
l68==l26::l286){l3"\x74\x61\x6b\x65\x20\x6f\x72\x20\x6f\x66";}l33 l1
l89(l68==l26::l144){l3"\x74\x61\x6b\x65\x20\x6d\x69\x6e\x20\x6f\x66";
}l33 l1 l89(l68==l26::l142){l3"\x74\x61\x6b\x65\x20\x6d\x61\x78\x20"
"\x6f\x66";}l33 l1 l89(l68==l26::l214||l68==l26::l211||l68==l26::l207
||l68==l26::l206||l68==l26::l212||l68==l26::l205){l3"\x63\x6f\x6d\x70"
"\x61\x72\x65";}l33 l1 l89(l68==l26::l1004){l3"\x63\x68\x6f\x6f\x73"
"\x65\x20\x66\x69\x72\x73\x74\x20\x6f\x66";}l33{l604(l503<l68>,"\x4e"
"\x6f\x6e\x20\x72\x65\x67\x75\x6c\x61\x72\x20\x62\x69\x6e\x61\x72\x79"
"\x20\x6f\x70");}}l64<l26 l68,l20 l274>l50 l401(l13&l5,l2 l13&l85){l1
l89(l274==l20::l45){l117<l68>(l5.l54,l85.l54,l5.l12);}l33 l1 l89(l274
==l20::l39){l117<l68>(l5.l99,l85.l99,l5.l12);}l33 l1 l89(l274==l20::
l75){l117<l68>(l5.l95,l85.l95,l5.l12);}l33{l604(l503<l274>,"\x55\x6e"
"\x6b\x6e\x6f\x77\x6e\x20\x74\x79\x70\x65");}}l64<l26 l68,l20 l274>
l13 l117(l2 l13&l112,l2 l13&l85,l2 l6*l78){l1(!l78&&l112.l12.l10()==
l112.l10()){l1(l85.l12.l10()==l85.l10())l3 l112;l9 l5=l112;l5.l246(
l85.l93());l3 l5;}l1(l112.l93()!=l274)l35 l41("\x43\x61\x6e\x6e\x6f"
"\x74\x20"+l700<l68>()+"\x20"+l461(l274)+"\x20\x64\x61\x74\x61\x76"
"\x65\x63\x74\x6f\x72\x73");l1(l85.l10()>1&&l112.l10()!=l85.l10())l35
l41("\x43\x61\x6e\x6e\x6f\x74\x20"+l700<l68>()+"\x20\x64\x61\x74\x61"
"\x76\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20\x64\x69\x66\x66\x65\x72"
"\x65\x6e\x74\x20\x73\x69\x7a\x65\x73");l1(l112.l93()!=l85.l93()){l1(
l78){l9 l14=l85;l14.l301(l112.l93());l14.l199();l14.l216( *l78);l3
l117<l68,l274>(l112,l14,l106);}l9 l5=l112;l5.l199();l3 l5;}l9 l5=l112
;l1(l85.l10()==1){l1(l78){l1(!l85.l12.l62())l3 l5;l5.l216( *l78);}
l401<l68,l274>(l5,l85);l3 l5;}l9 l655=&l85;l13 l14;l1(l78){l14=l85;l5
.l216( *l78);l14.l216( *l78);l5.l12=l811(l112,l85);l655=&l14;}l33 l5.
l12.l70(l85.l12.l72(),l85.l12.l40());l401<l68,l274>(l5, *l655);l3 l5;
}l13 l13::l906(l2 l13&l60,l2 l6*l78)l2{l80(l51){l27 l20::l45:l3 l117<
l26::l254,l20::l45>( *l42,l60,l78);l27 l20::l39:l3 l117<l26::l254,l20
::l39>( *l42,l60,l78);l84:l35 l41("\x43\x61\x6e\x6e\x6f\x74\x20\x61"
"\x64\x64\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20\x64\x61\x74\x61\x76\x65"
"\x63\x74\x6f\x72\x73");}}l13 l13::l871(l2 l13&l60,l2 l6*l78)l2{l3
l117<l26::l288,l20::l45>( *l42,l60,l78);}l13 l13::l896(l2 l13&l60,l2
l6*l78)l2{l3 l117<l26::l350,l20::l45>( *l42,l60,l78);}l13 l13::l846(
l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l287,l20::l45>( *l42,l60,l78);}
l13 l13::l922(l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l344,l20::l45>( *
l42,l60,l78);}l13 l13::l835(l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l284
,l20::l45>( *l42,l60,l78);}l13 l13::l903(l2 l13&l60,l2 l6*l78)l2{l3
l117<l26::l289,l20::l45>( *l42,l60,l78);}l13 l13::l917(l2 l13&l60,l2
l6*l78)l2{l3 l117<l26::l358,l20::l45>( *l42,l60,l78);}l13 l13::l827(
l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l279,l20::l45>( *l42,l60,l78);}
l13 l13::l899(l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l364,l20::l45>( *
l42,l60,l78);}l13 l13::l711(l2 l13&l60,l2 l6*l78)l2{l3 l117<l26::l286
,l20::l75>( *l42,l60,l78);}l13 l13::l873(l2 l13&l60,l2 l6*l78)l2{l3
l117<l26::l280,l20::l75>( *l42,l60,l78);}l64<l26 l68,l100 l7>l139 l22
<l18>l413(l2 l22<l7>&l112,l2 l22<l7>&l85){l1(l85.l10()>1&&l112.l10()!=
l85.l10())l35 l41("\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70\x61"
"\x72\x65\x20\x76\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20\x64\x69\x66"
"\x66\x65\x72\x65\x6e\x74\x20\x73\x69\x7a\x65\x73");l22<l18>l162(l112
.l10());l18 l317=l85.l10()==1;l11(l94 l0=0;l0<l112.l10();++l0){l7 l8=
l317?l85[0]:l85[l0];l1 l89(l68==l26::l214){l162[l0]=l112[l0]<l8;}l33
l1 l89(l68==l26::l211){l162[l0]=l112[l0]<=l8;}l33 l1 l89(l68==l26::
l207){l162[l0]=l112[l0]>l8;}l33 l1 l89(l68==l26::l206){l162[l0]=l112[
l0]>=l8;}l33 l1 l89(l68==l26::l205){l162[l0]=l112[l0]==l8;}l33 l1 l89
(l68==l26::l212){l162[l0]=l112[l0]!=l8;}l33{l604(l503<l68>,"\x4e\x6f"
"\x6e\x20\x63\x6f\x6d\x70\x61\x72\x69\x73\x6f\x6e\x20\x62\x69\x6e\x61"
"\x72\x79\x20\x6f\x70");}}l3 l162;}l64<l26 l68,l100 l7>l139 l22<l18>
l413(l2 l13&l112,l2 l13&l85){l3 l413<l68,l7>(l112.l14<l7>(),l85.l14<
l7>());}l64<l26 l68>l139 l13 l251(l2 l13&l112,l2 l13&l85){l1(l112.l93
()!=l85.l93())l35 l41("\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70"
"\x61\x72\x65\x20\x64\x61\x74\x61\x76\x65\x63\x74\x6f\x72\x73\x20\x6f"
"\x66\x20\x74\x79\x70\x65\x73\x20"+l461(l112.l93())+"\x20\x61\x6e\x64"
"\x20"+l461(l85.l93()));l22<l18>l5;l1(l112.l93()==l20::l153)l35 l41(""
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x74\x79\x70\x65");l80(l112.l93()){
l27 l20::l45:{l49 l7=l16;l53{l5=(l413<l68,l7>(l112,l85));}l47(0);l28;
}l27 l20::l39:{l49 l7=l24::l15;l53{l5=(l413<l68,l7>(l112,l85));}l47(0
);l28;}l27 l20::l75:{l49 l7=l18;l53{l5=(l413<l68,l7>(l112,l85));}l47(
0);l28;}l84:l28;};l13 l322(l5);l322.l12=l112.l12;l1(l85.l10()>1)l322.
l12.l70(l85.l12.l72(),l85.l12.l40());l3 l322;}l13 l13::l789(l2 l13&
l60,l26 l55)l2{l80(l55){l27 l26::l214:l3 l251<l26::l214>(( *l42),(l60
));l27 l26::l211:l3 l251<l26::l211>(( *l42),(l60));l27 l26::l207:l3
l251<l26::l207>(( *l42),(l60));l27 l26::l206:l3 l251<l26::l206>(( *
l42),(l60));l27 l26::l205:l3 l251<l26::l205>(( *l42),(l60));l27 l26::
l212:l3 l251<l26::l212>(( *l42),(l60));l84:l35 l454("\x43\x61\x6c\x6c"
"\x69\x6e\x67\x20\x63\x6f\x6d\x70\x61\x72\x69\x73\x6f\x6e\x20\x66\x75"
"\x6e\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x63\x6f"
"\x6d\x70\x61\x72\x69\x73\x6f\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72"
);}}l13 l13::l983(l2 l13&l60)l2{l3 l251<l26::l205>( *l42,l60);}l13 l13
::l1021(l2 l13&l60)l2{l3 l251<l26::l212>( *l42,l60);}l13 l13::l967(l2
l13&l60)l2{l3 l251<l26::l214>( *l42,l60);}l13 l13::l970(l2 l13&l60)l2
{l3 l251<l26::l211>( *l42,l60);}l13 l13::l980(l2 l13&l60)l2{l3 l251<
l26::l207>( *l42,l60);}l13 l13::l981(l2 l13&l60)l2{l3 l251<l26::l206>
( *l42,l60);}l64<l26 l68>l13 l515(l2 l13&l108,l2 l13&l282){l1(l282.
l10()==0)l3 l108;l1(l282.l93()!=l20::l45)l35 l41("\x62\x6f\x75\x6e"
"\x64\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x6e\x75\x6d\x65\x72\x69\x63"
);l1(l282.l10()==l282.l12.l10())l3 l108;l18 l317=l282.l10()==1;l1(!
l317&&l282.l10()!=l108.l10())l35 l41("\x62\x6f\x75\x6e\x64\x20\x6d"
"\x75\x73\x74\x20\x62\x65\x20\x73\x61\x6d\x65\x20\x73\x69\x7a\x65\x20"
"\x61\x73\x20\x76\x65\x63\x74\x6f\x72");l9 l5=l108;l11(l4 l0=0;l0<
l108.l29();++l0){l1(l108.l12.l63(l0)==l108.l12.l40()&&(l317||l282.l12
.l63(l0)==l282.l12.l40())){l9 l8=l317?l282.l54.l163(0):l282.l54.l163(
l0);l1 l89(l68==l26::l142){l1(l108.l54[l0]<l8)l5.l54[l0]=l8;}l33{l1(
l108.l54[l0]>l8)l5.l54[l0]=l8;}}}l3 l5;}l13 l13::l183(l26 l55,l2 l13&
l60,l2 l6*l78)l2{l80(l55){l27 l26::l254:l3 l906(l60,l78);l27 l26::
l288:l3 l871(l60,l78);l27 l26::l350:l3 l896(l60,l78);l27 l26::l284:l3
l835(l60,l78);l27 l26::l287:l3 l846(l60,l78);l27 l26::l344:l3 l922(
l60,l78);l27 l26::l289:l3 l903(l60,l78);l27 l26::l358:l3 l917(l60,l78
);l27 l26::l279:l3 l827(l60,l78);l27 l26::l364:l3 l899(l60,l78);l27
l26::l280:l3 l873(l60,l78);l27 l26::l286:l3 l711(l60,l78);l27 l26::
l142:l3 l515<l26::l142>( *l42,l60);l27 l26::l144:l3 l515<l26::l144>( *
l42,l60);l84:l3 l789(l60,l55);}}l13 l13::l838()l2{l1(l51!=l20::l75)l35
l41("\x4e\x4f\x54\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20"
"\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x62\x6f\x6f\x6c\x65\x61"
"\x6e\x20\x76\x65\x63\x74\x6f\x72");l9 l5= *l42;l11(l94 l0=0;l0<l10();
++l0)l5.l95[l0]=!l95[l0];l3 l5;}l13 l13::l874()l2{l1(l51!=l20::l45)l35
l41("\x2d\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70"
"\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20"
"\x76\x65\x63\x74\x6f\x72");l9 l5= *l42;l11(l94 l0=0;l0<l10();++l0)l5
.l54[l0] *=-1;l3 l5;}l13 l13::l815(l299 l55)l2{l80(l55){l27 l299::
l569:l3 l838();l27 l299::l672:l3 l874();l84:l35 l41("\x55\x6e\x6b\x6e"
"\x6f\x77\x6e\x20\x75\x6e\x61\x72\x79\x20\x6f\x70");}}l16 l13::l597(
l2 l13&l60)l2{l1(l51!=l20::l45||l60.l51!=l20::l45)l35 l41("\x44\x6f"
"\x74\x20\x70\x72\x6f\x64\x75\x63\x74\x20\x63\x61\x6e\x20\x6f\x6e\x6c"
"\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e"
"\x75\x6d\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");l1(l10()!=
l60.l10())l35 l41("\x44\x6f\x74\x20\x70\x72\x6f\x64\x75\x63\x74\x20"
"\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69"
"\x65\x64\x20\x74\x6f\x20\x76\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20"
"\x73\x61\x6d\x65\x20\x73\x69\x7a\x65");l1(!l12.l62()||!l60.l12.l62())l3
l165<l16>::l200();l16 l5=0;l11(l94 l0=0;l0<l10();++l0)l5+=l54[l0] *
l60.l54[l0];l3 l5;}l16 l13::l208(l2 l122<l4> *l347)l2{l1(l51!=l20::
l45)l35 l41("\x4d\x65\x61\x6e\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20"
"\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d"
"\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");l16 l188=0;l4 l128
=0;l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)==l12.l40()&&(l347==l106
||l347->l63(l0)==l347->l40())){l188+=l54[l0];++l128;}}l1(l128>0)l3
l188/l128;l33 l3 l165<l16>::l200();}l16 l13::l747(l4 l336,l18 l65,l18
l797)l2{l1(l51!=l20::l45)l35 l41("\x53\x75\x6d\x20\x63\x61\x6e\x20"
"\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74"
"\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73"
);l1(!l65&&!l12.l62())l3 l165<l16>::l200();l1(l336>0&&l10()-l12.l10()<
l336)l3 l165<l16>::l200();l1(l797){l16 l675=1;l11(l4 l0=0;l0<l29();++
l0){l1(l12.l63(l0)==l12.l40())l675*=l54[l0];}l3 l675;}l33{l16 l188=0;
l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)==l12.l40())l188+=l54[l0];}
l3 l188;}}l16 l13::l24(l16 l208,l4 l175,l2 l122<l4> *l347)l2{l1(l51!=
l20::l45)l35 l41("\x53\x74\x64\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79"
"\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75"
"\x6d\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");l16 l188=0;l4
l128=0;l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)==l12.l40()&&(l347==
l106||l347->l63(l0)==l347->l40())){l16 l332=l54.l163(l0)-l208;l332*=
l332;l188+=l332;++l128;}}l1(l128>l175)l3 l689(l188/(l128-l175));l33 l3
l165<l16>::l200();}l16 l13::l514(l2 l13&l60,l4 l230)l2{l1(l51!=l20::
l45||l60.l51!=l20::l45)l35 l41("\x43\x6f\x72\x72\x65\x6c\x61\x74\x69"
"\x6f\x6e\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70"
"\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20"
"\x76\x65\x63\x74\x6f\x72\x73");l1(l10()!=l60.l10())l35 l41("\x43\x6f"
"\x72\x72\x65\x6c\x61\x74\x69\x6f\x6e\x20\x63\x61\x6e\x20\x6f\x6e\x6c"
"\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x76"
"\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20\x73\x61\x6d\x65\x20\x73\x69"
"\x7a\x65");l16 l328=l208(&l60.l12);l1(l235(l328))l3 l328;l16 l342=
l60.l208(&l12);l1(l235(l342))l3 l342;l16 l493=l24(l328,1,&l60.l12);l1
(l235(l493))l3 l493;l16 l491=l60.l24(l342,1,&l12);l1(l235(l491))l3
l491;l16 l188=0;l4 l128=0;l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)==
l12.l40()&&l60.l12.l63(l0)==l60.l12.l40()){l16 l543=l54[l0]-l328;l16
l637=l60.l54[l0]-l342;l188+=l543*l637;++l128;}}l1(l128>1&&l128>=l230
&&l493>0&&l491>0)l3 l188/((l128-1) *l493*l491);l33 l3 l165<l16>::l200
();}l16 l13::l471(l2 l13&l60,l4 l230,l4 l175)l2{l1(l51!=l20::l45||l60
.l51!=l20::l45)l35 l41("\x43\x6f\x76\x61\x72\x69\x61\x6e\x63\x65\x20"
"\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69"
"\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20\x76\x65\x63"
"\x74\x6f\x72\x73");l1(l10()!=l60.l10())l35 l41("\x43\x6f\x76\x61\x72"
"\x69\x61\x6e\x63\x65\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70"
"\x6c\x69\x65\x64\x20\x74\x6f\x20\x76\x65\x63\x74\x6f\x72\x73\x20\x6f"
"\x66\x20\x73\x61\x6d\x65\x20\x73\x69\x7a\x65");l16 l328=l208(&l60.
l12);l1(l235(l328))l3 l328;l16 l342=l60.l208(&l12);l1(l235(l342))l3
l342;l16 l188=0;l4 l128=0;l11(l4 l0=0;l0<l29();++l0){l1(l12.l63(l0)==
l12.l40()&&l60.l12.l63(l0)==l60.l12.l40()){l16 l543=l54[l0]-l328;l16
l637=l60.l54[l0]-l342;l188+=l543*l637;++l128;}}l1(l128>l175&&l128>=
l230)l3 l188/((l128-l175));l33 l3 l165<l16>::l200();}l13 l13::l406(l2
l13&l85)l2{l9 l5= *l42;l1(l85.l10()==1){l9 l78=l85.l91(0);l5.l216(l78
);l3 l5;}l1(l10()!=l85.l10())l35 l41("\x43\x61\x6e\x6e\x6f\x74\x20"
"\x63\x6f\x6d\x62\x69\x6e\x65\x5f\x66\x69\x72\x73\x74\x20\x64\x61\x74"
"\x61\x76\x65\x63\x74\x6f\x72\x73\x20\x6f\x66\x20\x64\x69\x66\x66\x65"
"\x72\x65\x6e\x74\x20\x73\x69\x7a\x65\x73");l1(l93()!=l85.l93())l3 l5
;l11(l9 l0:l12){l1(l85.l12.l63(l0)==l85.l12.l40()){l9 l78=l85.l91(l0);
l5.l91(l0,l78);l5.l12.l213(l0);}}l3 l5;}l50 l13::l625(l2 l13&l85,l18
l402){l1(l93()!=l85.l93())l3;l1(l10()>l85.l10())l35 l41("\x43\x61\x6e"
"\x6e\x6f\x74\x20\x75\x70\x64\x61\x74\x65\x20\x64\x61\x74\x61\x76\x65"
"\x63\x74\x6f\x72\x20\x77\x69\x74\x68\x20\x73\x6d\x61\x6c\x6c\x65\x72"
"\x20\x64\x61\x74\x61\x76\x65\x63\x74\x6f\x72");l1(l402){l11(l4 l0=0;
l0<l29();++l0){l1(l85.l12.l63(l0)!=l85.l12.l40())l69;l91(l0,l85,l0);
l12.l213(l0);}l3;}l9 l828=l12;l11(l9 l0:l828){l1(l85.l12.l63(l0)!=l85
.l12.l40())l69;l91(l0,l85,l0);}}l50 l13::l319(){l1(l51!=l20::l45)l35
l41("\x61\x62\x73\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20"
"\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69"
"\x63\x20\x76\x65\x63\x74\x6f\x72");l11(l94 l0=0;l0<l10();++l0)l54[l0
]=l24::l319(l54[l0]);}l139 l79 l18 l516(l18 l8){l3!l8;}l139 l79 l18
l516(l16 l8){l3 l8==0;}l139 l79 l18 l516(l2 l15&l8){l3 l8.l62();}l64<
l100 l7>l79 l18 l639(l2 l22<l7>&l14,l2 l122<l4>&l12){l11(l4 l0=0;l0<(
l4)l14.l10();++l0){l1(l12.l63(l0)==l12.l40()&&l516(l14.l163(l0)))l3
l57;}l3 l43;}l64<l100 l7>l79 l18 l596(l2 l22<l7>&l14,l2 l122<l4>&l12,
l18 l459){l11(l4 l0=0;l0<(l4)l14.l10();++l0){l1(l12.l63(l0)==l12.l40(
)){l1(!l516(l14.l163(l0)))l3 l43;}l33{l1(!l459)l3 l43;}}l3 l57;}l18
l13::l337(l18 l264,l18 l65)l2{l1(l51!=l20::l75&&l264)l35 l41("\x61"
"\x6c\x6c\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70"
"\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x62\x6f\x6f\x6c\x65\x61\x6e\x20"
"\x76\x65\x63\x74\x6f\x72");l1(l10()==0)l3 l43;l1(!l65&&!l12.l62())l3
l43;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l639(l14<l7>(),l12);}l47
(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3 l639(l14<l7>(),l12);}
l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l639(l14<l7>(),l12);}l47(
0);l28;}l84:l28;};l3 l43;}l18 l13::l889(l18 l264,l18 l65)l2{l1(l51!=
l20::l75&&l264)l35 l41("\x61\x6e\x79\x20\x63\x61\x6e\x20\x6f\x6e\x6c"
"\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x62"
"\x6f\x6f\x6c\x65\x61\x6e\x20\x76\x65\x63\x74\x6f\x72");l1(l10()==0)l3
l43;l1(!l65&&!l12.l62())l3 l43;l80(l51){l27 l20::l45:{l49 l7=l16;l53{
l3 l596(l14<l7>(),l12,l65);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15
;l53{l3 l596(l14<l7>(),l12,l65);}l47(0);l28;}l27 l20::l75:{l49 l7=l18
;l53{l3 l596(l14<l7>(),l12,l65);}l47(0);l28;}l84:l28;};l3 l43;}l13 l13
::l657(l2 l13&l390,l2 l13&l184)l2{l1(l51!=l20::l45)l35 l41("\x63\x6c"
"\x69\x70\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70"
"\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20"
"\x76\x65\x63\x74\x6f\x72\x73");l9 l5= *l42;l5=l515<l26::l142>(l5,
l390);l5=l515<l26::l144>(l5,l184);l3 l5;}l4 l13::l128(l18 l76)l2{l1(
l76&&l51!=l20::l45)l3 0;l3 l29()-(l4)l12.l10();}l64<l100 l7>l4 l546(
l2 l22<l7>&l14,l2 l122<l4>&l12,l18 l158){l122<l7>l67;l11(l4 l0=0;l0<(
l4)l14.l10();++l0){l1(l12.l63(l0)==l12.l40())l67.l70(l14.l163(l0));}
l3(!l158&&!l12.l62()?1:0)+(l4)l67.l10();}l4 l13::l392(l18 l158)l2{l80
(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l546(l14<l7>(),l12,l158);}l47(0
);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3 l546(l14<l7>(),l12,l158);
}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l3 l546(l14<l7>(),l12,l158);
}l47(0);l28;}l84:l28;};l3 0;}l64<l167 l68>l50 l13::l215(l18 l65){l9&
l108= *l42;l1(l108.l93()!=l20::l45)l1 l89(l68==l167::l142){l35 l41(""
"\x63\x75\x6d\x6d\x61\x78\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62"
"\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65"
"\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");}l33 l1 l89(l68==l167
::l144){l35 l41("\x63\x75\x6d\x6d\x69\x6e\x20\x63\x61\x6e\x20\x6f\x6e"
"\x6c\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20"
"\x6e\x75\x6d\x65\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");}l33
l1 l89(l68==l167::l351){l35 l41("\x63\x75\x6d\x70\x72\x6f\x64\x20\x63"
"\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70\x6c\x69\x65"
"\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20\x76\x65\x63\x74"
"\x6f\x72\x73");}l33 l1 l89(l68==l167::l355){l35 l41("\x63\x75\x6d"
"\x73\x75\x6d\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61"
"\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63"
"\x20\x76\x65\x63\x74\x6f\x72\x73");}l1(l108.l10()==0)l3;l4 l86=l108.
l451();l1(l86<0)l3;l1(l86>0&&l65){l108.l199();l3;}l16 l369=l108.l54[
l86];l11(l4 l0=l86+1;l0<l108.l29();++l0){l1(l108.l12.l63(l0)!=l108.
l12.l40()){l1(l65)l69;l11(l4 l31=l0+1;l31<l108.l29();++l31)l108.l12.
l70(l31);l3;}l1 l89(l68==l167::l142)l369=l24::l333(l369,l108.l54.l163
(l0));l33 l1 l89(l68==l167::l144)l369=l24::l294(l369,l108.l54.l163(l0
));l33 l1 l89(l68==l167::l351)l369*=l108.l54.l163(l0);l33 l1 l89(l68
==l167::l355)l369+=l108.l54.l163(l0);l108.l54[l0]=l369;}}l64 l50 l13
::l215<l167::l142>(l18 l65);l64 l50 l13::l215<l167::l144>(l18 l65);
l64 l50 l13::l215<l167::l351>(l18 l65);l64 l50 l13::l215<l167::l355>(
l18 l65);l50 l13::l332(l4 l92){l1(l51!=l20::l45)l35 l41("\x64\x69\x66"
"\x66\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x61\x70\x70"
"\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65\x72\x69\x63\x20\x76"
"\x65\x63\x74\x6f\x72\x73");l1(l92==0)l3;l1(l24::l319(l92)>=l29()){
l199();l3;}l4 l86=l451();l1(l86<0)l3;l1(l92>0){l11(l4 l0=l29()-1;l0>=
l86+l92;--l0){l1(l12.l63(l0)!=l12.l40()||l12.l63(l0-l92)!=l12.l40()){
l12.l70(l0);l69;}l54[l0]-=l54[l0-l92];}l11(l4 l0=l86;l0<l86+l92;++l0)l12
.l70(l0);}l33{l11(l4 l0=l86;l0<l29()+l92;++l0){l1(l12.l63(l0)!=l12.
l40()||l12.l63(l0-l92)!=l12.l40()){l12.l70(l0);l69;}l54[l0]-=l54[l0-
l92];}l11(l4 l0=l29()+l92;l0<l29();++l0)l12.l70(l0);}}l50 l13::l626(
l4 l92,l136 l311,l4 l109){l1(l51!=l20::l45)l35 l41("\x70\x63\x74\x5f"
"\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62"
"\x65\x20\x61\x70\x70\x6c\x69\x65\x64\x20\x74\x6f\x20\x6e\x75\x6d\x65"
"\x72\x69\x63\x20\x76\x65\x63\x74\x6f\x72\x73");l1(l92==0)l3;l1(l24::
l319(l92)>=l29()){l199();l3;}l216(l311,l109);l4 l86=l451();l1(l86<0)l3
;l1(l92>0){l11(l4 l0=l29()-1;l0>=l86+l92;--l0){l1(l12.l63(l0)!=l12.
l40()||l12.l63(l0-l92)!=l12.l40()||l54[l0-l92]==0){l12.l70(l0);l69;}
l54[l0]=l54[l0]/l54[l0-l92]-1.;}l11(l4 l0=l86;l0<l86+l92;++l0)l12.l70
(l0);}l33{l11(l4 l0=l86;l0<l29()+l92;++l0){l1(l12.l63(l0)!=l12.l40()||
l12.l63(l0-l92)!=l12.l40()||l54[l0-l92]==0){l12.l70(l0);l69;}l54[l0]=
l54[l0]/l54[l0-l92]-1.;}l11(l4 l0=l29()+l92;l0<l29();++l0)l12.l70(l0);
}}l50 l13::l482(l4 l92,l2 l6*l78){l1(l92==0)l3;l1(l24::l319(l92)>=l29
()){l199();l1(l78)l216( *l78);l3;}l4 l86=l451();l1(l86<0)l3;l1(l92>0){
l11(l4 l0=l29()-1;l0>=l86+l92;--l0){l1(l12.l63(l0-l92)!=l12.l40()){
l12.l70(l0);l69;}l91(l0, *l42,l0-l92);}l11(l4 l0=l86;l0<l86+l92;++l0){
l1(l78)l91(l0, *l78);l33 l12.l70(l0);}}l33{l11(l4 l0=l86;l0<l29()+l92
;++l0){l1(l12.l63(l0-l92)!=l12.l40()){l12.l70(l0);l69;}l91(l0, *l42,
l0-l92);}l11(l4 l0=l29()+l92;l0<l29();++l0){l1(l78)l91(l0, *l78);l33
l12.l70(l0);}}}l13 l13::l733(l2 l24::l22<l16>&l257,l18 l595)l2{l13 l5
;l5.l51=l20::l39;l1(!l595&&l51==l20::l45){l9 l243=l257;l1(l243.l62())l243
={0.25,0.5,0.75};l5.l99.l81(l243.l10()+5);l5.l99[0]="\x63\x6f\x75\x6e"
"\x74";l5.l99[1]="\x6d\x65\x61\x6e";l5.l99[2]="\x73\x74\x64";l5.l99[3
]="\x6d\x69\x6e";l11(l4 l0=0;l0<l257.l10();++l0){l16 l66=l257[l0];l1(
l66<0||l66>1)l35 l41("\x70\x65\x72\x63\x65\x6e\x74\x69\x6c\x65\x20"
"\x6d\x75\x73\x74\x20\x62\x65\x20\x62\x65\x74\x77\x65\x65\x6e\x20\x30"
"\x20\x61\x6e\x64\x20\x31");l5.l99[4+l0]=l529(l66*100)+"\x25";}l5.l99
[4+l257.l10()]="\x6d\x61\x78";l3 l5;}l5.l99={"\x63\x6f\x75\x6e\x74",""
"\x75\x6e\x69\x71\x75\x65","\x74\x6f\x70","\x66\x72\x65\x71","\x66"
"\x69\x72\x73\x74","\x6c\x61\x73\x74"};l3 l5;}l13 l13::l478(l2 l24::
l22<l16>&l257,l18 l595)l2{l13 l5;l1(!l595&&l51==l20::l45){l5.l51=l20
::l45;l9 l243=l257;l1(l243.l62())l243={0.25,0.5,0.75};l5.l54.l81(l243
.l10()+5);l5.l54[0]=l128(l43);l5.l54[1]=l208();l5.l54[2]=l24(l5.l54[1
]);l5.l54[3]=l54[l534()];l9 l179=l356(l243);l11(l4 l0=0;l0<(l4)l179.
l10();++l0)l5.l54[4+l0]=l179[l0];l5.l54[4+l179.l10()]=l54[l614()];l3
l5;}l5.l51=l20::l39;l5.l99.l81(6);l5.l99[0]=l121(l128(l57));l5.l99[1]
=l121(l392());l5.l99[2]=l327(l851());l5.l99[3]=l121(l255());l5.l99[4]
=l327(l10()>0?l91(0):l6());l5.l99[5]=l327(l10()>0?l91(l29()-1):l6());
l3 l5;}l139 l79 l16 l856(l2 l22<l16>&l147,l16 l66){l177(l147.l10()>1);
l177(l66>0&&l66<1);l16 l157=l66* (l147.l10()-1);l4 l225=l495<l4>(l157
);l4 l418=l225+1;l1(l418>=l147.l10())l3 l147[l225];l16 l734=l157-l225
;l3 l147[l225] * (1-l734)+l147[l418] *l734;}l139 l79 l16 l865(l2 l22<
l16>&l147,l16 l66){l177(l147.l10()>1);l177(l66>0&&l66<1);l16 l157=l66
 * (l147.l10()-1);l4 l225=l495<l4>(l157+0.5);l3 l147[l225];}l139 l79
l16 l831(l2 l22<l16>&l147,l16 l66){l177(l147.l10()>1);l177(l66>0&&l66
<1);l16 l157=l66* (l147.l10()-1);l4 l225=l495<l4>(l157);l3 l147[l225]
;}l139 l79 l16 l826(l2 l22<l16>&l147,l16 l66){l177(l147.l10()>1);l177
(l66>0&&l66<1);l16 l157=l66* (l147.l10()-1);l4 l225=l495<l4>(l157+1);
l3 l147[l225];}l139 l79 l16 l902(l2 l22<l16>&l147,l16 l66){l177(l147.
l10()>1);l177(l66>0&&l66<1);l16 l157=l66* (l147.l10()-1);l4 l225=l495
<l4>(l157);l4 l418=l225+1;l1(l418>=l147.l10())l3 l147[l225];l3(l147[
l225]+l147[l418]) *0.5;}l739 l267 l263{l728,l513,l732,l708,l773};l139
l79 l263 l880(l2 l15&l231){l1(l231=="\x6c\x69\x6e\x65\x61\x72")l3 l263
::l728;l1(l231=="\x6e\x65\x61\x72\x65\x73\x74")l3 l263::l513;l1(l231
=="\x6c\x6f\x77\x65\x72")l3 l263::l732;l1(l231=="\x68\x69\x67\x68\x65"
"\x72")l3 l263::l708;l1(l231=="\x6d\x69\x64\x70\x6f\x69\x6e\x74")l3
l263::l773;l35 l41("\x69\x6e\x76\x61\x6c\x69\x64\x20\x69\x6e\x74\x65"
"\x72\x70\x6f\x6c\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64");}
l22<l16>l13::l356(l2 l22<l16>&l179,l2 l15&l231)l2{l1(l51!=l20::l45)l35
l41("\x71\x75\x61\x6e\x74\x69\x6c\x65\x20\x6f\x6e\x6c\x79\x20\x77\x6f"
"\x72\x6b\x73\x20\x6f\x6e\x20\x6e\x75\x6d\x65\x72\x69\x63\x20\x64\x61"
"\x74\x61");l22<l16>l5;l5.l101(l179.l10());l22<l16>l236;l236.l101(l29
());l11(l4 l0=0;l0<l29();++l0)l1(l12.l63(l0)==l12.l40())l236.l56(l54[
l0]);l1(l236.l62())l35 l41("\x71\x75\x61\x6e\x74\x69\x6c\x65\x20\x6f"
"\x6e\x6c\x79\x20\x77\x6f\x72\x6b\x73\x20\x6f\x6e\x20\x6e\x6f\x6e\x2d"
"\x65\x6d\x70\x74\x79\x20\x64\x61\x74\x61");l1(l236.l10()==1){l11(l9
l66:l179){l1(l66<0||l66>1)l35 l41("\x70\x65\x72\x63\x65\x6e\x74\x69"
"\x6c\x65\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x62\x65\x74\x77\x65\x65"
"\x6e\x20\x30\x20\x61\x6e\x64\x20\x31");l5.l56(l236[0]);}l3 l5;}l24::
l152(l236.l72(),l236.l40());l9 l533=l880(l231);l11(l9 l66:l179){l1(
l66<0||l66>1)l35 l41("\x70\x65\x72\x63\x65\x6e\x74\x69\x6c\x65\x20"
"\x6d\x75\x73\x74\x20\x62\x65\x20\x62\x65\x74\x77\x65\x65\x6e\x20\x30"
"\x20\x61\x6e\x64\x20\x31");l1(l66==1){l5.l56(l236.l171());l69;}l1(
l66==0){l5.l56(l236[0]);l69;}l80(l533){l27 l263::l728:l5.l56(l856(
l236,l66));l28;l27 l263::l513:l5.l56(l865(l236,l66));l28;l27 l263::
l732:l5.l56(l831(l236,l66));l28;l27 l263::l708:l5.l56(l826(l236,l66));
l28;l27 l263::l773:l5.l56(l902(l236,l66));l28;l84:l28;}}l3 l5;}l16 l13
::l727(l18 l65,l18 l915)l2{l1(l51!=l20::l45)l3 l165<l16>::l200();l1(!
l65&&l12.l10()==l29())l3 l165<l16>::l200();l9 l8=l870();l3 l915?l762(
l8):l780(l8);}l16 l13::l195(l105 l55,l18 l65,l4 l373)l2{l1(l51!=l20::
l45)l3 l165<l16>::l200();l1(!l65&&!l12.l62())l3 l165<l16>::l200();l1(
l12.l10()==l10())l3 l165<l16>::l200();l80(l55){l27 l105::l144:l3 l54[
l534()];l27 l105::l142:l3 l54[l614()];l27 l105::l669:l3 l534();l27
l105::l677:l3 l614();l27 l105::l643:l3 l208();l27 l105::l769:{l9 l67=
l24(l208(),l373);l1(l67<=0)l3 l165<l16>::l200();l3 l67/l689(l10()-l12
.l10());}l27 l105::l758:l3 l356({0.5})[0];l27 l105::l757:l3 l727(l65,
l43);l27 l105::l682:l3 l727(l65);l27 l105::l703:l3 l24(l208(),l373);
l27 l105::l645:{l9 l67=l24(l208(),l373);l3 l67*l67;}l27 l105::l355:l3
l747(l373,l65);l27 l105::l351:l3 l747(l373,l65,l43);l27 l105::l852:l3
l392(l65);l27 l105::l886:l3 l16(l10()-l12.l10());l84:l28;}l3 l165<l16
>::l200();}l64<l100 l7>l22<l7>l622(l2 l22<l7>&l8,l2 l122<l4>&l12,l18
l65,l122<l4>&l691){l1(l8.l62())l3{};l1(l65&&l12.l10()==l8.l10())l3{};
l1(l8.l10()==1&&l12.l62())l3{l8[0]};l297<l7,l4>l388;l11(l4 l0=0;l0<l8
.l10();++l0)l1(l12.l63(l0)==l12.l40())l388[l8[l0]]++;l4 l313=0;l11(l9
&l66:l388){l1(l66.l169>l313)l313=l66.l169;}l22<l7>l5;l1(!l65&&l313<(
l4)l12.l10()){l691.l70(0);l5.l56(l7());l3 l5;}l11(l9&l66:l388){l1(l66
.l169==l313)l5.l56(l66.l174);}l1(!l65&&l313==(l4)l12.l10()){l5.l56(l7
());l691.l70((l4)l5.l10()-1);}l3 l5;}l13 l13::l501(l18 l158)l2{l13 l5
;l5.l51=l51;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l5.l14<l7>()=l622(
l14<l7>(),l12,l158,l5.l12);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15
;l53{l5.l14<l7>()=l622(l14<l7>(),l12,l158,l5.l12);}l47(0);l28;}l27 l20
::l75:{l49 l7=l18;l53{l5.l14<l7>()=l622(l14<l7>(),l12,l158,l5.l12);}
l47(0);l28;}l84:l28;};l3 l5;}l739 l267 l96{l283,l144,l142,l305,l281};
l96 l718(l2 l15&l67){l1(l67.l62()||l67=="\x61\x76\x65\x72\x61\x67\x65"
)l3 l96::l283;l1(l67=="\x6d\x69\x6e")l3 l96::l144;l1(l67=="\x6d\x61"
"\x78")l3 l96::l142;l1(l67=="\x66\x69\x72\x73\x74")l3 l96::l305;l1(
l67=="\x64\x65\x6e\x73\x65")l3 l96::l281;l3 l96::l283;}l64<l96 l68,
l18 l883,l100 l7>l22<l16>l135(l22<l7>l8,l18 l914,l122<l4>l12,l15 l116
){l4 l37=(l4)l8.l10();l22<l16>l339(l37,l165<l16>::l200());l22<l4>l229
;l11(l4 l0=0;l0<l37;++l0)l1(l12.l63(l0)==l12.l40())l229.l56(l0);l895(
l229.l72(),l229.l40(),[&l8](l4 l272,l4 l384){l1 l89(l883)l3 l8[l272]<
l8[l384];l33 l3 l8[l272]>l8[l384];});l1(l116=="\x62\x6f\x74\x74\x6f"
"\x6d")l229.l70(l229.l40(),l12.l72(),l12.l40());l33 l1(l116=="\x74"
"\x6f\x70")l229.l70(l229.l72(),l12.l72(),l12.l40());l4 l238=(l4)l229.
l10();l11(l4 l0=0;l0<l238;){l4 l31=l0;l1(l12.l63(l229[l0])!=l12.l40())l47
(l31<l238&&l12.l63(l229[l31])!=l12.l40())++l31;l33 l47(l31<l238&&l8[
l229[l31]]==l8[l229[l0]])++l31;l1 l89(l68==l96::l305){l11(l4 l146=l0;
l146<l31;++l146)l339[l229[l146]]=l146+1;}l33{l16 l322;l1 l89(l68==l96
::l283){l322=0.5* (l0+l31+1);}l33 l1 l89(l68==l96::l144||l68==l96::
l281){l322=l0+1;}l33 l1 l89(l68==l96::l142){l322=l31;}l11(l4 l146=l0;
l146<l31;++l146)l339[l229[l146]]=l322;}l0=l31;}l1 l89(l68==l96::l281){
l24::l310<l16>l794(l339.l72(),l339.l40());l24::l297<l16,l16>l654;l4 l0
=0;l11(l9&l88:l794){l654.l999(l88,l16(l0+1));++l0;}l11(l9&l88:l339)l88
=l235(l88)?l88:l654[l88];}l1(l914){l16 l521=-l165<l16>::l497();l11(l9
&l157:l339)l1(!l24::l235(l157)&&l157>l521)l521=l157;l11(l9&l157:l339)l1
(!l24::l235(l157))l157=l157/l521;}l3 l339;}l13 l13::l157(l2 l24::l15&
l102,l2 l24::l15&l116,l18 l134,l18 l123)l2{l22<l16>l88;l9 l293=l718(
l102);l80(l718(l102)){l27 l96::l283:{l80(l51){l27 l20::l45:l1(l134)l88
=l135<l96::l283,l43>(l54,l123,l12,l116);l33 l88=l135<l96::l283,l57>(
l54,l123,l12,l116);l28;l27 l20::l39:l1(l134)l88=l135<l96::l283,l43>(
l99,l123,l12,l116);l33 l88=l135<l96::l283,l57>(l99,l123,l12,l116);l28
;l27 l20::l75:l1(l134)l88=l135<l96::l283,l43>(l95,l123,l12,l116);l33
l88=l135<l96::l283,l57>(l95,l123,l12,l116);l28;l84:l28;}}l28;l27 l96
::l144:{l80(l51){l27 l20::l45:l1(l134)l88=l135<l96::l144,l43>(l54,
l123,l12,l116);l33 l88=l135<l96::l144,l57>(l54,l123,l12,l116);l28;l27
l20::l39:l1(l134)l88=l135<l96::l144,l43>(l99,l123,l12,l116);l33 l88=
l135<l96::l144,l57>(l99,l123,l12,l116);l28;l27 l20::l75:l1(l134)l88=
l135<l96::l144,l43>(l95,l123,l12,l116);l33 l88=l135<l96::l144,l57>(
l95,l123,l12,l116);l28;l84:l28;}}l28;l27 l96::l142:{l80(l51){l27 l20
::l45:l1(l134)l88=l135<l96::l142,l43>(l54,l123,l12,l116);l33 l88=l135
<l96::l142,l57>(l54,l123,l12,l116);l28;l27 l20::l39:l1(l134)l88=l135<
l96::l142,l43>(l99,l123,l12,l116);l33 l88=l135<l96::l142,l57>(l99,
l123,l12,l116);l28;l27 l20::l75:l1(l134)l88=l135<l96::l142,l43>(l95,
l123,l12,l116);l33 l88=l135<l96::l142,l57>(l95,l123,l12,l116);l28;l84
:l28;}}l28;l27 l96::l305:{l80(l51){l27 l20::l45:l1(l134)l88=l135<l96
::l305,l43>(l54,l123,l12,l116);l33 l88=l135<l96::l305,l57>(l54,l123,
l12,l116);l28;l27 l20::l39:l1(l134)l88=l135<l96::l305,l43>(l99,l123,
l12,l116);l33 l88=l135<l96::l305,l57>(l99,l123,l12,l116);l28;l27 l20
::l75:l1(l134)l88=l135<l96::l305,l43>(l95,l123,l12,l116);l33 l88=l135
<l96::l305,l57>(l95,l123,l12,l116);l28;l84:l28;}}l28;l27 l96::l281:{
l80(l51){l27 l20::l45:l1(l134)l88=l135<l96::l281,l43>(l54,l123,l12,
l116);l33 l88=l135<l96::l281,l57>(l54,l123,l12,l116);l28;l27 l20::l39
:l1(l134)l88=l135<l96::l281,l43>(l99,l123,l12,l116);l33 l88=l135<l96
::l281,l57>(l99,l123,l12,l116);l28;l27 l20::l75:l1(l134)l88=l135<l96
::l281,l43>(l95,l123,l12,l116);l33 l88=l135<l96::l281,l57>(l95,l123,
l12,l116);l28;l84:l28;}}l28;}l13 l5(l88);l11(l4 l0=0;l0<l5.l29();++l0
){l1(l235(l5.l54[l0])){l5.l54[l0]=0;l5.l12.l70(l0);}}l3 l5;}l50 l13::
l345(l4 l222){l1(l51!=l20::l45)l3;l11(l4 l0=0;l0<l29();++l0){l1(l12.
l63(l0)!=l12.l40())l69;l16&l8=l54[l0];l8=l24::l345(l8*l24::l496(10,
l222))/l24::l496(10,l222);}}l13 l13::l662(l2 l13&l474,l2 l13&l120,l18
l275)l2{l1(l474.l29()!=l120.l29())l35 l41("\x6e\x75\x6d\x62\x65\x72"
"\x20\x6f\x66\x20\x6b\x65\x79\x73\x20\x61\x6e\x64\x20\x76\x61\x6c\x75"
"\x65\x73\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x61\x6d\x65"
);l1(!l474.l12.l62())l35 l41("\x66\x6f\x75\x6e\x64\x20\x4e\x41\x20"
"\x6b\x65\x79");l1(!l120.l12.l62())l35 l41("\x66\x6f\x75\x6e\x64\x20"
"\x4e\x41\x20\x76\x61\x6c\x75\x65");l1(!l275)l74(l474);l9 l30=l474.
l74( *l42,l43);l9 l5=l120.l125(l30);l1(!l5.l12.l62())l11(l4 l0=0;l0<
l29();++l0){l1(l30[l0]>=0)l69;l9 l8=l91(l0);l5.l91(l0,l8);}l3 l5;}l22
<l4>l13::l680(l2 l6&l233,l2 l6&l227)l2{l22<l4>l5;l13 l483(l233,0,0);
l13 l357(l227,0,0);l4 l37=l29();l1(l483.l29()==0&&l357.l29()==0){l5.
l81(l29());l11(l4 l0=0;l0<l37;++l0)l5[l0]=l0;l3 l5;}l4 l166=-1;l4 l141
=-1;l1(l483.l29()>0){l4 l61=l198(l483,l57);l1(l61==-2){l61=l427(l483,
l57);l1(l61==-2)l35 l41("\x76\x65\x63\x74\x6f\x72\x20\x73\x68\x6f\x75"
"\x6c\x64\x20\x62\x65\x20\x6d\x6f\x6e\x6f\x74\x6f\x6e\x6f\x75\x73");
l1(l61==-1)l3{};l166=l61;l141=0;l1(l357.l29()>0){l61=l427(l357,l43);
l1(l61==-1)l3{};l141=l61;}l1(l141>l166)l3{};l5.l101(l166-l141+1);l11(
l4 l0=l141;l0<=l166;++l0)l5.l56(l0);l3 l5;}l1(l61==-1)l3{};l166=l61;
l141=l37-1;l1(l357.l29()>0){l61=l198(l357,l43);l1(l61==-1)l3{};l141=
l61;}l1(l141<l166)l3{};l5.l101(l141-l166+1);l11(l4 l0=l166;l0<=l141;
++l0)l5.l56(l0);l3 l5;}l4 l61=l198(l357,l43);l1(l61==-2){l61=l427(
l357,l43);l1(l61==-2)l35 l41("\x76\x65\x63\x74\x6f\x72\x20\x73\x68"
"\x6f\x75\x6c\x64\x20\x62\x65\x20\x6d\x6f\x6e\x6f\x74\x6f\x6e\x6f\x75"
"\x73");l1(l61==-1)l3{};l141=l61;l5.l101(l37-l141);l11(l4 l0=l141;l0<
l37;++l0)l5.l56(l0);l3 l5;}l1(l61==-1)l3{};l141=l61;l5.l101(l141+1);
l11(l4 l0=0;l0<=l141;++l0)l5.l56(l0);l3 l5;}l50 l13::l234(l2 l6&l161,
l2 l6&l52,l18 l449){l234(l22<l6>{l161},l22<l6>{l52},l449);}l50 l13::
l234(l2 l24::l22<l98::l6>&l161,l2 l24::l22<l98::l6>&l52,l18 l449){l1(
l161.l62()||l52.l62())l3;l1(l52.l10()!=1&&(l52.l10()!=l161.l10()))l35
l41("\x76\x61\x6c\x75\x65\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20"
"\x73\x63\x61\x6c\x61\x72\x20\x6f\x72\x20\x73\x61\x6d\x65\x20\x6c\x65"
"\x6e\x67\x74\x68\x20\x61\x73\x20\x74\x6f\x5f\x72\x65\x70\x6c\x61\x63"
"\x65");l18 l317=l52.l10()==1;l22<l22<l4>>l298;l298.l101(l161.l10());
l11(l9&l8:l161)l298.l56(l449?l593(l8.l36<l15>()):l760(l8));l11(l94 l31
=0;l31<l161.l10();++l31){l11(l9 l0:l298[l31])l1(l0>=0){l9 l8=l52[l317
?0:l31];l91(l0,l8);}}}l50 l13::l234(l2 l22<l6>&l161,l136 l102,l4 l109
,l18 l449){l1(l161.l62())l3;l122<l4>l67;l1(l449){l11(l9&l8:l161){l9
l30=l593(l8.l36<l15>());l67.l70(l30.l72(),l30.l40());}}l33{l11(l9&l8:
l161){l9 l30=l760(l8);l67.l70(l30.l72(),l30.l40());}}l695( *l42,l102,
l109,l67);}l64<l100 l7>l79 l4 l528(l2 l7&l8,l2 l7&l58){l3(l8>l58)-(l8
<l58);}l4 l13::l720(l4 l0,l4 l31,l18 l314)l2{l177(l0>=0&&l31>=0&&l0<
l29()&&l31<l29());l18 l646=l12.l63(l0)!=l12.l40();l18 l722=l12.l63(
l31)!=l12.l40();l1(l646&&l722)l3 0;l1(l646)l3 l314?1:-1;l1(l722)l3
l314?-1:1;l80(l51){l27 l20::l45:{l49 l7=l16;l53{l3 l528(l14<l7>()[l0]
,l14<l7>()[l31]);}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l3
l528(l14<l7>()[l0],l14<l7>()[l31]);}l47(0);l28;}l27 l20::l75:{l49 l7=
l18;l53{l3 l528(l14<l7>()[l0],l14<l7>()[l31]);}l47(0);l28;}l84:l28;};
l3 0;}l49 l241 l24;l49 l241 l98;l64<l18 l374=l43>l79 l20 l979(l2 l98
::l6&l8,l4 l133,l4 l201=1){l1(l133>=l8.l1009<l374>()||l8.l653<l374>()<
2)l3 l20::l153;l11(l4 l0=l201;l0<l8.l653<l374>();++l0){l9 l168=l525(
l8.l561<l374>(l0,l133));l1(l168!=l20::l153)l3 l168;}l3 l20::l153;}l64
<l100 l7,l18 l374=l43>l22<l7>l1000(l2 l6&l8,l4 l868,l4 l505,l122<l4>&
l12){l9 l37=l8.l653<l374>();l22<l7>l5(l37-l505,l7());l11(l4 l31=l505;
l31<l37;++l31){l9 l467=l8.l561<l374>(l31,l868);l1(l467.l34<l50>()||
l467.l540()||!l467.l34<l7>()){l12.l70(l31-l505);l69;}l5[l31-l505]=
l467.l36<l7>();}l3 l5;}l139 l79 l18 l805(l2 l122<l4>&l67,l4 l561){l3(
l67.l63(l561)!=l67.l40());}l17 l17::l156(l2 l22<l4>&l97,l2 l22<l4>&
l113,l2 l6*l8)l2{l17 l5;l5.l23=l23.l125(l113);l5.l25=l25.l125(l97);l9
l648=l8?l13( *l8,0,0):l13();l1(l8)l648.l81(l5.l25.l29(),l43);l5.l114=
l20::l153;l4 l37=(l4)l21.l10();l11(l9 l0:l113){l1(l0<0||l0>=l37)l69;
l5.l114=l21[l0].l93();l28;}l11(l9 l0:l113){l1(l0<0||l0>=l37)l5.l21.
l56(l648);l33 l5.l21.l367(l21[l0].l125(l97,l8));l1(l5.l21.l171().l93(
)!=l5.l114)l5.l114=l20::l153;}l3 l5;}l17 l17::l156(l2 l22<l4>&l97,l2
l6*l8)l2{l4 l37=l23.l29();l22<l4>l113(l37);l11(l4 l0=0;l0<l37;++l0)l113
[l0]=l0;l3 l156(l97,l113,l8);}l17 l17::l252(l2 l22<l4>&l113,l2 l6*l8)l2
{l4 l37=l25.l29();l22<l4>l97(l37);l11(l4 l0=0;l0<l37;++l0)l97[l0]=l0;
l3 l156(l97,l113,l8);}l17 l17::l181(l2 l22<l4>&l97,l2 l22<l4>&l113)l2
{l24::l310<l4>l67;l11(l4 l0=0;l0<l25.l29();++l0)l67.l70(l0);l11(l9 l0
:l97)l67.l213(l0);l22<l4>l911(l67.l72(),l67.l40());l67.l140();l11(l4
l0=0;l0<l23.l29();++l0)l67.l70(l0);l11(l9 l0:l113)l67.l213(l0);l22<l4
>l909(l67.l72(),l67.l40());l3 l156(l911,l909);}l17 l17::l181(l2 l22<
l4>&l97)l2{l3 l181(l97,{});}l17 l17::l744(l2 l22<l4>&l113)l2{l3 l181(
{},l113);}l17::l17(l2 l6&l8,l2 l13*l44,l2 l13*l30){l4 l86=l44?0:1;l4
l164=l30?0:1;l1(l44&&l44->l29()!=l8.l44()-l164)l35 l41("\x63\x6f\x6c"
"\x75\x6d\x6e\x73\x20\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f\x65\x73\x20"
"\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68\x20\x64\x61\x74\x61");l1(l30&&
l30->l29()!=l8.l82()-l86)l35 l41("\x69\x6e\x64\x65\x78\x20\x6c\x65"
"\x6e\x67\x74\x68\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74"
"\x63\x68\x20\x64\x61\x74\x61");l1(l44)l23= *l44;l33 l23=l13(l8,0,
l164,l57);l1(l30)l25= *l30;l33 l25=l13(l8,0,l86);l1(l23.l10()==0)l3;
l21.l367(l8,l164,l86);l114=l21.l171().l93();l11(l4 l0=1;l0<l23.l29();
++l0){l21.l367(l8,l0+l164,l86);l1(l114!=l21.l171().l93())l114=l20::
l153;}}l13 l17::l256(l4 l0)l2{l13 l5;l1(l114==l20::l153||l0<0||l0>=
l25.l29())l3 l5;l4 l268=l23.l29();l11(l4 l31=0;l31<l268;++l31){l1(
l805(l21[l31].l12,l0))l5.l12.l70(l31);}l5.l246(l114);l80(l114){l27 l20
::l45:{l49 l7=l16;l53{l5.l14<l7>().l81(l268);l11(l4 l31=0;l31<l268;++
l31)l5.l14<l7>()[l31]=l21[l31].l14<l7>()[l0];l3 l5;}l47(0);l28;}l27
l20::l39:{l49 l7=l24::l15;l53{l5.l14<l7>().l81(l268);l11(l4 l31=0;l31
<l268;++l31)l5.l14<l7>()[l31]=l21[l31].l14<l7>()[l0];l3 l5;}l47(0);
l28;}l27 l20::l75:{l49 l7=l18;l53{l5.l14<l7>().l81(l268);l11(l4 l31=0
;l31<l268;++l31)l5.l14<l7>()[l31]=l21[l31].l14<l7>()[l0];l3 l5;}l47(0
);l28;}l84:l28;};l3 l5;}l6 l17::l46(l363 l442)l2{l4 l736=l25.l29();l4
l268=l23.l29();l4 l86=l442==l363::l633||l442==l363::l956?0:1;l4 l164=
l442==l363::l633||l442==l363::l1016?0:1;l6 l5(l736+l86,l268+l164);l1(
l442==l363::l960)l5(0,0)="";l1(l86==1)l23.l46(l5,0,1,l57);l1(l164==1)l25
.l46(l5,0);l1(l21.l62()){l11(l4 l0=0;l0<l736;++l0)l11(l4 l31=0;l31<
l268;++l31)l5(l0+l86,l31+l164).l443(l377);l3 l5;}l11(l4 l31=0;l31<
l268;++l31)l21[l31].l46(l5,l31+l164,l86);l3 l5;}l17 l17::l7()l2{l17 l5
;l5.l23=l25;l5.l25=l23;l5.l114=l114;l1(l21.l62()||l114==l20::l153)l3
l5;l11(l4 l0=0;l0<l25.l29();++l0)l5.l21.l367(l256(l0));l3 l5;}l6 l17
::l163(l2 l6&l256,l2 l6&l133)l2{l9 l193=l25.l30(l256);l9 l194=l23.l30
(l133);l1(l193<0||l194<0)l3 l428();l3 l21[l194].l91(l193);}l17&l17::
l163(l2 l6&l256,l2 l6&l133,l2 l6&l52){l9 l193=l25.l30(l256);l9 l194=
l23.l30(l133);l1(l194<0){l13 l48(l133,0,0);l1(l48.l62())l35 l41("\x63"
"\x6f\x6c\x20\x69\x73\x20\x65\x6d\x70\x74\x79");l1(l48.l29()!=1)l35
l41("\x63\x6f\x6c\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x69"
"\x6e\x67\x6c\x65\x20\x76\x61\x6c\x75\x65");l194=l23.l29();l23.l56(
l48,0);l13 l14(l52,0,0);l1(l14.l93()==l20::l153)l14.l246(l20::l45);
l14.l81(1);l14.l81(l25.l29());l14.l12.l70(0);l21.l56(l14);}l1(l193<0){
l13 l88(l256,0,0);l1(l88.l62())l35 l41("\x72\x6f\x77\x20\x69\x73\x20"
"\x65\x6d\x70\x74\x79");l1(l88.l29()!=1)l35 l41("\x72\x6f\x77\x20\x73"
"\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x73\x69\x6e\x67\x6c\x65\x20\x76"
"\x61\x6c\x75\x65");l193=l25.l29();l25.l56(l88,0);l11(l9&l48:l21)l48.
l81(l25.l29());}l21[l194].l91(l193,l52);l3*l42;}l6 l17::l91(l4 l193,
l4 l194)l2{l1(l193<0||l194<0||l193>=l25.l29()||l194>=l23.l29())l3 l428
();l3 l21[l194].l91(l193);}l17&l17::l91(l4 l193,l4 l194,l2 l6&l52){l1
(l193<0||l194<0||l193>=l25.l29()||l194>=l23.l29())l35 l454("\x62\x61"
"\x64\x20\x72\x6f\x77\x20\x6f\x72\x20\x63\x6f\x6c");l21[l194].l91(
l193,l52);l3*l42;}l17 l17::l125(l2 l6&l82,l2 l6&l44)l2{l9 l97=l441(
l82.l34<l50>()?"\x3a":l82,l25.l29());l9 l113=l441(l44.l34<l50>()?""
"\x3a":l44,l23.l29());l3 l156(l97,l113);}l17&l17::l125(l2 l22<l4>&l97
,l2 l22<l4>&l113,l2 l6&l52){l1(l52.l34<l50>())l3*l42;l1(l244(l52)){l9
l702=l25.l125(l97);l9 l784=l23.l125(l113);l17 l73(l52);l1(l73.l23.l29
()==1&&l73.l23.l93()==l20::l39&&l73.l23.l99[0]=="\x2a"){l9 l439=l73.
l25.l74(l702,l43);l11(l9 l132:l113){l1(l132<0)l69;l9&l48=l21[l132];
l11(l4 l107=0;l107<(l4)l97.l10();++l107){l1(l97[l107]<0)l69;l1(l439[
l107]<0)l48.l12.l70(l97[l107]);l33 l48.l91(l97[l107],l73.l21[0],l439[
l107]);}}l3*l42;}l1(l73.l25.l29()==1&&l73.l25.l93()==l20::l39&&l73.
l25.l99[0]=="\x2a"){l9 l417=l73.l23.l74(l784,l43);l11(l4 l132=0;l132<
(l4)l113.l10();++l132){l4 l421=l113[l132];l1(l421<0)l69;l9&l48=l21[
l421];l4 l522=l417[l132];l1(l522<0)l11(l9 l107:l97)l1(l107<0)l69;l33
l48.l12.l70(l107);l33 l11(l4 l107=0;l107<(l4)l97.l10();++l107)l1(l97[
l107]<0)l69;l33 l48.l91(l97[l107],l73.l21[l522],0);}l3*l42;}l9 l439=
l73.l25.l74(l702,l43);l9 l417=l73.l23.l74(l784,l43);l11(l4 l132=0;
l132<(l4)l113.l10();++l132){l4 l421=l113[l132];l1(l421<0)l69;l9&l48=
l21[l421];l4 l522=l417[l132];l1(l417[l132]<0)l11(l9 l107:l97)l1(l107<
0)l69;l33 l48.l12.l70(l107);l33 l11(l4 l107=0;l107<(l4)l97.l10();++
l107)l1(l97[l107]<0)l69;l33 l1(l439[l107]<0)l48.l12.l70(l97[l107]);
l33 l48.l91(l97[l107],l73.l21[l417[l132]],l439[l107]);}l3*l42;}l1(!
l52.l191()){l11(l9 l132:l113)l1(l132<0)l69;l33 l11(l9 l107:l97)l1(
l107<0)l69;l33 l21[l132].l91(l107,l52);l3*l42;}l1(l52.l44()==1){l1(
l52.l82()!=(l4)l97.l10())l35 l41("\x76\x61\x6c\x75\x65\x20\x73\x69"
"\x7a\x65\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x77"
"\x69\x74\x68\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e");l11(l9 l132:
l113)l1(l132<0)l69;l33 l11(l4 l107=0;l107<(l4)l97.l10();++l107)l1(l97
[l107]<0)l69;l33 l21[l132].l91(l97[l107],l52(l107,0));l3*l42;}l1(l52.
l82()==1){l1(l52.l44()!=(l4)l113.l10())l35 l41("\x76\x61\x6c\x75\x65"
"\x20\x73\x69\x7a\x65\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c"
"\x65\x20\x77\x69\x74\x68\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e");
l11(l4 l132=0;l132<(l4)l113.l10();++l132)l1(l113[l132]<0)l69;l33 l11(
l9 l107:l97)l1(l107<0)l69;l33 l21[l113[l132]].l91(l107,l52(0,l132));
l3*l42;}l1(l52.l44()!=(l4)l113.l10()||l52.l82()!=(l4)l97.l10())l35 l41
("\x76\x61\x6c\x75\x65\x20\x73\x69\x7a\x65\x20\x69\x6e\x63\x6f\x6d"
"\x70\x61\x74\x69\x62\x6c\x65\x20\x77\x69\x74\x68\x20\x73\x65\x6c\x65"
"\x63\x74\x69\x6f\x6e");l11(l4 l132=0;l132<(l4)l113.l10();++l132)l1(
l113[l132]<0)l69;l33 l11(l4 l107=0;l107<(l4)l97.l10();++l107)l1(l97[
l107]<0)l69;l33 l21[l113[l132]].l91(l97[l107],l52(l107,l132));l3*l42;
}l17&l17::l125(l2 l98::l6&l82,l2 l98::l6&l44,l2 l98::l6&l52){l9 l97=
l441(l82.l34<l50>()?"\x3a":l82,l25.l29());l9 l113=l441(l44.l34<l50>()?""
"\x3a":l44,l23.l29());l3 l125(l97,l113,l52);}l17 l17::l90(l2 l6&l82,
l2 l6&l44)l2{l9 l97=l25.l74(l82.l34<l50>()?"\x3a":l82);l9 l113=l23.
l74(l44.l34<l50>()?"\x3a":l44);l3 l156(l97,l113);}l17&l17::l90(l2 l98
::l6&l82,l2 l98::l6&l44,l2 l98::l6&l52,l17*l673){l13 l538;l297<l4,l4>
l542;l9 l97=l25.l74(l82.l34<l50>()?"\x3a":l82,&l538,&l542);l13 l602;
l297<l4,l4>l582;l9 l113=l23.l74(l44.l34<l50>()?"\x3a":l44,&l602,&l582
);l1(!l582.l62()){l4 l303=l23.l29();l23.l519(l602);l13 l133;l133.l246
(l20::l45);l133.l81(l25.l29());l21.l81(l303+l602.l29(),l133);l11(l4 l0
=0;l0<(l4)l113.l10();++l0)l1(l113[l0]<0)l113[l0]=l303+l582[l0];}l1(!
l542.l62()){l4 l303=l25.l29();l25.l519(l538);l11(l9&l48:l21)l48.l81(
l303+l538.l29());l11(l4 l0=0;l0<(l4)l97.l10();++l0)l1(l97[l0]<0)l97[
l0]=l303+l542[l0];}l125(l97,l113,l52);l1(l673) *l673=l156(l97,l113);
l3*l42;}l17 l17::l253(l2 l22<l20>&l457)l2{l122<l20>l310(l457.l72(),
l457.l40());l22<l4>l30;l30.l101(l21.l10());l11(l4 l0=0;l0<(l4)l21.l10
();++l0){l1(l310.l63(l21[l0].l93())!=l310.l40())l30.l56(l0);}l9 l5=
l252(l30);l1(l310.l10()==1)l5.l114= *l310.l72();l33 l5.l114=l20::l153
;l3 l5;}l17 l17::l793(l2 l22<l20>&l457)l2{l122<l20>l310(l457.l72(),
l457.l40());l22<l4>l30;l30.l101(l21.l10());l11(l4 l0=0;l0<(l4)l21.l10
();++l0){l1(l310.l63(l21[l0].l93())==l310.l40())l30.l56(l0);}l3 l252(
l30);}l17&l17::l70(l4 l90,l2 l6&l52,l2 l6&l302){l1(l90<0||l90>l23.l29
())l35("\x23\x20\x69\x6e\x64\x65\x78\x20\x73\x68\x6f\x75\x6c\x64\x20"
"\x62\x65\x20\x77\x69\x74\x68\x69\x6e\x20\x63\x75\x72\x72\x65\x6e\x74"
"\x20\x63\x6f\x6c\x75\x6d\x6e\x73");l13 l133(l302,0,0);l1(l52.l44()==
2){l17 l149(l52);l1(l149.l23.l29()!=1)l35("\x23\x20\x68\x61\x73\x20"
"\x74\x6f\x20\x62\x65\x20\x61\x20\x73\x69\x6e\x67\x6c\x65\x20\x63\x6f"
"\x6c\x75\x6d\x6e");l9 l30=l149.l25.l74(l25);l149=l149.l156(l30);l21.
l70(l21.l72()+l90,l149.l21[0]);l23.l70(l90,l133.l29()==0?l149.l23:
l133);l3*l42;}l1(l133.l29()!=1)l35("\x23\x20\x62\x61\x64\x20\x63\x6f"
"\x6c\x75\x6d\x6e\x20\x6e\x61\x6d\x65");l23.l70(l90,l133);l1(l52.l44(
)==1){l13 l149(l52,0,0);l149.l81(l25.l29(),l149.l29()==1);l21.l70(l21
.l72()+l90,l149);l3*l42;}l35("\x23\x20\x62\x61\x64\x20\x63\x6f\x6c"
"\x75\x6d\x6e\x20\x74\x6f\x20\x69\x6e\x73\x65\x72\x74");}l17&l17::
l216(l2 l98::l6&l52){l11(l9&l133:l21)l133.l216(l52);l3*l42;}l50 l17::
l512(){l22<l16>l30(l25.l29());l11(l4 l0=0;l0<(l4)l30.l10();++l0)l30[
l0]=l0;l25=l13(l30);}l17 l17::l245(l2 l6&l120)l2{l17 l5( *l42);l5.
l114=l20::l75;l1(!l120.l191()){l13 l131(l120,0,0);l11(l94 l0=0;l0<l21
.l10();++l0)l5.l21[l0]=l21[l0].l245(l131,l57);l3 l5;}l1(l120(0,0).l34
<l15>()&&l120(0,0).l36<l15>()=="\x2a"){l1(l120.l82()!=1&&l120.l44()!=
1)l35("\x23\x20\x69\x66\x20\x73\x74\x61\x72\x74\x73\x20\x77\x69\x74"
"\x68\x20\x2a\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x65\x69\x74"
"\x68\x65\x72\x20\x72\x6f\x77\x20\x6f\x72\x20\x63\x6f\x6c");l13 l131(
l120,0,1,l120.l44()==1);l11(l94 l0=0;l0<l21.l10();++l0)l5.l21[l0]=l21
[l0].l245(l131,l57);l3 l5;}l4 l37=l25.l29();l11(l9&l48:l5.l21){l48.
l140();l48.l246(l20::l75);l48.l95.l81(l37,l57);}l1(l244(l120)){l17
l131(l120);l1(l131.l21.l62())l3 l5;l9 l30=l25.l74(l131.l25,l43);l1(
l131.l23.l93()==l20::l39&&l131.l23.l14<l15>()[0]=="\x2a"){l11(l4 l0=0
;l0<l23.l29();++l0)l5.l21[l0]=l21[l0].l245(l131.l21[0],l30);l3 l5;}l9
l83=l23.l74(l131.l23,l43);l11(l4 l0=0;l0<(l4)l83.l10();++l0){l4 l38=
l83[l0];l1(l38<0||l38>=l23.l29())l69;l5.l21[l38]=l21[l38].l245(l131.
l21[l0],l30);}l3 l5;}l1(l120.l82()<=1)l3 l5;l13 l44(l120,0,0,l57);l22
<l13>l647;l11(l4 l0=0;l0<l120.l44();++l0)l647.l367(l120,l0,1,l43);l9
l30=l23.l74(l44,l43);l11(l4 l0=0;l0<l120.l44();++l0){l4 l38=l30[l0];
l1(l38<0||l38>=l23.l29())l69;l5.l21[l38]=l21[l38].l245(l647[l0],l57);
}l3 l5;}l139 l50 l859(l17&l5,l2 l17&l145){l1(l145.l21.l62())l3;l9 l30
=l5.l25.l74(l145.l25,l43);l1(l145.l23.l93()==l20::l39&&l145.l23.l14<
l15>()[0]=="\x2a"){l11(l4 l0=0;l0<(l4)l30.l10();++l0){l1(l145.l21[0].
l12.l63(l0)!=l145.l21[0].l12.l40())l69;l4 l38=l30[l0];l1(l38<0||l38>=
l5.l25.l29())l69;l11(l4 l31=0;l31<l5.l23.l29();++l31){l5.l21[l31].l95
[l38]=l145.l21[0].l95[l0];}}l3;}l9 l83=l5.l23.l74(l145.l23,l43);l11(
l4 l0=0;l0<(l4)l30.l10();++l0){l4 l38=l30[l0];l1(l38<0||l38>=l5.l25.
l29())l69;l11(l4 l31=0;l31<(l4)l83.l10();++l31){l4 l352=l83[l31];l1(
l352<0||l352>=l5.l23.l29())l69;l1(l145.l21[l31].l12.l63(l0)!=l145.l21
[l31].l12.l40())l69;l5.l21[l352].l95[l38]=l145.l21[l31].l95[l0];}}}
l17 l17::l552(l2 l6&l145,l2 l6&l104,l2 l6&l32,l18 l476,l26 l55)l2{l1(
!l145.l191())l3 l17();l17 l308( *l42);l308.l114=l20::l75;l4 l37=l25.
l29();l11(l9&l48:l308.l21){l48.l140();l48.l246(l20::l75);l48.l95.l81(
l37,l57);}l1(l244(l145)){l17 l131(l145);l859(l308,l131);}l33 l1(l145(
0,0).l34<l15>()&&l145(0,0).l36<l15>()=="\x2a"){l1(l145.l82()!=1&&l145
.l44()!=1)l35("\x23\x20\x69\x66\x20\x73\x74\x61\x72\x74\x73\x20\x77"
"\x69\x74\x68\x20\x2a\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x65"
"\x69\x74\x68\x65\x72\x20\x72\x6f\x77\x20\x6f\x72\x20\x63\x6f\x6c");
l13 l131(l145,0,1,l145.l44()==1);l4 l77=0;l1(l32.l34<l4>())l77=l32.
l36<l4>();l1(l77!=0&&l77!=1)l35("\x23\x20\x61\x78\x69\x73\x20\x73\x68"
"\x6f\x75\x6c\x64\x20\x62\x65\x20\x65\x69\x74\x68\x65\x72\x20\x30\x20"
"\x6f\x72\x20\x31");l1(l77==0){l1(l131.l29()!=l25.l29())l35("\x23\x20"
"\x6c\x65\x6e\x67\x74\x68\x20\x6f\x66\x20\x63\x6f\x6e\x64\x69\x74\x69"
"\x6f\x6e\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x65\x71\x75\x61"
"\x6c\x20\x74\x6f\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x72\x6f"
"\x77\x73");l11(l4 l0=0;l0<l23.l29();++l0){l11(l4 l31=0;l31<l25.l29();
++l31)l308.l21[l0].l95[l31]=l131.l95[l31];}}l33{l1(l131.l29()!=l23.
l29())l35("\x23\x20\x6c\x65\x6e\x67\x74\x68\x20\x6f\x66\x20\x63\x6f"
"\x6e\x64\x69\x74\x69\x6f\x6e\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65"
"\x20\x65\x71\x75\x61\x6c\x20\x74\x6f\x20\x6e\x75\x6d\x62\x65\x72\x20"
"\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73");l11(l4 l0=0;l0<l23.l29();
++l0){l11(l4 l31=0;l31<l25.l29();++l31)l308.l21[l0].l95[l31]=l131.l95
[l0];}}}l17 l5( *l42);l1(l104.l34<l50>()){l11(l4 l0=0;l0<l23.l29();++
l0){l11(l4 l31=0;l31<l25.l29();++l31){l1(l476==l308.l21[l0].l95[l31])l5
.l21[l0].l12.l70(l31);}}l3 l5;}l1(!l104.l191()){l11(l4 l0=0;l0<l23.
l29();++l0){l11(l4 l31=0;l31<l25.l29();++l31){l1(l476==l308.l21[l0].
l95[l31])l5.l21[l0].l91(l31,l104,l55);}}l3 l5;}l1(l244(l104)){l17 l636
(l104);l1(l636.l25.l10()!=l25.l10())l35("\x23\x20\x6f\x74\x68\x65\x72"
"\x20\x64\x61\x74\x61\x66\x72\x61\x6d\x65\x20\x73\x68\x6f\x75\x6c\x64"
"\x20\x68\x61\x76\x65\x20\x73\x61\x6d\x65\x20\x6e\x75\x6d\x62\x65\x72"
"\x20\x6f\x66\x20\x72\x6f\x77\x73");l1(l636.l23.l10()!=l23.l10())l35(""
"\x23\x20\x6f\x74\x68\x65\x72\x20\x64\x61\x74\x61\x66\x72\x61\x6d\x65"
"\x20\x73\x68\x6f\x75\x6c\x64\x20\x68\x61\x76\x65\x20\x73\x61\x6d\x65"
"\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e"
"\x73");l11(l4 l0=0;l0<l23.l29();++l0)l11(l4 l31=0;l31<l25.l29();++
l31){l1(!l476==l308.l21[l0].l95[l31])l69;l9 l8=l636.l21[l0].l91(l31);
l5.l21[l0].l91(l31,l8,l55);}l3 l5;}l1(l104.l82()!=1||l104.l44()!=l23.
l29())l35("\x23\x20\x6f\x74\x68\x65\x72\x20\x73\x68\x6f\x75\x6c\x64"
"\x20\x62\x65\x20\x65\x69\x74\x68\x65\x72\x20\x73\x63\x61\x6c\x61\x72"
"\x20\x6f\x72\x20\x31\x64\x20\x72\x61\x6e\x67\x65\x20\x6f\x66\x20\x76"
"\x61\x6c\x75\x65\x73\x20\x70\x65\x72\x20\x63\x6f\x6c\x75\x6d\x6e");
l11(l4 l0=0;l0<l23.l29();++l0)l11(l4 l31=0;l31<l25.l29();++l31){l1(!
l476==l308.l21[l0].l95[l31])l69;l5.l21[l0].l91(l31,l104(0,l0),l55);}
l3 l5;}l267 l710{l219:l710(l2 l17&l19):l452(l19){}l13 l186(l2 l111*
l110){l1(l9 l37=l412<l2 l430* >(l110))l3 l186(l37);l33 l1(l9 l37=l412
<l2 l477* >(l110))l3 l186(l37);l33 l1(l9 l37=l412<l2 l409* >(l110))l3
l186(l37);l33 l1(l9 l37=l412<l2 l266* >(l110))l3 l186(l37);l33 l1(l9
l37=l412<l2 l362* >(l110))l3 l186(l37);l33 l1(l9 l37=l412<l2 l440* >(
l110))l3 l186(l37);l35 l41("\x4e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65"
"\x64\x20\x66\x6f\x72\x20\x61\x62\x73\x74\x72\x61\x63\x74\x20\x6e\x6f"
"\x64\x65");}l860:l2 l17&l452;l13 l186(l2 l430*l110){l3 l13(l22<l16>(
l452.l25.l10(),l110->l52));}l13 l186(l2 l477*l110){l3 l13(l22<l15>(
l452.l25.l10(),l110->l52));}l13 l186(l2 l409*l110){l4 l30=l452.l23.
l30(l110->l290);l1(l30<0)l35 l41("\x44\x6f\x6e\x27\x74\x20\x68\x61"
"\x76\x65\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x60"+l110->l290+"\x60");l3
l452.l21[l30];}l13 l186(l2 l266*l110){l9 l87=l186(l110->l87.l438());
l9 l127=l186(l110->l127.l438());l3 l87.l183(l110->l55,l127);}l13 l186
(l2 l362*l110){l9 l14=l186(l110->l110.l438());l3 l14.l815(l110->l55);
}l13 l186(l2 l440*l110){l9 l87=l186(l110->l110.l438());l22<l13>l240;
l11(l9&l37:l110->l240)l240.l56(l186(l37.l438()));l3 l87.l245(l240);}}
;l13 l17::l415(l2 l15&l250)l2{l9 l179=l767(l250);l710 l14( *l42);l3
l14.l186(l179.l438());}l50 l17::l415(l2 l15&l250,l2 l15&l302){l9 l44=
l23;l9 l83=l44.l30(l302);l1(l83<0){l13 l48(l22<l15>{l302});l48.l301(
l23.l93());l44.l70(l44.l29(),l48,l57);l83=l44.l29()-1;}l9 l14=l415(
l250);l23=l44;l1(l83==(l4)l21.l10())l21.l56(l14);l33 l21[l83]=l14;l1(
l14.l93()!=l114)l114=l20::l153;}l17 l17::l904(l2 l15 l547)l2{l9 l14=
l415(l547);l1(l14.l93()!=l20::l75)l35 l41("\x51\x75\x65\x72\x79\x20"
"\x64\x69\x64\x20\x6e\x6f\x74\x20\x70\x72\x6f\x64\x75\x63\x65\x20\x62"
"\x6f\x6f\x6c\x65\x61\x6e\x20\x72\x65\x73\x75\x6c\x74\x73");l9 l5= *
l42;l5.l25=l5.l25.l786(l14);l11(l4 l0=0;l0<l5.l23.l29();++l0){l5.l21[
l0]=l5.l21[l0].l786(l14);}l3 l5;}l139 l50 l262(l17&l19,l2 l13&l693){
l9 l138=l19.l25.l74(l693,l43);l11(l4 l0=0;l0<(l4)l138.l10();++l0){l4
l38=l138[l0];l1(l38<0)l19.l25.l56(l693,l0);}l4 l221=l19.l25.l29();l11
(l9&l48:l19.l21)l48.l81(l221);}l139 l50 l269(l17&l19,l2 l17&l71,l2 l22
<l4>&l83){l4 l221=l19.l25.l29();l11(l4 l0=0;l0<(l4)l83.l10();++l0){l4
l38=l83[l0];l1(l38>=0)l69;l19.l23.l56(l71.l23,l0);l19.l21.l56(l71.l21
[l0]);l19.l21.l171().l199();l19.l21.l171().l81(l221);}}l17 l17::l117(
l26 l55,l2 l6&l8,l2 l6&l32,l2 l6&l115)l2{l17 l5( *l42);l9 l78=l115.
l34<l50>()?l106:&l115;l9 l434=l832(l55);l1(!l8.l191()){l13 l131(l8,0,
0);l11(l94 l0=0;l0<l21.l10();++l0)l5.l21[l0]=l5.l21[l0].l183(l55,l131
,l78);l3 l5;}l4 l77=1;l1(l32.l34<l4>())l77=l32.l36<l4>();l1(l77!=0&&
l77!=1)l35("\x23\x20\x41\x78\x69\x73\x20\x73\x68\x6f\x75\x6c\x64\x20"
"\x62\x65\x20\x65\x69\x74\x68\x65\x72\x20\x30\x20\x6f\x72\x20\x31");
l1(!l244(l8)&&(l8.l44()==1||l8.l82()==1)){l1(l77==1){l1(l8.l44() *l8.
l82()!=l23.l29())l35("\x23\x20\x6c\x65\x6e\x67\x74\x68\x20\x6f\x66"
"\x20\x78\x20\x73\x68\x6f\x75\x6c\x64\x20\x6d\x61\x74\x63\x68\x20\x6e"
"\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73");
l4 l38=0;l11(l4 l0=0;l0<l8.l82();++l0)l11(l4 l31=0;l31<l8.l44();++l31
){l13 l14(l8,l0,l31,l57,1);l5.l21[l38]=l5.l21[l38].l183(l55,l14,l78);
++l38;}}l33{l1(l8.l44() *l8.l82()!=l25.l29())l35("\x23\x20\x6c\x65"
"\x6e\x67\x74\x68\x20\x6f\x66\x20\x78\x20\x73\x68\x6f\x75\x6c\x64\x20"
"\x6d\x61\x74\x63\x68\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x63"
"\x6f\x6c\x75\x6d\x6e\x73");l13 l14(l8,0,0,l8.l44()==1);l11(l94 l0=0;
l0<l23.l10();++l0)l5.l21[l0]=l5.l21[l0].l183(l55,l14,l78);}l3 l5;}l9
l71=l244(l8)?l17(l8):(l77==0?l17(l8,&l23):l17(l8,l106,&l25));l1(l71.
l23.l10()==0){l262(l5,l71.l25);l1(l78&&!l434)l3 l5;l11(l94 l0=0;l0<
l21.l10();++l0)l5.l21[l0].l199();l3 l5;}l9 l83=l23.l74(l71.l23,l43);
l1(l71.l25.l10()==0){l269(l5,l71,l83);l1(l78&&!l434)l3 l5;l11(l94 l0=
0;l0<l21.l10();++l0)l5.l21[l0].l199();l3 l5;}l9 l338=l71.l23.l91(0);
l1(l338.l34<l15>()&&l338.l36<l15>()=="\x2a"){l1(l71.l23.l10()!=1)l35
l41("\x4f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x63\x6f\x6c\x75\x6d\x6e\x20"
"\x61\x6c\x6c\x6f\x77\x65\x64\x20\x69\x66\x20\x6e\x61\x6d\x65\x20\x69"
"\x73\x20\x27\x2a\x27");l1(l78&&!l434){l262(l5,l71.l25);l262(l71,l5.
l25);l9 l138=l71.l25.l74(l5.l25,l43);l11(l94 l0=0;l0<l5.l23.l10();++
l0)l5.l21[l0]=l5.l21[l0].l183(l55,l71.l21[0].l125(l138),&l115);l3 l5;
}l9 l138=l71.l25.l74(l25,l43);l11(l94 l0=0;l0<l23.l10();++l0)l5.l21[
l0]=l21[l0].l183(l55,l71.l21[0].l125(l138));l262(l5,l71.l25);l3 l5;}
l9 l86=l71.l25.l91(0);l1(l86.l34<l15>()&&l86.l36<l15>()=="\x2a"){l1(
l71.l25.l10()!=1)l35 l41("\x4f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x72"
"\x6f\x77\x20\x61\x6c\x6c\x6f\x77\x65\x64\x20\x69\x66\x20\x6e\x61\x6d"
"\x65\x20\x69\x73\x20\x27\x2a\x27");l1(l78&&!l434){l269(l5,l71,l83);
l9 l196=l71.l23.l74(l5.l23,l43);l269(l71,l5,l196);l196=l71.l23.l74(l5
.l23,l43);l11(l94 l0=0;l0<l196.l10();++l0){l4 l38=l196[l0];l177(l38>=
0);l5.l21[l0]=l5.l21[l0].l183(l55,l71.l21[l38],&l115);}l3 l5;}l11(l94
l0=0;l0<l83.l10();++l0){l4 l38=l83[l0];l1(l38<0)l69;l5.l21[l38]=l21[
l38].l183(l55,l71.l21[l0]);}l9 l196=l71.l23.l74(l23,l43);l11(l94 l0=0
;l0<l196.l10();++l0){l4 l38=l196[l0];l1(l38>=0)l69;l5.l21[l0].l199();
}l269(l5,l71,l83);l3 l5;}l1(l78&&!l434){l262(l5,l71.l25);l262(l71,l5.
l25);l269(l5,l71,l83);l9 l196=l71.l23.l74(l5.l23,l43);l269(l71,l5,
l196);l196=l71.l23.l74(l5.l23,l43);l9 l138=l71.l25.l74(l5.l25,l43);
l11(l94 l0=0;l0<l196.l10();++l0){l4 l38=l196[l0];l177(l38>=0);l5.l21[
l0]=l5.l21[l0].l183(l55,l71.l21[l38].l125(l138),&l115);}l3 l5;}l9 l138
=l71.l25.l74(l25,l43);l11(l94 l0=0;l0<l83.l10();++l0){l4 l38=l83[l0];
l1(l38<0)l69;l5.l21[l38]=l21[l38].l183(l55,l71.l21[l0].l125(l138));}
l9 l196=l71.l23.l74(l23,l43);l4 l221=l25.l29();l11(l94 l0=0;l0<l196.
l10();++l0){l1(l196[l0]>=0)l69;l5.l21[l0].l199();}l262(l5,l71.l25);
l269(l5,l71,l83);l3 l5;}l17&l17::l849(l26 l55,l2 l98::l6&l8){l1(!l8.
l191()){l13 l131(l8,0,0);l11(l94 l0=0;l0<l21.l10();++l0)l21[l0]=l21[
l0].l183(l55,l131);l3*l42;}l1(!l244(l8)&&(l8.l44()==1||l8.l82()==1)){
l1(l8.l82()==1){l1(l8.l44()!=l23.l29())l35("\x23\x20\x6c\x65\x6e\x67"
"\x74\x68\x20\x6f\x66\x20\x78\x20\x73\x68\x6f\x75\x6c\x64\x20\x6d\x61"
"\x74\x63\x68\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x63\x6f\x6c"
"\x75\x6d\x6e\x73");l11(l4 l0=0;l0<l8.l44();++l0){l13 l14(l8,l0,0,l43
);l21[l0]=l21[l0].l183(l55,l14);}}l33{l1(l8.l82()!=l25.l29())l35(""
"\x23\x20\x6c\x65\x6e\x67\x74\x68\x20\x6f\x66\x20\x78\x20\x73\x68\x6f"
"\x75\x6c\x64\x20\x6d\x61\x74\x63\x68\x20\x6e\x75\x6d\x62\x65\x72\x20"
"\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73");l13 l14(l8,0,0,l43);l11(
l94 l0=0;l0<l23.l10();++l0)l21[l0]=l21[l0].l183(l55,l14);}l3*l42;}l9
l71=l244(l8)?l17(l8):l17(l8,&l23,&l25);l1(l71.l23.l10()==0){l11(l94 l0
=0;l0<l21.l10();++l0)l21[l0].l199();l3*l42;}l1(l71.l25.l10()==0){l11(
l94 l0=0;l0<l21.l10();++l0)l21[l0].l199();l3*l42;}l9 l338=l71.l23.l91
(0);l9 l138=l71.l25.l74(l25,l43);l1(l338.l34<l15>()&&l338.l36<l15>()==""
"\x2a"){l1(l71.l23.l10()!=1)l35 l41("\x4f\x6e\x6c\x79\x20\x6f\x6e\x65"
"\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x61\x6c\x6c\x6f\x77\x65\x64\x20\x69"
"\x66\x20\x6e\x61\x6d\x65\x20\x69\x73\x20\x27\x2a\x27");l11(l94 l0=0;
l0<l23.l10();++l0)l21[l0]=l21[l0].l183(l55,l71.l21[0].l125(l138));l3*
l42;}l9 l83=l71.l23.l74(l23,l43);l9 l86=l71.l25.l91(0);l1(l86.l34<l15
>()&&l86.l36<l15>()=="\x2a"){l1(l71.l25.l10()!=1)l35 l41("\x4f\x6e"
"\x6c\x79\x20\x6f\x6e\x65\x20\x72\x6f\x77\x20\x61\x6c\x6c\x6f\x77\x65"
"\x64\x20\x69\x66\x20\x6e\x61\x6d\x65\x20\x69\x73\x20\x27\x2a\x27");
l11(l94 l0=0;l0<l83.l10();++l0){l4 l38=l83[l0];l1(l38<0){l21[l0].l199
();l69;}l21[l0]=l21[l0].l183(l55,l71.l21[l38]);}l3*l42;}l11(l94 l0=0;
l0<l83.l10();++l0){l4 l38=l83[l0];l1(l38<0){l21[l0].l199();l69;}l21[
l38]=l21[l38].l183(l55,l71.l21[l0].l125(l138));}l3*l42;}l17 l17::l597
(l2 l17&l104)l2{l1(l104.l25.l10()!=l23.l10())l35 l41("\x49\x6e\x63"
"\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x73\x69\x7a\x65\x73");l9 l30
=l23.l74(l104.l25,l57);l17 l5;l5.l25=l25;l5.l23=l104.l23;l5.l114=l20
::l45;l5.l21.l81(l23.l10());l11(l9&l48:l5.l21){l48.l210(l25.l29());}
l9 l8=l7();l11(l94 l31=0;l31<l104.l23.l10();++l31){l9 l847=l104.l21[
l31].l125(l30);l11(l4 l0=0;l0<l25.l29();++l0){l9 l59=l8.l21[l0].l597(
l847);l1(l235(l59))l5.l21[l31].l12.l70(l0);l33 l5.l21[l31].l54[l0]=
l59;}}l3 l5;}l17&l17::l1032(l2 l17&l71){l1(l71.l23.l10()==0||l71.l25.
l10()==0)l3*l42;l9 l83=l23.l74(l71.l23,l43);l9 l138=l25.l74(l71.l25,
l43);l11(l4 l0=0;l0<(l4)l83.l10();++l0){l4 l38=l83[l0];l1(l38<0)l69;
l11(l4 l31=0;l31<(l4)l138.l10();++l31){l4 l352=l138[l31];l1(l352<0)l69
;l1(l71.l21[l0].l12.l128(l31)>0)l69;l1(l21[l38].l12.l128(l352)==0)l69
;l21[l38].l91(l352,l71.l21[l0].l91(l31));}}l3*l42;}l17 l17::l406(l2
l98::l6&l8)l2{l17 l5( *l42);l1(!l8.l191())l3 l5.l216(l8);l1(!l244(l8))l35
("\x23\x20\x78\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x61\x20"
"\x64\x61\x74\x61\x66\x72\x61\x6d\x65");l17 l71(l8);l1(l71.l23.l10()==
0){l262(l5,l71.l25);l3 l5;}l9 l83=l23.l74(l71.l23,l43);l1(l71.l25.l10
()==0){l269(l5,l71,l83);l3 l5;}l9 l338=l71.l23.l91(0);l1(l338.l34<l15
>()&&l338.l36<l15>()=="\x2a"){l1(l71.l23.l10()!=1)l35 l41("\x4f\x6e"
"\x6c\x79\x20\x6f\x6e\x65\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x61\x6c\x6c"
"\x6f\x77\x65\x64\x20\x69\x66\x20\x6e\x61\x6d\x65\x20\x69\x73\x20\x27"
"\x2a\x27");l262(l5,l71.l25);l9 l138=l71.l25.l74(l5.l25,l43);l11(l94
l0=0;l0<l23.l10();++l0)l5.l21[l0]=l5.l21[l0].l406(l71.l21[0].l125(
l138));l3 l5;}l9 l86=l71.l25.l91(0);l1(l86.l34<l15>()&&l86.l36<l15>()==""
"\x2a"){l1(l71.l25.l10()!=1)l35 l41("\x4f\x6e\x6c\x79\x20\x6f\x6e\x65"
"\x20\x72\x6f\x77\x20\x61\x6c\x6c\x6f\x77\x65\x64\x20\x69\x66\x20\x6e"
"\x61\x6d\x65\x20\x69\x73\x20\x27\x2a\x27");l269(l5,l71,l83);l83=l5.
l23.l74(l71.l23,l43);l11(l94 l0=0;l0<l83.l10();++l0){l4 l38=l83[l0];
l1(l38<0)l69;l5.l21[l38]=l5.l21[l38].l406(l71.l21[l0]);}l3 l5;}l262(
l5,l71.l25);l269(l5,l71,l83);l83=l5.l23.l74(l71.l23,l43);l9 l138=l71.
l25.l74(l5.l25,l43);l11(l94 l0=0;l0<l83.l10();++l0){l4 l38=l83[l0];l1
(l38<0)l69;l5.l21[l38]=l5.l21[l38].l406(l71.l21[l0].l125(l138));}l3 l5
;}l17&l17::l319(){l11(l9&l48:l21)l1(l48.l93()==l20::l45)l48.l319();l3
 *l42;}l17 l17::l337(l4 l32,l18 l264,l18 l65,l18 l455)l2{l1(l264){l9
l61=l253(l22<l20>{l20::l75});l3 l61.l337(l32,l57,l65,l455);}l80(l32){
l27 0:{l17 l5;l5.l25.l210(l22<l15>{"\x2a"});l5.l23=l23;l5.l114=l20::
l75;l5.l21.l81(l23.l10());l11(l4 l0=0;l0<l23.l29();++l0){l5.l21[l0].
l246(l20::l75);l5.l21[l0].l95.l81(1,l43);l5.l21[l0].l95[0]=l455?l21[
l0].l889(l57,l65):l21[l0].l337(l57,l65);}l3 l5;}l27 1:{l9 l61= *l42;
l61.l114=l20::l75;l11(l9&l48:l61.l21)l48.l301(l20::l75);l3 l61.l7().
l337(0,l57,l65,l455).l7();}l84:l3 l337(0,l57,l65,l455).l337(1,l57,l65
,l455);}}l17 l17::l657(l2 l6&l390,l2 l6&l184,l2 l6&l32){l6 l78;l17*l5
=l42;l17 l61;l1(!l390.l34<l50>()){l61=l117(l26::l142,l390,l32,l78);l5
=&l61;}l1(!l184.l34<l50>()){l61=l5->l117(l26::l144,l184,l32,l78);l5=&
l61;}l3*l5;}l17 l17::l514(l4 l230,l18 l76)l2{l9 l19=l42;l17 l61;l1(
l76){l61=l19->l253(l22<l20>{l20::l45});l19=&l61;}l17 l5;l5.l25=l19->
l23;l5.l23=l19->l23;l4 l37=l19->l23.l29();l5.l114=l20::l45;l5.l21.l81
(l37);l11(l9&l48:l5.l21){l48.l246(l20::l45);l48.l54.l81(l37);}l11(l4
l0=0;l0<l37;++l0){l9&l423=l19->l21[l0];l5.l21[l0].l54[l0]=1;l11(l4 l31
=l0+1;l31<l37;++l31){l9&l573=l19->l21[l31];l9 l48=l423.l514(l573,l230
);l1(l235(l48)){l5.l21[l0].l12.l70(l31);l5.l21[l31].l12.l70(l0);}l33{
l5.l21[l0].l54[l31]=l48;l5.l21[l31].l54[l0]=l48;}}}l3 l5;}l17 l17::
l877(l2 l17&l104,l18 l181,l18 l76)l2{l9 l223=l42;l9 l249=&l104;l17
l771,l772;l1(l76){l771=l223->l253(l22<l20>{l20::l45});l223=&l771;l772
=l249->l253(l22<l20>{l20::l45});l249=&l772;}l33{l1(l223->l114!=l20::
l45||l249->l114!=l20::l45)l35 l41("\x63\x6f\x72\x72\x77\x69\x74\x68"
"\x20\x6f\x6e\x6c\x79\x20\x77\x6f\x72\x6b\x73\x20\x77\x69\x74\x68\x20"
"\x6e\x75\x6d\x65\x72\x69\x63\x20\x64\x61\x74\x61");}l17 l5;l5.l25.
l210(l22<l15>{"\x63\x6f\x72\x72"});l5.l23=l223->l23;l5.l114=l20::l45;
l5.l21.l81(l223->l23.l10());l11(l9&l48:l5.l21){l48.l246(l20::l45);l48
.l54.l81(1);}l269(l5, *l249,l223->l23.l74(l249->l23,l43));l9 l138=
l223->l25.l74(l249->l25,l43);l9 l196=l223->l23.l74(l5.l23,l43);l9 l924
=l249->l23.l74(l5.l23,l43);l11(l4 l0=0;l0<l5.l23.l29();++l0){l4 l272=
l196[l0];l4 l384=l924[l0];l1(l272<0||l384<0){l5.l21[l0].l12.l70(0);
l69;}l1(!l181&&(l223->l21[l272].l12.l10()>0||l249->l21[l384].l12.l10(
)>0)){l5.l21[l0].l12.l70(0);l69;}l9 l48=l223->l21[l272].l514(l249->
l21[l384].l125(l138),1);l1(l235(l48))l5.l21[l0].l12.l70(0);l33 l5.l21
[l0].l54[0]=l48;}l3 l5;}l17 l17::l128(l4 l32,l18 l76)l2{l17 l61=l76?
l253(l22<l20>{l20::l45}): *l42;l17 l5;l5.l114=l20::l45;l80(l32){l27 0
:{l5.l25.l210(l22<l15>{"\x63\x6f\x75\x6e\x74"});l5.l23=l61.l23;l5.l21
.l81(l61.l23.l10());l11(l4 l0=0;l0<l61.l23.l29();++l0){l5.l21[l0].
l246(l20::l45);l5.l21[l0].l54.l81(1);l5.l21[l0].l54[0]=l61.l21[l0].
l128();}l3 l5;}l27 1:{l5.l23.l210(l22<l15>{"\x63\x6f\x75\x6e\x74"});
l5.l21.l81(1);l5.l21[0].l246(l20::l45);l5.l21[0].l54.l81(l25.l29());
l5.l25=l25;l11(l4 l0=0;l0<l25.l29();++l0){l4 l37=0;l11(l9&l48:l61.l21
)l1(l48.l12.l63(l0)==l48.l12.l40())++l37;l5.l21[0].l54[l0]=l37;}l3 l5
;}l84:l3 l128(0,l76).l128(1,l76);}}l17&l17::l761(){l25.l81(l4(l21.l10
() *l25.l10()),l43);l11(l94 l0=1;l0<l21.l10();++l0)l21[0].l519(l21[l0
]);l21.l81(1);l23.l210(l22<l15>{"\x2a"});l3*l42;}l17 l17::l471(l4 l230
,l4 l175,l18 l76)l2{l9 l19=l42;l17 l61;l1(l76){l61=l19->l253(l22<l20>
{l20::l45});l19=&l61;}l17 l5;l5.l25=l19->l23;l5.l23=l19->l23;l4 l37=
l19->l23.l29();l5.l114=l20::l45;l5.l21.l81(l37);l11(l9&l48:l5.l21){
l48.l246(l20::l45);l48.l54.l81(l37);}l11(l4 l0=0;l0<l37;++l0){l9&l423
=l19->l21[l0];l5.l21[l0].l54[l0]=l423.l471(l423,l230,l175);l11(l4 l31
=l0+1;l31<l37;++l31){l9&l573=l19->l21[l31];l9 l48=l423.l471(l573,l230
,l175);l1(l235(l48)){l5.l21[l0].l12.l70(l31);l5.l21[l31].l12.l70(l0);
}l33{l5.l21[l0].l54[l31]=l48;l5.l21[l31].l54[l0]=l48;}}}l3 l5;}l64<
l167 l68>l17 l17::l215(l4 l32,l18 l65)l2{l1(l32!=0)l3 l7().l215<l68>(
0,l65).l7();l17 l5= *l42;l11(l9&l48:l5.l21)l48.l215<l68>(l65);l3 l5;}
l64 l17 l17::l215<l167::l142>(l4 l32,l18 l65)l2;l64 l17 l17::l215<
l167::l144>(l4 l32,l18 l65)l2;l64 l17 l17::l215<l167::l355>(l4 l32,
l18 l65)l2;l64 l17 l17::l215<l167::l351>(l4 l32,l18 l65)l2;l17 l17::
l478(l2 l22<l16>&l243,l2 l22<l20>&l398,l2 l22<l20>&l436)l2{l9 l61=
l253(l398.l62()?l22<l20>{l20::l45}:l398).l793(l436);l17 l5;l1(l61.l23
.l29()==0)l3 l5;l5.l23=l61.l23;l5.l114=l20::l153;l5.l25=l61.l21[0].
l733(l243);l5.l21.l56(l61.l21[0].l478(l243));l11(l4 l0=1;l0<l61.l23.
l29();++l0){l9 l178=l61.l21[l0].l733(l243);l262(l5,l178);l9 l138=l178
.l74(l5.l25,l43);l5.l21.l56(l61.l21[l0].l478(l243).l125(l138));}l3 l5
;}l17 l17::l332(l4 l92,l4 l32)l2{l1(l32!=0)l3 l7().l332(l92,0).l7();
l17 l5= *l42;l11(l9&l48:l5.l21)l48.l332(l92);l3 l5;}l17 l17::l195(
l105 l55,l2 l6&l32,l2 l6&l65,l2 l6&l76,l2 l6&l465)l2{l18 l204=l76.l34
<l18>()?l76.l36<l18>():l57;l9 l19=l42;l17 l61;l1(l204){l61=l19->l253(
l22<l20>{l20::l45});l19=&l61;}l4 l77=l32.l34<l4>()?l32.l36<l4>():0;l1
(l77==1)l3 l19->l7().l195(l55,0,l65,l57,l465).l7();l1(l77==-1){l1(l19
!=&l61)l61= *l19;l3 l61.l761().l195(l55,0,l65,l57,l465);}l18 l304=l65
.l34<l18>()?l65.l36<l18>():l43;l4 l373=l465.l34<l4>()?l465.l36<l4>():
0;l17 l5;l5.l23=l19->l23;l5.l25.l210(l22<l15>{l792(l55)});l5.l114=l20
::l45;l5.l21.l81(l19->l23.l29());l11(l4 l0=0;l0<l19->l23.l29();++l0){
l5.l21[l0].l246(l20::l45);l5.l21[l0].l54.l81(1);l9 l146=l19->l21[l0].
l195(l55,l304,l373);l1(l235(l146))l5.l21[l0].l12.l70(0);l33 l5.l21[l0
].l54[0]=l146;}l3 l5;}l17 l17::l501(l2 l6&l32,l2 l6&l76,l2 l6&l158){
l18 l204=l76.l34<l18>()?l76.l36<l18>():l57;l18 l621=l158.l34<l18>()?
l158.l36<l18>():l43;l9 l19=l42;l17 l61;l1(l204){l61=l19->l253(l22<l20
>{l20::l45});l19=&l61;}l4 l77=l32.l34<l4>()?l32.l36<l4>():0;l1(l77==1
)l3 l19->l7().l501(0,l57,l158).l7();l17 l5;l5.l23=l19->l23;l5.l21.l81
(l19->l23.l10());l5.l114=l19->l114;l11(l4 l0=0;l0<l19->l23.l29();++l0
)l5.l21[l0]=l19->l21[l0].l501(l621);l4 l37=0;l11(l9&l48:l5.l21)l37=
l333(l37,l48.l29());l11(l9&l48:l5.l21)l48.l81(l37);l22<l16>l30(l37);
l11(l4 l0=0;l0<l37;++l0)l30[l0]=l0;l5.l25.l210(l30);l3 l5;}l17 l17::
l626(l4 l92,l136 l311,l4 l109)l2{l17 l5= *l42;l11(l9&l48:l5.l21)l48.
l626(l92,l311,l109);l3 l5;}l17 l17::l482(l4 l92,l2 l6*l115)l2{l17 l5=
 *l42;l11(l9&l48:l5.l21)l48.l482(l92,l115);l3 l5;}l17 l17::l356(l2 l6
&l179,l2 l6&l32,l2 l6&l76,l2 l6&l231,l2 l6&l102)l2{l18 l204=l76.l34<
l18>()?l76.l36<l18>():l57;l9 l19=l42;l17 l61;l1(l204){l61=l19->l253(
l22<l20>{l20::l45});l19=&l61;}l15 l293=l102.l34<l15>()?l102.l36<l15>(
):"\x73\x69\x6e\x67\x6c\x65";l1(l293=="\x74\x61\x62\x6c\x65"){l1(l19
!=&l61)l61= *l19;l3 l61.l761().l356(l179,0,l57,l231,l102);}l4 l77=l32
.l34<l4>()?l32.l36<l4>():0;l1(l77==1)l3 l19->l7().l356(l179,0,l57,
l231,l102).l7();l15 l533=l231.l34<l15>()?l231.l36<l15>():"\x6c\x69"
"\x6e\x65\x61\x72";l22<l16>l668=l179.l34<l50>()?l22<l16>{0.5}:(l179.
l34<l16>()?l22<l16>{l179.l36<l16>()}:l179.l890());l17 l5;l5.l23=l19->
l23;l5.l21.l81(l19->l23.l10());l5.l114=l19->l114;l11(l4 l0=0;l0<l19->
l23.l29();++l0)l5.l21[l0]=l19->l21[l0].l356(l668,l533);l5.l25=l668;l3
l5;}l17 l17::l157(l2 l6&l32,l2 l6&l102,l2 l6&l76,l2 l6&l116,l2 l6&
l134,l2 l6&l123)l2{l18 l204=l76.l34<l18>()?l76.l36<l18>():l57;l18 l365
=l134.l34<l18>()?l134.l36<l18>():l43;l18 l862=l123.l34<l18>()?l123.
l36<l18>():l57;l9 l19=l42;l17 l61;l1(l204){l61=l19->l253(l22<l20>{l20
::l45});l19=&l61;}l4 l77=l32.l34<l4>()?l32.l36<l4>():0;l1(l77==1)l3
l19->l7().l157(0,l102,l57,l116,l134,l123).l7();l15 l293=l102.l34<l15>
()?l102.l36<l15>():"\x61\x76\x65\x72\x61\x67\x65";l15 l881=l116.l34<
l15>()?l116.l36<l15>():"\x6b\x65\x65\x70";l17 l5;l5.l23=l19->l23;l5.
l25=l19->l25;l5.l21.l81(l19->l23.l10());l5.l114=l20::l45;l11(l4 l0=0;
l0<l19->l23.l29();++l0)l5.l21[l0]=l19->l21[l0].l157(l293,l881,l365,
l862);l3 l5;}l17 l17::l345(l2 l98::l6&l222)l2{l1(l222.l34<l4>()){l4
l59=l222.l36<l4>();l17 l5= *l42;l11(l9&l48:l5.l21)l48.l345(l59);l3 l5
;}l1(l244(l222)){l17 l19(l222);l1(l19.l114!=l20::l45)l35 l41("\x72"
"\x6f\x75\x6e\x64\x3a\x20\x64\x65\x63\x69\x6d\x61\x6c\x73\x20\x6d\x75"
"\x73\x74\x20\x62\x65\x20\x6e\x75\x6d\x65\x72\x69\x63");l1(l19.l25.
l29()!=1)l35 l41("\x72\x6f\x75\x6e\x64\x3a\x20\x64\x65\x63\x69\x6d"
"\x61\x6c\x73\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x61\x20\x73\x69\x6e"
"\x67\x6c\x65\x20\x72\x6f\x77");l9 l83=l23.l74(l19.l23,l43);l9 l5=
l252(l83);l11(l4 l0=0;l0<l5.l23.l29();++l0){l9&l48=l5.l21[l0];l9&l706
=l19.l21[l83[l0]];l1(!l706.l12.l62())l35 l41("\x72\x6f\x75\x6e\x64"
"\x3a\x20\x64\x65\x63\x69\x6d\x61\x6c\x73\x20\x6d\x75\x73\x74\x20\x6e"
"\x6f\x74\x20\x63\x6f\x6e\x74\x61\x69\x6e\x20\x6d\x69\x73\x73\x69\x6e"
"\x67\x20\x76\x61\x6c\x75\x65\x73");l48.l345((l4)l706.l54[0]);}l3 l5;
}l1(l222.l191()&&(l222.l44()==1||l222.l82()==1)){l13 l73(l222,0,0,
l222.l44()==1);l1(l73.l93()!=l20::l45)l35 l41("\x72\x6f\x75\x6e\x64"
"\x3a\x20\x64\x65\x63\x69\x6d\x61\x6c\x73\x20\x6d\x75\x73\x74\x20\x62"
"\x65\x20\x6e\x75\x6d\x65\x72\x69\x63");l1(l73.l29()!=l23.l29())l35
l41("\x72\x6f\x75\x6e\x64\x3a\x20\x64\x65\x63\x69\x6d\x61\x6c\x73\x20"
"\x6d\x75\x73\x74\x20\x68\x61\x76\x65\x20\x74\x68\x65\x20\x73\x61\x6d"
"\x65\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x73\x20\x74\x68\x65\x20\x6e"
"\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73");
l1(!l73.l12.l62())l35 l41("\x72\x6f\x75\x6e\x64\x3a\x20\x64\x65\x63"
"\x69\x6d\x61\x6c\x73\x20\x6d\x75\x73\x74\x20\x6e\x6f\x74\x20\x63\x6f"
"\x6e\x74\x61\x69\x6e\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x76\x61\x6c"
"\x75\x65\x73");l17 l5= *l42;l11(l4 l0=0;l0<l5.l23.l29();++l0)l5.l21[
l0].l345((l4)l73.l54[l0]);l3 l5;}l35 l41("\x72\x6f\x75\x6e\x64\x3a"
"\x20\x62\x61\x64\x20\x64\x65\x63\x69\x6d\x61\x6c\x73\x20\x69\x6e\x70"
"\x75\x74");}l17 l17::l392(l4 l32,l18 l158)l2{l1(l32==1)l3 l7().l392(
0,l158).l7();l17 l5;l5.l23=l23;l5.l25.l210(l22<l15>{"\x6e\x75\x6e\x69"
"\x71\x75\x65"});l5.l21.l81(l23.l10());l5.l114=l20::l45;l11(l4 l0=0;
l0<l23.l29();++l0)l5.l21[l0].l210(1,(l16)l21[l0].l392(l158));l3 l5;}
l17&l17::l650(l2 l15&l361,l4 l32,l18 l752){l1(l32==1){l23.l301(l20::
l39);l1(l752)l11(l9&l48:l23.l99)l48=l361+l48;l33 l11(l9&l48:l23.l99)l48
=l48+l361;l3*l42;}l25.l301(l20::l39);l1(l752)l11(l9&l48:l25.l99)l48=
l361+l48;l33 l11(l9&l48:l25.l99)l48=l48+l361;l3*l42;}l17 l17::l473(
l16 l273,l16 l154,l4 l32)l2{l1(l32==1)l3 l7().l473(l273,l154,0).l7();
l9 l30=l25.l473(l273,l154);l3 l156(l30);}l17 l17::l502(l16 l265,l16
l270,l260 l370,l4 l32,l16 l154)l2{l1(l32==1)l3 l7().l502(l265,l270,
l370,0,l154).l7();l9 l30=l25.l502(l265,l270,l370,l154);l3 l156(l30);}
l17 l17::l181(l2 l13*l170,l4 l32,l2 l13*l178,l2 l13*l44,l18 l275)l2{
l1(l170==l106&&l178==l106&&l44==l106)l3*l42;l1(l170!=l106&&l170->l12.
l10()!=l170->l10()){l1(l32==0)l3 l181(l25.l74( *l170,l275));l33 l3
l744(l23.l74( *l170,l275));}l1(l178!=l106&&l44!=l106)l3 l181(l25.l74(
 *l178,l275),l23.l74( *l44,l275));l1(l178!=l106)l3 l181(l25.l74( *
l178,l275));l1(l44!=l106)l3 l744(l23.l74( *l44,l275));l35 l41("\x64"
"\x72\x6f\x70\x3a\x20\x62\x61\x64\x20\x69\x6e\x70\x75\x74");}l139 l22
<l4>l791(l22<l15>&l261,l4 l137){l297<l15,l4>l329;l22<l4>l5;l5.l101(
l261.l10());l80(l137){l27-1:l11(l4 l0=0;l0<(l4)l261.l10();++l0)l1(
l329.l63(l261[l0])==l329.l40()){l329[l261[l0]]=l0;l5.l56(l0);}l3 l5;
l27 0:l11(l2 l9&l67:l261)++l329[l67];l11(l4 l0=0;l0<(l4)l261.l10();++
l0)l1(l329[l261[l0]]==1)l5.l56(l0);l3 l5;l27 1:l11(l4 l0=(l4)l261.l10
()-1;l0>=0;--l0)l1(l329.l63(l261[l0])==l329.l40()){l329[l261[l0]]=l0;
l5.l56(l0);}l973(l5.l72(),l5.l40());l3 l5;l84:l3 l5;}}l22<l4>l17::
l565(l2 l13*l143,l4 l137)l2{l9 l19=l42;l17 l61;l1(l143!=l106){l61=l19
->l252(l23.l74( *l143));l19=&l61;}l9 l261=l420(l19->l46(),l43,l43);l3
l791(l261,l137);}l22<l4>l17::l1058(l2 l13*l143,l4 l137)l2{l3 l715(
l565(l143,l137),l25.l29());}l17 l17::l829(l2 l13*l143,l4 l137,l18 l155
)l2{l9 l5=l156(l565(l143,l137));l1(l155)l5.l512();l3 l5;}l17 l17::
l892(l2 l13*l143,l4 l137)l2{l9 l30=l565(l143,l137);l17 l5;l5.l25=l25;
l5.l23.l210(l22<l15>({"\x64\x75\x70\x6c\x69\x63\x61\x74\x65\x64"}));
l5.l21.l81(1);l5.l21[0]=l25.l863(l30,l57);l5.l114=l20::l75;l3 l5;}l17
l17::l866(l2 l13*l259,l2 l15*l316,l2 l15*l180,l4 l32)l2{l1(l32==0){l9
l30=l25.l725(l259,l316,l180);l3 l156(l30);}l9 l30=l23.l725(l259,l316,
l180);l3 l252(l30);}l17 l17::l599(l2 l13*l170,l4 l32,l2 l13*l178,l2
l13*l44,l136 l102,l2 l6&l115,l4 l109,l16 l239)l2{l1(l170==l106&&l178
==l106&&l44==l106)l35 l41("\x6e\x65\x65\x64\x20\x6f\x6e\x65\x20\x6f"
"\x66\x20\x6c\x61\x62\x65\x6c\x73\x2c\x20\x69\x6e\x64\x65\x78\x20\x6f"
"\x72\x20\x63\x6f\x6c\x75\x6d\x6e\x73");l2 l6*l8=l115.l34<l50>()?l106
:&l115;l1(l170){l3 l599(l106,l32,l32==0?l170:l106,l32==1?l170:l106,
l102,l115,l109,l239);}l22<l4>l83,l138;l1(l178)l138=l25.l74( *l178,l43
,l239,l102,l109);l1(l44)l83=l23.l74( *l44,l43,l239,l102,l109);l9 l5=
l178!=l106&&l44!=l106?l156(l138,l83,l8):l178?l156(l138,l8):l252(l83,
l8);l1(l178)l5.l25= *l178;l1(l44)l5.l23= *l44;l3 l5;}l17&l17::l512(
l18 l181,l18 l315,l2 l6&l494){l1(!l181){l13 l541(l494.l34<l50>()?l6(""
"\x69\x6e\x64\x65\x78"):l494,0,0);l23.l70(0,l541,l315);l21.l70(l21.
l72(),l25);}l22<l16>l30(l25.l29());l11(l4 l0=0;l0<l25.l29();++l0)l30[
l0]=l0;l25=l13(l30);l3*l42;}l17 l17::l713(l4 l37,l16 l330,l18 l234,l2
l6&l248,l4 l453,l4 l32,l18 l155)l2{l18 l741=!l248.l191()&&!l248.l34<
l50>();l1(l741&&l32!=0)l35 l41("\x61\x78\x69\x73\x20\x73\x68\x6f\x75"
"\x6c\x64\x20\x62\x65\x20\x30\x20\x69\x66\x20\x63\x6f\x6c\x75\x6d\x6e"
"\x20\x6e\x61\x6d\x65\x20\x69\x73\x20\x75\x73\x65\x64\x20\x61\x73\x20"
"\x77\x65\x69\x67\x68\x74\x73");l1(l37>0&&l330>0)l35 l41("\x6f\x6e"
"\x6c\x79\x20\x6f\x6e\x65\x20\x6f\x66\x20\x6e\x20\x61\x6e\x64\x20\x66"
"\x72\x61\x63\x20\x63\x61\x6e\x20\x62\x65\x20\x3e\x20\x30");l1(l32==1
)l3 l7().l713(l37,l330,l234,l248,l453,0,l155).l7();l1(l37==0&&l330==0
){l9 l5= *l42;l5.l25.l140();l11(l9&l59:l5.l21)l59.l140();l3 l5;}l1(
l330>0)l37=(l4)(l330*l25.l29());l22<l16>l242(l25.l29(),1);l1(l741){
l13 l48(l248,0,0);l9 l83=l23.l74(l48,l43);l1(l83.l62()||l83[0]<0)l35
l41("\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x64\x20\x77"
"\x65\x69\x67\x68\x74\x20\x63\x6f\x6c\x75\x6d\x6e");l4 l38=l83[0];l1(
l21[l38].l93()!=l20::l45)l35 l41("\x77\x65\x69\x67\x68\x74\x20\x63"
"\x6f\x6c\x75\x6d\x6e\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x6e\x75\x6d"
"\x65\x72\x69\x63");l9 l326=l21[l38];l326.l396(0.0,l43);l242=l326.l54
;}l33 l1(l244(l248)){l17 l326(l248);l1(l326.l23.l29()!=1)l35 l41(""
"\x77\x65\x69\x67\x68\x74\x20\x64\x61\x74\x61\x66\x72\x61\x6d\x65\x20"
"\x6d\x75\x73\x74\x20\x68\x61\x76\x65\x20\x6f\x6e\x65\x20\x63\x6f\x6c"
"\x75\x6d\x6e");l1(l326.l21[0].l93()!=l20::l45)l35 l41("\x77\x65\x69"
"\x67\x68\x74\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x6d\x75\x73\x74\x20\x62"
"\x65\x20\x6e\x75\x6d\x65\x72\x69\x63");l326.l21[0].l396(0.0,l43);l9
l30=l326.l25.l74(l25,l43);l11(l4 l0=0;l0<l25.l29();++l0)l242[l0]=l30[
l0]<0?0.0:l326.l21[0].l54[l30[l0]];}l33 l1(l248.l191()){l1(l248.l44()!=
1&&l248.l82()!=1)l35 l41("\x77\x65\x69\x67\x68\x74\x73\x20\x6d\x75"
"\x73\x74\x20\x62\x65\x20\x61\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x6f\x72"
"\x20\x72\x6f\x77");l13 l48(l248,0,0,l248.l44()==1);l1(l48.l93()!=l20
::l45)l35 l41("\x77\x65\x69\x67\x68\x74\x20\x63\x6f\x6c\x75\x6d\x6e"
"\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x6e\x75\x6d\x65\x72\x69\x63");
l1(l48.l10()!=l25.l10())l35 l41("\x77\x65\x69\x67\x68\x74\x20\x63\x6f"
"\x6c\x75\x6d\x6e\x20\x6d\x75\x73\x74\x20\x68\x61\x76\x65\x20\x73\x61"
"\x6d\x65\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x73\x20\x64\x61\x74\x61"
"\x66\x72\x61\x6d\x65");l48.l396(0.0,l43);l242=l48.l54;}l925 l785(
l453);l22<l4>l30(l37);l1(l234){l813<>l594(l242.l72(),l242.l40());l11(
l4 l0=0;l0<l37;++l0)l30[l0]=l594(l785);}l33{l22<l4>l431(l25.l10());
l743(l431.l72(),l431.l40(),0);l11(l4 l0=0;l0<l37;++l0){l16 l188=0;l4
l487=(l4)l242.l10()-l0-1;l11(l4 l31=0;l31<=l487;++l31)l188+=l242[l31]
;l1(l188==0)l35 l41("\x6e\x6f\x74\x20\x65\x6e\x6f\x75\x67\x68\x74\x20"
"\x6e\x6f\x6e\x7a\x65\x72\x6f\x20\x77\x65\x69\x67\x68\x74\x73");l813<
>l594(l242.l72(),l242.l72()+l487+1);l4 l25=l594(l785);l30[l0]=l431[
l25];l24::l802(l242[l25],l242[l487]);l24::l802(l431[l25],l431[l487]);
}}l9 l5=l156(l30);l1(l155)l5.l512();l3 l5;}l17 l17::l158(l4 l32,l18
l488,l4 l422,l2 l13*l143,l18 l155)l2{l9 l19=l42;l17 l61;l1(l143){l1(
l32==0){l9 l30=l23.l74( *l143,l43);l61=l252(l30);l19=&l61;}l33{l9 l30
=l25.l74( *l143,l43);l61=l156(l30);l19=&l61;}}l1(l32==0){l22<l4>l30;
l30.l101(l25.l10());l4 l567=l422>0?l422:(l488?0:l19->l23.l29()-1);l11
(l4 l0=0;l0<l25.l29();++l0){l4 l623=0;l11(l9&l48:l19->l21){l1(l48.l12
.l63(l0)!=l48.l12.l40()){++l623;l1(l623>l567)l69;}}l1(l623<=l567)l30.
l56(l0);}l9 l5=l156(l30);l1(l155){l22<l16>l463(l5.l25.l10());l11(l4 l0
=0;l0<l5.l25.l29();++l0)l463[l0]=l0;l5.l25=l13(l463);}l3 l5;}l33{l22<
l4>l30;l30.l101(l23.l10());l4 l567=l422>0?l422:(l488?0:l19->l25.l29());
l11(l4 l0=0;l0<l23.l29();++l0)l1(l4(l19->l21[l0].l12.l10())<=l422)l30
.l56(l0);l9 l5=l252(l30);l1(l155){l22<l16>l463(l5.l23.l10());l11(l4 l0
=0;l0<l5.l23.l29();++l0)l463[l0]=l0;l5.l23=l13(l463);}l3 l5;}}l17&l17
::l660(l136 l102,l4 l109){l11(l9&l48:l21)l48.l216(l102,l109);l3*l42;}
l22<l22<l6>>l683(l2 l6&l8,l2 l13&l23){l22<l22<l6>>l247;l1(!l8.l191()){
l247.l81(l23.l10(),{l8});l3 l247;}l1(l8.l82()==2){l13 l44(l8,0,0,l57);
l9 l30=l44.l74(l23,l43);l247.l81(l23.l10());l11(l4 l0=0;l0<l23.l29();
++l0){l4 l38=l30[l0];l1(l38<0)l69;l247[l0]={l8(1,l38)};}l3 l247;}l1(
l8.l82()==1||l8.l44()==1){l22<l6>l688(l8.l82() *l8.l44());l11(l4 l0=0
;l0<l8.l82();++l0)l11(l4 l31=0;l31<l8.l44();++l31)l688[l0*l8.l44()+
l31]=l8(l0,l31);l247.l81(l23.l10(),l688);l3 l247;}l35 l41("\x62\x61"
"\x64\x20\x76\x61\x6c\x75\x65");}l17&l17::l234(l2 l6&l161,l2 l6&l52,
l4 l109,l18 l180,l136 l102){l1(l161.l34<l50>())l35 l41("\x74\x6f\x5f"
"\x72\x65\x70\x6c\x61\x63\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x6f\x70"
"\x74\x69\x6f\x6e\x61\x6c");l1(l161.l82()==2&&l52.l34<l50>()){l22<l6>
l247(l161.l44());l22<l6>l131(l161.l44());l11(l4 l0=0;l0<l161.l44();++
l0){l247[l0]=l161(0,l0);l131[l0]=l161(1,l0);}l11(l4 l0=0;l0<l23.l29();
++l0)l21[l0].l234(l247,l131,l180);l3*l42;}l9 l247=l683(l161,l23);l1(
l102!=l136::l359){l11(l4 l0=0;l0<l23.l29();++l0)l21[l0].l234(l247[l0]
,l102,l109,l180);l3*l42;}l9 l131=l683(l52,l23);l11(l4 l0=0;l0<l23.l29
();++l0)l21[l0].l234(l247[l0],l131[l0],l180);l3*l42;}l4 l17::l687(l4
l0,l4 l31,l18 l314,l2 l22<l4>&l44)l2{l177(l0>=0&&l31>=0&&l0<l25.l29()&&
l31<l25.l29());l1(l44.l62())l3 l25.l720(l0,l31,l314);l4 l5=0;l11(l9
l48:l44){l177(l48>=0&&l48<l23.l29());l5=l21[l48].l720(l0,l31,l314);l1
(l5!=0)l3 l5;}l3 l5;}l17 l17::l152(l2 l13*l445,l18 l134,l2 l15&l300,
l18 l323,l18 l155,l4 l37,l4 l137)l2{l22<l4>l30(l25.l10());l1(l37==0){
l30.l140();}l33{l22<l4>l83=(l445==l106?l22<l4>():l23.l74( *l445));
l743(l30.l72(),l30.l40(),0);l18 l314=l134?l323:!l323;l4 l707=l134?-1:
1;l9 l696=[l42,l314,l707,&l83](l4 l0,l4 l31){l3 l42->l687(l0,l31,l314
,l83)==l707;};l1(l300.l62()||l300=="\x71\x75\x69\x63\x6b\x73\x6f\x72"
"\x74")l24::l152(l30.l72(),l30.l40(),l696);l33 l1(l300=="\x73\x74\x61"
"\x62\x6c\x65")l895(l30.l72(),l30.l40(),l696);l33 l35 l41("\x75\x6e"
"\x6b\x6e\x6f\x77\x6e\x20\x73\x6f\x72\x74\x69\x6e\x67\x20\x6b\x69\x6e"
"\x64");l1(l37>0&&l37<l25.l29()){l1(l137==-1)l30.l81(l37);l33{l4 l354
=0;l47(l37+l354<l25.l29()&&l687(l30[l37-1],l30[l37+l354],l314,l83)==0
)++l354;l1(l137==0)l30.l81(l37+l354);l33{l30[l37-1]=l30[l37+l354-1];
l30.l81(l37);}}}}l9 l5=l156(l30);l1(l155){l22<l16>l38(l30.l10());l11(
l94 l0=0;l0<l38.l10();++l0)l38[l0]=(l16)l0;l5.l25=l13(l38);}l3 l5;}
l64<l100 l7>l173<l22<l4>,l22<l4>>l927(l2 l22<l7>&l112,l2 l22<l7>&l85){
l190<l7,l173<l4,l4>>l190;l11(l4 l0=0;l0<(l4)l112.l10();l0++){l1(l190.
l63(l112[l0])==l190.l40()){l190[l112[l0]]=l433(l0,-1);}}l11(l4 l0=0;
l0<(l4)l85.l10();l0++){l1(l190.l63(l85[l0])==l190.l40()){l190[l85[l0]
]=l433(-1,l0);}l33{l190[l85[l0]].l169=l0;}}l22<l4>l391,l389;l11(l2 l9
&l173:l190){l391.l56(l173.l169.l174);l389.l56(l173.l169.l169);}l3 l433
(l391,l389);}l64<l100 l7>l173<l22<l4>,l22<l4>>l550(l2 l22<l7>&l112,l2
l22<l7>&l85){l190<l7,l22<l173<l4,l4>> >l190;l4 l37=0;l11(l4 l0=0;l0<(
l4)l85.l10();l0++){l9&l14=l190[l85[l0]];l14.l367(-1,l0);++l37;}l11(l4
l0=0;l0<(l4)l112.l10();l0++){l1(l190.l63(l112[l0])==l190.l40()){l190[
l112[l0]].l367(l0,-1);++l37;}l33{l9&l14=l190[l112[l0]];l177(!l14.l62(
));l1(l14[0].l174==-1){l11(l9&l66:l14)l66.l174=l0;}l33{l4 l86=l14[0].
l174;l11(l94 l31=0;l31<l14.l10();++l31){l1(l14[l31].l174!=l86)l28;l14
.l367(l0,l14[l31].l169);++l37;}}}}l22<l4>l391,l389;l391.l101(l37);
l389.l101(l37);l11(l9&l14:l190)l11(l9&l173:l14.l169){l391.l56(l173.
l174);l389.l56(l173.l169);}l3 l433(l391,l389);}l739 l267 l228{l508,
l450,l665,l537,l634};l228 l817(l2 l15&l67){l1(l67==""||l67=="\x6c\x65"
"\x66\x74")l3 l228::l508;l1(l67=="\x72\x69\x67\x68\x74")l3 l228::l450
;l1(l67=="\x69\x6e\x6e\x65\x72")l3 l228::l665;l1(l67=="\x6f\x75\x74"
"\x65\x72")l3 l228::l537;l1(l67=="\x63\x72\x6f\x73\x73")l3 l228::l634
;l35 l41("\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6a\x6f\x69\x6e\x20\x6d"
"\x65\x74\x68\x6f\x64");}l64<l100 l7>l50 l740(l22<l7>&l8,l2 l22<l4>&
l30){l22<l4>l598=l30;l152(l598.l782(),l598.l729());l11(l4 l0:l598)l8.
l213(l8.l72()+l0);}l17 l17::l705(l2 l17&l104,l2 l22<l4>&l187,l2 l22<
l4>&l307,l2 l15&l276,l2 l15&l381,l2 l15&l394,l18 l152,l2 l15&l900)l2{
l1(!l900.l62())l35 l41("\x76\x61\x6c\x69\x64\x61\x74\x65\x20\x69\x73"
"\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64");
l1(l307.l10()!=l187.l10())l35 l41("\x74\x72\x79\x69\x6e\x67\x20\x74"
"\x6f\x20\x6a\x6f\x69\x6e\x20\x75\x6e\x65\x71\x75\x61\x6c\x20\x6e\x75"
"\x6d\x62\x65\x72\x20\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73");l1(
l187.l62())l3 l17();l13 l585,l591;l1(l307.l10()>1){l585=l13(l420(l252
(l187).l46(),l43,l43));l591=l13(l420(l104.l252(l307).l46(),l43,l43));
}l2 l13*l87=l585.l10()>0?&l585:(l187[0]<0||l187[0]>=l23.l29()?&l25:&
l21[l187[0]]);l2 l13*l127=l591.l10()>0?&l591:(l307[0]<0||l307[0]>=l23
.l29()?&l104.l25:&l104.l21[l307[0]]);l9 l685=l817(l276);l22<l4>l285,
l220;l18 l372=l152;l80(l685){l27 l228::l508:l285=l731(l127->l615( *
l87),l220);l1(l220.l10()>l87->l10()){l372=l43;}l372=l152||l220.l10()>
l87->l10();l28;l27 l228::l450:l220=l731(l87->l615( *l127),l285);l372=
l152||l285.l10()>l127->l10();l28;l27 l228::l665:{l9 l468=l127->l615( *
l87);l220.l101(l468.l10());l285.l101(l220.l10());l11(l4 l0=0;l0<(l4)l468
.l10();++l0){l1(l468[l0].l10()>1)l372=l43;l11(l9 l38:l468[l0]){l220.
l56(l0);l285.l56(l38);}}}l28;l27 l228::l537:l1(l87->l93()!=l127->l93(
))l35 l41("\x74\x79\x70\x65\x73\x20\x73\x68\x6f\x75\x6c\x64\x20\x62"
"\x65\x20\x73\x61\x6d\x65");{l173<l22<l4>,l22<l4>>l298;l80(l87->l93()){
l27 l20::l45:{l49 l7=l16;l53{l298=l550(l87->l14<l7>(),l127->l14<l7>());
}l47(0);l28;}l27 l20::l39:{l49 l7=l24::l15;l53{l298=l550(l87->l14<l7>
(),l127->l14<l7>());}l47(0);l28;}l27 l20::l75:{l49 l7=l18;l53{l298=
l550(l87->l14<l7>(),l127->l14<l7>());}l47(0);l28;}l84:l28;};l220=l298
.l174;l285=l298.l169;l372=l43;}l28;l27 l228::l634:l220.l101(l87->l10(
) *l127->l10());l285.l101(l220.l10());l11(l4 l0=0;l0<l25.l29();++l0)l11
(l4 l31=0;l31<l104.l25.l29();++l31){l220.l56(l0);l285.l56(l31);}l372=
l57;l28;l84:l28;}l9 l5=l156(l220);l9 l484=l104.l156(l285);l5.l21.l70(
l5.l21.l40(),l484.l21.l72(),l484.l21.l40());l11(l9&l48:l484.l21){l1(
l48.l93()!=l114){l5.l114=l20::l153;l28;}}l13 l437;l22<l4>l407;{l13
l600;{l9 l30=l23.l74(l104.l23,l43);l297<l4,l4>l631;l11(l4 l0=0;l0<
l104.l23.l29();++l0){l9 l38=l30[l0];l1(l38>=0)l631[l38]=l0;}l1(l631.
l62()){l437=l23;}l33{l122<l4>l768(l187.l72(),l187.l40());l4 l714=0;l9
l61=l23;l61.l301(l20::l39);l9 l754=l61.l99;l61=l104.l23;l61.l301(l20
::l39);l9 l586=l61.l99;l11(l9&l238:l631){l1(l768.l63(l238.l174)!=l768
.l40()){l407.l56(l238.l169);l69;}l754[l238.l174]+=l381;l586[l238.l169
]+=l394;++l714;}l1(l714>0){l1(l381.l62()&&l394.l62())l35 l41("\x63"
"\x6f\x6c\x75\x6d\x6e\x73\x20\x6f\x76\x65\x72\x6c\x61\x70\x20\x62\x75"
"\x74\x20\x6e\x6f\x20\x73\x75\x66\x66\x69\x78\x20\x73\x70\x65\x63\x69"
"\x66\x69\x65\x64");l1(l381==l394)l35 l41("\x73\x75\x66\x66\x69\x78"
"\x20\x73\x68\x6f\x75\x6c\x64\x20\x62\x65\x20\x64\x69\x66\x66\x65\x72"
"\x65\x6e\x74");}l437=l13(l754);l740(l586,l407);l11(l9&l48:l407)l48+=
l23.l29();l740(l5.l21,l407);l600=l13(l586);}}l2 l13*l885=l600.l10()>0
||!l407.l62()?&l600:&l104.l23;l437.l70(l437.l29(), *l885);}l5.l23=
l437;l80(l685){l27 l228::l450:l5.l25=l484.l25;l28;l27 l228::l537:l11(
l4 l0=0;l0<l5.l25.l29();++l0)l1(l220[l0]<0)l5.l25.l91(l0,l104.l25,
l285[l0]);l28;l27 l228::l634:{l22<l16>l30(l220.l10());l11(l94 l0=0;l0
<l30.l10();++l0)l30[l0]=(l16)l0;l5.l25=l13(l30);}}l1(l372){l1(l187.
l10()==1&&(l187[0]<0||l187[0]>=l23.l29()))l5=l5.l152();l33{l9 l61=l5.
l23.l125(l187);l5=l5.l152(&l61);}}l3 l5;}l17&l17::l625(l2 l17&l104,
l18 l402){l9 l83=l23.l74(l104.l23,l43);l9 l30=l104.l25.l74(l25,l43);
l11(l4 l0=0;l0<l104.l23.l29();++l0){l4 l38=l83[l0];l1(l38<0)l69;l21[
l38].l625(l104.l21[l0].l125(l30),l402);}l3*l42;}l64<l100 l7>l79 l4
l554(l2 l22<l7>&l108,l7 l8){l9 l124=l564(l108.l72(),l108.l40(),l8);l1
(l124==l108.l40())l3-1;l3(l4)l424(l108.l72(),l124);}l17 l17::l858(l2
l13&l349,l2 l13*l143)l2{l1(l349.l93()!=l25.l93())l35 l41("\x77\x68"
"\x65\x72\x65\x20\x76\x61\x6c\x75\x65\x73\x20\x73\x68\x6f\x75\x6c\x64"
"\x20\x62\x65\x20\x73\x61\x6d\x65\x20\x74\x79\x70\x65\x20\x61\x73\x20"
"\x69\x6e\x64\x65\x78");l1(!l25.l12.l62())l35 l41("\x69\x6e\x64\x65"
"\x78\x20\x73\x68\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x68\x61\x76\x65"
"\x20\x4e\x41\x73");l1(!l349.l12.l62())l35 l41("\x77\x68\x65\x72\x65"
"\x20\x76\x61\x6c\x75\x65\x73\x20\x68\x61\x76\x65\x20\x4e\x41\x73");
l1(!l25.l198())l35 l41("\x61\x73\x6f\x66\x20\x66\x75\x6e\x63\x74\x69"
"\x6f\x6e\x20\x63\x61\x6e\x20\x62\x65\x20\x75\x73\x65\x64\x20\x6f\x6e"
"\x6c\x79\x20\x77\x68\x65\x6e\x20\x69\x6e\x64\x65\x78\x20\x69\x73\x20"
"\x69\x6e\x63\x72\x65\x61\x73\x69\x6e\x67");l22<l4>l83;l1(l143)l83=
l23.l74( *l143,l43);l33{l83.l101(l23.l10());l11(l4 l0=0;l0<l23.l29();
++l0)l83.l56(l0);}l22<l4>l30(l349.l10());l11(l94 l0=0;l0<l30.l10();++
l0){l4 l38=-1;l80(l25.l93()){l27 l20::l45:{l49 l7=l16;l53{l38=l554(
l25.l14<l7>(),l349.l14<l7>()[l0]);}l47(0);l28;}l27 l20::l39:{l49 l7=
l24::l15;l53{l38=l554(l25.l14<l7>(),l349.l14<l7>()[l0]);}l47(0);l28;}
l27 l20::l75:{l49 l7=l18;l53{l38=l554(l25.l14<l7>(),l349.l14<l7>()[l0
]);}l47(0);l28;}l84:l28;};l1(l38<0){l30[l0]=-1;l69;}l11(l4 l31=l38;
l31>=0;--l31){l18 l712=l57;l11(l9 l48:l83){l1(l48<0||l21[l48].l12.l63
(l31)==l21[l48].l12.l40())l69;l712=l43;l28;}l1(!l712){l38=l31;l28;}}
l30[l0]=l38;}l9 l5=l156(l30);l5.l25=l349;l3 l5;}l49 l241 l24;l6 l991(
l2 l6&l8){l17 l19(l8);l3 l19.l46();}l6 l916(l2 l6&l19){l3 l17(l19).l7
().l46();}l6 l1057(l2 l6&l19){l3 l916(l19);}l6 l928(l2 l6&l19){l3 l17
(l19).l25.l46();}l6 l1030(l2 l6&l19){l3 l17(l19).l23.l46(l57);}l6
l1012(l2 l6&l19,l2 l6&l755,l2 l6&l751){l17 l59(l19);l18 l616=l43;l1(
l755.l34<l50>()){l4 l694=100;l1(!l751.l34<l50>())l694=l751.l36<l4>();
l616=l59.l23.l29()<l694;}l33 l616=l755.l36<l18>();l1(l616){l4 l202=
l59.l23.l29();l6 l5(4+l202,4);l4 l38=0;l5(l38,0)="\x52\x61\x6e\x67"
"\x65\x49\x6e\x64\x65\x78\x3a";l9 l39=l121(l59.l25.l10())+"\x20\x72"
"\x6f\x77\x73";l1(!l59.l25.l12.l62())l39+="\x20\x28"+l121(l59.l25.l12
.l10())+"\x20\x4e\x41\x73\x29";l5(l38,1)=l39;l5(l38,2)=l121(l59.l25.
l560())+"\x20\x64\x69\x73\x74\x69\x6e\x63\x74\x20\x65\x6e\x74\x72\x69"
"\x65\x73";l9 l975=l59.l25.l294();l9 l1042=l59.l25.l333();l5(l38,3)=
l306(l59.l25.l294().l36<l15>())+"\x20\x74\x6f\x20"+l306(l59.l25.l333(
).l36<l15>());l38=1;l5(l38,0)="\x44\x61\x74\x61\x20\x63\x6f\x6c\x75"
"\x6d\x6e\x73\x3a\x20";l5(l38,1)="\x28\x74\x6f\x74\x61\x6c\x20"+l121(
l59.l21.l10())+"\x20\x63\x6f\x6c\x75\x6d\x6e\x73\x29\x3a";l5(l38,2)=""
;l5(l38,3)="";l38=2;l5(l38,0)="\x23";l5(l38,1)="\x43\x6f\x6c\x75\x6d"
"\x6e";l5(l38,2)="\x4e\x6f\x6e\x2d\x4e\x41\x20\x63\x6f\x75\x6e\x74";
l5(l38,3)="\x44\x61\x74\x61\x20\x74\x79\x70\x65";l59.l23.l46(l5,1,3);
l4 l456[]={0,0,0,0};l11(l4 l0=0;l0<l202;++l0){l4 l38=3+l0;l5(l38,0)=
l0;l5(l38,2)=l59.l21[l0].l29()-(l4)l59.l21[l0].l12.l10();l5(l38,3)=
l461(l59.l21[l0].l93());++l456[(l4)l59.l21[l0].l93()];}l38=3+l202;l5(
l38,0)="\x44\x61\x74\x61\x20\x74\x79\x70\x65\x73\x3a";l11(l4 l0=0;l0<
3;++l0)l5(l38,l0+1)=l461((l20)l0)+"\x28"+l121(l456[l0])+"\x29";l3 l5;
}l33{l4 l202=l59.l23.l29();l6 l5(3,4);l4 l38=0;l5(l38,0)="\x52\x61"
"\x6e\x67\x65\x49\x6e\x64\x65\x78\x3a";l9 l39=l121(l59.l25.l10())+""
"\x20\x72\x6f\x77\x73";l1(!l59.l25.l12.l62())l39+="\x20\x28"+l121(l59
.l25.l12.l10())+"\x20\x4e\x41\x73\x29";l5(l38,1)=l39;l5(l38,2)=l121(
l59.l25.l560())+"\x20\x64\x69\x73\x74\x69\x6e\x63\x74\x20\x65\x6e\x74"
"\x72\x69\x65\x73";l5(l38,3)=l306(l59.l25.l294().l36<l15>())+"\x20"
"\x74\x6f\x20"+l306(l59.l25.l333().l36<l15>());l38=1;l5(l38,0)="\x43"
"\x6f\x6c\x75\x6d\x6e\x73\x3a\x20";l39=l121(l59.l23.l10())+"\x20\x72"
"\x6f\x77\x73";l1(!l59.l23.l12.l62())l39+="\x20\x28"+l121(l59.l23.l12
.l10())+"\x20\x4e\x41\x73\x29";l5(l38,1)=l39;l5(l38,2)=l121(l59.l23.
l560())+"\x20\x64\x69\x73\x74\x69\x6e\x63\x74\x20\x65\x6e\x74\x72\x69"
"\x65\x73";l5(l38,3)=l306(l59.l23.l294().l36<l15>())+"\x20\x74\x6f"
"\x20"+l306(l59.l23.l333().l36<l15>());l38=2;l5(l38,0)="\x44\x61\x74"
"\x61\x20\x74\x79\x70\x65\x73\x3a";l4 l456[]={0,0,0,0};l11(l4 l0=0;l0
<l202;++l0)++l456[(l4)l59.l21[l0].l93()];l11(l4 l0=0;l0<3;++l0)l5(l38
,l0+1)=l461((l20)l0)+"\x28"+l121(l456[l0])+"\x29";l3 l5;}l3 l6();}
l139 l79 l26 l480(l2 l6&l55){l1(l55.l34<l50>()||(l55.l34<l15>()&&(l55
.l36<l15>()==""||l55.l36<l15>()=="\x3d")))l3 l26::l506;l1(!l55.l34<
l15>())l35 l41("\x6f\x70\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x73\x74"
"\x72\x69\x6e\x67");l9 l510=l55.l36<l15>();l177(!l510.l62());l1(l510.
l171()!='=')l35 l454("\x6f\x70\x20\x73\x68\x6f\x75\x6c\x64\x20\x65"
"\x6e\x64\x20\x77\x69\x74\x68\x20\x27\x3d\x27");l3 l644(l509(l510.
l232(0,l510.l10()-1)));}l6 l978(l2 l6&l19,l2 l6&l256,l2 l6&l133,l2 l6
&l55,l2 l6&l52){l1(l52.l34<l50>())l3 l17(l19).l163(l256,l133);l9 l5=
l17(l19);l9 l343=l480(l55);l1(l343==l26::l506)l3 l5.l163(l256,l133,
l52).l46();l9 l130=l13(l5.l163(l256,l133),0,0);l9 l375=l13(l52,0,0);
l1(l130.l62()||l375.l62())l3 l5.l163(l256,l133,l6()).l46();l9 l60=
l130.l183(l343,l375);l9 l149=l60.l46();l3 l5.l163(l256,l133,l149(0,0)).
l46();}l6 l997(l2 l6&l19,l2 l6&l193,l2 l6&l194,l2 l6&l55,l2 l6&l52){
l1(l52.l34<l50>())l3 l17(l19).l91(l193.l36<l4>(),l194.l36<l4>());l9 l5
=l17(l19);l9 l343=l480(l55);l4 l0=l193.l36<l4>();l4 l31=l194.l36<l4>(
);l1(l343==l26::l506)l3 l5.l91(l0,l31,l52).l46();l9 l130=l13(l5.l91(
l0,l31),0,0);l9 l375=l13(l52,0,0);l1(l130.l62()||l375.l62())l3 l5.l91
(l0,l31,l6()).l46();l3 l5.l91(l0,l31,l130.l183(l343,l375).l46()(0,0)).
l46();}l139 l6 l679(l2 l6&l19,l2 l6&l82,l2 l6&l44,l2 l6&l55,l2 l6&l52
,l18 l475){l9 l5=l17(l19);l17 l130;l1(l52.l34<l50>()){l130=l475?l5.
l125(l82,l44):l5.l90(l82,l44);l3 l130.l46();}l9 l343=l480(l55);l1(
l343==l26::l506){l130=l475?l5.l125(l82,l44,l52):l5.l90(l82,l44,l52);
l3 l130.l46();}l1(l475)l130=l5.l125(l82,l44);l33{l9 l61=l5;l61.l90(
l82,l44,l6(),&l130);}l9 l670=&l52;l6 l61;l1(!l244(l52)&&l52.l44()>1&&
l52.l82()>1){l61=l17(l52,&l130.l23,&l130.l25).l46();l670=&l61;}l9 l162
=l130.l849(l343, *l670).l46(l363::l633);l3 l475?l5.l125(l82,l44,l162).
l46():l5.l90(l82,l44,l162).l46();}l6 l577(l2 l6&l19,l2 l6&l82,l2 l6&
l44,l2 l6&l55,l2 l6&l52){l3 l679(l19,l82,l44,l55,l52,l43);}l6 l446(l2
l6&l19,l2 l6&l82,l2 l6&l44,l2 l6&l55,l2 l6&l52){l3 l679(l19,l82,l44,
l55,l52,l57);}l6 l993(l2 l6&l19){l17 l59(l19);l3 l6(l22<l22<l6>>{{l59
.l25.l29(),l59.l23.l29()}});}l6 l995(l2 l6&l19,l2 l6&l37){l4 l366=5;
l1(l37.l34<l16>())l366=l37.l36<l4>();l6 l209;l3 l577(l19,"\x3a"+l121(
l366),l209,l209,l209);}l6 l1040(l2 l6&l19,l2 l6&l37){l4 l366=5;l1(l37
.l34<l16>())l366=l37.l36<l4>();l6 l209;l3 l577(l19,"\x2d"+l121(l366)+""
"\x3a",l209,l209,l209);}l22<l20>l498(l2 l6&l8){l22<l20>l5;l1(l8.l34<
l50>()||l8.l540())l3 l5;l1(l8.l34<l15>()){l9 l67=l8.l36<l15>();l1(!
l67.l62()&&l67[0]=='a')l3{l20::l45,l20::l39,l20::l75};l11(l9&l67:l425
(l8.l36<l15>(),','))l5.l56(l842(l67));l3 l5;}l1(l8.l191()){l11(l4 l0=
0;l0<l8.l82();++l0){l11(l4 l31=0;l31<l8.l44();++l31)l1(l8(l0,l31).l34
<l15>())l5.l56(l842(l8(l0,l31).l36<l15>()));}l3 l5;}l3 l5;}l6 l945(l2
l6&l19,l2 l6&l398,l2 l6&l436){l9 l447=l498(l398);l9 l910=l498(l436);
l122<l20>l172;l1(l447.l62())l11(l4 l0=0;l0<4;++l0)l172.l70((l20)l0);
l33 l11(l9 l0:l447)l172.l70(l0);l11(l9 l8:l910){l172.l213(l8);}l447.
l140();l11(l9 l8:l172)l447.l56(l8);l3 l17(l19).l253(l447).l46();}l6
l821(l2 l6&l19){l17 l59(l19);l3 l59.l25.l29() *l59.l23.l29();}l6 l998
(l2 l6&l19){l3 l821(l19).l36<l4>()==0;}l6 l977(l2 l6&l19,l2 l6&l125,
l2 l6&l571,l2 l6&l52,l2 l6&l315){l18 l861=l315.l34<l50>()?l57:l315.
l36<l18>();l17 l59(l19);l4 l38=l125.l36<l4>();l1(l38<0||l38>l59.l23.
l29())l35("\x23\x20\x62\x61\x64\x20\x69\x6c\x6f\x63");l1(l571.l34<l50
>())l35("\x23\x20\x63\x6f\x6c\x75\x6d\x6e\x20\x69\x73\x20\x72\x65\x71"
"\x75\x69\x72\x65\x64");l1(l571.l191())l35("\x23\x20\x62\x61\x64\x20"
"\x63\x6f\x6c\x75\x6d\x6e");l13 l872(l571,0,0);l59.l23.l70(l38,l872,
l861);l13 l149(l52,0,0,l52.l44()==1);l1(l59.l21.l62())l59.l21.l56(
l149);l33{l1(l149.l29()==1){l149.l81(l59.l21[0].l29(),l43);}l149.l81(
l59.l21[0].l29());l59.l21.l70(l59.l21.l72()+l38,l149);}l3 l59.l46();}
l6 l996(l2 l6&l19,l2 l6&l120){l3 l17(l19).l245(l120).l46();}l6 l971(
l2 l6&l19,l2 l6&l145,l2 l6&l104,l2 l6&l32){l3 l17(l19).l552(l145,l104
,l32).l46();}l6 l1025(l2 l6&l19,l2 l6&l145,l2 l6&l104,l2 l6&l32){l3
l17(l19).l552(l145,l104,l32,l43).l46();}l6 l929(l2 l6&l19,l2 l15&l547
){l3 l17(l19).l904(l547).l46();}l6 l936(l2 l6&l19,l2 l6&l8,l2 l6&l32,
l2 l6&l115){l3 l17(l19).l117(l26::l254,l8,l32,l115).l46();}l6 l1033(
l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(l26::l288,
l8,l32,l115).l46();}l6 l950(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){
l3 l17(l19).l117(l26::l350,l8,l32,l115).l46();}l6 l1001(l2 l6&l19,l2
l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(l26::l284,l8,l32,l115).
l46();}l6 l1056(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).
l117(l26::l287,l8,l32,l115).l46();}l6 l1028(l2 l6&l19,l2 l6&l8,l2 l6&
l32,l2 l6&l115){l3 l17(l19).l117(l26::l344,l8,l32,l115).l46();}l6
l1059(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(l26::
l279,l8,l32,l115).l46();}l6 l955(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&
l115){l3 l17(l19).l117(l26::l364,l8,l32,l115).l46();}l6 l974(l2 l6&
l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(l26::l289,l8,l32,
l115).l46();}l6 l1023(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17
(l19).l117(l26::l358,l8,l32,l115).l46();}l6 l930(l2 l6&l19,l2 l6&l8,
l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(l26::l286,l8,l32,l115).l46();}
l6 l1024(l2 l6&l19,l2 l6&l8,l2 l6&l32,l2 l6&l115){l3 l17(l19).l117(
l26::l280,l8,l32,l115).l46();}l6 l989(l2 l6&l19,l2 l6&l104){l3 l17(
l19).l597(l17(l104)).l46();}l6 l940(l2 l6&l19,l2 l6&l8,l2 l6&l32){l3
l17(l19).l117(l26::l214,l8,l32,l6()).l46();}l6 l963(l2 l6&l19,l2 l6&
l8,l2 l6&l32){l3 l17(l19).l117(l26::l207,l8,l32,l6()).l46();}l6 l943(
l2 l6&l19,l2 l6&l8,l2 l6&l32){l3 l17(l19).l117(l26::l211,l8,l32,l6()).
l46();}l6 l964(l2 l6&l19,l2 l6&l8,l2 l6&l32){l3 l17(l19).l117(l26::
l206,l8,l32,l6()).l46();}l6 l934(l2 l6&l19,l2 l6&l8,l2 l6&l32){l3 l17
(l19).l117(l26::l212,l8,l32,l6()).l46();}l6 l966(l2 l6&l19,l2 l6&l8,
l2 l6&l32){l3 l17(l19).l117(l26::l205,l8,l32,l6()).l46();}l6 l1005(l2
l6&l19,l2 l6&l8){l3 l17(l19).l406(l8).l46();}l6 l953(l2 l6&l19){l3 l17
(l19).l319().l46();}l6 l1034(l2 l6&l19,l2 l6&l32,l2 l6&l264,l2 l6&l65
){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l18 l632=l264.l34<l18>()?l264
.l36<l18>():l57;l18 l459=l65.l34<l18>()?l65.l36<l18>():l43;l3 l17(l19
).l337(l77,l632,l459).l46();}l6 l1017(l2 l6&l19,l2 l6&l32,l2 l6&l264,
l2 l6&l65){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l18 l632=l264.l34<
l18>()?l264.l36<l18>():l57;l18 l459=l65.l34<l18>()?l65.l36<l18>():l43
;l3 l17(l19).l337(l77,l632,l459,l43).l46();}l6 l1036(l2 l6&l19,l2 l6&
l390,l2 l6&l184,l2 l6&l32){l3 l17(l19).l657(l390,l184,l32).l46();}l6
l972(l2 l6&l19,l2 l6&l102,l2 l6&l230,l2 l6&l76){l4 l570=l230.l34<l16>
()?l230.l36<l4>():1;l18 l204=l76.l34<l18>()?l76.l36<l18>():l57;l3 l17
(l19).l514(l570,l204).l46();}l6 l947(l2 l6&l19,l2 l6&l104,l2 l6&l32,
l2 l6&l181,l2 l6&l102,l2 l6&l76){l4 l77=l32.l34<l16>()?l32.l36<l4>():
0;l18 l204=l76.l34<l18>()?l76.l36<l18>():l57;l18 l841=l181.l34<l18>()?
l181.l36<l18>():l43;l3 l17(l19).l877(l77==0?l17(l104):l17(l104).l7(),
l841,l204).l46();}l6 l951(l2 l6&l19,l2 l6&l32,l2 l6&l76){l4 l77=l32.
l34<l16>()?l32.l36<l4>():0;l18 l204=l76.l34<l18>()?l76.l36<l18>():l57
;l3 l17(l19).l128(l77,l204).l46();}l6 l990(l2 l6&l19,l2 l6&l230,l2 l6
&l175,l2 l6&l76){l4 l570=l230.l34<l16>()?l230.l36<l4>():1;l18 l204=
l76.l34<l18>()?l76.l36<l18>():l57;l4 l845=l175.l34<l16>()?l175.l36<l4
>():1;l3 l17(l19).l471(l570,l845,l204).l46();}l6 l1053(l2 l6&l19,l2 l6
&l32,l2 l6&l65){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l18 l304=l65.
l34<l18>()?l65.l36<l18>():l43;l3 l17(l19).l215<l167::l142>(l77,l304).
l46();}l6 l948(l2 l6&l19,l2 l6&l32,l2 l6&l65){l4 l77=l32.l34<l16>()?
l32.l36<l4>():0;l18 l304=l65.l34<l18>()?l65.l36<l18>():l43;l3 l17(l19
).l215<l167::l144>(l77,l304).l46();}l6 l988(l2 l6&l19,l2 l6&l32,l2 l6
&l65){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l18 l304=l65.l34<l18>()?
l65.l36<l18>():l43;l3 l17(l19).l215<l167::l351>(l77,l304).l46();}l6
l1045(l2 l6&l19,l2 l6&l32,l2 l6&l65){l4 l77=l32.l34<l16>()?l32.l36<l4
>():0;l18 l304=l65.l34<l18>()?l65.l36<l18>():l43;l3 l17(l19).l215<
l167::l355>(l77,l304).l46();}l6 l958(l2 l6&l19,l2 l6&l257,l2 l6&l398,
l2 l6&l436){l24::l22<l16>l486;l1(l257.l34<l50>())l486={0.25,0.5,0.75}
;l33 l1(l257.l34<l16>())l486={l257.l36<l16>()};l33 l1(l257.l191())l486
=l257.l890();l33 l35 l24::l41("\x70\x65\x72\x63\x65\x6e\x74\x69\x6c"
"\x65\x73\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x61\x20\x6e\x75\x6d\x62"
"\x65\x72\x20\x6f\x72\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x6e\x75\x6d"
"\x62\x65\x72\x73");l9 l520=l498(l398);l9 l884=l498(l436);l3 l17(l19).
l478(l486,l520,l884).l46();}l6 l1020(l2 l6&l19,l2 l6&l92,l2 l6&l32){
l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l4 l579=l92.l34<l16>()?l92.l36<
l4>():1;l3 l17(l19).l332(l579,l77).l46();}l4 l618(l2 l24::l15&l67){
l24::l94 l103=l67.l822('=');l47(l103!=l24::l15::l258){l1((l103==0||!
l905("\x3c\x3e\x21\x2b\x2d\x2a\x2f\x25\x3d\x26\x7c",l67[l103-1]))&&(
l103==l67.l10()-1||!l905("\x3d",l67[l103+1]))){l3(l4)l103;}l103=l67.
l822('=',l103+1);}l3-1;}l139 l79 l173<l15,l15>l808(l2 l15&l39,l4 l119
,l18 l923=l43){l1(l119<0||l119>=l39.l10())l3{"",""};l24::l15 l563=l39
.l232(0,l119);l24::l15 l588=l39.l232(l119+1);l1(l923){l563=l509(l563);
l588=l509(l588);}l3 l24::l433(l563,l588);}l173<l15,l15>l854(l2 l6&
l250){l9 l67=l250.l36<l15>();l4 l982=l618(l67);l15 l302;l15 l558;l4
l103=l618(l67);l1(l103<0)l558=l67;l33{l9 l385=l808(l67,l103);l302=
l385.l174;l558=l385.l169;}l1(l302.l62())l302="\x2a";l3{l302,l558};}l6
l664(l2 l6&l19,l2 l6&l250){l17 l59(l19);l18 l629=l57;l1(l250.l191())l629
=l43;l33 l1(l618(l250.l36<l15>())>=0)l629=l43;l1(l629){l11(l4 l0=0;l0
<l250.l82();++l0)l11(l4 l31=0;l31<l250.l44();++l31){l1(!l250(l0,l31).
l34<l15>())l69;l9 l385=l854(l250(l0,l31));l1(l385.l174.l62())l35(""
"\x23\x20\x4d\x75\x6c\x74\x69\x70\x6c\x65\x20\x65\x78\x70\x72\x65\x73"
"\x73\x69\x6f\x6e\x73\x20\x61\x72\x65\x20\x6f\x6e\x6c\x79\x20\x76\x61"
"\x6c\x69\x64\x20\x69\x66\x20\x61\x6c\x6c\x20\x65\x78\x70\x72\x65\x73"
"\x73\x69\x6f\x6e\x20" "\x63\x6f\x6e\x74\x61\x69\x6e\x20\x61\x6e\x20"
"\x61\x73\x73\x69\x67\x6e\x6d\x65\x6e\x74");l59.l415(l385.l169,l385.
l174);}l3 l59.l46();}l17 l5;l5.l25=l59.l25;l5.l23.l210(l22<l15>{"\x2a"
});l5.l21.l56(l59.l415(l250.l36<l15>()));l5.l114=l5.l21[0].l93();l3 l5
.l46();}l6 l823(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76){l3 l17(l19).
l195(l105::l682,l32,l65,l76,l6()).l46();}l6 l985(l2 l6&l19,l2 l6&l32,
l2 l6&l65,l2 l6&l76){l3 l823(l19,l32,l65,l76);}l6 l1061(l2 l6&l19,l2
l6&l32,l2 l6&l65,l2 l6&l76){l3 l17(l19).l195(l105::l142,l32,l65,l76,
l6()).l46();}l6 l1013(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76){l3 l17
(l19).l195(l105::l144,l32,l65,l76,l6()).l46();}l6 l976(l2 l6&l19,l2 l6
&l32,l2 l6&l65,l2 l6&l76){l3 l17(l19).l195(l105::l643,l32,l65,l76,l6(
)).l46();}l6 l935(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76){l3 l17(l19
).l195(l105::l758,l32,l65,l76,l6()).l46();}l6 l878(l2 l6&l19,l2 l6&
l32,l2 l6&l65,l2 l6&l76,l2 l6&l336){l3 l17(l19).l195(l105::l351,l32,
l65,l76,l336).l46();}l6 l949(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76,
l2 l6&l336){l3 l878(l19,l32,l65,l76,l336);}l6 l946(l2 l6&l19,l2 l6&
l32,l2 l6&l65,l2 l6&l175,l2 l6&l76){l3 l17(l19).l195(l105::l769,l32,
l65,l76,l175.l34<l50>()?1:l175).l46();}l6 l994(l2 l6&l19,l2 l6&l32,l2
l6&l65,l2 l6&l76){l3 l17(l19).l195(l105::l757,l32,l65,l76,l6()).l46();
}l6 l1031(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76,l2 l6&l336){l3 l17(
l19).l195(l105::l355,l32,l65,l76,l336).l46();}l6 l1038(l2 l6&l19,l2 l6
&l32,l2 l6&l65,l2 l6&l175,l2 l6&l76){l3 l17(l19).l195(l105::l703,l32,
l65,l76,l175.l34<l50>()?1:l175).l46();}l6 l1048(l2 l6&l19,l2 l6&l32,
l2 l6&l65,l2 l6&l175,l2 l6&l76){l3 l17(l19).l195(l105::l645,l32,l65,
l76,l175.l34<l50>()?1:l175).l46();}l6 l1050(l2 l6&l19,l2 l6&l32,l2 l6
&l65,l2 l6&l76){l3 l17(l19).l195(l105::l677,l32,l65,l76,l6()).l46();}
l6 l1015(l2 l6&l19,l2 l6&l32,l2 l6&l65,l2 l6&l76){l3 l17(l19).l195(
l105::l669,l32,l65,l76,l6()).l46();}l6 l941(l2 l6&l19,l2 l6&l32,l2 l6
&l76,l2 l6&l158){l3 l17(l19).l501(l32,l76,l158).l46();}l6 l1019(l2 l6
&l19,l2 l6&l92,l2 l6&l311,l2 l6&l109){l4 l579=l92.l34<l4>()?l92.l36<
l4>():1;l4 l331=l109.l34<l4>()?l109.l36<l4>():-1;l136 l837=l311.l34<
l24::l15>()?l462(l311.l36<l24::l15>()):l136::l562;l3 l17(l19).l626(
l579,l837,l331).l46();}l6 l1008(l2 l6&l19,l2 l6&l179,l2 l6&l32,l2 l6&
l76,l2 l6&l231,l2 l6&l102){l3 l17(l19).l356(l179,l32,l76,l231,l102).
l46();}l6 l1014(l2 l6&l19,l2 l6&l32,l2 l6&l102,l2 l6&l76,l2 l6&l116,
l2 l6&l134,l2 l6&l123){l3 l17(l19).l157(l32,l102,l76,l116,l134,l123).
l46();}l6 l931(l2 l6&l19,l2 l6&l222){l3 l17(l19).l345(l222).l46();}l6
l969(l2 l6&l19,l2 l6&l32,l2 l6&l158){l4 l77=l32.l34<l4>()?l32.l36<l4>
():0;l18 l354=l158.l34<l18>()?l158.l36<l18>():l43;l3 l17(l19).l392(
l77,l354).l46();}l6 l1052(l2 l6&l19,l2 l6&l361,l2 l6&l32){l4 l77=l32.
l34<l4>()?l32.l36<l4>():1;l15 l617=l361.l34<l24::l15>()?l361.l36<l24
::l15>():"";l3 l17(l19).l650(l617,l77,l43).l46();}l6 l1046(l2 l6&l19,
l2 l6&l692,l2 l6&l32){l4 l77=l32.l34<l4>()?l32.l36<l4>():1;l15 l617=
l692.l34<l24::l15>()?l692.l36<l24::l15>():"";l3 l17(l19).l650(l617,
l77,l57).l46();}l6 l1041(l2 l6&l19,l2 l6&l273,l2 l6&l32,l2 l6&l154){
l4 l77=l32.l34<l4>()?l32.l36<l4>():0;l16 l803=l273.l34<l16>()?l273.
l36<l16>():0.0;l16 l566=l154.l34<l16>()?l154.l36<l16>():1./24./60./
60.;l3 l17(l19).l473(l803,l566,l77).l46();}l6 l1006(l2 l6&l19,l2 l6&
l201,l2 l6&l40,l2 l6&l370,l2 l6&l32,l2 l6&l154){l4 l77=l32.l34<l4>()?
l32.l36<l4>():0;l16 l804=l201.l34<l16>()?l201.l36<l16>():0.0;l16 l840
=l40.l34<l16>()?l40.l36<l16>():-0.5;l9 l520=l370.l34<l15>()?l894(l370
.l36<l15>()):l260::l635;l16 l566=l154.l34<l16>()?l154.l36<l16>():1./
24./60./60.;l3 l17(l19).l502(l804,l840,l520,l77,l566).l46();}l6 l984(
l2 l6&l19,l2 l6&l170,l2 l6&l32,l2 l6&l25,l2 l6&l23,l2 l6&l638){l4 l77
=l32.l34<l4>()?l32.l36<l4>():0;l18 l275=l638.l34<l15>()&&l638.l36<l15
>()=="\x69\x67\x6e\x6f\x72\x65";l13 l723(l170,0,0,l170.l44()==1);l13
l178(l25,0,0,l25.l44()==1);l13 l44(l23,0,0,l23.l44()==1);l3 l17(l19).
l181(l723.l29()==0?l106:&l723,l77,l178.l29()==0?l106:&l178,l44.l29()==
0?l106:&l44,l275).l46();}l6 l942(l2 l6&l19,l2 l6&l143,l2 l6&l137,l2 l6
&l155){l18 l630=l155.l34<l18>()?l155.l36<l18>():l57;l13 l321(l143,0,0
,l143.l44()==1);l4 l572=l137.l34<l18>()&&l137.l36<l18>()==l57?0:(l137
.l34<l15>()&&l137.l36<l15>()=="\x6c\x61\x73\x74"?1:-1);l3 l17(l19).
l829(l321.l29()==0?l106:&l321,l572,l630).l46();}l6 l1043(l2 l6&l19,l2
l6&l143,l2 l6&l137){l13 l321(l143,0,0,l143.l44()==1);l4 l572=l137.l34
<l18>()&&l137.l36<l18>()==l57?0:(l137.l34<l15>()&&l137.l36<l15>()==""
"\x6c\x61\x73\x74"?1:-1);l3 l17(l19).l892(l321.l29()==0?l106:&l321,
l572).l46();}l6 l1011(l2 l6&l223,l2 l6&l249){l9 l810=l327(l223);l9
l809=l327(l249);l3 l810==l809;}l6 l986(l2 l6&l19,l2 l6&l259,l2 l6&
l316,l2 l6&l180,l2 l6&l32){l13 l124(l259,0,0,l259.l44()==1);l15 l678=
l316.l34<l15>()?l316.l36<l15>():"";l15 l507=l180.l34<l15>()?l180.l36<
l15>():"";l3 l17(l19).l866(l124.l29()==0?l106:&l124,l678.l62()?l106:&
l678,l507.l62()?l106:&l507,l32.l34<l4>()?l32.l36<l4>():1).l46();}l6
l1055(l2 l6&l19,l2 l6&l170,l2 l6&l25,l2 l6&l23,l2 l6&l32,l2 l6&l102,
l2 l6&l115,l2 l6&l109,l2 l6&l239){l13 l641(l170,0,0,l170.l44()==1);
l13 l30(l25,0,0,l25.l44()==1);l13 l44(l23,0,0,l23.l44()==1);l4 l77=
l32.l34<l4>()?l32.l36<l4>():0;l9 l411=l102.l34<l15>()?l102.l36<l15>():""
;l136 l535=l411.l62()?l136::l359:l462(l411);l4 l545=l109.l34<l4>()?
l109.l36<l4>():-1;l16 l386=l239.l34<l16>()?l239.l36<l16>():0.0;l3 l17
(l19).l599(l641.l29()==0?l106:&l641,l77,l30.l29()==0?l106:&l30,l44.
l29()==0?l106:&l44,l535,l115,l545,l386).l46();}l6 l957(l2 l6&l223,l2
l6&l249,l2 l6&l102,l2 l6&l109,l2 l6&l239){l17 l709(l249);l9 l411=l102
.l34<l15>()?l102.l36<l15>():"";l136 l535=l411.l62()?l136::l359:l462(
l411);l4 l545=l109.l34<l4>()?l109.l36<l4>():-1;l16 l386=l239.l34<l16>
()?l239.l36<l16>():0.0;l3 l17(l223).l599(l106,0,&(l709.l25),&(l709.
l23),l535,l6(),l545,l386).l46();}l6 l937(l2 l6&l19,l2 l6&l470,l2 l6&
l25,l2 l6&l23,l2 l6&l32,l2 l6&l638){l1(!l470.l34<l50>()&&(!l25.l34<
l50>()||!l23.l34<l50>()))l35 l24::l41("\x43\x61\x6e\x6e\x6f\x74\x20"
"\x73\x70\x65\x63\x69\x66\x79\x20\x62\x6f\x74\x68\x20\x27\x6d\x61\x70"
"\x70\x65\x72\x27\x20\x61\x6e\x64\x20\x61\x6e\x79\x20\x6f\x66\x20\x27"
"\x69\x6e\x64\x65\x78\x27\x20\x6f\x72\x20\x27\x63\x6f\x6c\x75\x6d\x6e"
"\x73\x27");l17 l59(l19);l13 l730;l13 l745;l13 l663;l13 l676;l9 l77=
l32.l34<l4>()?l32.l36<l4>():0;l2 l6*l30=l106;l2 l6*l133=l106;l1(!l470
.l34<l50>()){l1(l77==0)l30=&l470;l33 l133=&l470;}l33{l1(!l25.l34<l50>
())l30=&l25;l1(!l23.l34<l50>())l133=&l23;}l17 l5(l19);l1(l30){l1(l30
->l44()!=2)l35 l24::l41("\x69\x6e\x64\x65\x78\x20\x6d\x75\x73\x74\x20"
"\x62\x65\x20\x61\x20\x32\x2d\x63\x6f\x6c\x75\x6d\x6e\x20\x72\x61\x6e"
"\x67\x65");l663=l13( *l30,0,0);l676=l13( *l30,1,0);l5.l25=l5.l25.
l662(l663,l676);}l1(l133){l1(l133->l82()!=2)l35 l24::l41("\x63\x6f"
"\x6c\x75\x6d\x6e\x73\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x61\x20\x32"
"\x2d\x72\x6f\x77\x20\x72\x61\x6e\x67\x65");l730=l13( *l133,0,0,l57);
l745=l13( *l133,1,0,l57);l5.l23=l5.l23.l662(l730,l745);}l3 l5.l46();}
l6 l1018(l2 l6&l19,l2 l6&l181,l2 l6&l315,l2 l6&l494){l18 l855=l181.
l34<l18>()?l181.l36<l18>():l57;l18 l843=l315.l34<l18>()?l315.l36<l18>
():l43;l3 l17(l19).l512(l855,l843,l494).l46();}l6 l1063(l2 l6&l19,l2
l6&l37,l2 l6&l330,l2 l6&l234,l2 l6&l248,l2 l6&l453,l2 l6&l32,l2 l6&
l155){l4 l366=l37.l34<l16>()?l37.l36<l4>():0;l16 l839=l330.l34<l16>()?
l330.l36<l16>():0.0;l18 l907=l234.l34<l18>()?l234.l36<l18>():l57;l4
l806=l453.l34<l4>()?l453.l36<l4>():0;l4 l77=l32.l34<l4>()?l32.l36<l4>
():0;l18 l630=l155.l34<l18>()?l155.l36<l18>():l57;l3 l17(l19).l713(
l366,l839,l907,l248,l806,l77,l630).l46();}l6 l952(l2 l6&l19,l2 l6&
l170,l2 l6&l32){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l13 l30(l170,0,
0,l170.l44()==1);l17 l59(l19);l1(l77==0){l1(l59.l25.l10()!=l30.l10())l35
l24::l41("\x6c\x61\x62\x65\x6c\x73\x20\x6d\x75\x73\x74\x20\x62\x65"
"\x20\x73\x61\x6d\x65\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x73\x20\x69"
"\x6e\x64\x65\x78");l59.l25=l30;}l33{l1(l59.l23.l10()!=l30.l10())l35
l24::l41("\x6c\x61\x62\x65\x6c\x73\x20\x6d\x75\x73\x74\x20\x62\x65"
"\x20\x73\x61\x6d\x65\x20\x6c\x65\x6e\x67\x74\x68\x20\x61\x73\x20\x63"
"\x6f\x6c\x75\x6d\x6e\x73");l59.l23=l30;}l3 l59.l46();}l6 l1029(l2 l6
&l19,l2 l6&l259,l2 l6&l32){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l13
l30(l259,0,0,l259.l44()==1);l1(l30.l93()!=l20::l45)l35 l24::l41("\x69"
"\x74\x65\x6d\x73\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x6e\x75\x6d\x65"
"\x72\x69\x63");l1(!l30.l12.l62())l35 l24::l41("\x69\x74\x65\x6d\x73"
"\x20\x6d\x75\x73\x74\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x74\x61\x69\x6e"
"\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x73");l17
l59(l19);l22<l4>l38;l38.l101(l30.l54.l10());l4 l37=l77==0?l59.l25.l29
():l59.l23.l29();l11(l9&l0:l30.l54){l38.l56(l0<0.?(l4)l0+l37:(l4)l0);
l1(l38.l171()<0||l38.l171()>=l37)l35 l24::l41("\x69\x6e\x64\x65\x78"
"\x20\x6f\x75\x74\x20\x6f\x66\x20\x72\x61\x6e\x67\x65");}l1(l77==0)l3
l59.l156(l38).l46();l33 l3 l59.l252(l38).l46();}l6 l1027(l2 l6&l19,l2
l6&l233,l2 l6&l227,l2 l6&l32){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;
l17 l59(l19);l1(l77==0){l9 l30=l59.l25.l680(l233,l227);l3 l59.l156(
l30).l46();}l33{l9 l30=l59.l23.l680(l233,l227);l3 l59.l252(l30).l46();
}}l6 l939(l2 l6&l19,l2 l6&l32,l2 l6&l276,l2 l6&l742,l2 l6&l143,l2 l6&
l155){l4 l77=l32.l34<l16>()?l32.l36<l4>():0;l18 l488=l276.l34<l50>()||
l276.l36<l15>()=="\x61\x6e\x79";l4 l796=l742.l34<l50>()?0:l742.l36<l4
>();l13 l321(l143,0,0,l143.l44()==1);l18 l368=l155.l34<l50>()?l57:
l155.l36<l18>();l3 l17(l19).l158(l77,l488,l796,l321.l29()>0?&l321:
l106,l368).l46();}l6 l1002(l2 l6&l19,l2 l6&l109,l2 l6&l32){l3 l770(
l19,l6(),"\x62\x66\x69\x6c\x6c",l32,l109);}l6 l1037(l2 l6&l19,l2 l6&
l32,l2 l6&l109){l3 l770(l19,l6(),"\x66\x66\x69\x6c\x6c",l32,l109);}l6
l770(l2 l6&l19,l2 l6&l52,l2 l6&l102,l2 l6&l32,l2 l6&l109){l4 l331=
l109.l34<l50>()?0:l109.l36<l4>();l17 l59(l19);l1(l52.l34<l50>()){l4
l77=l32.l34<l50>()?0:l32.l36<l4>();l9 l293=l102.l34<l50>()?l136::l359
:l462(l102.l36<l15>());l1(l77==1)l3 l59.l7().l660(l293,l331).l7().l46
();l33 l3 l59.l660(l293,l331).l46();}l1(!l52.l191()){l11(l9&l48:l59.
l21)l48.l216(l52,l331);l3 l59.l46();}l1(l52.l82()==1){l1(l52.l44()!=
l59.l23.l29())l35 l24::l41("\x76\x61\x6c\x75\x65\x20\x6d\x75\x73\x74"
"\x20\x68\x61\x76\x65\x20\x73\x61\x6d\x65\x20\x6e\x75\x6d\x62\x65\x72"
"\x20\x6f\x66\x20\x63\x6f\x6c\x75\x6d\x6e\x73\x20\x61\x73\x20\x64\x66"
);l11(l4 l0=0;l0<l59.l23.l29();++l0)l59.l21[l0].l216(l52(0,l0));l3 l59
.l46();}l1(l52.l82()==2){l13 l44(l52,0,0,l57);l9 l30=l44.l74(l59.l23);
l11(l4 l0=0;l0<l59.l23.l29();++l0){l4 l38=l30[l0];l1(l38>=0)l59.l21[
l0].l216(l52(1,l38),l331);}l3 l59.l46();}l35 l41("\x62\x61\x64\x20"
"\x76\x61\x6c\x75\x65\x20\x61\x72\x67\x75\x6d\x65\x6e\x74");}l6 l844(
l2 l6&l19){l17 l59(l19);l11(l9&l48:l59.l21)l48=l48.l746();l3 l59.l46(
);}l6 l1054(l2 l6&l19){l3 l844(l19);}l6 l850(l2 l6&l19){l17 l59(l19);
l11(l9&l48:l59.l21)l48=l48.l746(l57);l3 l59.l46();}l6 l962(l2 l6&l19){
l3 l850(l19);}l6 l1047(l2 l6&l19,l2 l6&l161,l2 l6&l52,l2 l6&l109,l2 l6
&l180,l2 l6&l102){l9 l331=l109.l34<l50>()?0:l109.l36<l4>();l9 l293=
l102.l34<l50>()?l136::l359:l462(l102.l36<l15>());l9 l807=l180.l34<l50
>()?l57:l180.l36<l18>();l3 l17(l19).l234(l161,l52,l331,l807,l293).l46
();}l6 l933(l2 l6&l19,l2 l6&l445,l2 l6&l32,l2 l6&l134,l2 l6&l300,l2 l6
&l419,l2 l6&l155){l13 l405(l445,0,0,l445.l44()==1);l9 l77=l32.l34<l50
>()?0:l32.l36<l4>();l9 l365=l134.l34<l50>()?l43:l134.l36<l18>();l9
l146=l300.l34<l50>()?l15(""):l300.l36<l15>();l15 l458=l419.l34<l50>()?
l15(""):l419.l36<l15>();l18 l323=l458==""||l458=="\x6c\x61\x73\x74";
l9 l368=l155.l34<l50>()?l57:l155.l36<l18>();l9 l59=l17(l19);l1(l77==1
)l3 l59.l7().l152(&l405,l365,l146,l323,l368).l7().l46();l3 l59.l152(&
l405,l365,l146,l323,l368).l46();}l6 l965(l2 l6&l19,l2 l6&l32,l2 l6&
l134,l2 l6&l300,l2 l6&l419,l2 l6&l155){l9 l77=l32.l34<l50>()?0:l32.
l36<l4>();l9 l365=l134.l34<l50>()?l43:l134.l36<l18>();l9 l146=l300.
l34<l50>()?l15(""):l300.l36<l15>();l15 l458=l419.l34<l50>()?l15(""):
l419.l36<l15>();l18 l323=l458==""||l458=="\x6c\x61\x73\x74";l9 l368=
l155.l34<l50>()?l57:l155.l36<l18>();l9 l59=l17(l19);l1(l77==1)l3 l59.
l7().l152(l106,l365,l146,l323,l368).l7().l46();l3 l59.l152(l106,l365,
l146,l323,l368).l46();}l6 l987(l2 l6&l19,l2 l6&l37,l2 l6&l23,l2 l6&
l137){l9 l45=l37.l36<l4>();l1(l45<0)l35 l24::l41("\x6e\x20\x6d\x75"
"\x73\x74\x20\x62\x65\x20\x3e\x3d\x20\x30");l13 l405(l23,0,0,l23.l44(
)==1);l15 l460=l137.l34<l50>()?l15(""):l137.l36<l15>();l4 l146=l460==""
"\x6c\x61\x73\x74"?1:(l460=="\x61\x6c\x6c"?0:-1);l3 l17(l19).l152(&
l405,l57,"",l43,l57,l45,l146).l46();}l6 l1035(l2 l6&l19,l2 l6&l37,l2
l6&l23,l2 l6&l137){l9 l45=l37.l36<l4>();l1(l45<0)l35 l24::l41("\x6e"
"\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x3e\x3d\x20\x30");l13 l405(l23,
0,0,l23.l44()==1);l15 l460=l137.l34<l50>()?l15(""):l137.l36<l15>();l4
l146=l460=="\x6c\x61\x73\x74"?1:(l460=="\x61\x6c\x6c"?0:-1);l3 l17(
l19).l152(&l405,l43,"",l43,l57,l45,l146).l46();}l6 l1003(l2 l6&l19,l2
l6&l104,l2 l6&l187,l2 l6&l276,l2 l6&l381,l2 l6&l394,l2 l6&l152){l9
l912=l187.l34<l50>()?l15(""):l187.l36<l15>();l9 l619=l276.l34<l50>()?
l15(""):l276.l36<l15>();l9 l544=l381.l34<l50>()?l15(""):l381.l36<l15>
();l9 l524=l394.l34<l50>()?l15(""):l394.l36<l15>();l9 l609=l152.l34<
l50>()?l57:l152.l36<l18>();l9 l87=l17(l19);l22<l4>l876={l87.l23.l30(
l912)};l22<l4>l882={-1};l3 l87.l705(l17(l104),l876,l882,l619,l544,
l524,l609).l46();}l6 l1010(l2 l6&l19,l2 l6&l127,l2 l6&l276,l2 l6&l187
,l2 l6&l721,l2 l6&l307,l2 l6&l738,l2 l6&l766,l2 l6&l152,l2 l6&l781){
l9 l464=l13(l187,0,0,l187.l44()==1);l9 l619=l276.l34<l50>()?l15("\x69"
"\x6e\x6e\x65\x72"):l276.l36<l15>();l9 l492=l13(l781,0,0,l781.l44()==
1);l9 l601=l13(l721,0,0,l721.l44()==1);l9 l606=l13(l307,0,0,l307.l44(
)==1);l18 l581=l738.l34<l50>()?l57:l738.l36<l18>();l18 l589=l766.l34<
l50>()?l57:l766.l36<l18>();l18 l609=l152.l34<l50>()?l57:l152.l36<l18>
();l9 l87=l17(l19);l9 l416=l17(l127);l22<l4>l346;l22<l4>l404;l1(l464.
l10()==0&&l601.l10()==0&&l606.l10()==0&&!l581&&!l589){l9 l61=l416.l23
.l74(l87.l23,l43);l11(l9&l0:l61)l1(l0>=0)l346.l56(l0);l61=l87.l23.l74
(l416.l23,l43);l11(l9&l0:l61)l1(l0>=0)l404.l56(l0);}l33 l1(l464.l10()>
0){l1(l601.l10()>0||l606.l10()>0||l581||l589)l35 l454("\x69\x66\x20"
"\x27\x6f\x6e\x27\x20\x69\x73\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64"
"\x2c\x20\x27\x6c\x65\x66\x74\x5f\x6f\x6e\x27\x2c\x20\x27\x72\x69\x67"
"\x68\x74\x5f\x6f\x6e\x27\x2c\x20" "\x27\x6c\x65\x66\x74\x5f\x69\x6e"
"\x64\x65\x78\x27\x20\x61\x6e\x64\x20\x27\x72\x69\x67\x68\x74\x5f\x69"
"\x6e\x64\x65\x78\x27\x20\x6d\x75\x73\x74\x20\x62\x65\x20\x4e\x6f\x6e"
"\x65");l346=l87.l23.l74(l464);l404=l416.l23.l74(l464);}l33{l1(l581)l346
={-1};l33 l346=l87.l23.l74(l601);l1(l589)l404={-1};l33 l404=l416.l23.
l74(l606);}l1(l346.l10()!=l404.l10())l35 l454("\x4d\x65\x72\x67\x65"
"\x20\x63\x6f\x6c\x75\x6d\x6e\x73\x20\x6d\x75\x73\x74\x20\x62\x65\x20"
"\x73\x61\x6d\x65\x20\x6c\x65\x6e\x67\x74\x68");l1(l346.l62())l35 l454
("\x4e\x6f\x20\x63\x6f\x6d\x6d\x6f\x6e\x20\x63\x6f\x6c\x75\x6d\x6e"
"\x73\x20\x74\x6f\x20\x70\x65\x72\x66\x6f\x72\x6d\x20\x6d\x65\x72\x67"
"\x65\x20\x6f\x6e");l15 l544=l492.l10()>0?l492.l91(0).l36<l15>():""
"\x5f\x78";l15 l524=l492.l10()>0?l492.l91(1).l36<l15>():"\x5f\x79";l3
l87.l705(l416,l346,l404,l619,l544,l524,l609).l46();}l6 l959(l2 l6&l19
,l2 l6&l104,l2 l6&l402){l18 l819=l402.l34<l50>()?l43:l402.l36<l18>();
l3 l17(l19).l625(l17(l104),l819).l46();}l6 l954(l2 l6&l19,l2 l6&l778,
l2 l6&l143){l9 l242=l13(l778,0,0,l778.l44()==1);l9 l67=l13(l143,0,0,
l143.l44()==1);l3 l17(l19).l858(l242,l67.l10()==0?l106:&l67).l46();}
l6 l1007(l2 l6&l19,l2 l6&l92,l2 l6&l32,l2 l6&l115){l9 l66=l92.l34<l50
>()?1:l92.l36<l4>();l9 l141=l32.l34<l50>()?0:l32.l36<l4>();l2 l6*l698
=l115.l34<l50>()?l106:&l115;l1(l141==1)l3 l17(l19).l7().l482(l66,l698
).l7().l46();l3 l17(l19).l482(l66,l698).l46();}l6 l918(l2 l6&l19,l2 l6
&l197,l2 l6&l55,l2 l6&l52){l6 l209;l1(l197.l82()==1||l197.l44()==1){
l1(l197.l34<l15>()){l1(l197.l36<l15>().l63(':')!=l15::l258)l3 l577(
l19,l197,l209,l55,l52);l33{l320{l9 l5=l664(l19,l197);l1(l1051(l5))l3
l446(l19,l5,l209,l55,l52);}l340(...){}}}l13 l146(l197,0,0,l197.l44()==
1);l1(l146.l93()==l20::l75)l3 l446(l19,l197,l209,l55,l52);l1(l52.l34<
l15>()){l320{l9 l5=l664(l19,l52);l1(l244(l5))l3 l446(l19,l209,l197,
l55,l5);}l340(...){}}l3 l446(l19,l209,l197,l55,l52);}l1(l244(l197)){
l1(l197.l44()==2)l3 l446(l19,l197,l209,l55,l52);l3 l17(l19).l552(l197
,l52,l209,!l52.l34<l50>(),l480(l55)).l46();}l35 l41("\x62\x61\x64\x20"
"\x6b\x65\x79\x20\x76\x61\x6c\x75\x65");}l6 l19(l2 l6&l800,l2 l6&l197
,l2 l6&l55,l2 l6&l52){l3 l918(l800,l197,l55,l52);}l6 l961(l2 l6&l19){
l3 l17(l19).l46(l363::l633);}
