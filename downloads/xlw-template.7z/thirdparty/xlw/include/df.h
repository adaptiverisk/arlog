#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <xlw/xl.h> // for XlfOper

namespace xlw
{
// ========= data types =========
enum class BinaryOp
{
  Add,
  Subtract,
  RSubtract,
  Multiply,
  Divide,
  Power,
  Modulo,
  LessThan,
  LessThanOrEqual,
  GreaterThan,
  GreaterThanOrEqual,
  Equal,
  NotEqual,
  And,
  Or,
  // not provided by query_parser:
  RDivide,
  RPower,
  RModulo,
  Min,
  Max,
  Unknown
};

enum class UnaryOp
{
  Negate,
  Not
};

enum class df_type
{
  num,
  str,
  bol,
  unk
};

inline std::string type_name(df_type t)
{
  switch (t)
  {
    case df_type::num: return "number";
    case df_type::str: return "string";
    case df_type::bol: return "boolean";
    default: return "unknown";
  }
}

inline df_type from_name(const std::string& str)
{
  if (str.empty())
    return df_type::unk;
  switch (str[0])
  {
    case 'n': return df_type::num;
    case 's': return df_type::str;
    case 'b': return df_type::bol;
    default: return df_type::unk;
  }
}

inline df_type xl_type(const XlfOper& x)
{
  if (x.is<double>())
    return df_type::num;
  if (x.is<std::string>())
    return df_type::str;
  if (x.is<bool>())
    return df_type::bol;
  return df_type::unk;
}

template<typename T>
inline bool is_type(df_type t)
{
  return false;
}
template<>
inline bool is_type<int>(df_type t)
{
  return t == df_type::num;
}
template<>
inline bool is_type<double>(df_type t)
{
  return t == df_type::num;
}
template<>
inline bool is_type<std::string>(df_type t)
{
  return t == df_type::str;
}
template<>
inline bool is_type<bool>(df_type t)
{
  return t == df_type::bol;
}

template<typename T>
inline df_type t_type()
{
  return df_type::unk;
}
template<>
inline df_type t_type<double>()
{
  return df_type::num;
}
template<>
inline df_type t_type<std::string>()
{
  return df_type::str;
}
template<>
inline df_type t_type<bool>()
{
  return df_type::bol;
}

// ========= DataVector =========
enum class CumOp
{
  Max,
  Min,
  Prod,
  Sum
};

enum class Op1d
{
  Min,
  Max,
  IdxMax,
  IdxMin,
  Mean,
  Sem,
  Median,
  Skew,
  Kurt,
  Std,
  Var,
  Sum,
  Prod,
  NUnique,
  Count
};

std::string op1d2str(Op1d op);

enum class FillMethod
{
  Bfill, // same as backfill
  Ffill, // Default (same as pad)
  Nearest,
  None
};

FillMethod str2fill_method(const std::string& s);

enum class BoundsInclusion
{
  Both, // Default
  Left,
  Right,
  Neither
};

BoundsInclusion str2bounds_inclusion(const std::string& s);

// take multi_index (for each index in loc, vector of indexes in vec)
// flatten it in the following way:
// if idx[i] is empty replace with -1
// otherwise insert into idx[i]'th position all values in idx[i] vector
// so result can be longer than idx - the result is which rows from vec to take
// at the same time vec_idx is a map from result to loc
// i.e. if not duplicates it is just 0, 1, 2, ...
// if duplicates the corresponding index repeats (i.e. if idx[1] = {2, 3} then
// 0, 1, 1, 2 ...
std::vector<int> idx_flatten(
    const std::vector<std::vector<int>>& idx, std::vector<int>& vec_idx);

class DataVector
{
private:
  df_type type_ = df_type::unk;

public:
  // not public because of utility template functions in .cpp
  // also used in some places in dataframe
  std::vector<std::string> str_;
  std::vector<double> num_;
  std::vector<bool> bol_;
  bool is_date_ = false; // if true, treat as date

  // ---
  std::unordered_set<int> missing;

  DataVector() {}

  // creates data vector from i'th column (or row if is_column = false)
  // if n >= 0, only the first n elements are taken (if not enough - missing
  // values are added)
  DataVector(
      const xlw::XlfOper& x, int i, int j0 = 1, bool is_column = true,
      int n = -1)
  {
    init(x, i, j0, is_column, n);
  }
  DataVector(int n, double x = 0) { init(n, x); }

  DataVector(const std::vector<double>& vec) { init(vec); }
  DataVector(const std::vector<std::string>& vec) { init(vec); }
  DataVector(const std::vector<bool>& vec) { init(vec); }
  bool empty() const { return type_ == df_type::unk || size() == 0; }
  void init(
      const xlw::XlfOper& x, int i, int j = 1, bool is_column = true,
      int n = -1);
  void init(int n, double x = 0.0);
  template<typename T>
  void init(const std::vector<T>& vec)
  {
    type_ = t_type<T>();
    v<T>() = vec;
  }
  void init(const DataVector& dv) { *this = dv; }

  df_type type() const { return type_; }
  void set_type(df_type t) { type_ = t; }
  void convert2type(df_type t);

  size_t size() const;
  int len() const { return (int)size(); }

  void clear();

  // get reference to underlying vector depending on type
  template<typename T>
  const std::vector<T>& v() const
  {
    throw("# bad type");
  }
  template<>
  const std::vector<double>& v() const
  {
    return num_;
  }
  template<>
  const std::vector<std::string>& v() const
  {
    return str_;
  }
  template<>
  const std::vector<bool>& v() const
  {
    return bol_;
  }

  template<typename T>
  std::vector<T>& v()
  {
    throw("# bad type");
  }
  template<>
  std::vector<double>& v()
  {
    return num_;
  }
  template<>
  std::vector<std::string>& v()
  {
    return str_;
  }
  template<>
  std::vector<bool>& v()
  {
    return bol_;
  }

  // get vector of non-missing numerical values
  std::vector<double> get_non_missing() const;

  // replace missing with val
  // if clear_missing - do not treat them as missing anymore
  template<typename T>
  void replace_na(const T& val, bool clear_missing = false);

  // resize to new size. if size if larger set new items to missing
  // unless replicate back is true, then set to the last available
  void resize(int new_size, bool replicate_back = false);

  // throws errors if bad location, incompatible types
  // if allow_duplicates is false and have duplicates - throws error
  void insert(int loc, const DataVector& dv, bool allow_duplicates = true);
  void append(const DataVector& dv, bool allow_duplicates = true)
  {
    insert(len(), dv, allow_duplicates);
  }

  // add idv's element from dv to the end
  void push_back(const DataVector& dv, int idv)
  {
    insert(len(), dv.iloc({idv}));
  }

  // copies data to x
  // returns how many did not fit x
  // if is_column == true
  //    i'th column, start at row j0
  // if is_column = false
  //    i'th row, start at col j0
  int to_xl(XlfOper& x, int i, int j0 = 1, bool is_column = true) const;
  XlfOper to_xl(bool is_column = true) const;

  /// <summary>
  /// Get first index of x
  /// </summary>
  /// <param name="x">value to search</param>
  /// <returns>index of x or -1 if not found</returns>
  int idx(const XlfOper& x) const;
  std::vector<int> idx_all(const xlw::XlfOper& x) const;

  // convert string to underlying type and get first index of x
  int idx(const std::string& x) const;
  // get bolean mask DataVector with is_true for positions found in idx
  // and !is_true otherwise
  DataVector idx2mask(const std::vector<int>& idx, bool is_true = true) const;
  // if DataVector is a mask (boolean vector) keep only the ones matching
  // keep_true
  std::vector<int> mask2idx(bool keep_true = true, bool drop_na = true) const;

  XlfOper iat(int i) const; // get value at i'th position

  // set value at i'th position
  // set value at i'th position from dv at position idv
  // if op is specified, use it instead of assignment
  void iat(int i, const XlfOper& x, BinaryOp op = BinaryOp::Unknown);
  void iat(int i, const DataVector& dv, int idv);

  // idx < 0 || idx > size set to *x or na if x == nullptr
  DataVector
  iloc(const std::vector<int>& idx, const xlw::XlfOper* x = nullptr) const;

  // replaces all missing values with x
  void fill_na(const XlfOper& x, int limit = -1);
  void fill_na(FillMethod fill_method, int limit = -1);
  void set_all_na();

  friend bool operator==(const DataVector& lhs, const DataVector& rhs);

  // find positions in vec of elmenents from loc (result size = size of loc)
  // both should not have missing values
  // vec is assumed not to have duplicates
  //
  // convenient for index aligning (keep skip_missing = false)
  // if skip_missing = false - throw if found in loc that is not in vec
  // if skip_missing = true, result will have same size as loc
  // with -1 for values not found
  // if numerical and tolerance > 0, find closest value within tolerance
  // note in pandas tolerance can be vector of size loc.size()
  // we are not going to support this
  // method describes what to do if some values in loc are not found in vec
  // (only relevant if skip_missing = true)
  // None - just keep -1
  // BackFill - use next found value (vec should be increasing and have no NAs)
  // ForwardFill - use last found value (vec should be increasing and have no
  // NAs) Nearest - use nearest found value (vec should be t_num, increasing and
  // have no NAs) limit - max number of consecutive elements to forward or back
  // fill. Limit is ignored right now
  // In pandas it says limit is well-defined only if index and target are
  // monotonic
  std::vector<int> loc_idx(
      const DataVector& loc, bool skip_missing = false, double tolerance = 0,
      FillMethod method = FillMethod::None, int limit = -1) const;

  // find index corresponding to locations described by pos
  // - bool mask
  // - list of labels
  // - index aligned booleans (two columns: index, bool)
  // - string representing slice
  // if need to figure out enlargement
  // supply new_keys DataVector and new_key_map to modify
  // new_key_map: i of negative idx -> index of added key in new_keys
  std::vector<int> loc_idx(
      const xlw::XlfOper& pos, DataVector* new_keys = nullptr,
      std::unordered_map<int, int>* new_key_map = nullptr) const;

  // same as loc_idx, but allows for multiple matches
  // find positions in vec of elmenents from loc (result size = size of loc)
  // both can have duplicates and missing values
  // for each element in loc returns all positions in vec
  // if not found returns empty vector for the element
  // the rest is similar to loc_idx
  std::vector<std::vector<int>> loc_multi_idx(const DataVector& loc) const;

  bool is_increasing() const;
  bool is_decreasing() const;

  // throws if have nans or x is not same type and x.len() != 1
  // returns -2 if not increasing
  // upper refers if x is bounds from above or below
  // if upper == true, returns -1 if x is smaller than all elements,
  //   otherwise gives position of max element that is <= x
  // if upper == false, returns -1 if x is larger than all elements,
  //   otherwise gives position of min element that is >= x
  int is_increasing(const DataVector& x, bool upper) const;

  // throws if have nans or x is not same type
  // returns -2 if not decreasing
  // if upper == true, returns -1 if x is smaller than all elements,
  //   otherwise gives position of first element from end that is <= x
  // if upper == false, returns -1 if x is larger than all elements,
  //   otherwise gives position of first element from end that is >= x
  int is_decreasing(const DataVector& x, bool upper) const;

  // find positions in vec of elements that match filter
  // only one of items, like, regex can be non-null
  // items - list of items to match
  // like - matches by substring
  // regex - matches by regular expression
  // if like or regex, convert items to string before matching
  std::vector<int> filter_idx(
      const DataVector* items, const std::string* like,
      const std::string* regex) const;

  // find positions in vec of elements with given time of day
  // time - fraction of day (0.5 = 12:00), if > 1, take only fractional part
  // dt - tolerance (in fraction of day). Default 1 second: 1/24/60/60
  std::vector<int> at_time(double time, double dt) const;
  std::vector<int> between_time(
      double time1, double time2, BoundsInclusion inclusive, double dt) const;

  // returns -1 if all nans
  int first_non_na_idx() const;

  int min_idx() const;
  int max_idx() const;
  XlfOper min() const { return iat(min_idx()); }
  XlfOper max() const { return iat(max_idx()); }
  // return value that appears most often
  XlfOper top() const;
  // return number of times top appears
  int freq() const;

  // ignoring na's
  int distinct_count() const;

  //// get
  // vector<int> loc(xlw::XlfOper& x) const;

  // returns boolean mask DataVector of size len()
  // if match_position = false, checks if each element is in values
  // otherwise check that each element matches values in same position
  DataVector isin(const DataVector& values, bool match_position) const;

  // returns boolean mask DataVector of size len()
  // assume that values is index-aligned using idx:
  // i.e. result at idx[i] is true if values.v()[i] == v()[idx[i]]
  DataVector isin(const DataVector& values, const std::vector<int>& idx) const;

  // returns boolean mask DataVector of size len()
  // an element at position i is true if it is in list
  // [vals[0][i], vals[1][i], ...]
  DataVector isin(const std::vector<DataVector>& vals) const;

  // index of elements that have substring
  std::vector<int> has_substr(const std::string& substr) const;
  // index of elements matching regex
  std::vector<int> match_regex(const std::string& regex) const;

  // returns DataVector keeping only elements where mask is true
  // mask should be boolean DataVector of size len()
  DataVector filter_mask(const DataVector& mask) const;

  // when na_value = true, missing values are treated as true
  DataVector na_mask(bool na_value = true) const;

  // if vv has size 1 it is treated as scalar
  // if fill is not null - fill missing with fill, however if both
  // positions are missing - fill with missing
  DataVector
  add(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  subtract(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  rsubtract(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  multiply(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  divide(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  rdivide(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  power(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  rpower(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  modulo(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  rmodulo(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  or_op(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector
  and_op(const DataVector& vv, const xlw::XlfOper* fill = nullptr) const;
  DataVector comp(const DataVector& vv, BinaryOp op) const;
  DataVector eq(const DataVector& vv) const;
  DataVector neq(const DataVector& vv) const;
  DataVector lt(const DataVector& vv) const;
  DataVector le(const DataVector& vv) const;
  DataVector gt(const DataVector& vv) const;
  DataVector ge(const DataVector& vv) const;

  // fill is ignored for comparison operators
  DataVector binary_op(
      BinaryOp op, const DataVector& vv,
      const xlw::XlfOper* fill = nullptr) const;

  DataVector not_op() const;
  DataVector negation_op() const;

  DataVector unary_op(UnaryOp op) const;

  double dot(const DataVector& vv) const;
  // skip missing and other_missing if not null
  double mean(const std::unordered_set<int>* other_missing = nullptr) const;

  double
  sum_prod(int min_cound, bool skipna = true, bool do_prod = false) const;

  double
  std(double mean, int ddof = 1,
      const std::unordered_set<int>* other_missing = nullptr) const;

  double corr(const DataVector& vv, int min_periods) const;

  double cov(const DataVector& vv, int min_periods, int ddof) const;

  DataVector combine_first(const DataVector& x2) const;
  void update(const DataVector& x2, bool overwrite);

  // abs - only if num
  void abs();

  // wheather all elements are true. empty is true. NA is true if not skipped
  bool all(bool bool_only = false, bool skipna = true) const;
  // weather any element is true. empty is false. NA is true if not skipped
  bool any(bool bool_only = false, bool skipna = true) const;

  // trim values at input thresholds (if lower/upper is size 1, it is treated as
  // scalar) if lower/upper is size 0, it is ignored missing threshold is
  // ignored (numeric only)
  DataVector clip(const DataVector& lower, const DataVector& upper) const;

  // count non-missing values
  int count(bool numeric_only = false) const;
  // count unique values (if dropna = false, missing is counted as unique)
  int nunique(bool dropna = true) const;

  // cumulative functions
  // periods is used only for diff
  // skipna is not used for diff
  template<CumOp Op>
  void cum(bool skipna = true);

  // first discrete difference
  // periods - offset back from current row (can be negative)
  // i.e. if periods = 1, then result[i] = v[i] - v[i-1]
  void diff(int periods = 1);
  void pct_change(
      int periods = 1, FillMethod fill_method = FillMethod::Ffill,
      int limit = -1);
  void shift(int periods = 1, const XlfOper* fill = nullptr);

  // returns row names when called describe with percentiles
  // if t_num, returns 'count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'
  // or other percentiles when percentiles vector is not empty
  // it not t_num returns 'count', 'unique', 'top', 'freq', 'first', 'last'
  DataVector describe_rows(
      const std::vector<double>& percentiles, bool force_not_num = false) const;

  DataVector describe(
      const std::vector<double>& percentiles, bool force_not_num = false) const;

  // interpolation (linear, lower, higher, nearest, midpoint):
  // when the desired quantile lies between two data points i and j
  //  - 'linear' the quantile estimate is i + (j - i) * fraction, where fraction
  //  is the fractional part of the index surrounded by i and j.
  //  - 'lower' the quantile estimate is the value of the data point with i.
  //  - 'higher' the quantile estimate is the value of the data point with j.
  //  - 'nearest' the quantile estimate is the value of the data point with
  //  index nearest to i + fraction.
  //  - 'midpoint' the quantile estimate is the mean of the values of the data
  //    points with indices floor(i + fraction) and ceil(i + fraction).
  std::vector<double> quantile(
      const std::vector<double>& q,
      const std::string& interpolation = "linear") const;

  double kurt_skew(bool skipna = true, bool calc_skew = false) const;

  // xtra is mostly ignored, except for:
  // prod: min_count paramete: default 0
  // sum: min_count parameter: default 0
  // std: ddof parameter: default 1
  // var: ddof parameter: default 1
  // sem: ddof parameter: default 1
  double op1d(Op1d op, bool skipna = true, int xtra = 0) const;

  // compute mode of a vector
  // the mode is a value that appears most often
  // if there are multiple values that appear most often, all of them are
  // returned if skipna is true, missing values are ignored else NA is treated
  // as a value
  DataVector mode(bool dropna = true) const;

  DataVector rank(
      const std::string& method, const std::string& na_option, bool ascending,
      bool pct) const;

  void round(int decimals = 0);

  // errors: 'ignore' - existing keys will be renamed and extra ignored
  //        'raise' - if keys have values not in in vec, raise an error
  // for values of vec not in keys, keep the original
  DataVector rename(
      const DataVector& keys, const DataVector& values,
      bool ignore_errors = true) const;

  // return indexes to keep
  std::vector<int>
  truncate(const xlw::XlfOper& before, const XlfOper& after) const;

  // to_replace - DataVector with single value
  // value: scalar to replace with
  void replace(const XlfOper& to_replace, const XlfOper& value, bool is_regex);
  void replace(
      const std::vector<XlfOper>& to_replace, const std::vector<XlfOper>& value,
      bool is_regex);
  void replace(
      const std::vector<XlfOper>& to_replace, FillMethod method, int limit,
      bool is_regex);

  // compares elements i and j and returns -1 if i < j, 0 if i == j, 1 if i > j
  // if na_large is true, NA is considered larger than any other value
  int el_comp(int i, int j, bool na_large) const;
};

// ============= DataFrame ================
/// <summary>
/// Creates index from range representing boolean mask.
/// </summary>
/// <param name="pos">boolean mask pos, which can be row or column - have length
/// == size param</param> <param name="size">To ensure length of pos</param>
/// <returns>vector of indexes of elements in pos that are true</returns>
std::vector<int> bool_mask(XlfOper& pos, int size);

/// <summary>
/// Checks if v is a dataframe.
/// </summary>
/// <param name="v">range to check</param>
/// <returns>true if v is a dataframe</returns>
static inline bool is_df(const XlfOper& v)
{
  if (!v.IsMulti())
    return false;
  return v(0, 0).is<void>()
         || (v(0, 0).is<std::string>() && v(0, 0).as<std::string>() == "");
}

/// <summary>
/// Describes conversion mode from dataframe to xl.
/// </summary>
enum class ToXlMode
{
  All,        // full dataframe (is_df will return true)
  Data,       // just data (like to_numpy)
  DataIndex,  // data + index
  DataColumns // data + columns
};

class DataFrame
{
private:
public:
  std::vector<DataVector> data; // columns
  DataVector columns;           // column names
  DataVector index;             // index
  df_type _row_type =
      df_type::unk;     // not unknown only when all columns are of same type
  std::string idx_name; // name of index

  DataFrame() {}

  /// <summary>
  /// Create dataframe from 2d range
  /// </summary>
  /// <param name="x"></param>
  /// <param name="columns">if not nullptr, assume x has no column names and use
  /// this vector instead</param> <param name="index">if not nullptr, assume x
  /// has no index and use this vector instead</param>
  DataFrame(
      const XlfOper& x, const DataVector* columns = nullptr,
      const DataVector* index = nullptr);

  /// <summary>
  /// Get i'th row
  /// </summary>
  /// <param name="i">row index</param>
  /// <returns>row of type _row_type</returns>
  DataVector row(int i) const;

  /// <summary>
  /// Create xl representation of dataframe.
  /// </summary>
  /// <param name="to_numpy">specifies what to output</param>
  /// <returns>xl representation</returns>
  XlfOper to_xl(ToXlMode to_numpy = ToXlMode::All) const;

  /// <summary>
  /// Transpose. Only works when all columns are of same type.
  /// </summary>
  /// <returns>Transposed dataframe</returns>
  DataFrame T() const;

  // Access a single value for a row/column label pair.

  /// <summary>
  /// Get element at row with index label 'row' and column with label 'col'.
  /// </summary>
  /// <param name="row">row where index equals to this value</param>
  /// <param name="col">column where label equals to this value</param>
  /// <returns>element or NA if not found</returns>
  XlfOper at(const XlfOper& row, const XlfOper& col) const;
  DataFrame& at(const XlfOper& row, const XlfOper& col, const XlfOper& value);
  XlfOper iat(int irow, int icol) const;
  DataFrame& iat(int irow, int icol, const XlfOper& value);
  DataFrame iloc(const XlfOper& rows, const XlfOper& cols) const;
  // if value is empty do nothing
  DataFrame& iloc(
      const std::vector<int>& row_idx, const std::vector<int>& col_idx,
      const XlfOper& value);
  DataFrame&
  iloc(const XlfOper& rows, const XlfOper& cols, const XlfOper& value);
  DataFrame loc(const XlfOper& rows, const XlfOper& cols) const;
  // if selected_part != nullptr, also computes just selected part
  DataFrame&
  loc(const XlfOper& rows, const XlfOper& cols, const XlfOper& value,
      DataFrame* selected_part = nullptr);
  DataFrame select_dtypes(const std::vector<df_type>& types) const;
  DataFrame remove_dtypes(const std::vector<df_type>& types) const;

  // for any row or col idx which are negative insert NA, unless x != nullptr,
  // then use x
  DataFrame
  sel(const std::vector<int>& row_idx, const std::vector<int>& col_idx,
      const XlfOper* x = nullptr) const;
  DataFrame
  sel(const std::vector<int>& row_idx, const XlfOper* x = nullptr) const;
  DataFrame
  sel_col(const std::vector<int>& col_idx, const XlfOper* x = nullptr) const;

  DataFrame
  drop(const std::vector<int>& row_idx, const std::vector<int>& col_idx) const;
  DataFrame drop(const std::vector<int>& row_idx) const;
  DataFrame drop_col(const std::vector<int>& col_idx) const;

  DataFrame& insert(int loc, const XlfOper& value, const XlfOper& colname);
  DataFrame& fill_na(const XlfOper& value);

  void reset_index();
  // values: range of values, columns (like dataframe, but without index)
  // dataframe
  // create dataframe with same size as parent
  // each element of which is true at location if all labels match:
  // - single value
  // - if just range, first element of range should be "*"
  //   (can be column or row) checks if an element matches an element from range
  //   range can have values of different types
  // - if columns: element column name should match column name and
  //   element value should be one of the values in the column
  // - if dataframe: also should match indexes
  // - if dataframe with single column named "*" should match indexes
  DataFrame isin(const XlfOper& values) const;

  // keeps values that have true condition, and replaces the rest (opposite of
  // mask)
  DataFrame where(
      const XlfOper& cond, // bool dataframe (can have single column named "*" -
      // matches indexes) or 1d range (first el should be
      // "*") - same size as df.rows (if axis=0 or missing)
      // or df.cols if axis=1
      const XlfOper&
          other, // optional. If not specified, all elements where cond is
      // false will be set to NA. Otherwise set according to other: scalar,
      // dataframe (same size as df), 1 row - value for each column.
      // Value from other is converted to column type.
      const XlfOper& axis, // optional (see description of cond)
      bool opposite =
          false, // if true, replaces values that have false condition
      // and replaces the rest (opposite of where)
      BinaryOp op = BinaryOp::Unknown // if specified, use this operation
                                      // instead of simple asignment for other

  ) const;

  // evaluate expression in which variables are column names
  DataVector eval(const std::string& expr) const;
  // evaluate expression and adds result as new column
  void eval(const std::string& expr, const std::string& colname);

  DataFrame query(const std::string qry) const;

  // todo: see if can/need to normalize types of inputs with isin function
  // fill_value is ignored when op is comparison operator
  // binary operation on dataframe. x can be:
  // - scalar
  // - 1d range, should have length same as number of columns if axis=1 or
  //      number of rows if axis=0
  // - columns with names (if axis=1). Length of columns beyond names should
  //   be either 1 or same as number of rows in dataframe. Aligns on columsn.
  // - rows with names (if axis=0 - names correspond to index).
  //   Length of rows beyond names should be either 1 or same as number of
  //   columns in dataframe. Aligns on rows.
  // - dataframe. Aligns on both index and columns. If single column with
  //   name "*" - aligns on index only and apply to all columns. If single
  //   row with name "*" - aligns on columns only and apply to all rows.
  //   The result is expanded to include indexes and columns of both
  // - fill value works as follows:
  //   Fill existing missing (NA) values, and any new element needed for
  //   successful DataFrame alignment, with this value before computation. If
  //   data in both corresponding DataFrame locations is missing the result will
  //   be missing.
  // - axis = 1 by default
  // - Min, Max ignores fill_value and ignores NA in x
  DataFrame bin_op(
      BinaryOp op, const XlfOper& x, const XlfOper& axis,
      const XlfOper& fill_value) const;

  // do operation from op= x (e.g. += x)
  // doesn't do expansion
  DataFrame& bin_op_to(BinaryOp op, const XlfOper& x);

  DataFrame dot(const DataFrame& other) const;

  DataFrame& combine_first_no_expand(const DataFrame& other);
  DataFrame combine_first(const XlfOper& x) const;

  DataFrame& abs();

  // if axis=0, reduces index, if axis=1 reduces columns, otherwise
  // reduces all and returns single value
  // bool_only - if true, only bool columns are considered
  // skipna - if true, NA values are skipped (see DataVector::all)
  // if do_any - run any instead of all
  DataFrame
  all(int axis = 0, bool bool_only = false, bool skipna = true,
      bool do_any = false) const;

  // lower and upper is similar to x in bin_op with axis similar
  DataFrame
  clip(const XlfOper& lower, const XlfOper& upper, const XlfOper& axis);

  // if numeric_only is true, only numeric columns are considered
  // if it is false and have nonnumeric columns - throws exception
  DataFrame corr(int min_periods = 1, bool numeric_only = false) const;

  // aligns columns and indexes. Returns union of columns.
  // If other has single column '*' - aligns on index only and apply to all
  DataFrame corrwith(
      const DataFrame& other, bool skipna = false,
      bool numeric_only = false) const;

  // count non-NA cells for each column or row
  // if numeric_only is true, only numeric columns are considered
  // if axis = 0, counts for each column, if axis = 1, counts for each row
  DataFrame count(int axis = 0, bool numeric_only = false) const;

  // stack the columns
  DataFrame& flatten();

  // if numeric_only is true, only numeric columns are considered
  // if it is false and have nonnumeric columns - throws exception
  // the divisor used in calculations is N - ddof, where N represents the number
  // of elements
  DataFrame
  cov(int min_periods = 1, int ddof = 1, bool numeric_only = false) const;

  template<CumOp Op>
  DataFrame cum(int axis = 0, bool skipna = true) const;

  DataFrame describe(
      const std::vector<double>& percentiles,
      const std::vector<df_type>& include,
      const std::vector<df_type>& exclude) const;

  DataFrame diff(int periods = 1, int axis = 0) const;

  DataFrame op1d(
      Op1d op, const XlfOper& axis, const XlfOper& skipna,
      const XlfOper& numeric_only, const XlfOper& extra_param) const;

  DataFrame
  mode(const XlfOper& axis, const XlfOper& numeric_only, const XlfOper& dropna);

  DataFrame pct_change(
      int periods = 1, FillMethod fill_method = FillMethod::Ffill,
      int limit = -1) const;

  DataFrame shift(int periods = 1, const XlfOper* fill_value = nullptr) const;

  DataFrame quantile(
      const XlfOper& q, const XlfOper& axis, const XlfOper& numeric_only,
      const XlfOper& interpolation, const XlfOper& method) const;

  DataFrame rank(
      const XlfOper& axis, const XlfOper& method, const XlfOper& numeric_only,
      const XlfOper& na_option, const XlfOper& ascending,
      const XlfOper& pct) const;

  DataFrame round(const XlfOper& decimals) const;

  DataFrame nunique(int axis = 0, bool dropna = true) const;

  // axis = 1 - add prefix to columns, otherwise to index
  // first convert to string vector
  DataFrame& add_presufix(const std::string& prefix, int axis, bool is_prefix);

  DataFrame at_time(double time, double dt, int axis = 0) const;
  DataFrame between_time(
      double time1, double time2, BoundsInclusion inclusive, int axis = 0,
      double dt = 1. / 24. / 60. / 60.) const;

  DataFrame drop(
      const DataVector* labels, int axis, const DataVector* index,
      const DataVector* columns, bool ignore_errors = false) const;

  // keep: -1 first, 1 last, 0 false - drop all
  DataFrame drop_duplicates(
      const DataVector* subset, int keep, bool ignore_index = false) const;

  std::vector<int> unique_idx(const DataVector* subset, int keep) const;
  std::vector<int> dupl_idx(const DataVector* subset, int keep) const;

  // returns true for each row that is duplicated
  DataFrame duplicated(const DataVector* subset, int keep) const;

  DataFrame filter(
      const DataVector* items, const std::string* like,
      const std::string* regex, int axis) const;

  DataFrame reindex(
      const DataVector* labels, int axis, const DataVector* index,
      const DataVector* columns, FillMethod method, const XlfOper& fill_value,
      int limit, double tolerance) const;

  // resets with default index
  // if drop is true (default: false), drops index, otherwise adds index as
  // column the name of the column: "index" by default, unless name is specified
  DataFrame& reset_index(bool drop, bool allow_duplicates, const XlfOper& name);

  // weights: default: empty - equal weights
  // not isMulti: column name which is used as weights
  // dataframe: should be dataframe with single column
  //  align with index. weights not in index are ignored, index not in weights
  //  is weighted with 0. If weigths do not sum to 1, they are normalized.
  //  Missing values in weights are treated as 0.
  // can be just single column - should be same length as index
  // axis: 0 - rows (default), 1 - columns
  DataFrame sample(
      int n, double frac, bool replace, const XlfOper& weights,
      int random_state, int axis, bool ignore_index) const;

  // thres - drop row/column if number of NA values is greater than thres
  // needs to be > 0 to be used
  DataFrame dropna(
      int axis = 0, bool how_any = true, int thres = -1,
      const DataVector* subset = nullptr, bool ignore_index = false) const;

  DataFrame& fillna(FillMethod method, int limit);

  DataFrame& replace(
      const XlfOper& to_replace, const XlfOper& value, int limit, bool regex,
      FillMethod method);

  // returns 0 if row i = row j, -1 if row i < rowj, 1 if row i > row j.
  //  Comparison in lexigraphical order across
  // in order specified in cols
  // na_large: if true, NA is considered larger than any other value
  // if cols empty compare index
  int row_comp(int i, int j, bool na_large, const std::vector<int>& cols) const;

  // only support kind = 'quicksort' or 'stable'
  // if by is empty, sort by index
  // if n >= 0, return n rows from top
  // if keep specifies what to do with duplicates at n:
  //  -1: 'first' - keep first found (default)
  //  1: 'last' - keep last found
  //  0: 'all' - keep all found (even it it exceeds n)
  DataFrame sort(
      const DataVector* by = nullptr, bool ascending = true,
      const std::string& kind = "", bool na_last = true,
      bool ignore_index = false, int ntop = -1, int keep = -1) const;

  // on - columns to join on (or index if -1)
  // if on variables can containe -1 only when their size is 1 (then join on
  // index), otherwise should denote columns only and this is not checked
  DataFrame join(
      const DataFrame& other, const std::vector<int>& on = {},
      const std::vector<int>& right_on = {}, const std::string& how = "left",
      const std::string& lsuffix = "", const std::string& rsuffix = "",
      bool sort = false, const std::string& validate = "") const;

  // unlike combine_first does not modify size of the dataframe
  // and can overwrite non only NA value if overwrite = true
  DataFrame& update(const DataFrame& other, bool overwrite = true);

  DataFrame
  asof(const DataVector& where_vec, const DataVector* subset = nullptr) const;
};

/// <summary>
/// Checks if v is a boolean dataframe.
/// </summary>
/// <param name="v">range to check</param>
/// <returns>true if v is a boolean dataframe</returns>
static inline bool is_bool_df(const XlfOper& v)
{
  if (!v.IsMulti())
    return false;
  if (v(0, 0).is<void>()
      || (v(0, 0).is<std::string>() && v(0, 0).as<std::string>() == ""))
  { // dataframe
    auto df = DataFrame(v);
    return df._row_type == df_type::bol;
  }
  return false;
}

} // namespace xlw
