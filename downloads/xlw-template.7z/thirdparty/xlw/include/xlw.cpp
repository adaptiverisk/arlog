#include"xlw/CriticalSection.h"
#include"xlw/TempMemory.h"
#include"xlw/ThreadLocalStorage.h"
#include<algorithm>
#include<assert.h>
#include<cctype>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<fstream>
#include<iostream>
#include<locale>
#include<memory>
#include<sstream>
#include<stdexcept>
#include<stdio.h>
#include<string>
#include<sys/stat.h>
#include<vector>
#include<xlw/HiResTimer.h>
#include<xlw/NCmatrices.h>
#include<xlw/PascalStrConv.h>
#include<xlw/XlFunctionRegistration.h>
#include<xlw/XlOpenClose.h>
#include<xlw/XlfAbstractCmdDesc.h>
#include<xlw/XlfArgDesc.h>
#include<xlw/XlfArgDescList.h>
#include<xlw/XlfCmdDesc.h>
#include<xlw/XlfExcel.h>
#include<xlw/XlfFuncDesc.h>
#include<xlw/XlfOper.h>
#include<xlw/XlfRef.h>
#include<xlw/XlfServices.h>
#include<xlw/XlfWindows.h>
#include<xlw/macros.h>
#include<xlw/xl.h>
#include<xlw/xl_log.h>
#include<xlw/xlcall32.h>
#include<xlw/xlfArgDescList.h>
#include<xlw/xlfCmdDesc.h>
#include<xlw/xlfFuncDesc.h>
#define lz_xlw xlw
#define l164_HiResTimer HiResTimer
#define l341_QueryPerformanceCounter QueryPerformanceCounter
#define l105_start start
#define l18_double double
#define l700_elapsed elapsed
#define la_const const
#define l399_LARGE_INTEGER LARGE_INTEGER
#define l638_QueryPerformanceFrequency QueryPerformanceFrequency
#define le_return return
#define l271_QuadPart QuadPart
#define l5_using using
#define lr_namespace namespace
#define l62_NCMatrix NCMatrix
#define l6_data data
#define l640_copy copy
#define l24_size_t size_t
#define l88_new new
#define l755_NCMatrixData NCMatrixData
#define l361_resize resize
#define l147_rows rows
#define l433_swap swap
#define l154_this this
#define l167_operator operator
#define lb_if if
#define l16_std std
#define lo_char char
#define l129_PascalStrConv PascalStrConv
#define l732_WPascalStr2Str WPascalStr2Str
#define l17_wchar_t wchar_t
#define lw_TempMemory TempMemory
#define l241_GetMemory GetMemory
#define l547_WideCharToMultiByte WideCharToMultiByte
#define l499_CP_ACP CP_ACP
#define lf_int int
#define l59_NULL NULL
#define l279_wstring wstring
#define l704_WPascalStr2WStr WPascalStr2WStr
#define l707_Str2WPascalStr Str2WPascalStr
#define lc_string string
#define l138_length length
#define lx_cerr cerr
#define l14_XLW__HERE__ XLW__HERE__
#define lg_endl endl
#define l593_MultiByteToWideChar MultiByteToWideChar
#define l15_c_str c_str
#define l85_static_cast static_cast
#define l150_XCHAR XCHAR
#define l657_WStr2WPascalStr WStr2WPascalStr
#define l649_wcsncpy_s wcsncpy_s
#define l756_WPascalStrCopy WPascalStrCopy
#define l408_memcpy memcpy
#define l156_sizeof sizeof
#define l753_WPascalStrNewCopy WPascalStrNewCopy
#define l669_GetMemoryUsingNew GetMemoryUsingNew
#define l393_StringUtilities StringUtilities
#define l485_getEnvVar getEnvVar
#define l99_DWORD DWORD
#define l137_vector vector
#define l444_GetEnvironmentVariable GetEnvironmentVariable
#define l222_class class
#define l171_public public
#define l431_streambuf streambuf
#define l653_protected protected
#define l506_int_type int_type
#define l617_overflow overflow
#define l229_traits_type traits_type
#define l645_eq_int_type eq_int_type
#define l602_eof eof
#define l664_append append
#define l724_to_char_type to_char_type
#define ln_else else
#define l533_sync sync
#define l674_not_eof not_eof
#define l527_erase erase
#define l510_private private
#define lk_void void
#define l243_CerrBufferRedirector CerrBufferRedirector
#define l477_rdbuf rdbuf
#define l104_static static
#define l532_MEMORY_BASIC_INFORMATION MEMORY_BASIC_INFORMATION
#define l290_HMODULE HMODULE
#define l470_MAX_PATH MAX_PATH
#define ls_bool bool
#define l47_empty empty
#define l574_VirtualQuery VirtualQuery
#define l736_LPCVOID LPCVOID
#define l616_AllocationBase AllocationBase
#define l690_GetModuleFileName GetModuleFileName
#define l68_XlfServices XlfServices
#define l296_StatusBar StatusBar
#define l34_false false
#define l731_size_type size_type
#define l293_find_last_of find_last_of
#define l237_substr substr
#define l715_SetEnvironmentVariable SetEnvironmentVariable
#define l316_extern extern
#define l144_EXCEL_EXPORT EXCEL_EXPORT
#define l719_xl_on_recalc_macro xl_on_recalc_macro
#define l155_MacroCache MacroCache
#define l461_Recalc Recalc
#define ll_Instance Instance
#define l228_ExecuteMacros ExecuteMacros
#define l275_long long
#define l629_xlAutoOpen xlAutoOpen
#define l306_try try
#define li_XlfExcel XlfExcel
#define l346_InitializeProcess InitializeProcess
#define l23_auto auto
#define l172_XLRegistration XLRegistration
#define l66_ExcelFunctionRegistrationRegistry ExcelFunctionRegistrationRegistry
#define l284_has_recalc has_recalc
#define l540_HasMacros HasMacros
#define l331_XLCommandRegistrationData XLCommandRegistrationData
#define l287_AddCommand AddCommand
#define l360_DoTheRegistrations DoTheRegistrations
#define l305_clear clear
#define l545_Open Open
#define l61_Commands Commands
#define l385_SetOnRecalc SetOnRecalc
#define l295_catch catch
#define l610_xlAutoClose xlAutoClose
#define l721_Close Close
#define l439_DoTheDeregistrations DoTheDeregistrations
#define l472_DeleteInstance DeleteInstance
#define l350_TerminateProcess TerminateProcess
#define l537_xlAutoRemove xlAutoRemove
#define l571_Remove Remove
#define l69_true true
#define l242_typedef typedef
#define l270_shared_ptr shared_ptr
#define l632_ThreadLocalStorage ThreadLocalStorage
#define l708_CriticalSection CriticalSection
#define l388_isThreadDead isThreadDead
#define l587_template template
#define l130_struct struct
#define l322_delete delete
#define l733_GetBytes GetBytes
#define l176_GetValue GetValue
#define l264_CreateTempMemory CreateTempMemory
#define l501_InternalGetMemory InternalGetMemory
#define l699_EnterExportedFunction EnterExportedFunction
#define l374_InternalEnterExportedFunction InternalEnterExportedFunction
#define l544_LeaveExportedFunction LeaveExportedFunction
#define l469_InternalLeaveExportedFunction InternalLeaveExportedFunction
#define l92_offset_ offset_
#define l382_threadId_ threadId_
#define l443_GetCurrentThreadId GetCurrentThreadId
#define l177_depth_ depth_
#define l247_InternalFreeMemory InternalFreeMemory
#define l199_while while
#define l112_freeList_ freeList_
#define l51_size size
#define l254_pop_back pop_back
#define l446_ProtectInScope ProtectInScope
#define l743_remove_if remove_if
#define l146_begin begin
#define l81_end end
#define l168_get get
#define l696_SetValue SetValue
#define l289_push_back push_back
#define l276_PushNewBuffer PushNewBuffer
#define l512_XlfBuffer XlfBuffer
#define l567_shared_char_ptr shared_char_ptr
#define l563_push_front push_front
#define l281_unsigned unsigned
#define l308_front front
#define l748_max max
#define l343_memset memset
#define l19_for for
#define l569_HANDLE HANDLE
#define l538_OpenThread OpenThread
#define l596_THREAD_QUERY_INFORMATION THREAD_QUERY_INFORMATION
#define l372_FALSE FALSE
#define l480_BOOL BOOL
#define l671_GetExitCodeThread GetExitCodeThread
#define l712_CloseHandle CloseHandle
#define l738_STILL_ACTIVE STILL_ACTIVE
#define l333_map map
#define l377_num_fmt num_fmt
#define l559_get_fmts get_fmts
#define ld_XlfOper XlfOper
#define l358_reserve reserve
#define l288_cols cols
#define l363_continue continue
#define l725_find find
#define l589_second second
#define l42_to_string to_string
#define l67_inline inline
#define l22_name name
#define l459_stat stat
#define l166_FILE FILE
#define l227_is is
#define l46_fprintf fprintf
#define l89_as as
#define l634_flog_init flog_init
#define l245_lib lib
#define l246_nullptr nullptr
#define l636_time_t time_t
#define l735_time time
#define l448_tm tm
#define l659_fopen_s fopen_s
#define l749_localtime_s localtime_s
#define l652_fopen fopen
#define l565_localtime localtime
#define l528_strftime strftime
#define l623_log_xlf log_xlf
#define l635_xltypeName xltypeName
#define l583_IsMulti IsMulti
#define l618_PASCAL PASCAL
#define l261_EXCEL12PROC EXCEL12PROC
#define lq_LPXLOPER12 LPXLOPER12
#define l255_FetchExcel12EntryPt FetchExcel12EntryPt
#define l586_GetModuleHandle GetModuleHandle
#define l680_GetProcAddress GetProcAddress
#define l682__cdecl _cdecl
#define l224_Excel12 Excel12
#define l727_va_list va_list
#define l203_xlretFailed xlretFailed
#define l516_xlretInvCount xlretInvCount
#define l631_va_start va_start
#define l742_va_arg va_arg
#define l752_va_end va_end
#define l627_pascal pascal
#define l379_Excel12v Excel12v
#define l75_XlfAbstractCmdDesc XlfAbstractCmdDesc
#define l103_InvalidFunctionId InvalidFunctionId
#define l116_name_ name_
#define l160_comment_ comment_
#define l12_alias alias
#define l38_comment comment
#define l323_Register Register
#define l93_GetName GetName
#define ly_throw throw
#define l403_GetHelpName GetHelpName
#define l200_ostringstream ostringstream
#define l94_str str
#define l301_DoRegister DoRegister
#define l0_xlretSuccess xlretSuccess
#define l260_Unregister Unregister
#define l297_DoUnregister DoUnregister
#define l312_GenerateMamlDocs GenerateMamlDocs
#define l325_ofstream ofstream
#define l251_DoMamlDocs DoMamlDocs
#define l45_XlfArgDesc XlfArgDesc
#define l274_CheckNameLength CheckNameLength
#define l140_type_ type_
#define l607_SetName SetName
#define l644_SetComment SetComment
#define l142_GetComment GetComment
#define l313_GetType GetType
#define l359_xlfOperType xlfOperType
#define l689_xlfXloperType xlfXloperType
#define l576_wStrType wStrType
#define l465_fpType fpType
#define l82_XlfArgDescList XlfArgDescList
#define l54_XlfCmdDesc XlfCmdDesc
#define l58_menu menu
#define l53_menu_ menu_
#define l108_text_ text_
#define l395_hidden_ hidden_
#define l73_funcId_ funcId_
#define l595_IsAddedToMenuBar IsAddedToMenuBar
#define l493_AddToMenuBar AddToMenuBar
#define l10_Call12 Call12
#define l165_xlfGetBar xlfGetBar
#define l216_IsError IsError
#define l183_menuName menuName
#define l63_menuDesc menuDesc
#define l750_xlfAddMenu xlfAddMenu
#define l121_command command
#define l548_xlfAddCommand xlfAddCommand
#define l552_Check Check
#define l566_xlfCheckCommand xlfCheckCommand
#define l536_RemoveFromMenuBar RemoveFromMenuBar
#define l599_xlfDeleteCommand xlfDeleteCommand
#define l329_firstItemLocation firstItemLocation
#define l687_xlfDeleteMenu xlfDeleteMenu
#define l41_args args
#define l478_const_iterator const_iterator
#define l285_excel12 excel12
#define l191_min min
#define l20_Call12v Call12v
#define l483_xlfRegister xlfRegister
#define l347_IsNumber IsNumber
#define l113_AsDouble AsDouble
#define l490_xlfSetName xlfSetName
#define l185_unreg unreg
#define l402_xlfUnregister xlfUnregister
#define l486_ostream ostream
#define l560_GetFileAttributes GetFileAttributes
#define l740_INVALID_FILE_ATTRIBUTES INVALID_FILE_ATTRIBUTES
#define l541_FILE_ATTRIBUTE_DIRECTORY FILE_ATTRIBUTE_DIRECTORY
#define l280_XlfExcelImpl XlfExcelImpl
#define l283_handle_ handle_
#define l174_HINSTANCE HINSTANCE
#define l98_this_ this_
#define l522_InitLibrary InitLibrary
#define l722_IsEscPressed IsEscPressed
#define l575_xlAbort xlAbort
#define l226_HWND HWND
#define l101_hWnd hWnd
#define l371_short short
#define l454_loWord loWord
#define l502_CALLBACK CALLBACK
#define l317_LPARAM LPARAM
#define l666_LOWORD LOWORD
#define l440_GetClassName GetClassName
#define l656_lstrcmpi lstrcmpi
#define l531_TRUE TRUE
#define l435_GetMainWindow GetMainWindow
#define l354_XLOPER12 XLOPER12
#define l609_xlGetHwnd xlGetHwnd
#define l132_val val
#define l192_w w
#define l573_EnumWindows EnumWindows
#define l556_GetExcelInstance GetExcelInstance
#define l555_GetWindowLongPtr GetWindowLongPtr
#define l557_GWLP_HINSTANCE GWLP_HINSTANCE
#define l39_impl_ impl_
#define l362_get_excel_version get_excel_version
#define l72_xltype xltype
#define l219_xltypeInt xltypeInt
#define l432_xlfGetWorkspace xlfGetWorkspace
#define l598_xlCoerce xlCoerce
#define l300_xltypeStr xltypeStr
#define l553__wtoi _wtoi
#define l637_xlFree xlFree
#define l675_LoadLibrary LoadLibrary
#define l688_excelVersion_ excelVersion_
#define l723_xlfOperType_ xlfOperType_
#define l716_xlfXloperType_ xlfXloperType_
#define l698_wStrType_ wStrType_
#define l601_fpArrayType_ fpArrayType_
#define l60_LPXLFOPER LPXLFOPER
#define l455_isEnglish_ isEnglish_
#define l710_xlGetName xlGetName
#define l111_xllFileName_ xllFileName_
#define l404_LookForHelp LookForHelp
#define l400_m_mainExcelThread m_mainExcelThread
#define l206_helpFileName_ helpFileName_
#define l630_GetXllDirectory GetXllDirectory
#define l458_npos npos
#define l134_assert assert
#define l726_xlCommand xlCommand
#define l658_xlSpecial xlSpecial
#define l189_xlIntl xlIntl
#define l745_xlPrompt xlPrompt
#define l508_xltypeRef xltypeRef
#define l542_mref mref
#define l579_lpmref lpmref
#define l496_xltypeMulti xltypeMulti
#define l564_xltypeBigData xltypeBigData
#define l182_XlfOperImpl XlfOperImpl
#define l639_xlbitFreeAuxMem xlbitFreeAuxMem
#define l231_bFuncWiz bFuncWiz
#define l668_FAR FAR
#define l304_LPEnumStruct LPEnumStruct
#define l424_EnumProc EnumProc
#define l257_LPSTR LPSTR
#define l554_CompareString CompareString
#define l626_MAKELCID MAKELCID
#define l714_MAKELANGID MAKELANGID
#define l597_LANG_ENGLISH LANG_ENGLISH
#define l643_SUBLANG_ENGLISH_US SUBLANG_ENGLISH_US
#define l585_SORT_DEFAULT SORT_DEFAULT
#define l591_NORM_IGNORECASE NORM_IGNORECASE
#define l294_lstrlen lstrlen
#define l539_GetWindowText GetWindowText
#define l452_strstr strstr
#define l582_IsCalledByFuncWiz IsCalledByFuncWiz
#define l701_EnumThreadWindows EnumThreadWindows
#define l697_WNDENUMPROC WNDENUMPROC
#define l52_XlfFuncDesc XlfFuncDesc
#define l683_RecalcPolicy RecalcPolicy
#define l122_helpID helpID
#define l225_helpID_ helpID_
#define l149_returnTypeCode_ returnTypeCode_
#define l625_XlfFuncDescImpl XlfFuncDescImpl
#define l421_SetArguments SetArguments
#define l314_arguments_ arguments_
#define l460_RegisterAs RegisterAs
#define l214_excel14 excel14
#define l161_Asynchronous_ Asynchronous_
#define l729_recalcPolicy_ recalcPolicy_
#define l208_Volatile Volatile
#define l335_Threadsafe_ Threadsafe_
#define l307_ClusterSafe_ ClusterSafe_
#define l268_MacroSheetEquivalent_ MacroSheetEquivalent_
#define l703_category_ category_
#define l489_ThrowOnError ThrowOnError
#define l612_xlretUncalced xlretUncalced
#define l592_xlretAbort xlretAbort
#define l551_xlretStackOvfl xlretStackOvfl
#define l407_xlretInvXloper xlretInvXloper
#define l757_xlretInvXlfn xlretInvXlfn
#define l588_xlRetInvAsynchronousContext xlRetInvAsynchronousContext
#define l550_xlretNotClusterSafe xlretNotClusterSafe
#define l673_MissingOrEmptyError MissingOrEmptyError
#define l529_xltypeMissing xltypeMissing
#define l457_xltypeErr xltypeErr
#define l428_xltypeNil xltypeNil
#define l549_XlTypeToString XlTypeToString
#define l611_xltypeNum xltypeNum
#define l606_xltypeBool xltypeBool
#define l692_xltypeSRef xltypeSRef
#define l561_RW RW
#define l526_COL COL
#define l462_XlfRef XlfRef
#define l661_GetTextA1 GetTextA1
#define l220_rowbegin_ rowbegin_
#define l193_colbegin_ colbegin_
#define l201_colend_ colend_
#define l238_rowend_ rowend_
#define l746_GetTextR1C1 GetTextR1C1
#define l615_Services_t Services_t
#define l263_StatusBar_t StatusBar_t
#define l342_xlcMessage xlcMessage
#define l299_Notes_t Notes_t
#define l758_GetNote GetNote
#define l389_xlfGetNote xlfGetNote
#define l646_SetNote SetNote
#define l370_xlcNote xlcNote
#define l641_ClearNote ClearNote
#define l43_Information_t Information_t
#define l504_GetNow GetNow
#define l744_xlfNow xlfNow
#define l655_GetCallingCell GetCallingCell
#define l713_xlfCaller xlfCaller
#define l482_GetActiveCell GetActiveCell
#define l663_xlfActiveCell xlfActiveCell
#define l691_GetActiveRange GetActiveRange
#define l648_xlfSelection xlfSelection
#define l642_SetActiveCell SetActiveCell
#define l411_xlcSelect xlcSelect
#define l741_GetFormula GetFormula
#define l269_isEnglish isEnglish
#define l498_xlfGetFormula xlfGetFormula
#define l79_AsString AsString
#define l581_ConvertA1FormulaToR1C1 ConvertA1FormulaToR1C1
#define l376_xlfFormulaConvert xlfFormulaConvert
#define l670_ConvertR1C1FormulaToA1 ConvertR1C1FormulaToA1
#define l584_GetCellRefA1 GetCellRefA1
#define l401_xlfTextref xlfTextref
#define l351_GetCellRefR1C1 GetCellRefR1C1
#define l706_xlfAbsref xlfAbsref
#define l720_GetRefTextA1 GetRefTextA1
#define l396_xlfReftext xlfReftext
#define l600_GetRefTextR1C1 GetRefTextR1C1
#define l605_GetSheetName GetSheetName
#define l608_xlSheetNm xlSheetNm
#define l543_IDSHEET IDSHEET
#define l613_GetCurrentSheetId GetCurrentSheetId
#define l730_xlSheetId xlSheetId
#define l650_AsShort AsShort
#define l56_Cell_t Cell_t
#define l693_GetContents GetContents
#define l695_SetContents SetContents
#define l685_xlcFormula xlcFormula
#define l619_GetHeight GetHeight
#define l141_xlfGetCell xlfGetCell
#define l760_SetHeight SetHeight
#define l662_xlcRowHeight xlcRowHeight
#define l624_GetWidth GetWidth
#define l751_SetWidth SetWidth
#define l572_xlcColumnWidth xlcColumnWidth
#define l570_GetFont GetFont
#define l344_Information Information
#define l180_Select Select
#define l568_xlcFontProperties xlcFontProperties
#define l651_SetFont SetFont
#define l702_GetFontSize GetFontSize
#define l647_SetFontSize SetFontSize
#define l734_GetFormat GetFormat
#define l717_IsString IsString
#define l672_SetFormat SetFormat
#define l628_xlcFormatNumber xlcFormatNumber
#define l35_Commands_t Commands_t
#define l546_Alert Alert
#define l679_xlcAlert xlcAlert
#define l694_InputFormula InputFormula
#define l143_xlfInput xlfInput
#define l633_InputNumber InputNumber
#define l621_InputText InputText
#define l654_InputBool InputBool
#define l686_AsBool AsBool
#define l676_InputReference InputReference
#define l558_InputArray InputArray
#define l562_ShowDialogBox ShowDialogBox
#define l665_xlfDialogBox xlfDialogBox
#define l718_InsertWorkSheet InsertWorkSheet
#define l530_xlcWorkbookInsert xlcWorkbookInsert
#define l739_InsertMacroWorkSheet InsertMacroWorkSheet
#define l622_SelectPreviousSheet SelectPreviousSheet
#define l603_xlcWorkbookPrev xlcWorkbookPrev
#define l594_SelectNextSheet SelectNextSheet
#define l578_xlcWorkbookNext xlcWorkbookNext
#define l737_SetScreenUpdates SetScreenUpdates
#define l678_xlcEcho xlcEcho
#define l383_SetOnTime SetOnTime
#define l577_xlcOnTime xlcOnTime
#define l590_SetOnTimer SetOnTimer
#define l728_xlcOnRecalc xlcOnRecalc
#define l215_DisableCalculation DisableCalculation
#define l240_calulationState_ calulationState_
#define l684_xlfGetDocument xlfGetDocument
#define l705_AsInt AsInt
#define l413_xlcOptionsCalculation xlcOptionsCalculation
#define l223_XLFunctionRegistrationData XLFunctionRegistrationData
#define l357_Arg Arg
#define l145_excel_name excel_name
#define l525_descr descr
#define l175_nargs nargs
#define l381_volat volat
#define l348_threadsafe threadsafe
#define l420_ret_type_code ret_type_code
#define l520_asynch asynch
#define l523_macro_sheet_equiv macro_sheet_equiv
#define l380_claster_safe claster_safe
#define l487_XLFunctionRegistrationHelper XLFunctionRegistrationHelper
#define l474_AddFunction AddFunction
#define l488_XLCommandRegistrationHelper XLCommandRegistrationHelper
#define l747_to_xl_str to_xl_str
#define l681_wcslen wcslen
#define l620_wcscpy_s wcscpy_s
#define l107_Functions Functions
#define l709_NotVolatile NotVolatile
#define l614_menu_text menu_text
#define l519_GenerateChmBuilderConfig GenerateChmBuilderConfig
#define l427_GenerateToc GenerateToc
#define l384_GenerateDocumentation GenerateDocumentation
#define l660_xlwGenDoc xlwGenDoc
lz_xlw::l164_HiResTimer::l164_HiResTimer(){
l341_QueryPerformanceCounter(&l105_start);}lz_xlw::l164_HiResTimer::~
l164_HiResTimer(){}l18_double lz_xlw::l164_HiResTimer::l700_elapsed()la_const
{l399_LARGE_INTEGER l259_stop;l341_QueryPerformanceCounter(&l259_stop
);l399_LARGE_INTEGER l334_frequency;l638_QueryPerformanceFrequency(&
l334_frequency);le_return l18_double(l259_stop.l271_QuadPart-
l105_start.l271_QuadPart)/l18_double(l334_frequency.l271_QuadPart);}
l5_using lr_namespace lz_xlw;l62_NCMatrix::l62_NCMatrix(la_const
l62_NCMatrix&l148_original):l6_data(l148_original.l6_data.l640_copy()){
}l62_NCMatrix::l62_NCMatrix(l24_size_t l445_Rows_,l24_size_t
l464_Columns_):l6_data(l88_new l755_NCMatrixData(l445_Rows_,
l464_Columns_)){}l62_NCMatrix&l62_NCMatrix::l361_resize(l24_size_t
l147_rows,l24_size_t l515_columns){l62_NCMatrix l110_temp(l147_rows,
l515_columns);l433_swap(l110_temp);le_return*l154_this;}l62_NCMatrix&
l62_NCMatrix::l167_operator=(la_const l62_NCMatrix&l148_original){
lb_if(l154_this!=&l148_original){l62_NCMatrix l110_temp(l148_original
);l433_swap(l110_temp);}le_return*l154_this;}l5_using lr_namespace
lz_xlw;l5_using lr_namespace l16_std;lo_char*l129_PascalStrConv::
l732_WPascalStr2Str(la_const l17_wchar_t*l55_pascalString){l24_size_t
lv_n=l55_pascalString[0];lo_char*lj_result=lw_TempMemory::
l241_GetMemory<lo_char>(lv_n+1);lj_result[lv_n]=0;lb_if(lv_n>0){
l547_WideCharToMultiByte(l499_CP_ACP,0x00000400,l55_pascalString+1,(
lf_int)lv_n,lj_result,(lf_int)lv_n,l59_NULL,l59_NULL);}le_return
lj_result;}l279_wstring l129_PascalStrConv::l704_WPascalStr2WStr(
la_const l17_wchar_t*l55_pascalString){l24_size_t lv_n=
l55_pascalString[0];l279_wstring lj_result(l55_pascalString+1,
l55_pascalString+1+lv_n);le_return lj_result;}l17_wchar_t*
l129_PascalStrConv::l707_Str2WPascalStr(la_const lc_string&
l124_cString){l24_size_t lv_n(l124_cString.l138_length());lb_if(lv_n>
32767){lx_cerr<<l14_XLW__HERE__<<"\x53\x74\x72\x69\x6e\x67\x20\x74"
"\x72\x75\x6e\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36\x37"
"\x20\x62\x79\x74\x65\x73"<<lg_endl;lv_n=32767;}l17_wchar_t*lj_result
=lw_TempMemory::l241_GetMemory<l17_wchar_t>(lv_n+2);
l593_MultiByteToWideChar(l499_CP_ACP,0,l124_cString.l15_c_str(),(
lf_int)lv_n,lj_result+1,(lf_int)lv_n);lj_result[lv_n+1]=0;lj_result[0
]=l85_static_cast<l150_XCHAR>(lv_n);le_return lj_result;}l17_wchar_t*
l129_PascalStrConv::l657_WStr2WPascalStr(la_const l279_wstring&
l124_cString){l24_size_t lv_n(l124_cString.l138_length());lb_if(lv_n>
32766){lx_cerr<<l14_XLW__HERE__<<"\x53\x74\x72\x69\x6e\x67\x20\x74"
"\x72\x75\x6e\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36\x36"
"\x20\x62\x79\x74\x65\x73"<<lg_endl;lv_n=32766;}l17_wchar_t*lj_result
=lw_TempMemory::l241_GetMemory<l17_wchar_t>(lv_n+2);l649_wcsncpy_s(
lj_result+1,lv_n+1,l124_cString.l15_c_str(),lv_n);lj_result[lv_n+1]=
'\0';lj_result[0]=l85_static_cast<l17_wchar_t>(lv_n);le_return
lj_result;}l17_wchar_t*l129_PascalStrConv::l756_WPascalStrCopy(
la_const l17_wchar_t*l55_pascalString){l24_size_t lv_n=
l85_static_cast<l17_wchar_t>(l55_pascalString[0]);l17_wchar_t*
lj_result=lw_TempMemory::l241_GetMemory<l17_wchar_t>(lv_n+2);
l408_memcpy(lj_result,l55_pascalString,(lv_n+1) *l156_sizeof(
l17_wchar_t));lj_result[lv_n+1]=0;le_return lj_result;}l17_wchar_t*
l129_PascalStrConv::l753_WPascalStrNewCopy(la_const l17_wchar_t*
l55_pascalString){l24_size_t lv_n=l85_static_cast<l17_wchar_t>(
l55_pascalString[0]);l17_wchar_t*lj_result=lw_TempMemory::
l669_GetMemoryUsingNew<l17_wchar_t>(lv_n+2);l408_memcpy(lj_result,
l55_pascalString,(lv_n+1) *l156_sizeof(l17_wchar_t));lj_result[lv_n+1
]=0;le_return lj_result;}lc_string l393_StringUtilities::
l485_getEnvVar(la_const lc_string&l190_variableName){la_const
l99_DWORD l169_bufferSize=4096;l137_vector<lo_char>lj_result(
l169_bufferSize);l99_DWORD l84_dwRet=l444_GetEnvironmentVariable(
l190_variableName.l15_c_str(),&lj_result[0],l169_bufferSize);lb_if(
l169_bufferSize<l84_dwRet){lj_result.l361_resize(l84_dwRet);l84_dwRet
=l444_GetEnvironmentVariable(l190_variableName.l15_c_str(),&lj_result
[0],l84_dwRet);}lb_if(!l84_dwRet){lx_cerr<<l14_XLW__HERE__<<"\x20\x43"
"\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x62\x74\x61\x69\x6e\x20"<<
l190_variableName<<"\x20\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74"
"\x20\x76\x61\x72\x69\x61\x62\x6c\x65\x20"<<lg_endl;le_return"";}
le_return&lj_result[0];}l5_using lr_namespace l16_std;lr_namespace
lz_xlw{l222_class l91_Win32StreamBuf:l171_public l431_streambuf{
l171_public:l91_Win32StreamBuf(){}~l91_Win32StreamBuf(){}
l653_protected:l506_int_type l617_overflow(l506_int_type l187_ch){
lb_if(!l229_traits_type::l645_eq_int_type(l229_traits_type::l602_eof(
),l187_ch)){l309_buf_.l664_append(1,l229_traits_type::
l724_to_char_type(l187_ch));}ln_else{le_return l533_sync();}le_return
l229_traits_type::l674_not_eof(l187_ch);}lf_int l533_sync(){
l397_SendToDebugWindow();l309_buf_.l527_erase();le_return 0;}
l510_private:lk_void l397_SendToDebugWindow(){}lc_string l309_buf_;
l91_Win32StreamBuf(la_const l91_Win32StreamBuf&);l91_Win32StreamBuf&
l167_operator=(la_const l91_Win32StreamBuf&);};l222_class
l243_CerrBufferRedirector{l171_public:l243_CerrBufferRedirector(){
l286_m_oldStreamBuf=lx_cerr.l477_rdbuf(&l364_m_debuggerStreamBuf);
lx_cerr<<l14_XLW__HERE__<<"\x53\x74\x72\x65\x61\x6d\x20\x72\x65\x64"
"\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x4d\x53\x56\x43\x20\x64"
"\x65\x62\x75\x67\x67\x65\x72"<<lg_endl;}~l243_CerrBufferRedirector(){
lx_cerr.l477_rdbuf(l286_m_oldStreamBuf);}l510_private:l431_streambuf*
l286_m_oldStreamBuf;l91_Win32StreamBuf l364_m_debuggerStreamBuf;};}
l104_static lz_xlw::l243_CerrBufferRedirector l759_redirectCerr;
lr_namespace lz_xlw{l222_class l218_PathUpdater{l171_public:
l218_PathUpdater(){l532_MEMORY_BASIC_INFORMATION l277_theInfo;
l290_HMODULE l272_theHandle=l59_NULL;lo_char l233_theDLLPathChar[
l470_MAX_PATH+1]="";l99_DWORD l84_dwRet=0;lc_string
l326_originalPathValue(l393_StringUtilities::l485_getEnvVar("\x50\x41"
"\x54\x48"));ls_bool l153_ok(!l326_originalPathValue.l47_empty());
l84_dwRet=l85_static_cast<l99_DWORD>(l574_VirtualQuery(((l736_LPCVOID
)l154_this),&l277_theInfo,(l85_static_cast<l99_DWORD>(l156_sizeof(
l532_MEMORY_BASIC_INFORMATION)))));lb_if(l84_dwRet){l272_theHandle=((
l290_HMODULE)(l277_theInfo.l616_AllocationBase));
l690_GetModuleFileName(l272_theHandle,l233_theDLLPathChar,
l470_MAX_PATH);lz_xlw::l68_XlfServices.l296_StatusBar=
l233_theDLLPathChar;}ln_else{l153_ok=l34_false;lx_cerr<<
l14_XLW__HERE__<<"\x20\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x61"
"\x74\x74\x61\x69\x6e\x20\x70\x61\x74\x68\x20\x6f\x66\x20\x44\x4c\x4c"
<<lg_endl;}lb_if(l153_ok){lc_string l327_theDLLPath(
l233_theDLLPathChar);lc_string l336_newPathValue(
l326_originalPathValue);lc_string::l731_size_type l352_pos=
l327_theDLLPath.l293_find_last_of("\\");l336_newPathValue+="\x3b"+
l327_theDLLPath.l237_substr(0,l352_pos);lb_if(!
l715_SetEnvironmentVariable("\x50\x61\x74\x68",l336_newPathValue.
l15_c_str())){lx_cerr<<l14_XLW__HERE__<<"\x20\x53\x65\x74\x45\x6e\x76"
"\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x56\x61\x72\x69\x61\x62\x6c\x65\x20"
"\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x65\x74\x20\x50\x41\x54"
"\x48"<<lg_endl;l153_ok=l34_false;}ln_else{lx_cerr<<l14_XLW__HERE__<<""
"\x20\x50\x41\x54\x48\x20\x73\x65\x74\x20\x73\x75\x63\x63\x65\x73\x73"
"\x66\x75\x6c\x6c\x79\x20"<<lg_endl;}}lb_if(!l153_ok){lx_cerr<<
l14_XLW__HERE__<<"\x20\x57\x61\x72\x6e\x69\x6e\x67\x3a\x20\x55\x6e"
"\x61\x62\x6c\x65\x20\x74\x6f\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x73"
"\x65\x20\x50\x41\x54\x48\x20\x74\x6f\x20\x64\x69\x72\x65\x63\x74\x6f"
"\x72\x79\x20\x6f\x66\x20\x6c\x69\x62\x72\x61\x72\x79\x20"<<lg_endl;}
}~l218_PathUpdater(){}};}l5_using lr_namespace lz_xlw;l316_extern""
"\x43"{lf_int l144_EXCEL_EXPORT l719_xl_on_recalc_macro(){
l155_MacroCache<l461_Recalc>::ll_Instance().l228_ExecuteMacros();
le_return 1;}}l316_extern"\x43"{l275_long l144_EXCEL_EXPORT
l629_xlAutoOpen(){l306_try{li_XlfExcel::ll_Instance();lw_TempMemory::
l346_InitializeProcess();l104_static l218_PathUpdater l580_updatePath
;l68_XlfServices.l296_StatusBar="\x52\x65\x67\x69\x73\x74\x65\x72\x69"
"\x6e\x67\x20\x6c\x69\x62\x72\x61\x72\x79\x2e\x2e\x2e";l23_auto&
l303_reg=l172_XLRegistration::l66_ExcelFunctionRegistrationRegistry::
ll_Instance();l23_auto l284_has_recalc=l155_MacroCache<l461_Recalc>::
ll_Instance().l540_HasMacros();lb_if(l284_has_recalc){
l172_XLRegistration::l331_XLCommandRegistrationData l126_tmp("\x78"
"\x6c\x5f\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63\x5f\x6d\x61\x63\x72\x6f"
,"\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63\x5f\x6d\x61\x63\x72\x6f","\x6f"
"\x6e\x20\x72\x65\x63\x61\x6c\x63\x20\x6d\x61\x63\x72\x6f\x20","",""
"\x6f\x6e\x20\x72\x65\x63\x61\x6c\x63\x20\x6d\x61\x63\x72\x6f\x20");
l303_reg.l287_AddCommand(l126_tmp);}l303_reg.l360_DoTheRegistrations(
);l68_XlfServices.l296_StatusBar.l305_clear();l155_MacroCache<
l545_Open>::ll_Instance().l228_ExecuteMacros();lb_if(l284_has_recalc)l68_XlfServices
.l61_Commands.l385_SetOnRecalc("\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63"
"\x5f\x6d\x61\x63\x72\x6f");le_return 1;}l295_catch(...){le_return 0;
}}l104_static ls_bool l258_autoRemoveCalled=l34_false;l275_long
l144_EXCEL_EXPORT l610_xlAutoClose(){l306_try{lx_cerr<<
l14_XLW__HERE__<<"\x52\x65\x6c\x65\x61\x73\x69\x6e\x67\x20\x72\x65"
"\x73\x6f\x75\x72\x63\x65\x73"<<lg_endl;l155_MacroCache<l721_Close>::
ll_Instance().l228_ExecuteMacros();lb_if(l258_autoRemoveCalled){
l172_XLRegistration::l66_ExcelFunctionRegistrationRegistry::
ll_Instance().l439_DoTheDeregistrations();}ln_else{}li_XlfExcel::
l472_DeleteInstance();lw_TempMemory::l350_TerminateProcess();}
l295_catch(...){lx_cerr<<l14_XLW__HERE__<<"\x53\x6f\x6d\x65\x74\x68"
"\x69\x6e\x67\x20\x62\x61\x64\x20\x68\x61\x70\x70\x65\x6e\x65\x64\x20"
"\x69\x6e\x20\x78\x6c\x41\x75\x74\x6f\x43\x6c\x6f\x73\x65"<<lg_endl;}
le_return 1;}l275_long l144_EXCEL_EXPORT l537_xlAutoRemove(){l306_try
{lx_cerr<<l14_XLW__HERE__<<"\x41\x64\x64\x69\x6e\x20\x62\x65\x69\x6e"
"\x67\x20\x75\x6e\x6c\x6f\x61\x64\x65\x64"<<lg_endl;l155_MacroCache<
l571_Remove>::ll_Instance().l228_ExecuteMacros();
l258_autoRemoveCalled=l69_true;}l295_catch(...){lx_cerr<<
l14_XLW__HERE__<<"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x62\x61"
"\x64\x20\x68\x61\x70\x70\x65\x6e\x65\x64\x20\x69\x6e\x20\x78\x6c\x41"
"\x75\x74\x6f\x52\x65\x6d\x6f\x76\x65"<<lg_endl;}le_return 1;}}
l5_using lr_namespace l16_std;l5_using lr_namespace lz_xlw;
l242_typedef l270_shared_ptr<lw_TempMemory>l210_TempMemoryPtr;
lr_namespace{l632_ThreadLocalStorage<lw_TempMemory>l125_tls;
l708_CriticalSection l337_threadInfoVector;l137_vector<
l210_TempMemoryPtr>l102_tempMemoryInstances;}lr_namespace{ls_bool
l438_threadIsDead(la_const l210_TempMemoryPtr&l484_tempMemory){
le_return l484_tempMemory->l388_isThreadDead();}}lr_namespace lz_xlw{
l587_template<l222_class l406_T>l130_struct l416_CustomArrayDeleter{
lk_void l167_operator()(l406_T*l479_ptr)la_const{l322_delete[]
l479_ptr;}};lo_char*lw_TempMemory::l733_GetBytes(l24_size_t l87_bytes
){lw_TempMemory*l40_threadStorage=l125_tls.l176_GetValue();lb_if(!
l40_threadStorage)l40_threadStorage=l264_CreateTempMemory();le_return
l40_threadStorage->l501_InternalGetMemory(l87_bytes);}lk_void
lw_TempMemory::l699_EnterExportedFunction(){lw_TempMemory*
l40_threadStorage=l125_tls.l176_GetValue();lb_if(!l40_threadStorage)l40_threadStorage
=l264_CreateTempMemory();l40_threadStorage->
l374_InternalEnterExportedFunction();}lk_void lw_TempMemory::
l544_LeaveExportedFunction(){lw_TempMemory*l40_threadStorage=l125_tls
.l176_GetValue();lb_if(l40_threadStorage)l40_threadStorage->
l469_InternalLeaveExportedFunction();}lw_TempMemory::lw_TempMemory():
l92_offset_(0),l382_threadId_(l443_GetCurrentThreadId()),l177_depth_(
0){}lw_TempMemory::~lw_TempMemory(){l247_InternalFreeMemory(l69_true);
}lk_void lw_TempMemory::l247_InternalFreeMemory(ls_bool l418_finished
){l24_size_t l332_nbBuffersToKeep=1;lb_if(l418_finished)l332_nbBuffersToKeep
=0;l199_while(l112_freeList_.l51_size()>l332_nbBuffersToKeep)l112_freeList_
.l254_pop_back();l92_offset_=0;}lk_void lw_TempMemory::
l374_InternalEnterExportedFunction(){lb_if(l177_depth_==0)l247_InternalFreeMemory
(l34_false);++l177_depth_;}lk_void lw_TempMemory::
l469_InternalLeaveExportedFunction(){--l177_depth_;}lw_TempMemory*
lw_TempMemory::l264_CreateTempMemory(){l446_ProtectInScope
l511_protecting(l337_threadInfoVector);lw_TempMemory*
l40_threadStorage=l125_tls.l176_GetValue();lb_if(!l40_threadStorage){
l102_tempMemoryInstances.l527_erase(l743_remove_if(
l102_tempMemoryInstances.l146_begin(),l102_tempMemoryInstances.
l81_end(),l438_threadIsDead),l102_tempMemoryInstances.l81_end());
l210_TempMemoryPtr l319_smartThreadStorage(l88_new lw_TempMemory);
l40_threadStorage=l319_smartThreadStorage.l168_get();l125_tls.
l696_SetValue(l40_threadStorage);l102_tempMemoryInstances.
l289_push_back(l319_smartThreadStorage);}le_return l40_threadStorage;
}lk_void lw_TempMemory::l276_PushNewBuffer(l24_size_t l51_size){
l512_XlfBuffer l188_newBuffer;l188_newBuffer.l51_size=l51_size;
l188_newBuffer.l105_start=l567_shared_char_ptr(l88_new lo_char[
l51_size],l416_CustomArrayDeleter<lo_char>());;l112_freeList_.
l563_push_front(l188_newBuffer);l92_offset_=0;lx_cerr<<"\x78\x6c\x77"
"\x20\x69\x73\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6e\x67\x20\x61\x20"
"\x6e\x65\x77\x20\x62\x75\x66\x66\x65\x72\x20\x6f\x66\x20"<<
l85_static_cast<l281_unsigned lf_int>(l51_size)<<"\x20\x62\x79\x74"
"\x65\x73"<<lg_endl;le_return;}lo_char*lw_TempMemory::
l501_InternalGetMemory(l24_size_t l87_bytes){lb_if(l112_freeList_.
l47_empty())l276_PushNewBuffer(8192);l512_XlfBuffer&l106_buffer=
l112_freeList_.l308_front();lb_if(l92_offset_+l87_bytes>l106_buffer.
l51_size){l276_PushNewBuffer(l748_max((l106_buffer.l51_size*3)/2,(
l92_offset_+l87_bytes)+4096));l343_memset(l112_freeList_.l308_front().
l105_start.l168_get(),0,l87_bytes);l92_offset_=l87_bytes;le_return
l112_freeList_.l308_front().l105_start.l168_get();}ln_else{l24_size_t
l110_temp=l92_offset_;l343_memset(l106_buffer.l105_start.l168_get()+
l110_temp,0,l87_bytes);l92_offset_+=l87_bytes;le_return l106_buffer.
l105_start.l168_get()+l110_temp;}}lk_void lw_TempMemory::
l346_InitializeProcess(){}lk_void lw_TempMemory::
l350_TerminateProcess(){l446_ProtectInScope l511_protecting(
l337_threadInfoVector);l19_for(l24_size_t l21_i(0);l21_i<
l102_tempMemoryInstances.l51_size();++l21_i){l102_tempMemoryInstances
[l21_i]->l247_InternalFreeMemory(l69_true);}}ls_bool lw_TempMemory::
l388_isThreadDead()la_const{l569_HANDLE l209_threadHandle(
l538_OpenThread(l596_THREAD_QUERY_INFORMATION,l372_FALSE,
l382_threadId_));lb_if(l209_threadHandle){l99_DWORD l265_exitCode(0);
l480_BOOL lj_result=l671_GetExitCodeThread(l209_threadHandle,&
l265_exitCode);l712_CloseHandle(l209_threadHandle);lb_if(lj_result!=0
){lb_if(l265_exitCode==l738_STILL_ACTIVE)le_return l34_false;ln_else
le_return l69_true;}ln_else le_return l34_false;}ln_else le_return
l34_false;}}l5_using lr_namespace l16_std;l5_using lr_namespace lz_xlw
;l104_static l333_map<lc_string,lc_string>l170_g_fmt_map;l104_static
l16_std::l333_map<l16_std::lc_string,l16_std::lc_string>&l330_fmt_map
(){lb_if(l170_g_fmt_map.l47_empty()){l170_g_fmt_map={{"\x64\x61\x74"
"\x65","\x79\x79\x79\x79\x2d\x6d\x6d\x2d\x64\x64"},{"\x74\x69\x6d\x65"
,"\x68\x68\x3a\x6d\x6d\x3a\x73\x73"},{"\x64\x61\x74\x65\x74\x69\x6d"
"\x65","\x79\x79\x79\x79\x2d\x6d\x6d\x2d\x64\x64\x20\x68\x68\x3a\x6d"
"\x6d\x3a\x73\x73"},{"\x24","\x24\x23\x2c\x23\x23\x30\x2e\x30\x30"},{""
"\x24\x33","\x24\x23\x2c\x23\x23\x30\x2e\x30\x30\x30"},{"\x24\x34",""
"\x24\x23\x2c\x23\x23\x30\x2e\x30\x30\x30\x30"},{"\x25","\x30\x25"},{""
"\x25\x31","\x30\x2e\x30\x25"},{"\x25\x32","\x30\x2e\x30\x30\x25"},{""
"\x67\x65\x6e\x65\x72\x61\x6c","\x47\x65\x6e\x65\x72\x61\x6c"},{"\x6e"
"\x6f\x6e\x65","\x47\x65\x6e\x65\x72\x61\x6c"},{"\x73\x74\x72","\x47"
"\x65\x6e\x65\x72\x61\x6c"},{"\x69\x6e\x74","\x47\x65\x6e\x65\x72\x61"
"\x6c"},{"\x6e\x75\x6d","\x47\x65\x6e\x65\x72\x61\x6c"}};};le_return
l170_g_fmt_map;}l137_vector<l377_num_fmt>lz_xlw::l559_get_fmts(
la_const ld_XlfOper&l36_c,la_const lc_string&l315_sheet_name,lf_int
l211_row0,lf_int l205_col0,la_const l333_map<lf_int,lc_string>&
l324_fmts,ls_bool l419_is_df){lb_if(l211_row0<=0||l205_col0<=0)le_return
{};l137_vector<l377_num_fmt>l1_res;l1_res.l358_reserve(l324_fmts.
l51_size());l19_for(l23_auto&[l186_icol,l151_fmt]:l324_fmts){lb_if(
l186_icol>=l36_c.l288_cols())le_return{};lb_if(l151_fmt.l47_empty())l363_continue
;l23_auto l11_it=l330_fmt_map().l725_find(l151_fmt);lb_if(l11_it==
l330_fmt_map().l81_end())l363_continue;l23_auto l356_fm=l11_it->
l589_second;lc_string lp_ref=l315_sheet_name.l47_empty()?"\x52":
l315_sheet_name+"\x21\x52";lp_ref+=l42_to_string(l211_row0+(
l419_is_df?1:0));lp_ref+="\x43";lp_ref+=l42_to_string(l205_col0+
l186_icol);lp_ref+="\x3a\x52";lp_ref+=l42_to_string(l211_row0+l36_c.
l147_rows()-1);lp_ref+="\x43";lp_ref+=l42_to_string(l205_col0+
l186_icol);l1_res.l289_push_back({lp_ref,l356_fm});}le_return l1_res;
}l104_static l67_inline ls_bool l450_file_exist(la_const lo_char*
l22_name){l130_struct l459_stat l106_buffer;le_return(l459_stat(
l22_name,&l106_buffer)==0);}l104_static l67_inline lk_void
l292_log_xlf_val(l166_FILE*l9_flog,la_const lz_xlw::ld_XlfOper&l30_x){
lb_if(l30_x.l227_is<l18_double>())l46_fprintf(l9_flog,"\x25\x67",
l30_x.l89_as<l18_double>());ln_else lb_if(l30_x.l227_is<lf_int>())l46_fprintf
(l9_flog,"\x25\x64",l30_x.l89_as<lf_int>());ln_else lb_if(l30_x.
l227_is<ls_bool>())l46_fprintf(l9_flog,l30_x.l89_as<ls_bool>()?"\x54"
"\x52\x55\x45":"\x46\x41\x4c\x53\x45");ln_else lb_if(l30_x.l227_is<
l16_std::lc_string>())l46_fprintf(l9_flog,"\x25\x73",l30_x.l89_as<
l16_std::lc_string>().l15_c_str());ln_else l46_fprintf(l9_flog,"\x4e"
"\x41");}lr_namespace lz_xlw{l166_FILE*l634_flog_init(la_const lo_char
 *l217_fpath,la_const lo_char*l245_lib,la_const lo_char*
l463_func_name,la_const lo_char*l133_version){lb_if(!l450_file_exist(
l217_fpath))le_return l246_nullptr;l16_std::l636_time_t l163_now=
l16_std::l735_time(0);l16_std::l448_tm*l159_ltmp=l246_nullptr;
#ifdef _MSC_VER
l166_FILE*l9_flog=l246_nullptr;l659_fopen_s(&l9_flog,l217_fpath,"\x61"
"\x2b");l16_std::l448_tm l320_ltm;l749_localtime_s(&l320_ltm,&
l163_now);l159_ltmp=&l320_ltm;
#else
l166_FILE*l9_flog=l652_fopen(l217_fpath,"\x61\x2b");l159_ltmp=
l565_localtime(&l163_now);
#endif
lb_if(!l9_flog)le_return l246_nullptr;lo_char l173_datebuf[128],
l184_timebuf[128];l528_strftime(l173_datebuf,l156_sizeof(l173_datebuf
),"\x25\x59\x2d\x25\x6d\x2d\x25\x64",l159_ltmp);l528_strftime(
l184_timebuf,l156_sizeof(l184_timebuf),"\x25\x48\x3a\x25\x4d\x3a\x25"
"\x53",l159_ltmp);l16_std::lc_string l1_res="\n\x2d\x2d\x2d";l1_res+=
l463_func_name;l1_res+="\x3d";l1_res+=l173_datebuf;l1_res+="\x3d";
l1_res+=l184_timebuf;l1_res+="\x3d";l1_res+=l245_lib;l1_res+="\x3a";
l1_res+=l133_version;l1_res+="\n";l46_fprintf(l9_flog,l1_res.
l15_c_str());le_return l9_flog;}lk_void l623_log_xlf(l166_FILE*
l9_flog,la_const lz_xlw::ld_XlfOper&l30_x,la_const lo_char*l22_name){
lb_if(!l9_flog)le_return;l46_fprintf(l9_flog,"\x25\x73\x3c\x25\x73"
"\x3e\x20\x3d\x20",l22_name,l30_x.l635_xltypeName().l15_c_str());
lb_if(!l30_x.l583_IsMulti()){l292_log_xlf_val(l9_flog,l30_x);
l46_fprintf(l9_flog,"\n");le_return;}l46_fprintf(l9_flog,"\x28\x25"
"\x64\x2c\x25\x64\x29",l30_x.l147_rows(),l30_x.l288_cols());
l46_fprintf(l9_flog,"\x7b");la_const lo_char*l248_blank="";la_const
lo_char*l491_comma="\x2c";la_const lo_char*l368_comma_ret="\x2c\n";
la_const lo_char*l262_rowsep=l248_blank;l19_for(lf_int l21_i=0;l21_i<
l30_x.l147_rows();++l21_i){l46_fprintf(l9_flog,l262_rowsep);la_const
lo_char*l273_sep=l248_blank;l46_fprintf(l9_flog,"\x7b");l19_for(
lf_int l204_j=0;l204_j<l30_x.l288_cols();++l204_j){l46_fprintf(
l9_flog,l273_sep);l292_log_xlf_val(l9_flog,l30_x(l21_i,l204_j));
l273_sep=l491_comma;}l46_fprintf(l9_flog,"\x7d");l262_rowsep=
l368_comma_ret;}l46_fprintf(l9_flog,"\x7d\n");}}l242_typedef lf_int(
l618_PASCAL*l261_EXCEL12PROC)(lf_int lt_xlfn,lf_int l754_coper,
la_const lq_LPXLOPER12*l677_rgpxloper12,lq_LPXLOPER12 l711_xloper12Res
);l290_HMODULE l212_hmodule;l261_EXCEL12PROC l114_pexcel12;lk_void
l255_FetchExcel12EntryPt(lk_void){lb_if(l114_pexcel12==l59_NULL){
l212_hmodule=l586_GetModuleHandle(l59_NULL);lb_if(l212_hmodule!=
l59_NULL){l114_pexcel12=(l261_EXCEL12PROC)l680_GetProcAddress(
l212_hmodule,"\x4d\x64\x43\x61\x6c\x6c\x42\x61\x63\x6b\x31\x32");}}}
lf_int l682__cdecl l224_Excel12(lf_int lt_xlfn,lq_LPXLOPER12
l221_operRes,lf_int l8_count,...){lq_LPXLOPER12 l256_rgxloper12[255];
l727_va_list l194_ap;lf_int l158_ioper;lf_int l83_mdRet;
l255_FetchExcel12EntryPt();lb_if(l114_pexcel12==l59_NULL)l83_mdRet=
l203_xlretFailed;ln_else{l83_mdRet=l516_xlretInvCount;lb_if((l8_count
>=0)&&(l8_count<=255)){l631_va_start(l194_ap,l8_count);l19_for(
l158_ioper=0;l158_ioper<l8_count;l158_ioper++){l256_rgxloper12[
l158_ioper]=l742_va_arg(l194_ap,lq_LPXLOPER12);}l752_va_end(l194_ap);
l83_mdRet=(l114_pexcel12)(lt_xlfn,l8_count,&l256_rgxloper12[0],
l221_operRes);}}le_return(l83_mdRet);}lf_int l627_pascal l379_Excel12v
(lf_int lt_xlfn,lq_LPXLOPER12 l221_operRes,lf_int l8_count,la_const
lq_LPXLOPER12 l410_opers[]){lf_int l83_mdRet;l255_FetchExcel12EntryPt
();lb_if(l114_pexcel12==l59_NULL){l83_mdRet=l203_xlretFailed;}ln_else
{l83_mdRet=(l114_pexcel12)(lt_xlfn,l8_count,&l410_opers[0],
l221_operRes);}le_return(l83_mdRet);}l5_using lr_namespace lz_xlw;
l5_using lr_namespace l16_std;la_const l18_double
l75_XlfAbstractCmdDesc::l103_InvalidFunctionId=-1.0;
l75_XlfAbstractCmdDesc::l75_XlfAbstractCmdDesc(la_const lc_string&
l116_name_,la_const lc_string&l391_alias_,la_const lc_string&
l160_comment_):l22_name(l116_name_),l12_alias(l391_alias_),
l38_comment(l160_comment_){}l75_XlfAbstractCmdDesc::~
l75_XlfAbstractCmdDesc(){}lk_void l75_XlfAbstractCmdDesc::
l323_Register(lf_int l425_functionId)la_const{lc_string l50_dllName=
li_XlfExcel::ll_Instance().l93_GetName();lb_if(l50_dllName.l47_empty(
))ly_throw("\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20"
"\x6c\x69\x62\x72\x61\x72\x79\x20\x6e\x61\x6d\x65");lc_string
l328_helpName=li_XlfExcel::ll_Instance().l403_GetHelpName();lc_string
l97_suggestedHelpId;lb_if(!l328_helpName.l47_empty()){
l200_ostringstream l131_oss;l131_oss<<l328_helpName<<"\x21"<<
l425_functionId;l97_suggestedHelpId=l131_oss.l94_str();}lf_int lh_err
=l301_DoRegister(l50_dllName,l97_suggestedHelpId);lb_if(lh_err!=
l0_xlretSuccess){lx_cerr<<l14_XLW__HERE__<<"\x45\x72\x72\x6f\x72\x20"
<<lh_err<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67\x69\x73\x74\x65"
"\x72\x69\x6e\x67\x20"<<l12_alias.l15_c_str()<<lg_endl;}le_return;}
lk_void l75_XlfAbstractCmdDesc::l260_Unregister()la_const{lc_string
l50_dllName=li_XlfExcel::ll_Instance().l93_GetName();lb_if(
l50_dllName.l47_empty())ly_throw("\x43\x6f\x75\x6c\x64\x20\x6e\x6f"
"\x74\x20\x67\x65\x74\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x6e\x61\x6d"
"\x65");lf_int lh_err=l297_DoUnregister(l50_dllName);lb_if(lh_err!=
l0_xlretSuccess)lx_cerr<<l14_XLW__HERE__<<"\x45\x72\x72\x6f\x72\x20"
<<lh_err<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67\x69\x73\x74\x65"
"\x72\x69\x6e\x67\x20"<<l12_alias.l15_c_str()<<lg_endl;le_return;}
lk_void l75_XlfAbstractCmdDesc::l312_GenerateMamlDocs(la_const
lc_string l86_outputDir,lf_int l667_itemId)la_const{
l200_ostringstream l131_oss;l131_oss<<l86_outputDir<<"\\"<<l12_alias
<<"\x2e\x6d\x61\x6d\x6c";l325_ofstream lm_outFile(l131_oss.l94_str().
l15_c_str());lm_outFile<<"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73"
"\x69\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67"
"\x3d\"\x75\x74\x66\x2d\x38\"\x3f\x3e"<<lg_endl;lm_outFile<<"\x3c\x74"
"\x6f\x70\x69\x63\x20\x69\x64\x3d\""<<l12_alias<<"\"\x20\x72\x65\x76"
"\x69\x73\x69\x6f\x6e\x4e\x75\x6d\x62\x65\x72\x3d\"\x39\"\x3e"<<
lg_endl;lm_outFile<<"\x3c\x64\x65\x76\x65\x6c\x6f\x70\x65\x72\x52\x65"
"\x66\x65\x72\x65\x6e\x63\x65\x57\x69\x74\x68\x53\x79\x6e\x74\x61\x78"
"\x44\x6f\x63\x75\x6d\x65\x6e\x74\x20" "\x78\x6d\x6c\x6e\x73\x3d\""
"\x68\x74\x74\x70\x3a\x2f\x2f\x64\x64\x75\x65\x2e\x73\x63\x68\x65\x6d"
"\x61\x73\x2e\x6d\x69\x63\x72\x6f\x73\x6f\x66\x74\x2e\x63\x6f\x6d\x2f"
"\x61\x75\x74\x68\x6f\x72\x69\x6e\x67\x2f\x32\x30\x30\x33\x2f\x35\""
"\x20" "\x78\x6d\x6c\x6e\x73\x3a\x78\x6c\x69\x6e\x6b\x3d\"\x68\x74"
"\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x77\x33\x2e\x6f\x72\x67\x2f\x31"
"\x39\x39\x39\x2f\x78\x6c\x69\x6e\x6b\"\x3e"<<lg_endl;lm_outFile<<""
"\x3c\x74\x69\x74\x6c\x65\x3e"<<l12_alias<<"\x3c\x2f\x74\x69\x74\x6c"
"\x65\x3e"<<lg_endl;l251_DoMamlDocs(lm_outFile);lm_outFile<<"\x3c\x72"
"\x65\x6c\x61\x74\x65\x64\x54\x6f\x70\x69\x63\x73\x3e\x3c\x2f\x72\x65"
"\x6c\x61\x74\x65\x64\x54\x6f\x70\x69\x63\x73\x3e"<<lg_endl;
lm_outFile<<"\x3c\x2f\x64\x65\x76\x65\x6c\x6f\x70\x65\x72\x52\x65\x66"
"\x65\x72\x65\x6e\x63\x65\x57\x69\x74\x68\x53\x79\x6e\x74\x61\x78\x44"
"\x6f\x63\x75\x6d\x65\x6e\x74\x3e"<<lg_endl;lm_outFile<<"\x3c\x2f\x74"
"\x6f\x70\x69\x63\x3e"<<lg_endl;}l5_using lr_namespace lz_xlw;
l5_using lr_namespace l16_std;lk_void l45_XlfArgDesc::
l274_CheckNameLength(){lb_if(l116_name_.l138_length()>=19)lx_cerr<<
l14_XLW__HERE__<<"\x41\x72\x67\x75\x6d\x65\x6e\x74\x20\x6e\x61\x6d"
"\x65\x20\""<<l116_name_.l15_c_str()<<"\"\x20\x6d\x61\x79\x20\x62\x65"
"\x20\x74\x6f\x6f\x20\x6c\x6f\x6e\x67\x20\x74\x6f\x20\x66\x69\x74\x20"
"\x74\x68\x65\x20\x69\x6e\x20\x74\x68\x65\x20\x66\x75\x6e\x63\x74\x69"
"\x6f\x6e\x20\x77\x69\x7a\x61\x72\x64"<<lg_endl;};l45_XlfArgDesc::
l45_XlfArgDesc(){}l45_XlfArgDesc::l45_XlfArgDesc(la_const lc_string&
l22_name,la_const lc_string&l38_comment,la_const lc_string&l25_type):
l116_name_(l22_name),l160_comment_(l38_comment),l140_type_(l25_type){
l274_CheckNameLength();}l45_XlfArgDesc::~l45_XlfArgDesc(){}lk_void
l45_XlfArgDesc::l607_SetName(la_const lc_string&l22_name){l116_name_=
l22_name;l274_CheckNameLength();}la_const lc_string&l45_XlfArgDesc::
l93_GetName()la_const{le_return l116_name_;}lk_void l45_XlfArgDesc::
l644_SetComment(la_const lc_string&l38_comment){l160_comment_=
l38_comment;}la_const lc_string&l45_XlfArgDesc::l142_GetComment()la_const
{le_return l160_comment_;}lc_string l45_XlfArgDesc::l313_GetType()la_const
{lb_if(l140_type_=="\x58\x4c\x46\x5f\x4f\x50\x45\x52")le_return
li_XlfExcel::ll_Instance().l359_xlfOperType();ln_else lb_if(
l140_type_=="\x58\x4c\x46\x5f\x58\x4c\x4f\x50\x45\x52")le_return
li_XlfExcel::ll_Instance().l689_xlfXloperType();ln_else lb_if(
l140_type_=="\x58\x4c\x57\x5f\x57\x53\x54\x52")le_return li_XlfExcel
::ll_Instance().l576_wStrType();ln_else lb_if(l140_type_=="\x58\x4c"
"\x57\x5f\x46\x50")le_return li_XlfExcel::ll_Instance().l465_fpType();
ln_else le_return l140_type_;}l5_using lr_namespace lz_xlw;
l82_XlfArgDescList l167_operator+(la_const l45_XlfArgDesc&l340_lhs,
la_const l45_XlfArgDesc&l378_rhs){le_return l82_XlfArgDescList(
l340_lhs)+l378_rhs;}l5_using lr_namespace l16_std;l5_using
lr_namespace lz_xlw;l54_XlfCmdDesc::l54_XlfCmdDesc(la_const lc_string
&l22_name,la_const lc_string&l12_alias,la_const lc_string&l38_comment
,la_const lc_string&l58_menu,la_const lc_string&l422_menuText,ls_bool
l497_hidden):l75_XlfAbstractCmdDesc(l22_name,l12_alias,l38_comment),
l53_menu_(l58_menu),l108_text_(l422_menuText),l395_hidden_(
l497_hidden),l73_funcId_(l103_InvalidFunctionId){}l54_XlfCmdDesc::~
l54_XlfCmdDesc(){}ls_bool l54_XlfCmdDesc::l595_IsAddedToMenuBar(){
le_return!l53_menu_.l47_empty();}lf_int l54_XlfCmdDesc::
l493_AddToMenuBar(la_const lo_char*l58_menu,la_const lo_char*
l339_text){lb_if(l58_menu)l53_menu_=l58_menu;lb_if(l339_text)l108_text_
=l339_text;lb_if(l53_menu_.l47_empty()||l108_text_.l47_empty())le_return
0;ld_XlfOper l77_barNum(10);ld_XlfOper l119_menuLocation;ld_XlfOper
l49_missingValue;ld_XlfOper l291_menuOper(l53_menu_);lf_int lh_err=
li_XlfExcel::ll_Instance().l10_Call12(l165_xlfGetBar,
l119_menuLocation,3,l77_barNum,l291_menuOper,ld_XlfOper(0));lb_if(
lh_err||l119_menuLocation.l216_IsError()){lf_int l152_menuPosition(1);
ld_XlfOper l183_menuName;lh_err=li_XlfExcel::ll_Instance().l10_Call12
(l165_xlfGetBar,l183_menuName,3,l77_barNum,ld_XlfOper(
l152_menuPosition+1),ld_XlfOper(0));l199_while(!lh_err&&!
l183_menuName.l216_IsError()){++l152_menuPosition;lh_err=li_XlfExcel
::ll_Instance().l10_Call12(l165_xlfGetBar,l183_menuName,3,l77_barNum,
ld_XlfOper(l152_menuPosition+1),ld_XlfOper(0));}ld_XlfOper
l63_menuDesc(2,5);l63_menuDesc(0,0)=l53_menu_;l63_menuDesc(0,1)="";
l63_menuDesc(0,2)="";l63_menuDesc(0,3)="";l63_menuDesc(0,4)="";
l63_menuDesc(1,0)=l108_text_;l63_menuDesc(1,1)=l12_alias;l63_menuDesc
(1,2)="";l63_menuDesc(1,3)=l38_comment;l63_menuDesc(1,4)="";lh_err=
li_XlfExcel::ll_Instance().l10_Call12(l750_xlfAddMenu,0,3,l77_barNum,
l63_menuDesc,ld_XlfOper(l152_menuPosition));lb_if(lh_err!=
l0_xlretSuccess)lx_cerr<<l14_XLW__HERE__<<"\x41\x64\x64\x20\x4d\x65"
"\x6e\x75\x20"<<l53_menu_.l15_c_str()<<"\x20\x66\x61\x69\x6c\x65\x64"
<<lg_endl;}ln_else{ld_XlfOper l121_command(1,4);l121_command(0,0)=
l108_text_;l121_command(0,1)=l12_alias;l121_command(0,2)="";
l121_command(0,3)=l38_comment;lh_err=li_XlfExcel::ll_Instance().
l10_Call12(l548_xlfAddCommand,0,3,l77_barNum,l291_menuOper,
l121_command);lb_if(lh_err!=l0_xlretSuccess)lx_cerr<<l14_XLW__HERE__
<<"\x41\x64\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20"<<l22_name.
l15_c_str()<<"\x20\x74\x6f\x20"<<l53_menu_.l15_c_str()<<"\x20\x66\x61"
"\x69\x6c\x65\x64"<<lg_endl;}le_return lh_err;}lf_int l54_XlfCmdDesc
::l552_Check(ls_bool l518_ERR_CHECK)la_const{lb_if(l53_menu_.
l47_empty()){lx_cerr<<l14_XLW__HERE__<<"\x4e\x6f\x20\x6d\x65\x6e\x75"
"\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x20\x66\x6f\x72\x20\x74\x68"
"\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\""<<l22_name.l15_c_str()<<""
"\""<<lg_endl;le_return l203_xlretFailed;}lf_int lh_err=li_XlfExcel::
ll_Instance().l10_Call12(l566_xlfCheckCommand,0,4,ld_XlfOper(10),
ld_XlfOper(l53_menu_),ld_XlfOper(l108_text_),ld_XlfOper(
l518_ERR_CHECK));lb_if(lh_err!=l0_xlretSuccess){lx_cerr<<
l14_XLW__HERE__<<"\x52\x65\x67\x69\x73\x74\x72\x61\x74\x69\x6f\x6e"
"\x20\x6f\x66\x20"<<l12_alias.l15_c_str()<<"\x20\x66\x61\x69\x6c\x65"
"\x64"<<lg_endl;le_return lh_err;}le_return l0_xlretSuccess;}lk_void
l54_XlfCmdDesc::l536_RemoveFromMenuBar(){ld_XlfOper l77_barNum(10);
ld_XlfOper l58_menu(l53_menu_);ld_XlfOper l119_menuLocation;lf_int
lh_err=li_XlfExcel::ll_Instance().l10_Call12(l165_xlfGetBar,
l119_menuLocation,3,l77_barNum,l58_menu,ld_XlfOper(0));lb_if(!lh_err
&&!l119_menuLocation.l216_IsError()){lh_err=li_XlfExcel::ll_Instance(
).l10_Call12(l599_xlfDeleteCommand,0,3,l77_barNum,l58_menu,ld_XlfOper
(l108_text_));lb_if(lh_err!=l0_xlretSuccess)lx_cerr<<l14_XLW__HERE__
<<"\x44\x65\x6c\x65\x74\x65\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20"<<
l22_name.l15_c_str()<<"\x20\x66\x72\x6f\x6d\x20"<<l53_menu_.l15_c_str
()<<"\x20\x66\x61\x69\x6c\x65\x64"<<lg_endl;ld_XlfOper
l329_firstItemLocation;lh_err=li_XlfExcel::ll_Instance().l10_Call12(
l165_xlfGetBar,l329_firstItemLocation,3,ld_XlfOper(10),l58_menu,
ld_XlfOper(1));lb_if(!lh_err&&l329_firstItemLocation.l216_IsError()){
lh_err=li_XlfExcel::ll_Instance().l10_Call12(l687_xlfDeleteMenu,0,2,
l77_barNum,l58_menu);lb_if(lh_err!=l0_xlretSuccess)lx_cerr<<
l14_XLW__HERE__<<"\x44\x65\x6c\x65\x74\x65\x20\x4d\x65\x6e\x75\x20"<<
l53_menu_.l15_c_str()<<"\x20\x66\x61\x69\x6c\x65\x64"<<lg_endl;}}}
lf_int l54_XlfCmdDesc::l301_DoRegister(la_const lc_string&l50_dllName
,la_const lc_string&l97_suggestedHelpId)la_const{l82_XlfArgDescList
l28_arguments=l41_args;l18_double l25_type=l395_hidden_?0:2;lf_int
l32_nbargs=l85_static_cast<lf_int>(l28_arguments.l51_size());
lc_string l41_args("\x41");lc_string l33_argnames;l82_XlfArgDescList
::l478_const_iterator l11_it=l28_arguments.l146_begin();l199_while(
l11_it!=l28_arguments.l81_end()){l33_argnames+=( *l11_it).l93_GetName
();l41_args+=( *l11_it).l313_GetType();++l11_it;lb_if(l11_it!=
l28_arguments.l81_end())l33_argnames+="\x2c\x20";}lb_if(l33_argnames.
l138_length()>255)l33_argnames="\x54\x6f\x6f\x20\x6d\x61\x6e\x79\x20"
"\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f\x72\x20\x46\x75\x6e"
"\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a\x61\x72\x64";l137_vector<
lq_LPXLOPER12>l136_argArray(10+l32_nbargs);lq_LPXLOPER12*l2_px=&
l136_argArray[0];( *l2_px++)=ld_XlfOper(l50_dllName);( *l2_px++)=
ld_XlfOper(l22_name);( *l2_px++)=ld_XlfOper(l41_args);( *l2_px++)=
ld_XlfOper(l12_alias);( *l2_px++)=ld_XlfOper(l33_argnames);( *l2_px++
)=ld_XlfOper(l25_type);( *l2_px++)=ld_XlfOper("");( *l2_px++)=
ld_XlfOper("");( *l2_px++)=ld_XlfOper("");( *l2_px++)=ld_XlfOper(
l38_comment);lf_int l13_counter(0);l19_for(l11_it=l28_arguments.
l146_begin();l11_it!=l28_arguments.l81_end();++l11_it){++l13_counter;
lb_if(l13_counter<l32_nbargs)( *l2_px++)=ld_XlfOper(( *l11_it).
l142_GetComment());ln_else( *l2_px++)=ld_XlfOper(( *l11_it).
l142_GetComment()+"\x2e\x20");}lb_if(li_XlfExcel::ll_Instance().
l285_excel12())l32_nbargs=l191_min(l32_nbargs,245);ln_else l32_nbargs
=l191_min(l32_nbargs,20);ld_XlfOper l1_res;lf_int lh_err=li_XlfExcel
::ll_Instance().l20_Call12v(l483_xlfRegister,l1_res,10+l32_nbargs,&
l136_argArray[0]);lb_if(lh_err==l0_xlretSuccess&&l1_res.l347_IsNumber
())l73_funcId_=l1_res.l113_AsDouble();ln_else l73_funcId_=
l103_InvalidFunctionId;le_return lh_err;}lf_int l54_XlfCmdDesc::
l297_DoUnregister(la_const lc_string&l50_dllName)la_const{lb_if(
l73_funcId_!=l103_InvalidFunctionId){li_XlfExcel::ll_Instance().
l10_Call12(l490_xlfSetName,l59_NULL,1,ld_XlfOper(l12_alias));
ld_XlfOper l185_unreg;lf_int lh_err=li_XlfExcel::ll_Instance().
l10_Call12(l402_xlfUnregister,l185_unreg,1,ld_XlfOper(l73_funcId_));
le_return lh_err;}ln_else le_return l0_xlretSuccess;}lk_void
l54_XlfCmdDesc::l251_DoMamlDocs(l486_ostream&l3_ostr)la_const{l3_ostr
<<"\x3c\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e\x3e"<<lg_endl
;l3_ostr<<"\x3c\x70\x61\x72\x61\x3e"<<l38_comment<<"\x3c\x2f\x70\x61"
"\x72\x61\x3e"<<lg_endl;l3_ostr<<"\x3c\x2f\x69\x6e\x74\x72\x6f\x64"
"\x75\x63\x74\x69\x6f\x6e\x3e"<<lg_endl;}l5_using lr_namespace l16_std
;lr_namespace{ls_bool l250_doesFileExist(la_const lc_string&
l127_fileName){l99_DWORD l252_attributes(l560_GetFileAttributes(
l127_fileName.l15_c_str()));le_return((l252_attributes!=
l740_INVALID_FILE_ATTRIBUTES)&&((l252_attributes&
l541_FILE_ATTRIBUTE_DIRECTORY)==0));}}l130_struct lz_xlw::
l280_XlfExcelImpl{l280_XlfExcelImpl():l283_handle_(0){}l174_HINSTANCE
l283_handle_;};l5_using lr_namespace lz_xlw;li_XlfExcel*li_XlfExcel::
l98_this_=0;li_XlfExcel&li_XlfExcel::ll_Instance(){lb_if(!l98_this_){
l98_this_=l88_new li_XlfExcel;l98_this_->l522_InitLibrary();}
le_return*l98_this_;}lk_void li_XlfExcel::l472_DeleteInstance(){
l322_delete l98_this_;l98_this_=0;}ls_bool li_XlfExcel::
l722_IsEscPressed()la_const{ld_XlfOper l139_ret;l10_Call12(
l575_xlAbort,l139_ret,1,ld_XlfOper(l34_false));le_return l139_ret.
l89_as<ls_bool>();}lr_namespace{l242_typedef l130_struct{l226_HWND
l101_hWnd;l281_unsigned l371_short l454_loWord;}
l213_GetMainWindowStruct;l480_BOOL l502_CALLBACK
l436_GetMainWindowProc(l226_HWND l101_hWnd,l317_LPARAM l426_lParam){
l213_GetMainWindowStruct*l162_pEnum=(l213_GetMainWindowStruct* )l426_lParam
;lb_if(l666_LOWORD(l101_hWnd)==l162_pEnum->l454_loWord){lo_char
l267_className[7];lb_if(l440_GetClassName(l101_hWnd,l267_className,7)!=
0){lb_if(!l656_lstrcmpi(l267_className,"\x58\x4c\x4d\x41\x49\x4e")){
l162_pEnum->l101_hWnd=l101_hWnd;le_return l372_FALSE;}}}le_return
l531_TRUE;}}l226_HWND li_XlfExcel::l435_GetMainWindow(){l354_XLOPER12
l139_ret;lb_if(l10_Call12(l609_xlGetHwnd,&l139_ret,0)==
l0_xlretSuccess){l213_GetMainWindowStruct l202_getMainWindowStruct={
l59_NULL,(l281_unsigned l371_short)l139_ret.l132_val.l192_w};
l573_EnumWindows(l436_GetMainWindowProc,(l317_LPARAM)&
l202_getMainWindowStruct);lb_if(l202_getMainWindowStruct.l101_hWnd!=
l59_NULL)le_return l202_getMainWindowStruct.l101_hWnd;ln_else ly_throw
("\x78\x6c\x47\x65\x74\x48\x77\x6e\x64\x20\x6e\x6f\x20\x6d\x61\x74"
"\x63\x68\x20\x66\x6f\x72\x20\x70\x61\x72\x74\x69\x61\x6c\x20\x68\x61"
"\x6e\x64\x6c\x65");}ln_else ly_throw("\x78\x6c\x47\x65\x74\x48\x77"
"\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x61\x69\x6c\x65\x64");}
l174_HINSTANCE li_XlfExcel::l556_GetExcelInstance(){le_return(
l174_HINSTANCE)l555_GetWindowLongPtr(l435_GetMainWindow(),
l557_GWLP_HINSTANCE);}li_XlfExcel::li_XlfExcel():l39_impl_(0){
l39_impl_=l88_new lz_xlw::l280_XlfExcelImpl();le_return;}li_XlfExcel
::~li_XlfExcel(){l322_delete l39_impl_;l98_this_=0;le_return;}lf_int
l362_get_excel_version(){lf_int l133_version(10);l354_XLOPER12
l123_xRet1,l196_xRet2,l244_xTemp1,l239_xTemp2;l244_xTemp1.l72_xltype=
l239_xTemp2.l72_xltype=l219_xltypeInt;l244_xTemp1.l132_val.l192_w=2;
l239_xTemp2.l132_val.l192_w=l219_xltypeInt;l224_Excel12(
l432_xlfGetWorkspace,&l123_xRet1,1,&l244_xTemp1);l224_Excel12(
l598_xlCoerce,&l196_xRet2,2,&l123_xRet1,&l239_xTemp2);lb_if(
l196_xRet2.l72_xltype==l219_xltypeInt){l133_version=l196_xRet2.
l132_val.l192_w;}ln_else lb_if(l123_xRet1.l72_xltype==l300_xltypeStr){
l133_version=l553__wtoi(l123_xRet1.l132_val.l94_str+1);}l224_Excel12(
l637_xlFree,0,1,&l123_xRet1);le_return l133_version;}lk_void
li_XlfExcel::l522_InitLibrary(){l174_HINSTANCE l310_handle=
l675_LoadLibrary("\x58\x4c\x43\x41\x4c\x4c\x33\x32\x2e\x44\x4c\x4c");
lb_if(l310_handle==0)ly_throw("\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74"
"\x20\x6c\x6f\x61\x64\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x58\x4c\x43"
"\x41\x4c\x4c\x33\x32\x2e\x44\x4c\x4c");l688_excelVersion_=
l362_get_excel_version();l723_xlfOperType_="\x51";l716_xlfXloperType_
="\x55";l698_wStrType_="\x43\x25";l601_fpArrayType_="\x4b\x25";
l39_impl_->l283_handle_=l310_handle;ld_XlfOper l321_intlInfo;lf_int
lh_err=l10_Call12(l432_xlfGetWorkspace,(l60_LPXLFOPER)l321_intlInfo,1
,ld_XlfOper(37));lb_if(lh_err==l0_xlretSuccess)l455_isEnglish_=(
l321_intlInfo(0,0).l89_as<lf_int>()==1);ln_else{l455_isEnglish_=
l69_true;lx_cerr<<l14_XLW__HERE__<<"\x43\x6f\x75\x6c\x64\x20\x6e\x6f"
"\x74\x20\x67\x65\x74\x20\x69\x6e\x74\x65\x72\x6e\x61\x74\x69\x6f\x6e"
"\x61\x6c\x20\x69\x6e\x66\x6f\x2c\x20\x67\x75\x65\x73\x73\x69\x6e\x67"
"\x20\x45\x6e\x67\x6c\x69\x73\x68"<<lg_endl;}ld_XlfOper l298_xName;
lh_err=l10_Call12(l710_xlGetName,(l60_LPXLFOPER)l298_xName,0);lb_if(
lh_err==l0_xlretSuccess)l111_xllFileName_=l298_xName.l89_as<lc_string
>();ln_else lx_cerr<<l14_XLW__HERE__<<"\x43\x6f\x75\x6c\x64\x20\x6e"
"\x6f\x74\x20\x67\x65\x74\x20\x44\x4c\x4c\x20\x6e\x61\x6d\x65"<<
lg_endl;l404_LookForHelp();l400_m_mainExcelThread=
l443_GetCurrentThreadId();}la_const lc_string&li_XlfExcel::
l93_GetName()la_const{le_return l111_xllFileName_;}la_const lc_string
&li_XlfExcel::l403_GetHelpName()la_const{le_return l206_helpFileName_
;}lc_string li_XlfExcel::l630_GetXllDirectory()la_const{l24_size_t
l109_slashPos(l111_xllFileName_.l293_find_last_of("\\\x2f"));lb_if(
l109_slashPos==lc_string::l458_npos)le_return"\x2e";ln_else le_return
l111_xllFileName_.l237_substr(0,l109_slashPos);}lk_void li_XlfExcel::
l404_LookForHelp(){l206_helpFileName_.l305_clear();l24_size_t
l128_nameLen(l111_xllFileName_.l138_length());lb_if(l128_nameLen<5||
l111_xllFileName_[l128_nameLen-4]!='.')le_return;lc_string
l57_testFile=l111_xllFileName_;l57_testFile[l128_nameLen-3]='c';
l57_testFile[l128_nameLen-2]='h';l57_testFile[l128_nameLen-1]='m';
lb_if(l250_doesFileExist(l57_testFile)){l206_helpFileName_=
l57_testFile;le_return;}l24_size_t l109_slashPos(l57_testFile.
l293_find_last_of("\\\x2f"));lb_if(l109_slashPos==lc_string::
l458_npos)le_return;l57_testFile=l57_testFile.l237_substr(0,
l109_slashPos)+"\\\x2e\x2e"+l57_testFile.l237_substr(l109_slashPos);
lb_if(l250_doesFileExist(l57_testFile))l206_helpFileName_=
l57_testFile;}lf_int li_XlfExcel::l10_Call12(lf_int lt_xlfn,
lq_LPXLOPER12 l29_pxResult,lf_int l8_count)la_const{l134_assert(
l8_count==0);le_return l20_Call12v(lt_xlfn,l29_pxResult,0,0);}lf_int
li_XlfExcel::l10_Call12(lf_int lt_xlfn,lq_LPXLOPER12 l29_pxResult,
lf_int l8_count,la_const lq_LPXLOPER12 l4_param1)la_const{l134_assert
(l8_count==1);le_return l20_Call12v(lt_xlfn,l29_pxResult,1,&l4_param1
);}lf_int li_XlfExcel::l10_Call12(lf_int lt_xlfn,lq_LPXLOPER12
l29_pxResult,lf_int l8_count,la_const lq_LPXLOPER12 l4_param1,
la_const lq_LPXLOPER12 l26_param2)la_const{l134_assert(l8_count==2);
la_const lq_LPXLOPER12 l95_paramArray[2]={l4_param1,l26_param2};
le_return l20_Call12v(lt_xlfn,l29_pxResult,2,l95_paramArray);}lf_int
li_XlfExcel::l10_Call12(lf_int lt_xlfn,lq_LPXLOPER12 l29_pxResult,
lf_int l8_count,la_const lq_LPXLOPER12 l4_param1,la_const
lq_LPXLOPER12 l26_param2,la_const lq_LPXLOPER12 l48_param3)la_const{
l134_assert(l8_count==3);la_const lq_LPXLOPER12 l95_paramArray[3]={
l4_param1,l26_param2,l48_param3};le_return l20_Call12v(lt_xlfn,
l29_pxResult,3,l95_paramArray);}lf_int li_XlfExcel::l10_Call12(lf_int
lt_xlfn,lq_LPXLOPER12 l29_pxResult,lf_int l8_count,la_const
lq_LPXLOPER12 l4_param1,la_const lq_LPXLOPER12 l26_param2,la_const
lq_LPXLOPER12 l48_param3,la_const lq_LPXLOPER12 l100_param4)la_const{
l134_assert(l8_count==4);la_const lq_LPXLOPER12 l95_paramArray[4]={
l4_param1,l26_param2,l48_param3,l100_param4};le_return l20_Call12v(
lt_xlfn,l29_pxResult,4,l95_paramArray);}lf_int li_XlfExcel::
l10_Call12(lf_int lt_xlfn,lq_LPXLOPER12 l29_pxResult,lf_int l8_count,
la_const lq_LPXLOPER12 l4_param1,la_const lq_LPXLOPER12 l26_param2,
la_const lq_LPXLOPER12 l48_param3,la_const lq_LPXLOPER12 l100_param4,
la_const lq_LPXLOPER12 l514_param5,la_const lq_LPXLOPER12 l509_param6
,la_const lq_LPXLOPER12 l521_param7,la_const lq_LPXLOPER12 l513_param8
,la_const lq_LPXLOPER12 l500_param9,la_const lq_LPXLOPER12
l417_param10)la_const{l134_assert(l8_count>=5&&l8_count<=10);la_const
lq_LPXLOPER12 l95_paramArray[10]={l4_param1,l26_param2,l48_param3,
l100_param4,l514_param5,l509_param6,l521_param7,l513_param8,
l500_param9,l417_param10};le_return l20_Call12v(lt_xlfn,l29_pxResult,
l8_count,l95_paramArray);}lf_int li_XlfExcel::l20_Call12v(lf_int
lt_xlfn,lq_LPXLOPER12 l29_pxResult,lf_int l8_count,la_const
lq_LPXLOPER12 l282_pxdata[])la_const{l19_for(lf_int l21_i=0;l21_i<
l8_count;++l21_i)lb_if(!l282_pxdata[l21_i]){lb_if(lt_xlfn&
l726_xlCommand)lx_cerr<<l14_XLW__HERE__<<"\x78\x6c\x43\x6f\x6d\x6d"
"\x61\x6e\x64\x20\x7c\x20"<<(lt_xlfn&0x0FFF)<<lg_endl;lb_if(lt_xlfn&
l658_xlSpecial)lx_cerr<<"\x78\x6c\x53\x70\x65\x63\x69\x61\x6c\x20\x7c"
"\x20"<<(lt_xlfn&0x0FFF)<<lg_endl;lb_if(lt_xlfn&l189_xlIntl)lx_cerr<<""
"\x78\x6c\x49\x6e\x74\x6c\x20\x7c\x20"<<(lt_xlfn&0x0FFF)<<lg_endl;
lb_if(lt_xlfn&l745_xlPrompt)lx_cerr<<"\x78\x6c\x50\x72\x6f\x6d\x70"
"\x74\x20\x7c\x20"<<(lt_xlfn&0x0FFF)<<lg_endl;lx_cerr<<"\x30\x20\x70"
"\x6f\x69\x6e\x74\x65\x72\x20\x70\x61\x73\x73\x65\x64\x20\x61\x73\x20"
"\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x23"<<l21_i<<lg_endl;}lf_int
l65_xlret=l379_Excel12v(lt_xlfn,l29_pxResult,l8_count,l282_pxdata);
lb_if(l29_pxResult){lf_int l25_type=l29_pxResult->l72_xltype;ls_bool
l409_hasAuxMem=(l25_type&l300_xltypeStr||((l25_type&l508_xltypeRef)&&
l29_pxResult->l132_val.l542_mref.l579_lpmref)||l25_type&
l496_xltypeMulti||l25_type&l564_xltypeBigData);lb_if(l409_hasAuxMem)l29_pxResult
->l72_xltype|=l182_XlfOperImpl::l639_xlbitFreeAuxMem;}le_return
l65_xlret;}lr_namespace{l242_typedef l130_struct l604__EnumStruct{
ls_bool l231_bFuncWiz;}l375_EnumStruct,l668_FAR*l304_LPEnumStruct;
ls_bool l502_CALLBACK l424_EnumProc(l226_HWND l311_hwnd,
l304_LPEnumStruct l162_pEnum){la_const l24_size_t
l197_CLASS_NAME_BUFFER=256;lo_char l115_rgsz[l197_CLASS_NAME_BUFFER];
l440_GetClassName(l311_hwnd,(l257_LPSTR)l115_rgsz,
l197_CLASS_NAME_BUFFER);lb_if(2==l554_CompareString(l626_MAKELCID(
l714_MAKELANGID(l597_LANG_ENGLISH,l643_SUBLANG_ENGLISH_US),
l585_SORT_DEFAULT),l591_NORM_IGNORECASE,(l257_LPSTR)l115_rgsz,(
l294_lstrlen((l257_LPSTR)l115_rgsz)>l294_lstrlen("\x62\x6f\x73\x61"
"\x5f\x73\x64\x6d\x5f\x58\x4c"))?l294_lstrlen("\x62\x6f\x73\x61\x5f"
"\x73\x64\x6d\x5f\x58\x4c"):-1,"\x62\x6f\x73\x61\x5f\x73\x64\x6d\x5f"
"\x58\x4c",-1)){lb_if(l539_GetWindowText(l311_hwnd,l115_rgsz,
l197_CLASS_NAME_BUFFER)){lb_if(!l452_strstr(l115_rgsz,"\x52\x65\x70"
"\x6c\x61\x63\x65")&&!l452_strstr(l115_rgsz,"\x50\x61\x73\x74\x65")){
l162_pEnum->l231_bFuncWiz=l531_TRUE;le_return l34_false;}ln_else{
le_return l34_false;}}}le_return l69_true;}}ls_bool li_XlfExcel::
l582_IsCalledByFuncWiz()la_const{l375_EnumStruct l207_enm;l207_enm.
l231_bFuncWiz=l34_false;l701_EnumThreadWindows(l400_m_mainExcelThread
,(l697_WNDENUMPROC)l424_EnumProc,(l317_LPARAM)((l304_LPEnumStruct)&
l207_enm));le_return l207_enm.l231_bFuncWiz;}l5_using lr_namespace
lz_xlw;l5_using lr_namespace l16_std;l52_XlfFuncDesc::l52_XlfFuncDesc
(la_const lc_string&l22_name,la_const lc_string&l12_alias,la_const
lc_string&l38_comment,la_const lc_string&l466_category,
l683_RecalcPolicy l349_recalcPolicy,ls_bool l178_Threadsafe,la_const
lc_string&l235_returnTypeCode,la_const lc_string&l122_helpID,ls_bool
l230_Asynchronous,ls_bool l234_MacroSheetEquivalent,ls_bool
l179_ClusterSafe):l75_XlfAbstractCmdDesc(l22_name,l12_alias,
l38_comment),l225_helpID_(l122_helpID),l149_returnTypeCode_(
l235_returnTypeCode),l39_impl_(l88_new l625_XlfFuncDescImpl(
l349_recalcPolicy,l178_Threadsafe,l466_category,l230_Asynchronous,
l234_MacroSheetEquivalent,l179_ClusterSafe)),l73_funcId_(
l103_InvalidFunctionId){}l52_XlfFuncDesc::~l52_XlfFuncDesc(){}lk_void
l52_XlfFuncDesc::l421_SetArguments(la_const l82_XlfArgDescList&
l28_arguments){l39_impl_->l314_arguments_=l28_arguments;}lf_int
l52_XlfFuncDesc::l301_DoRegister(la_const lc_string&l50_dllName,
la_const lc_string&l97_suggestedHelpId)la_const{lb_if(
l149_returnTypeCode_.l47_empty())l149_returnTypeCode_=li_XlfExcel::
ll_Instance().l359_xlfOperType(l34_false);lb_if(l149_returnTypeCode_
=="\x58\x4c\x57\x5f\x46\x50")l149_returnTypeCode_=li_XlfExcel::
ll_Instance().l465_fpType();le_return l460_RegisterAs(l50_dllName,
l97_suggestedHelpId,1);}lf_int l52_XlfFuncDesc::l297_DoUnregister(
la_const lc_string&l50_dllName)la_const{lb_if(l73_funcId_!=
l103_InvalidFunctionId){li_XlfExcel::ll_Instance().l10_Call12(
l490_xlfSetName,l59_NULL,1,ld_XlfOper(l12_alias));ld_XlfOper
l185_unreg;lf_int lh_err=li_XlfExcel::ll_Instance().l10_Call12(
l402_xlfUnregister,l185_unreg,1,ld_XlfOper(l73_funcId_));le_return
lh_err;}ln_else le_return l0_xlretSuccess;}lf_int l52_XlfFuncDesc::
l460_RegisterAs(la_const lc_string&l50_dllName,la_const lc_string&
l97_suggestedHelpId,l18_double l373_mode_)la_const{l82_XlfArgDescList
&l28_arguments=l39_impl_->l314_arguments_;lf_int l32_nbargs=(lf_int)l28_arguments
.l51_size();lc_string l41_args="\x51";lc_string l33_argnames;lb_if(
li_XlfExcel::ll_Instance().l214_excel14()&&l39_impl_->
l161_Asynchronous_)l41_args="\x3e";l19_for(l23_auto&l96_arg:
l28_arguments){l33_argnames+=l96_arg.l93_GetName()+"\x2c\x20";
l41_args+=l96_arg.l313_GetType();}lb_if(l32_nbargs>0){l33_argnames.
l254_pop_back();l33_argnames.l254_pop_back();}lb_if(l33_argnames.
l138_length()>255)l33_argnames="\x54\x6f\x6f\x20\x6d\x61\x6e\x79\x20"
"\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f\x72\x20\x46\x75\x6e"
"\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a\x61\x72\x64";lb_if(li_XlfExcel
::ll_Instance().l214_excel14()&&l39_impl_->l161_Asynchronous_)l41_args
+="\x58";lb_if(l39_impl_->l729_recalcPolicy_==l52_XlfFuncDesc::
l208_Volatile)l41_args+="\x21";lb_if(li_XlfExcel::ll_Instance().
l285_excel12()&&l39_impl_->l335_Threadsafe_)l41_args+="\x24";lb_if(
li_XlfExcel::ll_Instance().l214_excel14()&&l39_impl_->
l307_ClusterSafe_)l41_args+="\x26";lb_if(l39_impl_->
l268_MacroSheetEquivalent_)l41_args+="\x23";l137_vector<lq_LPXLOPER12
>l136_argArray(10+l32_nbargs);lq_LPXLOPER12*l2_px=&l136_argArray[0];
l23_auto l278_functionName=l22_name;lb_if(li_XlfExcel::ll_Instance().
l214_excel14()&&l39_impl_->l161_Asynchronous_)l278_functionName+=""
"\x53\x79\x6e\x63";( *l2_px++)=ld_XlfOper(l50_dllName);( *l2_px++)=
ld_XlfOper(l278_functionName);( *l2_px++)=ld_XlfOper(l41_args);( *
l2_px++)=ld_XlfOper(l12_alias);( *l2_px++)=ld_XlfOper(l33_argnames);(
 *l2_px++)=ld_XlfOper(l373_mode_);( *l2_px++)=ld_XlfOper(l39_impl_->
l703_category_);( *l2_px++)=ld_XlfOper("");lb_if(!l225_helpID_.
l47_empty()&&l225_helpID_!="\x61\x75\x74\x6f")( *l2_px++)=ld_XlfOper(
l225_helpID_);ln_else( *l2_px++)=ld_XlfOper(l97_suggestedHelpId);( *
l2_px++)=ld_XlfOper(l38_comment);lf_int l13_counter=0;l19_for(
l23_auto&l96_arg:l28_arguments){++l13_counter;lb_if(l13_counter<
l32_nbargs)( *l2_px++)=ld_XlfOper(l96_arg.l142_GetComment());ln_else(
 *l2_px++)=ld_XlfOper(l96_arg.l142_GetComment()+"\x2e\x20");}lb_if(
li_XlfExcel::ll_Instance().l285_excel12())l32_nbargs=l191_min(
l32_nbargs,245);ln_else l32_nbargs=l191_min(l32_nbargs,20);ld_XlfOper
l1_res;lf_int lh_err=li_XlfExcel::ll_Instance().l20_Call12v(
l483_xlfRegister,l1_res,10+l32_nbargs,&l136_argArray[0]);lb_if(lh_err
==l0_xlretSuccess&&l1_res.l347_IsNumber())l73_funcId_=l1_res.l89_as<
l18_double>();ln_else l73_funcId_=l103_InvalidFunctionId;le_return
lh_err;}lk_void l52_XlfFuncDesc::l251_DoMamlDocs(l486_ostream&l3_ostr
)la_const{l3_ostr<<"\x3c\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69\x6f"
"\x6e\x3e"<<lg_endl;l82_XlfArgDescList&l28_arguments=l39_impl_->
l314_arguments_;l3_ostr<<"\x3c\x70\x61\x72\x61\x3e"<<l38_comment<<""
"\x3c\x2f\x70\x61\x72\x61\x3e"<<lg_endl;lc_string l33_argnames;
l82_XlfArgDescList::l478_const_iterator l11_it=l28_arguments.
l146_begin();l199_while(l11_it!=l28_arguments.l81_end()){l33_argnames
+=( *l11_it).l93_GetName();++l11_it;lb_if(l11_it!=l28_arguments.
l81_end())l33_argnames+="\x2c\x20";}l3_ostr<<"\x3c\x63\x6f\x64\x65"
"\x3e\x3d"<<l12_alias<<"\x28"<<l33_argnames<<"\x29\x3c\x2f\x63\x6f"
"\x64\x65\x3e"<<lg_endl;l3_ostr<<"\x3c\x2f\x69\x6e\x74\x72\x6f\x64"
"\x75\x63\x74\x69\x6f\x6e\x3e"<<lg_endl;l3_ostr<<"\x3c\x73\x65\x63"
"\x74\x69\x6f\x6e\x3e"<<lg_endl;l3_ostr<<"\x20\x20\x3c\x74\x69\x74"
"\x6c\x65\x3e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x3c\x2f\x74\x69"
"\x74\x6c\x65\x3e"<<lg_endl;l3_ostr<<"\x20\x20\x3c\x63\x6f\x6e\x74"
"\x65\x6e\x74\x3e"<<lg_endl;l19_for(l11_it=l28_arguments.l146_begin();
l11_it!=l28_arguments.l81_end();++l11_it){l3_ostr<<"\x20\x20\x20\x20"
"\x3c\x70\x61\x72\x61\x3e";l3_ostr<<( *l11_it).l93_GetName()<<"\x3a"
"\x20"<<( *l11_it).l142_GetComment();l3_ostr<<"\x3c\x2f\x70\x61\x72"
"\x61\x3e"<<lg_endl;}l3_ostr<<"\x20\x20\x3c\x2f\x63\x6f\x6e\x74\x65"
"\x6e\x74\x3e"<<lg_endl;l3_ostr<<"\x3c\x2f\x73\x65\x63\x74\x69\x6f"
"\x6e\x3e"<<lg_endl;}l5_using lr_namespace l16_std;lr_namespace{
lc_string l78_CombineErrorString(la_const lo_char*l468_Msg,la_const
lo_char*l44_ErrorId,la_const lo_char*l71_Identifier){lc_string
lj_result(l468_Msg);lb_if(l44_ErrorId){lj_result+="\x2c\x20";
lj_result+=l44_ErrorId;}lb_if(l71_Identifier){lj_result+="\x20";
lj_result+=l71_Identifier;}le_return lj_result;}}lr_namespace lz_xlw{
lk_void l182_XlfOperImpl::l489_ThrowOnError(lf_int l65_xlret,la_const
lo_char*l44_ErrorId,la_const lo_char*l71_Identifier){lb_if(l65_xlret&
l612_xlretUncalced)ly_throw"\x75\x6e\x63\x61\x6c\x63\x75\x6c\x61\x74"
"\x65\x64";lb_if(l65_xlret&l592_xlretAbort)ly_throw"\x61\x62\x6f\x72"
"\x74";lb_if(l65_xlret&l551_xlretStackOvfl)ly_throw"\x73\x74\x61\x63"
"\x6b\x20\x6f\x76\x65\x72\x66\x6c\x6f\x77";lb_if(l65_xlret&
l407_xlretInvXloper)ly_throw(l78_CombineErrorString("\x69\x6e\x76\x61"
"\x6c\x69\x64\x20\x4f\x50\x45\x52\x20\x73\x74\x72\x75\x63\x74\x75\x72"
"\x65\x20\x28\x6d\x65\x6d\x6f\x72\x79\x20\x63\x6f\x75\x6c\x64\x20\x62"
"\x65\x20\x65\x78\x68\x61\x75\x73\x74\x65\x64\x29",l44_ErrorId,
l71_Identifier));lb_if(l65_xlret&l203_xlretFailed)ly_throw(
l78_CombineErrorString("\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x61\x69"
"\x6c\x65\x64",l44_ErrorId,l71_Identifier));lb_if(l65_xlret&
l516_xlretInvCount)ly_throw(l78_CombineErrorString("\x69\x6e\x76\x61"
"\x6c\x69\x64\x20\x6e\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x61\x72\x67"
"\x75\x6d\x65\x6e\x74\x73",l44_ErrorId,l71_Identifier));lb_if(
l65_xlret&l757_xlretInvXlfn)ly_throw(l78_CombineErrorString("\x69\x6e"
"\x76\x61\x6c\x69\x64\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x75"
"\x6d\x62\x65\x72",l44_ErrorId,l71_Identifier));lb_if(l65_xlret&
l588_xlRetInvAsynchronousContext)ly_throw(l78_CombineErrorString(""
"\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x73\x79\x6e\x63\x68\x20\x63\x6f"
"\x6e\x65\x78\x74",l44_ErrorId,l71_Identifier));lb_if(l65_xlret&
l550_xlretNotClusterSafe)ly_throw(l78_CombineErrorString("\x66\x75"
"\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x63\x6c\x75\x73\x74\x65"
"\x72\x20\x73\x61\x66\x65",l44_ErrorId,l71_Identifier));}lk_void
l182_XlfOperImpl::l673_MissingOrEmptyError(lf_int l72_xltype,la_const
lo_char*l44_ErrorId,la_const lo_char*l157_identifier){lb_if(
l72_xltype==l529_xltypeMissing)ly_throw(l78_CombineErrorString("\x70"
"\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x73\x20\x6d\x69\x73\x73\x69"
"\x6e\x67",l44_ErrorId,l157_identifier));lb_if(l72_xltype==
l457_xltypeErr)ly_throw(l78_CombineErrorString("\x70\x61\x72\x61\x6d"
"\x65\x74\x65\x72\x20\x69\x73\x20\x65\x72\x72\x6f\x72",l44_ErrorId,
l157_identifier));lb_if(l72_xltype==l428_xltypeNil)ly_throw(
l78_CombineErrorString("\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69"
"\x73\x20\x6e\x69\x6c",l44_ErrorId,l157_identifier));
l489_ThrowOnError(l407_xlretInvXloper,l44_ErrorId,l157_identifier);}
lc_string l182_XlfOperImpl::l549_XlTypeToString(lf_int l434_xlType){
l99_DWORD l25_type=l434_xlType&0xFFF;lb_if(l25_type==l611_xltypeNum)le_return""
"\x78\x6c\x74\x79\x70\x65\x4e\x75\x6d";ln_else lb_if(l25_type==
l300_xltypeStr)le_return"\x78\x6c\x74\x79\x70\x65\x53\x74\x72";
ln_else lb_if(l25_type==l606_xltypeBool)le_return"\x78\x6c\x74\x79"
"\x70\x65\x42\x6f\x6f\x6c";ln_else lb_if(l25_type==l508_xltypeRef)le_return""
"\x78\x6c\x74\x79\x70\x65\x52\x65\x66";ln_else lb_if(l25_type==
l457_xltypeErr)le_return"\x78\x6c\x74\x79\x70\x65\x45\x72\x72";
ln_else lb_if(l25_type==l496_xltypeMulti)le_return"\x78\x6c\x74\x79"
"\x70\x65\x4d\x75\x6c\x74\x69";ln_else lb_if(l25_type==
l529_xltypeMissing)le_return"\x78\x6c\x74\x79\x70\x65\x4d\x69\x73\x73"
"\x69\x6e\x67";ln_else lb_if(l25_type==l428_xltypeNil)le_return"\x78"
"\x6c\x74\x79\x70\x65\x4e\x69\x6c";ln_else lb_if(l25_type==
l692_xltypeSRef)le_return"\x78\x6c\x74\x79\x70\x65\x53\x52\x65\x66";
ln_else lb_if(l25_type==l219_xltypeInt)le_return"\x78\x6c\x74\x79\x70"
"\x65\x49\x6e\x74";ln_else le_return"\x75\x6e\x6b\x6e\x6f\x77\x6e";}}
l5_using lr_namespace l16_std;lr_namespace{lc_string l302_RowColToA1(
l561_RW l390_row,l526_COL l198_col){l200_ostringstream l3_ostr;
l526_COL l117_colLeft=l198_col;lb_if(l198_col>26*26){lo_char
l120_colChar='A'+l117_colLeft/(26*26)-1;l117_colLeft%=(26*26);l3_ostr
<<l120_colChar;}lb_if(l198_col>26){lo_char l120_colChar='A'+
l117_colLeft/26-1;l117_colLeft%=26;l3_ostr<<l120_colChar;}{lo_char
l120_colChar='A'+l117_colLeft;l3_ostr<<l120_colChar;}l3_ostr<<
l390_row+1;le_return l3_ostr.l94_str();}}lr_namespace lz_xlw{
lc_string l462_XlfRef::l661_GetTextA1(){lc_string lj_result=
l302_RowColToA1(l220_rowbegin_,l193_colbegin_);lb_if(l201_colend_>
l193_colbegin_+1||l238_rowend_>l220_rowbegin_+1){lj_result+="\x3a";
lj_result+=l302_RowColToA1(l238_rowend_-1,l201_colend_-1);}le_return
lj_result;}lc_string l462_XlfRef::l746_GetTextR1C1(){
l200_ostringstream l3_ostr;l3_ostr<<"\x52"<<l220_rowbegin_+1<<"\x43"
<<l193_colbegin_+1;lb_if(l201_colend_>l193_colbegin_+1||l238_rowend_>
l220_rowbegin_+1)l3_ostr<<"\x3a"<<"\x52"<<l238_rowend_<<"\x43"<<
l201_colend_;le_return l3_ostr.l94_str();}}l5_using lr_namespace
l16_std;lr_namespace lz_xlw{l130_struct l615_Services_t
l68_XlfServices;lr_namespace{l67_inline ld_XlfOper lu_CallFunction(
lf_int lt_xlfn,la_const lo_char*l27_errorString){ld_XlfOper lj_result
;lf_int lh_err=li_XlfExcel::ll_Instance().l20_Call12v(lt_xlfn,
lj_result,0,0);lb_if(lh_err!=l0_xlretSuccess)ly_throw(lc_string(
l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
l42_to_string(lh_err));le_return lj_result;}l67_inline ld_XlfOper
lu_CallFunction(lf_int lt_xlfn,la_const ld_XlfOper&l4_param1,la_const
lo_char*l27_errorString){ld_XlfOper lj_result;la_const l60_LPXLFOPER
l31_params[]={l4_param1};lf_int lh_err=li_XlfExcel::ll_Instance().
l20_Call12v(lt_xlfn,lj_result,1,l31_params);lb_if(lh_err!=
l0_xlretSuccess)ly_throw(lc_string(l27_errorString)+lc_string("\x20"
"\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c"
"\x74\x20\x63\x6f\x64\x65\x20")+l42_to_string(lh_err));le_return
lj_result;}l67_inline ld_XlfOper lu_CallFunction(lf_int lt_xlfn,
la_const ld_XlfOper&l4_param1,la_const ld_XlfOper&l26_param2,la_const
lo_char*l27_errorString){ld_XlfOper lj_result;la_const l60_LPXLFOPER
l31_params[]={l4_param1,l26_param2};lf_int lh_err=li_XlfExcel::
ll_Instance().l20_Call12v(lt_xlfn,lj_result,2,l31_params);lb_if(
lh_err!=l0_xlretSuccess)ly_throw(lc_string(l27_errorString)+lc_string
("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73"
"\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42_to_string(lh_err));
le_return lj_result;}l67_inline ld_XlfOper lu_CallFunction(lf_int
lt_xlfn,la_const ld_XlfOper&l4_param1,la_const ld_XlfOper&l26_param2,
la_const ld_XlfOper&l48_param3,la_const lo_char*l27_errorString){
ld_XlfOper lj_result;la_const l60_LPXLFOPER l31_params[]={l4_param1,
l26_param2,l48_param3};lf_int lh_err=li_XlfExcel::ll_Instance().
l20_Call12v(lt_xlfn,lj_result,3,l31_params);lb_if(lh_err!=
l0_xlretSuccess)ly_throw(lc_string(l27_errorString)+lc_string("\x20"
"\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c"
"\x74\x20\x63\x6f\x64\x65\x20")+l42_to_string(lh_err));le_return
lj_result;}l67_inline ld_XlfOper lu_CallFunction(lf_int lt_xlfn,
la_const ld_XlfOper&l4_param1,la_const ld_XlfOper&l26_param2,la_const
ld_XlfOper&l48_param3,la_const ld_XlfOper&l100_param4,la_const lo_char
 *l27_errorString){ld_XlfOper lj_result;la_const l60_LPXLFOPER
l31_params[]={l4_param1,l26_param2,l48_param3,l100_param4};lf_int
lh_err=li_XlfExcel::ll_Instance().l20_Call12v(lt_xlfn,lj_result,4,
l31_params);lb_if(lh_err!=l0_xlretSuccess)ly_throw(lc_string(
l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
l42_to_string(lh_err));le_return lj_result;}l67_inline lk_void
l7_CallCommand(lf_int l76_xlcmd,la_const lo_char*l27_errorString){
ld_XlfOper lj_result;lf_int lh_err=li_XlfExcel::ll_Instance().
l20_Call12v(l76_xlcmd,lj_result,0,0);lb_if(lh_err!=l0_xlretSuccess)ly_throw
(lc_string(l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64"
"\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65"
"\x20")+l42_to_string(lh_err));}l67_inline lk_void l7_CallCommand(
lf_int l76_xlcmd,la_const ld_XlfOper&l4_param1,la_const lo_char*
l27_errorString){ld_XlfOper lj_result;la_const l60_LPXLFOPER
l31_params[]={l4_param1};lf_int lh_err=li_XlfExcel::ll_Instance().
l20_Call12v(l76_xlcmd,lj_result,1,l31_params);lb_if(lh_err!=
l0_xlretSuccess)ly_throw(lc_string(l27_errorString)+lc_string("\x20"
"\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c"
"\x74\x20\x63\x6f\x64\x65\x20")+l42_to_string(lh_err));}l67_inline
lk_void l7_CallCommand(lf_int l76_xlcmd,la_const ld_XlfOper&l4_param1
,la_const ld_XlfOper&l26_param2,la_const lo_char*l27_errorString){
ld_XlfOper lj_result;la_const l60_LPXLFOPER l31_params[]={l4_param1,
l26_param2};lf_int lh_err=li_XlfExcel::ll_Instance().l20_Call12v(
l76_xlcmd,lj_result,2,l31_params);lb_if(lh_err!=l0_xlretSuccess)ly_throw
(lc_string(l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64"
"\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65"
"\x20")+l42_to_string(lh_err));}l67_inline lk_void l7_CallCommand(
lf_int l76_xlcmd,la_const ld_XlfOper&l4_param1,la_const ld_XlfOper&
l26_param2,la_const ld_XlfOper&l48_param3,la_const lo_char*
l27_errorString){ld_XlfOper lj_result;la_const l60_LPXLFOPER
l31_params[]={l4_param1,l26_param2,l48_param3};lf_int lh_err=
li_XlfExcel::ll_Instance().l20_Call12v(l76_xlcmd,lj_result,3,
l31_params);lb_if(lh_err!=l0_xlretSuccess)ly_throw(lc_string(
l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
l42_to_string(lh_err));}l67_inline lk_void l7_CallCommand(lf_int
l76_xlcmd,la_const ld_XlfOper&l4_param1,la_const ld_XlfOper&
l26_param2,la_const ld_XlfOper&l48_param3,la_const ld_XlfOper&
l100_param4,la_const lo_char*l27_errorString){ld_XlfOper lj_result;
la_const l60_LPXLFOPER l31_params[]={l4_param1,l26_param2,l48_param3,
l100_param4};lf_int lh_err=li_XlfExcel::ll_Instance().l20_Call12v(
l76_xlcmd,lj_result,4,l31_params);lb_if(lh_err!=l0_xlretSuccess)ly_throw
(lc_string(l27_errorString)+lc_string("\x20\x66\x61\x69\x6c\x65\x64"
"\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65"
"\x20")+l42_to_string(lh_err));}}l263_StatusBar_t&l263_StatusBar_t::
l167_operator=(la_const lc_string&l37_message){l7_CallCommand(
l342_xlcMessage,l69_true,l37_message,"\x53\x65\x74\x20\x53\x74\x61"
"\x74\x75\x73\x20\x42\x61\x72");le_return*l154_this;}lk_void
l263_StatusBar_t::l305_clear(){l7_CallCommand(l342_xlcMessage,0,
l34_false,"\x43\x6c\x65\x61\x72\x20\x53\x74\x61\x74\x75\x73\x20\x42"
"\x61\x72");}ld_XlfOper l299_Notes_t::l758_GetNote(la_const ld_XlfOper
&l80_cellRef,lf_int l249_startCharacter,lf_int l338_numChars){lb_if(
l338_numChars==0){le_return lu_CallFunction(l389_xlfGetNote,
l80_cellRef,l249_startCharacter+1,"\x47\x65\x74\x20\x4e\x6f\x74\x65");
}ln_else{le_return lu_CallFunction(l389_xlfGetNote,l80_cellRef,
l249_startCharacter+1,l338_numChars,"\x47\x65\x74\x20\x4e\x6f\x74\x65"
);}}lk_void l299_Notes_t::l646_SetNote(la_const ld_XlfOper&
l80_cellRef,la_const lc_string&l394_note){l7_CallCommand(l370_xlcNote
,l394_note,l80_cellRef,"\x53\x65\x74\x20\x4e\x6f\x74\x65");}lk_void
l299_Notes_t::l641_ClearNote(la_const ld_XlfOper&l80_cellRef){
l7_CallCommand(l370_xlcNote,ld_XlfOper(),l80_cellRef,"\x43\x6c\x65"
"\x61\x72\x20\x4e\x6f\x74\x65");}l18_double l43_Information_t::
l504_GetNow(){le_return lu_CallFunction(l744_xlfNow,"\x47\x65\x74\x20"
"\x4e\x6f\x77").l113_AsDouble();}ld_XlfOper l43_Information_t::
l655_GetCallingCell(){le_return lu_CallFunction(l713_xlfCaller,"\x43"
"\x61\x6c\x6c\x69\x6e\x67\x20\x43\x65\x6c\x6c");}ld_XlfOper
l43_Information_t::l482_GetActiveCell(){le_return lu_CallFunction(
l663_xlfActiveCell,"\x47\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20\x43"
"\x65\x6c\x6c");}ld_XlfOper l43_Information_t::l691_GetActiveRange(){
le_return lu_CallFunction(l648_xlfSelection,"\x47\x65\x74\x20\x41\x63"
"\x74\x69\x76\x65\x20\x52\x61\x6e\x67\x65");}lk_void l43_Information_t
::l642_SetActiveCell(la_const ld_XlfOper&lp_ref){l7_CallCommand(
l411_xlcSelect,lp_ref,"\x53\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20"
"\x43\x65\x6c\x6c");}lc_string l43_Information_t::l741_GetFormula(
la_const ld_XlfOper&l80_cellRef){lf_int l135_flag=(li_XlfExcel::
ll_Instance().l269_isEnglish()?0:l189_xlIntl);le_return
lu_CallFunction(l498_xlfGetFormula|l135_flag,l80_cellRef,"\x47\x65"
"\x74\x20\x46\x6f\x72\x6d\x75\x6c\x61").l79_AsString();}lc_string
l43_Information_t::l581_ConvertA1FormulaToR1C1(lc_string
l494_a1Formula){le_return lu_CallFunction(l376_xlfFormulaConvert,
l494_a1Formula,l69_true,l34_false,1,"\x46\x6f\x72\x6d\x75\x6c\x61\x20"
"\x43\x6f\x6e\x76\x65\x72\x74").l79_AsString();}lc_string
l43_Information_t::l670_ConvertR1C1FormulaToA1(lc_string
l473_r1c1Formula,ls_bool l414_fixRows,ls_bool l503_fixColums){lf_int
l430_toRefType(4-l414_fixRows?2:0-l503_fixColums?1:0);le_return
lu_CallFunction(l376_xlfFormulaConvert,l473_r1c1Formula,l34_false,
l69_true,l430_toRefType,"\x46\x6f\x72\x6d\x75\x6c\x61\x20\x43\x6f\x6e"
"\x76\x65\x72\x74").l79_AsString();}ld_XlfOper l43_Information_t::
l584_GetCellRefA1(lc_string l495_a1Location){le_return lu_CallFunction
(l401_xlfTextref,l495_a1Location,l69_true,"\x54\x65\x78\x74\x20\x52"
"\x65\x66");}ld_XlfOper l43_Information_t::l351_GetCellRefR1C1(
lc_string l534_r1c1Location){le_return lu_CallFunction(
l401_xlfTextref,l534_r1c1Location,l34_false,"\x54\x65\x78\x74\x20\x52"
"\x65\x66");}ld_XlfOper l43_Information_t::l351_GetCellRefR1C1(
ld_XlfOper l453_referenceCell,lc_string l451_r1c1RelativeLocation){
le_return lu_CallFunction(l706_xlfAbsref,l451_r1c1RelativeLocation,
l453_referenceCell,"\x41\x62\x73\x20\x52\x65\x66");}lc_string
l43_Information_t::l720_GetRefTextA1(la_const ld_XlfOper&lp_ref){
le_return lu_CallFunction(l396_xlfReftext,lp_ref,l69_true,"\x52\x65"
"\x66\x20\x54\x65\x78\x74").l79_AsString();}lc_string
l43_Information_t::l600_GetRefTextR1C1(la_const ld_XlfOper&lp_ref){
le_return lu_CallFunction(l396_xlfReftext,lp_ref,l34_false,"\x52\x65"
"\x66\x20\x54\x65\x78\x74").l79_AsString();}lc_string
l43_Information_t::l605_GetSheetName(la_const ld_XlfOper&lp_ref){
le_return lu_CallFunction(l608_xlSheetNm,lp_ref,"\x47\x65\x74\x20\x53"
"\x68\x65\x65\x74\x20\x4e\x61\x6d\x65").l79_AsString();}l543_IDSHEET
l43_Information_t::l613_GetCurrentSheetId(){ld_XlfOper lj_result;
lf_int lh_err=li_XlfExcel::ll_Instance().l20_Call12v(l730_xlSheetId,(
l60_LPXLFOPER)&lj_result,0,0);lb_if(lh_err!=l0_xlretSuccess)ly_throw(
lc_string("\x78\x6c\x53\x68\x65\x65\x74\x49\x64\x20\x66\x61\x69\x6c"
"\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f"
"\x64\x65\x20")+l42_to_string(lh_err));le_return lj_result.
l650_AsShort();}ld_XlfOper l56_Cell_t::l693_GetContents(la_const
ld_XlfOper&lp_ref){lf_int l135_flag=(li_XlfExcel::ll_Instance().
l269_isEnglish()?0:l189_xlIntl);le_return lu_CallFunction(
l498_xlfGetFormula|l135_flag,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20"
"\x46\x6f\x72\x6d\x75\x6c\x61");}lk_void l56_Cell_t::l695_SetContents
(la_const ld_XlfOper&lp_ref,la_const ld_XlfOper&l449_newValue){lf_int
l135_flag=(li_XlfExcel::ll_Instance().l269_isEnglish()?0:l189_xlIntl);
l7_CallCommand(l685_xlcFormula|l135_flag,l449_newValue,lp_ref,"\x53"
"\x65\x74\x20\x43\x65\x6c\x6c\x20\x43\x6f\x6e\x74\x65\x6e\x74\x73");}
l18_double l56_Cell_t::l619_GetHeight(la_const ld_XlfOper&lp_ref){
le_return lu_CallFunction(l141_xlfGetCell,17,lp_ref,"\x47\x65\x74\x20"
"\x43\x65\x6c\x6c\x20\x48\x65\x69\x67\x68\x74").l113_AsDouble();}
lk_void l56_Cell_t::l760_SetHeight(la_const ld_XlfOper&lp_ref,
l18_double l236_newPoints){l7_CallCommand(l662_xlcRowHeight,
l236_newPoints,"\x53\x65\x74\x20\x52\x6f\x77\x20\x48\x65\x69\x67\x68"
"\x74");}l18_double l56_Cell_t::l624_GetWidth(la_const ld_XlfOper&
lp_ref){l18_double l387_distRight(lu_CallFunction(l141_xlfGetCell,44,
lp_ref,"\x47\x65\x74\x20\x52\x69\x67\x68\x74\x20\x50\x6f\x73\x69\x74"
"\x69\x6f\x6e").l113_AsDouble());l18_double l437_distLeft(
lu_CallFunction(l141_xlfGetCell,42,lp_ref,"\x47\x65\x74\x20\x4c\x65"
"\x66\x74\x20\x50\x6f\x73\x69\x74\x69\x6f\x6e").l113_AsDouble());
le_return l387_distRight-l437_distLeft;}lk_void l56_Cell_t::
l751_SetWidth(la_const ld_XlfOper&lp_ref,l18_double l236_newPoints){
l7_CallCommand(l572_xlcColumnWidth,l236_newPoints,"\x53\x65\x74\x20"
"\x43\x65\x6c\x6c\x20\x57\x69\x64\x74\x68");}lc_string l56_Cell_t::
l570_GetFont(la_const ld_XlfOper&lp_ref){le_return lu_CallFunction(
l141_xlfGetCell,18,lp_ref,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46"
"\x6f\x6e\x74").l79_AsString();}lr_namespace{lk_void
l318_setFontProperties(la_const ld_XlfOper&lp_ref,la_const ld_XlfOper
&l429_fontName,la_const ld_XlfOper&l392_fontSize){ld_XlfOper
l447_currentCell(l68_XlfServices.l344_Information.l482_GetActiveCell(
));l68_XlfServices.l61_Commands.l180_Select(lp_ref);ld_XlfOper
l49_missingValue;la_const l60_LPXLFOPER l31_params[]={l429_fontName,
l49_missingValue,l392_fontSize,l49_missingValue,l49_missingValue,
l49_missingValue,l49_missingValue,l49_missingValue,l49_missingValue,
l49_missingValue,l49_missingValue,l49_missingValue,l49_missingValue,
l49_missingValue};lf_int lh_err=li_XlfExcel::ll_Instance().
l20_Call12v(l568_xlcFontProperties,0,14,l31_params);l68_XlfServices.
l61_Commands.l180_Select(l447_currentCell);lb_if(lh_err!=
l0_xlretSuccess)ly_throw(lc_string("\x53\x65\x74\x20\x46\x6f\x6e\x74"
"\x20\x50\x72\x6f\x70\x65\x72\x74\x69\x65\x73\x20\x66\x61\x69\x6c\x65"
"\x64\x20\x77\x69\x74\x68\x20\x63\x6f\x64\x65\x20")+l42_to_string(
lh_err));}}lk_void l56_Cell_t::l651_SetFont(la_const ld_XlfOper&
lp_ref,la_const lc_string&l369_newFont){l318_setFontProperties(lp_ref
,l369_newFont,ld_XlfOper());}l18_double l56_Cell_t::l702_GetFontSize(
la_const ld_XlfOper&lp_ref){le_return lu_CallFunction(l141_xlfGetCell
,19,lp_ref,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x6e\x74").
l113_AsDouble();}lk_void l56_Cell_t::l647_SetFontSize(la_const
ld_XlfOper&lp_ref,l18_double l441_newFontSize){l318_setFontProperties
(lp_ref,ld_XlfOper(),l441_newFontSize);}lc_string l56_Cell_t::
l734_GetFormat(la_const ld_XlfOper&lp_ref){l23_auto l1_res=
lu_CallFunction(l141_xlfGetCell,7,lp_ref,"\x47\x65\x74\x20\x43\x65"
"\x6c\x6c\x20\x46\x6f\x72\x6d\x61\x74");le_return l1_res.
l717_IsString()?l1_res.l79_AsString():"";}lk_void l56_Cell_t::
l672_SetFormat(la_const ld_XlfOper&lp_ref,la_const lc_string&
l492_newFormat){l68_XlfServices.l61_Commands.l180_Select(lp_ref);
ld_XlfOper l151_fmt=l492_newFormat;l7_CallCommand(
l628_xlcFormatNumber,l151_fmt,"\x53\x65\x74\x20\x43\x65\x6c\x6c\x20"
"\x46\x6f\x72\x6d\x61\x74");}lk_void l35_Commands_t::l546_Alert(
la_const lc_string&l37_message){l7_CallCommand(l679_xlcAlert,
l37_message,"\x41\x6c\x65\x72\x74\x20\x43\x6f\x6d\x6d\x61\x6e\x64");}
lc_string l35_Commands_t::l694_InputFormula(la_const lc_string&
l37_message,la_const lc_string&l64_title,la_const lc_string&
l90_defaultValue){le_return lu_CallFunction(l143_xlfInput,l37_message
,0,l64_title,l90_defaultValue,"\x49\x6e\x70\x75\x74\x20\x46\x6f\x72"
"\x6d\x75\x6c\x61").l79_AsString();}l18_double l35_Commands_t::
l633_InputNumber(la_const lc_string&l37_message,la_const lc_string&
l64_title,l18_double l90_defaultValue){le_return lu_CallFunction(
l143_xlfInput,l37_message,1,l64_title,l90_defaultValue,"\x49\x6e\x70"
"\x75\x74\x20\x4e\x75\x6d\x62\x65\x72").l113_AsDouble();}lc_string
l35_Commands_t::l621_InputText(la_const lc_string&l37_message,
la_const lc_string&l64_title,la_const lc_string&l90_defaultValue){
le_return lu_CallFunction(l143_xlfInput,l37_message,2,l64_title,
l90_defaultValue,"\x49\x6e\x70\x75\x74\x20\x54\x65\x78\x74").
l79_AsString();}ls_bool l35_Commands_t::l654_InputBool(la_const
lc_string&l37_message,la_const lc_string&l64_title){le_return
lu_CallFunction(l143_xlfInput,l37_message,4,l64_title,"\x49\x6e\x70"
"\x75\x74\x20\x42\x6f\x6f\x6c").l686_AsBool();}ld_XlfOper
l35_Commands_t::l676_InputReference(la_const lc_string&l37_message,
la_const lc_string&l64_title,la_const lc_string&l90_defaultValue){
le_return lu_CallFunction(l143_xlfInput,l37_message,8,l64_title,
l90_defaultValue,"\x49\x6e\x70\x75\x74\x20\x52\x65\x66\x65\x72\x65"
"\x6e\x63\x65");}ld_XlfOper l35_Commands_t::l558_InputArray(la_const
lc_string&l37_message,la_const lc_string&l64_title){le_return
lu_CallFunction(l143_xlfInput,l37_message,64,l64_title,"\x49\x6e\x70"
"\x75\x74\x20\x41\x72\x72\x61\x79");}lk_void l35_Commands_t::
l180_Select(la_const ld_XlfOper&lp_ref){l7_CallCommand(l411_xlcSelect
,lp_ref,"\x53\x65\x6c\x65\x63\x74\x20\x52\x61\x6e\x67\x65");}
ld_XlfOper l35_Commands_t::l562_ShowDialogBox(la_const ld_XlfOper&
l475_dialogData){le_return lu_CallFunction(l665_xlfDialogBox,
l475_dialogData,"\x53\x68\x6f\x77\x20\x44\x69\x61\x6c\x6f\x67\x20\x42"
"\x6f\x78");}lk_void l35_Commands_t::l718_InsertWorkSheet(){
l7_CallCommand(l530_xlcWorkbookInsert,1,"\x57\x6f\x72\x6b\x73\x68\x65"
"\x65\x74\x20\x49\x6e\x73\x65\x72\x74");}lk_void l35_Commands_t::
l739_InsertMacroWorkSheet(){l7_CallCommand(l530_xlcWorkbookInsert,3,""
"\x49\x6e\x73\x65\x72\x74\x20\x4d\x61\x63\x72\x6f\x20\x53\x68\x65\x65"
"\x74");}lk_void l35_Commands_t::l622_SelectPreviousSheet(){
l7_CallCommand(l603_xlcWorkbookPrev,"\x53\x65\x6c\x65\x63\x74\x20\x50"
"\x72\x65\x76\x69\x6f\x75\x73\x20\x53\x68\x65\x65\x74");}lk_void
l35_Commands_t::l594_SelectNextSheet(){l7_CallCommand(
l578_xlcWorkbookNext,"\x53\x65\x6c\x65\x63\x74\x20\x4e\x65\x78\x74"
"\x20\x53\x68\x65\x65\x74");}lk_void l35_Commands_t::
l737_SetScreenUpdates(ls_bool l517_doesScreenUpdate){l7_CallCommand(
l678_xlcEcho,l517_doesScreenUpdate,"\x45\x63\x68\x6f");}lk_void
l35_Commands_t::l383_SetOnTime(l18_double l195_dt,la_const lc_string&
l118_macroName){l7_CallCommand(l577_xlcOnTime,l195_dt,l118_macroName,""
"\x4f\x6e\x20\x54\x69\x6d\x65");}lk_void l35_Commands_t::
l590_SetOnTimer(l18_double l195_dt,la_const lc_string&l118_macroName){
l23_auto l163_now=l68_XlfServices.l344_Information.l504_GetNow();
l68_XlfServices.l61_Commands.l383_SetOnTime(l163_now+l195_dt/(60.*60.
 *24.),l118_macroName);}lk_void l35_Commands_t::l385_SetOnRecalc(
la_const lc_string&l118_macroName){l7_CallCommand(l728_xlcOnRecalc,
ld_XlfOper(),l118_macroName,"\x4f\x6e\x20\x52\x65\x63\x61\x6c\x63");}
l215_DisableCalculation::l215_DisableCalculation(){
l240_calulationState_=lu_CallFunction(l684_xlfGetDocument,14,"\x47"
"\x65\x74\x20\x44\x6f\x63\x75\x6d\x65\x6e\x74\x20\x70\x72\x6f\x70\x65"
"\x72\x69\x65\x73\x20\x66\x6f\x72\x20\x63\x61\x6c\x63\x75\x6c\x61\x74"
"\x69\x6f\x6e").l705_AsInt();lb_if(l240_calulationState_<3){
l7_CallCommand(l413_xlcOptionsCalculation,3,"\x53\x65\x74\x20\x63\x61"
"\x6c\x63\x75\x6c\x61\x74\x69\x6f\x6e\x20\x6f\x70\x74\x69\x6f\x73\x6e"
);}}l215_DisableCalculation::~l215_DisableCalculation(){lb_if(
l240_calulationState_<3){l7_CallCommand(l413_xlcOptionsCalculation,
l240_calulationState_,"\x53\x65\x74\x20\x63\x61\x6c\x63\x75\x6c\x61"
"\x74\x69\x6f\x6e\x20\x6f\x70\x74\x69\x6f\x73\x6e");}}}l5_using
lr_namespace lz_xlw;l5_using lr_namespace l16_std;l5_using
lr_namespace l172_XLRegistration;l223_XLFunctionRegistrationData::
l223_XLFunctionRegistrationData(la_const lc_string&l367_FunctionName_
,la_const lc_string&l353_ExcelFunctionName_,la_const lc_string&
l398_FunctionDescription_,la_const lc_string&l423_Library_,la_const
l357_Arg l345_Arguments[],lf_int l415_NoOfArguments_,ls_bool
l476_Volatile_,ls_bool l335_Threadsafe_,la_const lc_string&
l507_ReturnTypeCode_,la_const lc_string&l412_HelpID_,ls_bool
l161_Asynchronous_,ls_bool l268_MacroSheetEquivalent_,ls_bool
l307_ClusterSafe_):l22_name(l367_FunctionName_),l145_excel_name(
l353_ExcelFunctionName_),l525_descr(l398_FunctionDescription_),
l245_lib(l423_Library_),l175_nargs(l415_NoOfArguments_),l381_volat(
l476_Volatile_),l348_threadsafe(l335_Threadsafe_),l420_ret_type_code(
l507_ReturnTypeCode_),l122_helpID(l412_HelpID_),l520_asynch(
l161_Asynchronous_),l523_macro_sheet_equiv(l268_MacroSheetEquivalent_
),l380_claster_safe(l307_ClusterSafe_){l41_args.l358_reserve(
l175_nargs);l19_for(lf_int l21_i=0;l21_i<l175_nargs;l21_i++)l41_args.
l289_push_back(l345_Arguments[l21_i]);}
l487_XLFunctionRegistrationHelper::l487_XLFunctionRegistrationHelper(
la_const lc_string&l524_FunctionName,la_const lc_string&
l505_ExcelFunctionName,la_const lc_string&l405_FunctionDescription,
la_const lc_string&l366_Library,la_const l357_Arg l467_Args[],lf_int
l365_NoOfArguments,ls_bool l208_Volatile,ls_bool l178_Threadsafe,
la_const lc_string&l235_returnTypeCode,la_const lc_string&l122_helpID
,ls_bool l230_Asynchronous,ls_bool l234_MacroSheetEquivalent,ls_bool
l179_ClusterSafe){l223_XLFunctionRegistrationData l126_tmp(
l524_FunctionName,l505_ExcelFunctionName,l405_FunctionDescription,
l366_Library,l467_Args,l365_NoOfArguments,l208_Volatile,
l178_Threadsafe,l235_returnTypeCode,l122_helpID,l230_Asynchronous,
l234_MacroSheetEquivalent,l179_ClusterSafe);
l66_ExcelFunctionRegistrationRegistry::ll_Instance().l474_AddFunction
(l126_tmp);}l488_XLCommandRegistrationHelper::
l488_XLCommandRegistrationHelper(la_const lc_string&l386_CommandName,
la_const lc_string&l481_ExcelCommandName,la_const lc_string&
l471_Comment,la_const lc_string&l456_Menu,la_const lc_string&
l442_MenuText){l331_XLCommandRegistrationData l126_tmp(
l386_CommandName,l481_ExcelCommandName,l471_Comment,l456_Menu,
l442_MenuText);l66_ExcelFunctionRegistrationRegistry::ll_Instance().
l287_AddCommand(l126_tmp);}l150_XCHAR*l747_to_xl_str(la_const
l17_wchar_t*l94_str){l24_size_t l181_len=l681_wcslen(l94_str);
l150_XCHAR*l232_excelStr=l88_new l150_XCHAR[l181_len+2];l232_excelStr
[0]=l85_static_cast<l150_XCHAR>(l181_len);l620_wcscpy_s(&
l232_excelStr[1],l181_len+1,l94_str);le_return l232_excelStr;}lk_void
l66_ExcelFunctionRegistrationRegistry::l360_DoTheRegistrations()la_const
{lf_int l13_counter=1;l19_for(l23_auto&[l74__,l70_f]:l107_Functions){
l70_f->l323_Register(l13_counter);++l13_counter;}l19_for(l23_auto&[
l74__,l36_c]:l61_Commands){l36_c->l323_Register(l13_counter);l36_c->
l493_AddToMenuBar();++l13_counter;}}lk_void
l66_ExcelFunctionRegistrationRegistry::l439_DoTheDeregistrations()la_const
{l19_for(l23_auto&[l74__,l70_f]:l107_Functions)l70_f->l260_Unregister
();l19_for(l23_auto&[l74__,l36_c]:l61_Commands){l36_c->
l536_RemoveFromMenuBar();l36_c->l260_Unregister();}}lk_void
l66_ExcelFunctionRegistrationRegistry::l474_AddFunction(la_const
l223_XLFunctionRegistrationData&l6_data){l23_auto l535_policy=l6_data
.l381_volat?l52_XlfFuncDesc::l208_Volatile:l52_XlfFuncDesc::
l709_NotVolatile;l270_shared_ptr<l52_XlfFuncDesc>l253_xlFunction(
l88_new l52_XlfFuncDesc(l6_data.l22_name,l6_data.l145_excel_name,
l6_data.l525_descr,l6_data.l245_lib,l535_policy,l6_data.
l348_threadsafe,l6_data.l420_ret_type_code,l6_data.l122_helpID,
l6_data.l520_asynch,l6_data.l523_macro_sheet_equiv,l6_data.
l380_claster_safe));l82_XlfArgDescList l266_xlFunctionArgs;l19_for(
lf_int l21_i=0;l21_i<l6_data.l175_nargs;++l21_i){l45_XlfArgDesc
l96_arg(l6_data.l41_args[l21_i]);l266_xlFunctionArgs+l96_arg;}
l253_xlFunction->l421_SetArguments(l266_xlFunctionArgs);
l107_Functions[l6_data.l145_excel_name]=l253_xlFunction;}lk_void
l66_ExcelFunctionRegistrationRegistry::l287_AddCommand(la_const
l331_XLCommandRegistrationData&l6_data){l270_shared_ptr<
l54_XlfCmdDesc>l355_theCommand(l88_new l54_XlfCmdDesc(l6_data.
l22_name,l6_data.l145_excel_name,l6_data.l38_comment,l6_data.l58_menu
,l6_data.l614_menu_text,!l6_data.l58_menu.l47_empty()));l61_Commands[
l6_data.l145_excel_name]=l355_theCommand;}lk_void
l66_ExcelFunctionRegistrationRegistry::l519_GenerateChmBuilderConfig(
la_const lc_string&l127_fileName){l325_ofstream lm_outFile(
l127_fileName.l15_c_str());lm_outFile<<"\x3c\x3f\x78\x6d\x6c\x20\x76"
"\x65\x72\x73\x69\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e\x63\x6f\x64"
"\x69\x6e\x67\x3d\"\x75\x74\x66\x2d\x38\"\x20\x3f\x3e"<<lg_endl;
lm_outFile<<"\x3c\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
"\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x61\x6e\x67\x75\x61\x67\x65\x73"
"\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x61\x6e\x67\x75\x61\x67\x65\x20"
"\x69\x64\x3d\"\x31\x30\x33\x33\"\x20\x63\x6f\x64\x65\x70\x61\x67\x65"
"\x3d\"\x36\x35\x30\x30\x31\"\x20\x6e\x61\x6d\x65\x3d\"\x30\x78\x34"
"\x30\x39\x20\x45\x6e\x67\x6c\x69\x73\x68\x20" "\x28\x55\x6e\x69\x74"
"\x65\x64\x20\x53\x74\x61\x74\x65\x73\x29\"\x20\x2f\x3e"<<lg_endl;
lm_outFile<<"\x3c\x2f\x6c\x61\x6e\x67\x75\x61\x67\x65\x73\x3e"<<
lg_endl;lm_outFile<<"\x3c\x63\x68\x6d\x54\x69\x74\x6c\x65\x73\x3e"<<
lg_endl;lm_outFile<<"\x3c\x74\x69\x74\x6c\x65\x20\x70\x72\x6f\x6a\x65"
"\x63\x74\x4e\x61\x6d\x65\x3d\"\x58\x6c\x77\"\x3e\x41\x64\x64\x2d\x69"
"\x6e\x20\x48\x65\x6c\x70\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<lg_endl;
lm_outFile<<"\x3c\x2f\x63\x68\x6d\x54\x69\x74\x6c\x65\x73\x3e"<<
lg_endl;lm_outFile<<"\x3c\x68\x68\x70\x54\x65\x6d\x70\x6c\x61\x74\x65"
"\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x4f\x50\x54"
"\x49\x4f\x4e\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;
lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x43\x6f\x6d\x70\x61\x74\x69\x62"
"\x69\x6c\x69\x74\x79\x3d\x31\x2e\x31\x20\x6f\x72\x20\x6c\x61\x74\x65"
"\x72\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69"
"\x6e\x65\x3e\x43\x6f\x6d\x70\x69\x6c\x65\x64\x20\x66\x69\x6c\x65\x3d"
"\x7b\x30\x7d\x2e\x63\x68\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;
lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x43\x6f\x6e\x74\x65\x6e\x74\x73"
"\x20\x66\x69\x6c\x65\x3d\x7b\x30\x7d\x2e\x68\x68\x63\x3c\x2f\x6c\x69"
"\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x44\x65"
"\x66\x61\x75\x6c\x74\x20\x54\x6f\x70\x69\x63\x3d\x7b\x31\x7d\x3c\x2f"
"\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e"
"\x46\x75\x6c\x6c\x2d\x74\x65\x78\x74\x20\x73\x65\x61\x72\x63\x68\x3d"
"\x59\x65\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c"
"\x6c\x69\x6e\x65\x3e\x4c\x61\x6e\x67\x75\x61\x67\x65\x3d\x7b\x32\x7d"
"\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e"
"\x65\x3e\x54\x69\x74\x6c\x65\x3d\x7b\x33\x7d\x3c\x2f\x6c\x69\x6e\x65"
"\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x46\x49\x4c"
"\x45\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c"
"\x6c\x69\x6e\x65\x3e\x69\x63\x6f\x6e\x73\\\x2a\x2e\x67\x69\x66\x3c"
"\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65"
"\x3e\x61\x72\x74\\\x2a\x2e\x67\x69\x66\x3c\x2f\x6c\x69\x6e\x65\x3e"
<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x6d\x65\x64\x69\x61"
"\\\x2a\x2e\x67\x69\x66\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;
lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x73\x63\x72\x69\x70\x74\x73\\"
"\x2a\x2e\x6a\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<""
"\x3c\x6c\x69\x6e\x65\x3e\x73\x74\x79\x6c\x65\x73\\\x2a\x2e\x63\x73"
"\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69"
"\x6e\x65\x3e\x68\x74\x6d\x6c\\\x2a\x2e\x68\x74\x6d\x3c\x2f\x6c\x69"
"\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x41"
"\x4c\x49\x41\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;lf_int
l13_counter=1;l19_for(l23_auto&[l74__,l70_f]:l107_Functions){
lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x41"<<l13_counter<<"\x3d\x68"
"\x74\x6d\x6c\\"<<l70_f->l12_alias<<"\x2e\x68\x74\x6d\x3c\x2f\x6c\x69"
"\x6e\x65\x3e"<<lg_endl;++l13_counter;}l19_for(l23_auto&[l74__,l36_c]
:l61_Commands){lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x41"<<
l13_counter<<"\x3d\x68\x74\x6d\x6c\\"<<l36_c->l12_alias<<"\x2e\x68"
"\x74\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg_endl;++l13_counter;}
lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x4d\x41\x50\x5d\x3c\x2f\x6c"
"\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e\x23"
"\x69\x6e\x63\x6c\x75\x64\x65\x20\x61\x6c\x69\x61\x73\x2e\x68\x3c\x2f"
"\x6c\x69\x6e\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x6c\x69\x6e\x65\x3e"
"\x5b\x49\x4e\x46\x4f\x54\x59\x50\x45\x53\x5d\x3c\x2f\x6c\x69\x6e\x65"
"\x3e"<<lg_endl;lm_outFile<<"\x3c\x2f\x68\x68\x70\x54\x65\x6d\x70\x6c"
"\x61\x74\x65\x3e"<<lg_endl;lm_outFile<<"\x3c\x2f\x63\x6f\x6e\x66\x69"
"\x67\x75\x72\x61\x74\x69\x6f\x6e\x3e"<<lg_endl;}lk_void
l66_ExcelFunctionRegistrationRegistry::l427_GenerateToc(la_const
lc_string&l127_fileName){l325_ofstream lm_outFile(l127_fileName.
l15_c_str());lm_outFile<<"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73"
"\x69\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67"
"\x3d\"\x75\x74\x66\x2d\x38\"\x3f\x3e"<<lg_endl;lm_outFile<<"\x3c\x74"
"\x6f\x70\x69\x63\x73\x3e"<<lg_endl;lf_int l13_counter=1;lb_if(
l107_Functions.l51_size()>0){lm_outFile<<"\x3c\x74\x6f\x70\x69\x63"
"\x20\x69\x64\x3d\"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\"\x20\x66\x69"
"\x6c\x65\x3d\"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\"\x3e"<<lg_endl;
l19_for(l23_auto&[l74__,l70_f]:l107_Functions){lm_outFile<<"\x3c\x74"
"\x6f\x70\x69\x63\x20\x69\x64\x3d\""<<l70_f->l12_alias<<"\"\x20\x66"
"\x69\x6c\x65\x3d\""<<l70_f->l12_alias<<"\"\x20\x2f\x3e"<<lg_endl;++
l13_counter;}lm_outFile<<"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<lg_endl;
}lb_if(l61_Commands.l51_size()>0){lm_outFile<<"\x3c\x74\x6f\x70\x69"
"\x63\x20\x69\x64\x3d\"\x43\x6f\x6d\x6d\x61\x6e\x64\x73\"\x20\x66\x69"
"\x6c\x65\x3d\"\x43\x6f\x6d\x6d\x61\x6e\x64\x73\"\x3e"<<lg_endl;
l19_for(l23_auto&[l74__,l36_c]:l61_Commands){lm_outFile<<"\x3c\x74"
"\x6f\x70\x69\x63\x20\x69\x64\x3d\""<<l36_c->l12_alias<<"\"\x20\x66"
"\x69\x6c\x65\x3d\""<<l36_c->l12_alias<<"\"\x20\x2f\x3e"<<lg_endl;++
l13_counter;}lm_outFile<<"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<lg_endl;
}lm_outFile<<"\x3c\x2f\x74\x6f\x70\x69\x63\x73\x3e"<<lg_endl;}lk_void
l66_ExcelFunctionRegistrationRegistry::l384_GenerateDocumentation(
la_const lc_string&l86_outputDir){l519_GenerateChmBuilderConfig(
l86_outputDir+"\\\x43\x68\x6d\x42\x75\x69\x6c\x64\x65\x72\x2e\x63\x6f"
"\x6e\x66\x69\x67");l427_GenerateToc(l86_outputDir+"\\\x74\x6f\x63"
"\x2e\x78\x6d\x6c");lf_int l13_counter=1;l19_for(l23_auto&[l74__,
l70_f]:l107_Functions){l70_f->l312_GenerateMamlDocs(l86_outputDir,
l13_counter);++l13_counter;}l19_for(l23_auto&[l74__,l36_c]:
l61_Commands){l36_c->l312_GenerateMamlDocs(l86_outputDir,l13_counter);
++l13_counter;}}l316_extern"\x43"{lk_void l144_EXCEL_EXPORT
l660_xlwGenDoc(la_const lo_char*l86_outputDir){
l66_ExcelFunctionRegistrationRegistry::ll_Instance().
l384_GenerateDocumentation(l86_outputDir);}}
