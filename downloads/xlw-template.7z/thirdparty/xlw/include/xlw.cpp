#include"xlw/CriticalSection.h"
#include"xlw/TempMemory.h"
#include"xlw/ThreadLocalStorage.h"
#include<algorithm>
#include<assert.h>
#include<cctype>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<fstream>
#include<iostream>
#include<locale>
#include<memory>
#include<sstream>
#include<stdexcept>
#include<stdio.h>
#include<string>
#include<sys/stat.h>
#include<vector>
#include<xlw/DataFrame.h>
#include<xlw/HiResTimer.h>
#include<xlw/NCmatrices.h>
#include<xlw/PascalStrConv.h>
#include<xlw/XlFunctionRegistration.h>
#include<xlw/XlOpenClose.h>
#include<xlw/XlfAbstractCmdDesc.h>
#include<xlw/XlfArgDesc.h>
#include<xlw/XlfArgDescList.h>
#include<xlw/XlfCmdDesc.h>
#include<xlw/XlfExcel.h>
#include<xlw/XlfFuncDesc.h>
#include<xlw/XlfOper.h>
#include<xlw/XlfRef.h>
#include<xlw/XlfServices.h>
#include<xlw/XlfWindows.h>
#include<xlw/macros.h>
#include<xlw/xl.h>
#include<xlw/xl_log.h>
#include<xlw/xlcall32.h>
#include<xlw/xlfArgDescList.h>
#include<xlw/xlfCmdDesc.h>
#include<xlw/xlfFuncDesc.h>
#define l8 xlw
#define l193 HiResTimer
#define l579 QueryPerformanceCounter
#define l139 start
#define l3 double
#define l741 elapsed
#define la const
#define l436 LARGE_INTEGER
#define l681 QueryPerformanceFrequency
#define lc return
#define l319 QuadPart
#define l10 using
#define lu namespace
#define l75 NCMatrix
#define l7 data
#define l680 copy
#define l28 size_t
#define l108 new
#define l802 NCMatrixData
#define l184 resize
#define l135 rows
#define l125 columns
#define l472 swap
#define l80 this
#define l206 operator
#define lb if
#define l25 std
#define lt char
#define l162 PascalStrConv
#define l777 WPascalStr2Str
#define l29 wchar_t
#define l5 TempMemory
#define l286 GetMemory
#define l813 WideCharToMultiByte
#define l539 CP_ACP
#define lf int
#define l78 NULL
#define l326 wstring
#define l752 WPascalStr2WStr
#define l754 Str2WPascalStr
#define ld string
#define l172 length
#define l4 cerr
#define l24 XLW__HERE__
#define lg endl
#define l631 MultiByteToWideChar
#define l27 c_str
#define l109 static_cast
#define l208 XCHAR
#define l697 WStr2WPascalStr
#define l702 wcsncpy_s
#define l798 WPascalStrCopy
#define l582 memcpy
#define l194 sizeof
#define l800 WPascalStrNewCopy
#define l714 GetMemoryUsingNew
#define l427 StringUtilities
#define l527 getEnvVar
#define l127 DWORD
#define l43 vector
#define l486 GetEnvironmentVariable
#define l258 class
#define l285 public
#define l473 streambuf
#define l699 protected
#define l546 int_type
#define l661 overflow
#define l254 traits_type
#define l690 eq_int_type
#define l646 eof
#define l707 append
#define l772 to_char_type
#define lr else
#define l574 sync
#define l718 not_eof
#define l566 erase
#define l550 private
#define lj void
#define l268 CerrBufferRedirector
#define l517 rdbuf
#define l37 static
#define l569 MEMORY_BASIC_INFORMATION
#define l297 HMODULE
#define l510 MAX_PATH
#define lq bool
#define l48 empty
#define l616 VirtualQuery
#define l784 LPCVOID
#define l659 AllocationBase
#define l727 GetModuleFileName
#define l88 XlfServices
#define l342 StatusBar
#define l36 false
#define l767 size_type
#define l332 find_last_of
#define l296 substr
#define l760 SetEnvironmentVariable
#define l387 extern
#define l198 EXCEL_EXPORT
#define l764 xl_on_recalc_macro
#define l188 MacroCache
#define l504 Recalc
#define ll Instance
#define l263 ExecuteMacros
#define l345 long
#define l672 xlAutoOpen
#define l265 try
#define li XlfExcel
#define l572 InitializeProcess
#define l9 auto
#define l282 XLRegistration
#define l84 ExcelFunctionRegistrationRegistry
#define l333 has_recalc
#define l806 HasMacros
#define l389 XLCommandRegistrationData
#define l341 AddCommand
#define l400 DoTheRegistrations
#define l119 clear
#define l812 Open
#define l81 Commands
#define l422 SetOnRecalc
#define l242 catch
#define l652 xlAutoClose
#define l770 Close
#define l482 DoTheDeregistrations
#define l533 DeleteInstance
#define l591 TerminateProcess
#define l803 xlAutoRemove
#define l614 Remove
#define l65 true
#define l277 typedef
#define l315 shared_ptr
#define l675 ThreadLocalStorage
#define l755 CriticalSection
#define l499 isThreadDead
#define l49 template
#define l143 struct
#define l392 delete
#define l778 GetBytes
#define l289 GetValue
#define l310 CreateTempMemory
#define l541 InternalGetMemory
#define l747 EnterExportedFunction
#define l411 InternalEnterExportedFunction
#define l811 LeaveExportedFunction
#define l508 InternalLeaveExportedFunction
#define l115 offset_
#define l419 threadId_
#define l485 GetCurrentThreadId
#define l218 depth_
#define l272 InternalFreeMemory
#define l246 while
#define l148 freeList_
#define l51 size
#define l300 pop_back
#define l489 ProtectInScope
#define l793 remove_if
#define l211 begin
#define l103 end
#define l201 get
#define l742 SetValue
#define l336 push_back
#define l390 PushNewBuffer
#define l553 XlfBuffer
#define l607 shared_char_ptr
#define l603 push_front
#define l335 unsigned
#define l302 front
#define l560 max
#define l584 memset
#define l0 for
#define l612 HANDLE
#define l804 OpenThread
#define l637 THREAD_QUERY_INFORMATION
#define l410 FALSE
#define l522 BOOL
#define l716 GetExitCodeThread
#define l756 CloseHandle
#define l785 STILL_ACTIVE
#define l378 map
#define l414 num_fmt
#define l823 get_fmts
#define le XlfOper
#define l397 reserve
#define l73 cols
#define l217 continue
#define l773 find
#define l632 second
#define l42 to_string
#define l12 inline
#define l30 name
#define l500 stat
#define l207 FILE
#define l126 is
#define l59 fprintf
#define l104 as
#define l677 flog_init
#define l278 lib
#define l295 nullptr
#define l678 time_t
#define l783 time
#define l451 tm
#define l708 fopen_s
#define l795 localtime_s
#define l696 fopen
#define l606 localtime
#define l554 strftime
#define l669 log_xlf
#define l676 xltypeName
#define l628 IsMulti
#define l660 PASCAL
#define l350 EXCEL12PROC
#define lw LPXLOPER12
#define l298 FetchExcel12EntryPt
#define l629 GetModuleHandle
#define l726 GetProcAddress
#define l728 _cdecl
#define l248 Excel12
#define l776 va_list
#define l281 xlretFailed
#define l442 xlretInvCount
#define l667 va_start
#define l790 va_arg
#define l797 va_end
#define l665 pascal
#define l407 Excel12v
#define l92 XlfAbstractCmdDesc
#define l136 InvalidFunctionId
#define l145 name_
#define l183 comment_
#define l23 alias
#define l58 comment
#define l368 Register
#define l123 GetName
#define l2 throw
#define l540 GetHelpName
#define l256 ostringstream
#define l116 str
#define l324 DoRegister
#define l11 xlretSuccess
#define l304 Unregister
#define l327 DoUnregister
#define l325 GenerateMamlDocs
#define l307 ofstream
#define l394 DoMamlDocs
#define l60 XlfArgDesc
#define l317 CheckNameLength
#define l50 type_
#define l649 SetName
#define l687 SetComment
#define l157 GetComment
#define l367 GetType
#define l398 xlfOperType
#define l739 xlfXloperType
#define l619 wStrType
#define l507 fpType
#define l105 XlfArgDescList
#define l70 XlfCmdDesc
#define l82 menu
#define l69 menu_
#define l141 text_
#define l599 hidden_
#define l100 funcId_
#define l636 IsAddedToMenuBar
#define l575 AddToMenuBar
#define l22 Call12
#define l200 xlfGetBar
#define l251 IsError
#define l799 xlfAddMenu
#define l814 xlfAddCommand
#define l819 Check
#define l609 xlfCheckCommand
#define l433 RemoveFromMenuBar
#define l639 xlfDeleteCommand
#define l692 xlfDeleteMenu
#define l54 args
#define l450 const_iterator
#define l346 excel12
#define l190 min
#define l31 Call12v
#define l515 xlfRegister
#define l586 IsNumber
#define l147 AsDouble
#define l420 xlfSetName
#define l585 xlfUnregister
#define l526 ostream
#define l824 GetFileAttributes
#define l787 INVALID_FILE_ATTRIBUTES
#define l808 FILE_ATTRIBUTE_DIRECTORY
#define l323 XlfExcelImpl
#define l330 handle_
#define l290 HINSTANCE
#define l130 this_
#define l558 InitLibrary
#define l771 IsEscPressed
#define l618 xlAbort
#define l222 HWND
#define l122 hWnd
#define l409 short
#define l497 loWord
#define l544 CALLBACK
#define l380 LPARAM
#define l710 LOWORD
#define l479 GetClassName
#define l700 lstrcmpi
#define l543 TRUE
#define l476 GetMainWindow
#define l595 XLOPER12
#define l651 xlGetHwnd
#define l152 val
#define l227 w
#define l617 EnumWindows
#define l820 GetExcelInstance
#define l826 GetWindowLongPtr
#define l821 GWLP_HINSTANCE
#define l53 impl_
#define l401 get_excel_version
#define l91 xltype
#define l259 xltypeInt
#define l474 xlfGetWorkspace
#define l638 xlCoerce
#define l320 xltypeStr
#define l825 _wtoi
#define l679 xlFree
#define l719 LoadLibrary
#define l737 excelVersion_
#define l765 xlfOperType_
#define l761 xlfXloperType_
#define l745 wStrType_
#define l642 fpArrayType_
#define l74 LPXLFOPER
#define l487 isEnglish_
#define l759 xlGetName
#define l144 xllFileName_
#define l439 LookForHelp
#define l431 m_mainExcelThread
#define l232 helpFileName_
#define l673 GetXllDirectory
#define l501 npos
#define l165 assert
#define l775 xlCommand
#define l698 xlSpecial
#define l269 xlIntl
#define l792 xlPrompt
#define l549 xltypeRef
#define l809 mref
#define l827 lpmref
#define l535 xltypeMulti
#define l605 xltypeBigData
#define l264 XlfOperImpl
#define l670 xlbitFreeAuxMem
#define l283 bFuncWiz
#define l713 FAR
#define l361 LPEnumStruct
#define l466 EnumProc
#define l301 LPSTR
#define l818 CompareString
#define l666 MAKELCID
#define l758 MAKELANGID
#define l640 LANG_ENGLISH
#define l685 SUBLANG_ENGLISH_US
#define l624 SORT_DEFAULT
#define l634 NORM_IGNORECASE
#define l352 lstrlen
#define l805 GetWindowText
#define l495 strstr
#define l627 IsCalledByFuncWiz
#define l744 EnumThreadWindows
#define l743 WNDENUMPROC
#define l67 XlfFuncDesc
#define l730 RecalcPolicy
#define l155 helpID
#define l279 helpID_
#define l209 returnTypeCode_
#define l648 XlfFuncDescImpl
#define l511 SetArguments
#define l322 arguments_
#define l503 RegisterAs
#define l247 excel14
#define l210 Asynchronous_
#define l766 recalcPolicy_
#define l240 Volatile
#define l386 Threadsafe_
#define l316 ClusterSafe_
#define l313 MacroSheetEquivalent_
#define l748 category_
#define l529 ThrowOnError
#define l654 xlretUncalced
#define l635 xlretAbort
#define l816 xlretStackOvfl
#define l443 xlretInvXloper
#define l828 xlretInvXlfn
#define l630 xlRetInvAsynchronousContext
#define l817 xlretNotClusterSafe
#define l717 MissingOrEmptyError
#define l565 xltypeMissing
#define l429 xltypeErr
#define l468 xltypeNil
#define l815 XlTypeToString
#define l656 xltypeNum
#define l643 xltypeBool
#define l734 xltypeSRef
#define l604 RW
#define l563 COL
#define l523 XlfRef
#define l712 GetTextA1
#define l236 rowbegin_
#define l230 colbegin_
#define l231 colend_
#define l271 rowend_
#define l794 GetTextR1C1
#define l655 Services_t
#define l349 StatusBar_t
#define l577 xlcMessage
#define l321 Notes_t
#define l829 GetNote
#define l424 xlfGetNote
#define l686 SetNote
#define l408 xlcNote
#define l683 ClearNote
#define l63 Information_t
#define l441 GetNow
#define l791 xlfNow
#define l695 GetCallingCell
#define l757 xlfCaller
#define l520 GetActiveCell
#define l706 xlfActiveCell
#define l733 GetActiveRange
#define l684 xlfSelection
#define l682 SetActiveCell
#define l446 xlcSelect
#define l788 GetFormula
#define l314 isEnglish
#define l587 xlfGetFormula
#define l99 AsString
#define l622 ConvertA1FormulaToR1C1
#define l413 xlfFormulaConvert
#define l715 ConvertR1C1FormulaToA1
#define l623 GetCellRefA1
#define l438 xlfTextref
#define l592 GetCellRefR1C1
#define l749 xlfAbsref
#define l769 GetRefTextA1
#define l432 xlfReftext
#define l641 GetRefTextR1C1
#define l645 GetSheetName
#define l650 xlSheetNm
#define l810 IDSHEET
#define l657 GetCurrentSheetId
#define l779 xlSheetId
#define l689 AsShort
#define l72 Cell_t
#define l768 GetContents
#define l740 SetContents
#define l735 xlcFormula
#define l662 GetHeight
#define l177 xlfGetCell
#define l830 SetHeight
#define l703 xlcRowHeight
#define l626 GetWidth
#define l796 SetWidth
#define l615 xlcColumnWidth
#define l611 GetFont
#define l581 Information
#define l215 Select
#define l610 xlcFontProperties
#define l694 SetFont
#define l746 GetFontSize
#define l688 SetFontSize
#define l781 GetFormat
#define l762 IsString
#define l720 SetFormat
#define l671 xlcFormatNumber
#define l45 Commands_t
#define l807 Alert
#define l725 xlcAlert
#define l738 InputFormula
#define l166 xlfInput
#define l674 InputNumber
#define l664 InputText
#define l691 InputBool
#define l736 AsBool
#define l721 InputReference
#define l822 InputArray
#define l602 ShowDialogBox
#define l709 xlfDialogBox
#define l763 InsertWorkSheet
#define l568 xlcWorkbookInsert
#define l786 InsertMacroWorkSheet
#define l668 SelectPreviousSheet
#define l625 xlcWorkbookPrev
#define l647 SelectNextSheet
#define l613 xlcWorkbookNext
#define l782 SetScreenUpdates
#define l723 xlcEcho
#define l421 SetOnTime
#define l620 xlcOnTime
#define l633 SetOnTimer
#define l774 xlcOnRecalc
#define l250 DisableCalculation
#define l275 calulationState_
#define l729 xlfGetDocument
#define l753 AsInt
#define l449 xlcOptionsCalculation
#define l261 XLFunctionRegistrationData
#define l399 Arg
#define l191 excel_name
#define l430 descr
#define l294 nargs
#define l418 volat
#define l576 threadsafe
#define l460 ret_type_code
#define l557 asynch
#define l562 macro_sheet_equiv
#define l417 claster_safe
#define l528 XLFunctionRegistrationHelper
#define l457 AddFunction
#define l448 XLCommandRegistrationHelper
#define l789 to_xl_str
#define l62 len
#define l724 wcslen
#define l663 wcscpy_s
#define l137 Functions
#define l750 NotVolatile
#define l653 menu_text
#define l559 GenerateChmBuilderConfig
#define l471 GenerateToc
#define l498 GenerateDocumentation
#define l701 xlwGenDoc
#define l6 df_type
#define l179 t_num
#define l178 t_str
#define l189 t_bool
#define l124 t_unknown
#define l138 typename
#define l658 floor
#define l506 fabs
#define lx Series
#define l202 num_
#define l175 str_
#define l280 bol_
#define l192 missing
#define l86 v
#define l331 SetError
#define l362 xlerrNA
#define l545 insert
#define l328 switch
#define l93 case
#define l223 break
#define l353 default
#define l360 DataFrame
#define l530 runtime_error
#define l228 index
#define l459 emplace_back
#define l693 to_xl
#define l169 ToXlMode
#define l458 Data
#define l731 DataIndex
#define l608 DataColumns
#define l732 All
#define l780 idx_name
l8::l193::l193(){l579(&l139);}l8::l193::~l193(){}l3 l8::l193::l741()la
{l436 l358;l579(&l358);l436 l379;l681(&l379);lc l3(l358.l319-l139.
l319)/l3(l379.l319);}l10 lu l8;l75::l75(la l75&l187):l7(l187.l7.l680(
)){}l75::l75(l28 l491,l28 l534):l7(l108 l802(l491,l534)){}l75&l75::
l184(l28 l135,l28 l125){l75 l150(l135,l125);l472(l150);lc*l80;}l75&
l75::l206=(la l75&l187){lb(l80!=&l187){l75 l150(l187);l472(l150);}lc*
l80;}l10 lu l8;l10 lu l25;lt*l162::l777(la l29*l71){l28 ln=l71[0];lt*
lk=l5::l286<lt>(ln+1);lk[ln]=0;lb(ln>0){l813(l539,0x00000400,l71+1,(
lf)ln,lk,(lf)ln,l78,l78);}lc lk;}l326 l162::l752(la l29*l71){l28 ln=
l71[0];l326 lk(l71+1,l71+1+ln);lc lk;}l29*l162::l754(la ld&l154){l28
ln(l154.l172());lb(ln>32767){l4<<l24<<"\x53\x74\x72\x69\x6e\x67\x20"
"\x74\x72\x75\x6e\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36"
"\x37\x20\x62\x79\x74\x65\x73"<<lg;ln=32767;}l29*lk=l5::l286<l29>(ln+
2);l631(l539,0,l154.l27(),(lf)ln,lk+1,(lf)ln);lk[ln+1]=0;lk[0]=l109<
l208>(ln);lc lk;}l29*l162::l697(la l326&l154){l28 ln(l154.l172());lb(
ln>32766){l4<<l24<<"\x53\x74\x72\x69\x6e\x67\x20\x74\x72\x75\x6e\x63"
"\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36\x36\x20\x62\x79\x74"
"\x65\x73"<<lg;ln=32766;}l29*lk=l5::l286<l29>(ln+2);l702(lk+1,ln+1,
l154.l27(),ln);lk[ln+1]='\0';lk[0]=l109<l29>(ln);lc lk;}l29*l162::
l798(la l29*l71){l28 ln=l109<l29>(l71[0]);l29*lk=l5::l286<l29>(ln+2);
l582(lk,l71,(ln+1) *l194(l29));lk[ln+1]=0;lc lk;}l29*l162::l800(la l29
 *l71){l28 ln=l109<l29>(l71[0]);l29*lk=l5::l714<l29>(ln+2);l582(lk,
l71,(ln+1) *l194(l29));lk[ln+1]=0;lc lk;}ld l427::l527(la ld&l257){la
l127 l260=4096;l43<lt>lk(l260);l127 l110=l486(l257.l27(),&lk[0],l260);
lb(l260<l110){lk.l184(l110);l110=l486(l257.l27(),&lk[0],l110);}lb(!
l110){l4<<l24<<"\x20\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x62"
"\x74\x61\x69\x6e\x20"<<l257<<"\x20\x45\x6e\x76\x69\x72\x6f\x6e\x6d"
"\x65\x6e\x74\x20\x76\x61\x72\x69\x61\x62\x6c\x65\x20"<<lg;lc"";}lc&
lk[0];}l10 lu l25;lu l8{l258 l117:l285 l473{l285:l117(){}~l117(){}
l699:l546 l661(l546 l237){lb(!l254::l690(l254::l646(),l237)){l351.
l707(1,l254::l772(l237));}lr{lc l574();}lc l254::l718(l237);}lf l574(
){l593();l351.l566();lc 0;}l550:lj l593(){}ld l351;l117(la l117&);
l117&l206=(la l117&);};l258 l268{l285:l268(){l338=l4.l517(&l597);l4<<
l24<<"\x53\x74\x72\x65\x61\x6d\x20\x72\x65\x64\x69\x72\x65\x63\x74"
"\x65\x64\x20\x74\x6f\x20\x4d\x53\x56\x43\x20\x64\x65\x62\x75\x67\x67"
"\x65\x72"<<lg;}~l268(){l4.l517(l338);}l550:l473*l338;l117 l597;};}
l37 l8::l268 l704;lu l8{l258 l241{l285:l241(){l569 l348;l297 l306=l78
;lt l287[l510+1]="";l127 l110=0;ld l371(l427::l527("\x50\x41\x54\x48"
));lq l203(!l371.l48());l110=l109<l127>(l616(((l784)l80),&l348,(l109<
l127>(l194(l569)))));lb(l110){l306=((l297)(l348.l659));l727(l306,l287
,l510);l8::l88.l342=l287;}lr{l203=l36;l4<<l24<<"\x20\x43\x6f\x75\x6c"
"\x64\x20\x6e\x6f\x74\x20\x61\x74\x74\x61\x69\x6e\x20\x70\x61\x74\x68"
"\x20\x6f\x66\x20\x44\x4c\x4c"<<lg;}lb(l203){ld l373(l287);ld l343(
l371);ld::l767 l598=l373.l332("\\");l343+="\x3b"+l373.l296(0,l598);lb
(!l760("\x50\x61\x74\x68",l343.l27())){l4<<l24<<"\x20\x53\x65\x74\x45"
"\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x56\x61\x72\x69\x61\x62\x6c"
"\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x65\x74\x20\x50"
"\x41\x54\x48"<<lg;l203=l36;}lr{l4<<l24<<"\x20\x50\x41\x54\x48\x20"
"\x73\x65\x74\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x20"
<<lg;}}lb(!l203){l4<<l24<<"\x20\x57\x61\x72\x6e\x69\x6e\x67\x3a\x20"
"\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x69\x6e\x69\x74\x69\x61\x6c"
"\x69\x73\x65\x20\x50\x41\x54\x48\x20\x74\x6f\x20\x64\x69\x72\x65\x63"
"\x74\x6f\x72\x79\x20\x6f\x66\x20\x6c\x69\x62\x72\x61\x72\x79\x20"<<
lg;}}~l241(){}};}l10 lu l8;l387"\x43"{lf l198 l764(){l188<l504>::ll().
l263();lc 1;}}l387"\x43"{l345 l198 l672(){l265{li::ll();l5::l572();
l37 l241 l621;l88.l342="\x52\x65\x67\x69\x73\x74\x65\x72\x69\x6e\x67"
"\x20\x6c\x69\x62\x72\x61\x72\x79\x2e\x2e\x2e";l9&l391=l282::l84::ll(
);l9 l333=l188<l504>::ll().l806();lb(l333){l282::l389 l151("\x78\x6c"
"\x5f\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63\x5f\x6d\x61\x63\x72\x6f",""
"\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63\x5f\x6d\x61\x63\x72\x6f","\x6f"
"\x6e\x20\x72\x65\x63\x61\x6c\x63\x20\x6d\x61\x63\x72\x6f\x20","",""
"\x6f\x6e\x20\x72\x65\x63\x61\x6c\x63\x20\x6d\x61\x63\x72\x6f\x20");
l391.l341(l151);}l391.l400();l88.l342.l119();l188<l812>::ll().l263();
lb(l333)l88.l81.l422("\x6f\x6e\x5f\x72\x65\x63\x61\x6c\x63\x5f\x6d"
"\x61\x63\x72\x6f");lc 1;}l242(...){lc 0;}}l37 lq l303=l36;l345 l198
l652(){l265{l4<<l24<<"\x52\x65\x6c\x65\x61\x73\x69\x6e\x67\x20\x72"
"\x65\x73\x6f\x75\x72\x63\x65\x73"<<lg;l188<l770>::ll().l263();lb(
l303){l282::l84::ll().l482();}lr{}li::l533();l5::l591();}l242(...){l4
<<l24<<"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x62\x61\x64\x20\x68"
"\x61\x70\x70\x65\x6e\x65\x64\x20\x69\x6e\x20\x78\x6c\x41\x75\x74\x6f"
"\x43\x6c\x6f\x73\x65"<<lg;}lc 1;}l345 l198 l803(){l265{l4<<l24<<""
"\x41\x64\x64\x69\x6e\x20\x62\x65\x69\x6e\x67\x20\x75\x6e\x6c\x6f\x61"
"\x64\x65\x64"<<lg;l188<l614>::ll().l263();l303=l65;}l242(...){l4<<
l24<<"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x62\x61\x64\x20\x68"
"\x61\x70\x70\x65\x6e\x65\x64\x20\x69\x6e\x20\x78\x6c\x41\x75\x74\x6f"
"\x52\x65\x6d\x6f\x76\x65"<<lg;}lc 1;}}l10 lu l25;l10 lu l8;l277 l315
<l5>l219;lu{l675<l5>l156;l755 l382;l43<l219>l113;}lu{lq l481(la l219&
l525){lc l525->l499();}}lu l8{l49<l258 l38>l143 l454{lj l206()(l38*
l521)la{l392[]l521;}};lt*l5::l778(l28 l112){l5*l57=l156.l289();lb(!
l57)l57=l310();lc l57->l541(l112);}lj l5::l747(){l5*l57=l156.l289();
lb(!l57)l57=l310();l57->l411();}lj l5::l811(){l5*l57=l156.l289();lb(
l57)l57->l508();}l5::l5():l115(0),l419(l485()),l218(0){}l5::~l5(){
l272(l65);}lj l5::l272(lq l462){l28 l377=1;lb(l462)l377=0;l246(l148.
l51()>l377)l148.l300();l115=0;}lj l5::l411(){lb(l218==0)l272(l36);++
l218;}lj l5::l508(){--l218;}l5*l5::l310(){l489 l552(l382);l5*l57=l156
.l289();lb(!l57){l113.l566(l793(l113.l211(),l113.l103(),l481),l113.
l103());l219 l364(l108 l5);l57=l364.l201();l156.l742(l57);l113.l336(
l364);}lc l57;}lj l5::l390(l28 l51){l553 l224;l224.l51=l51;l224.l139=
l607(l108 lt[l51],l454<lt>());;l148.l603(l224);l115=0;l4<<"\x78\x6c"
"\x77\x20\x69\x73\x20\x61\x6c\x6c\x6f\x63\x61\x74\x69\x6e\x67\x20\x61"
"\x20\x6e\x65\x77\x20\x62\x75\x66\x66\x65\x72\x20\x6f\x66\x20"<<l109<
l335 lf>(l51)<<"\x20\x62\x79\x74\x65\x73"<<lg;lc;}lt*l5::l541(l28 l112
){lb(l148.l48())l390(8192);l553&l140=l148.l302();lb(l115+l112>l140.
l51){l390(l560((l140.l51*3)/2,(l115+l112)+4096));l584(l148.l302().
l139.l201(),0,l112);l115=l112;lc l148.l302().l139.l201();}lr{l28 l150
=l115;l584(l140.l139.l201()+l150,0,l112);l115+=l112;lc l140.l139.l201
()+l150;}}lj l5::l572(){}lj l5::l591(){l489 l552(l382);l0(l28 lo(0);
lo<l113.l51();++lo){l113[lo]->l272(l65);}}lq l5::l499()la{l612 l252(
l804(l637,l410,l419));lb(l252){l127 l311(0);l522 lk=l716(l252,&l311);
l756(l252);lb(lk!=0){lb(l311==l785)lc l36;lr lc l65;}lr lc l36;}lr lc
l36;}}l10 lu l25;l10 lu l8;l37 l378<ld,ld>l284;l37 l25::l378<l25::ld,
l25::ld>&l376(){lb(l284.l48()){l284={{"\x64\x61\x74\x65","\x79\x79"
"\x79\x79\x2d\x6d\x6d\x2d\x64\x64"},{"\x74\x69\x6d\x65","\x68\x68\x3a"
"\x6d\x6d\x3a\x73\x73"},{"\x64\x61\x74\x65\x74\x69\x6d\x65","\x79\x79"
"\x79\x79\x2d\x6d\x6d\x2d\x64\x64\x20\x68\x68\x3a\x6d\x6d\x3a\x73\x73"
},{"\x24","\x24\x23\x2c\x23\x23\x30\x2e\x30\x30"},{"\x24\x33","\x24"
"\x23\x2c\x23\x23\x30\x2e\x30\x30\x30"},{"\x24\x34","\x24\x23\x2c\x23"
"\x23\x30\x2e\x30\x30\x30\x30"},{"\x25","\x30\x25"},{"\x25\x31","\x30"
"\x2e\x30\x25"},{"\x25\x32","\x30\x2e\x30\x30\x25"},{"\x67\x65\x6e"
"\x65\x72\x61\x6c","\x47\x65\x6e\x65\x72\x61\x6c"},{"\x6e\x6f\x6e\x65"
,"\x47\x65\x6e\x65\x72\x61\x6c"},{"\x73\x74\x72","\x47\x65\x6e\x65"
"\x72\x61\x6c"},{"\x69\x6e\x74","\x47\x65\x6e\x65\x72\x61\x6c"},{""
"\x6e\x75\x6d","\x47\x65\x6e\x65\x72\x61\x6c"}};};lc l284;}l43<l414>
l8::l823(la le&l21,la ld&l354,lf l253,lf l243,la l378<lf,ld>&l384,lq
l512){lb(l253<=0||l243<=0)lc{};l43<l414>l1;l1.l397(l384.l51());l0(l9&
[l235,l185]:l384){lb(l235>=l21.l73())lc{};lb(l185.l48())l217;l9 l20=
l376().l773(l185);lb(l20==l376().l103())l217;l9 l601=l20->l632;ld lv=
l354.l48()?"\x52":l354+"\x21\x52";lv+=l42(l253+(l512?1:0));lv+="\x43"
;lv+=l42(l243+l235);lv+="\x3a\x52";lv+=l42(l253+l21.l135()-1);lv+=""
"\x43";lv+=l42(l243+l235);l1.l336({lv,l601});}lc l1;}l37 l12 lq l492(
la lt*l30){l143 l500 l140;lc(l500(l30,&l140)==0);}l37 l12 lj l340(
l207*l18,la l8::le&ls){lb(ls.l126<l3>())l59(l18,"\x25\x67",ls.l104<l3
>());lr lb(ls.l126<lf>())l59(l18,"\x25\x64",ls.l104<lf>());lr lb(ls.
l126<lq>())l59(l18,ls.l104<lq>()?"\x54\x52\x55\x45":"\x46\x41\x4c\x53"
"\x45");lr lb(ls.l126<l25::ld>())l59(l18,"\x25\x73",ls.l104<l25::ld>(
).l27());lr l59(l18,"\x4e\x41");}lu l8{l207*l677(la lt*l245,la lt*
l278,la lt*l505,la lt*l181){lb(!l492(l245))lc l295;l25::l678 l204=l25
::l783(0);l25::l451*l212=l295;
#ifdef _MSC_VER
l207*l18=l295;l708(&l18,l245,"\x61\x2b");l25::l451 l375;l795(&l375,&
l204);l212=&l375;
#else
l207*l18=l696(l245,"\x61\x2b");l212=l606(&l204);
#endif
lb(!l18)lc l295;lt l291[128],l238[128];l554(l291,l194(l291),"\x25\x59"
"\x2d\x25\x6d\x2d\x25\x64",l212);l554(l238,l194(l238),"\x25\x48\x3a"
"\x25\x4d\x3a\x25\x53",l212);l25::ld l1="\n\x2d\x2d\x2d";l1+=l505;l1
+="\x3d";l1+=l291;l1+="\x3d";l1+=l238;l1+="\x3d";l1+=l278;l1+="\x3a";
l1+=l181;l1+="\n";l59(l18,l1.l27());lc l18;}lj l669(l207*l18,la l8::
le&ls,la lt*l30){lb(!l18)lc;l59(l18,"\x25\x73\x3c\x25\x73\x3e\x20\x3d"
"\x20",l30,ls.l676().l27());lb(!ls.l628()){l340(l18,ls);l59(l18,"\n");
lc;}l59(l18,"\x28\x25\x64\x2c\x25\x64\x29",ls.l135(),ls.l73());l59(
l18,"\x7b");la lt*l366="";la lt*l531="\x2c";la lt*l567="\x2c\n";la lt
 *l308=l366;l0(lf lo=0;lo<ls.l135();++lo){l59(l18,l308);la lt*l305=
l366;l59(l18,"\x7b");l0(lf l46=0;l46<ls.l73();++l46){l59(l18,l305);
l340(l18,ls(lo,l46));l305=l531;}l59(l18,"\x7d");l308=l567;}l59(l18,""
"\x7d\n");}}l277 lf(l660*l350)(lf ly,lf l801,la lw*l722,lw l751);l297
l249;l350 l142;lj l298(lj){lb(l142==l78){l249=l629(l78);lb(l249!=l78){
l142=(l350)l726(l249,"\x4d\x64\x43\x61\x6c\x6c\x42\x61\x63\x6b\x31"
"\x32");}}}lf l728 l248(lf ly,lw l292,lf l19,...){lw l299[255];l776
l229;lf l196;lf l106;l298();lb(l142==l78)l106=l281;lr{l106=l442;lb((
l19>=0)&&(l19<=255)){l667(l229,l19);l0(l196=0;l196<l19;l196++){l299[
l196]=l790(l229,lw);}l797(l229);l106=(l142)(ly,l19,&l299[0],l292);}}
lc(l106);}lf l665 l407(lf ly,lw l292,lf l19,la lw l445[]){lf l106;
l298();lb(l142==l78){l106=l281;}lr{l106=(l142)(ly,l19,&l445[0],l292);
}lc(l106);}l10 lu l8;l10 lu l25;la l3 l92::l136=-1.0;l92::l92(la ld&
l145,la ld&l426,la ld&l183):l30(l145),l23(l426),l58(l183){}l92::~l92(
){}lj l92::l368(lf l467)la{ld l66=li::ll().l123();lb(l66.l48())l2(""
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x6c\x69\x62"
"\x72\x61\x72\x79\x20\x6e\x61\x6d\x65");ld l374=li::ll().l540();ld
l128;lb(!l374.l48()){l256 l160;l160<<l374<<"\x21"<<l467;l128=l160.
l116();}lf lh=l324(l66,l128);lb(lh!=l11){l4<<l24<<"\x45\x72\x72\x6f"
"\x72\x20"<<lh<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67\x69\x73\x74"
"\x65\x72\x69\x6e\x67\x20"<<l23.l27()<<lg;}lc;}lj l92::l304()la{ld l66
=li::ll().l123();lb(l66.l48())l2("\x43\x6f\x75\x6c\x64\x20\x6e\x6f"
"\x74\x20\x67\x65\x74\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x6e\x61\x6d"
"\x65");lf lh=l327(l66);lb(lh!=l11)l4<<l24<<"\x45\x72\x72\x6f\x72\x20"
<<lh<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72"
"\x69\x6e\x67\x20"<<l23.l27()<<lg;lc;}lj l92::l325(la ld l107,lf l711
)la{l256 l160;l160<<l107<<"\\"<<l23<<"\x2e\x6d\x61\x6d\x6c";l307 lp(
l160.l116().l27());lp<<"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73\x69"
"\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67\x3d"
"\"\x75\x74\x66\x2d\x38\"\x3f\x3e"<<lg;lp<<"\x3c\x74\x6f\x70\x69\x63"
"\x20\x69\x64\x3d\""<<l23<<"\"\x20\x72\x65\x76\x69\x73\x69\x6f\x6e"
"\x4e\x75\x6d\x62\x65\x72\x3d\"\x39\"\x3e"<<lg;lp<<"\x3c\x64\x65\x76"
"\x65\x6c\x6f\x70\x65\x72\x52\x65\x66\x65\x72\x65\x6e\x63\x65\x57\x69"
"\x74\x68\x53\x79\x6e\x74\x61\x78\x44\x6f\x63\x75\x6d\x65\x6e\x74\x20" ""
"\x78\x6d\x6c\x6e\x73\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f\x64\x64\x75"
"\x65\x2e\x73\x63\x68\x65\x6d\x61\x73\x2e\x6d\x69\x63\x72\x6f\x73\x6f"
"\x66\x74\x2e\x63\x6f\x6d\x2f\x61\x75\x74\x68\x6f\x72\x69\x6e\x67\x2f"
"\x32\x30\x30\x33\x2f\x35\"\x20" "\x78\x6d\x6c\x6e\x73\x3a\x78\x6c"
"\x69\x6e\x6b\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x77"
"\x33\x2e\x6f\x72\x67\x2f\x31\x39\x39\x39\x2f\x78\x6c\x69\x6e\x6b\""
"\x3e"<<lg;lp<<"\x3c\x74\x69\x74\x6c\x65\x3e"<<l23<<"\x3c\x2f\x74\x69"
"\x74\x6c\x65\x3e"<<lg;l394(lp);lp<<"\x3c\x72\x65\x6c\x61\x74\x65\x64"
"\x54\x6f\x70\x69\x63\x73\x3e\x3c\x2f\x72\x65\x6c\x61\x74\x65\x64\x54"
"\x6f\x70\x69\x63\x73\x3e"<<lg;lp<<"\x3c\x2f\x64\x65\x76\x65\x6c\x6f"
"\x70\x65\x72\x52\x65\x66\x65\x72\x65\x6e\x63\x65\x57\x69\x74\x68\x53"
"\x79\x6e\x74\x61\x78\x44\x6f\x63\x75\x6d\x65\x6e\x74\x3e"<<lg;lp<<""
"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<lg;}l10 lu l8;l10 lu l25;lj l60::
l317(){lb(l145.l172()>=19)l4<<l24<<"\x41\x72\x67\x75\x6d\x65\x6e\x74"
"\x20\x6e\x61\x6d\x65\x20\""<<l145.l27()<<"\"\x20\x6d\x61\x79\x20\x62"
"\x65\x20\x74\x6f\x6f\x20\x6c\x6f\x6e\x67\x20\x74\x6f\x20\x66\x69\x74"
"\x20\x74\x68\x65\x20\x69\x6e\x20\x74\x68\x65\x20\x66\x75\x6e\x63\x74"
"\x69\x6f\x6e\x20\x77\x69\x7a\x61\x72\x64"<<lg;};l60::l60(){}l60::l60
(la ld&l30,la ld&l58,la ld&l35):l145(l30),l183(l58),l50(l35){l317();}
l60::~l60(){}lj l60::l649(la ld&l30){l145=l30;l317();}la ld&l60::l123
()la{lc l145;}lj l60::l687(la ld&l58){l183=l58;}la ld&l60::l157()la{
lc l183;}ld l60::l367()la{lb(l50=="\x58\x4c\x46\x5f\x4f\x50\x45\x52")lc
li::ll().l398();lr lb(l50=="\x58\x4c\x46\x5f\x58\x4c\x4f\x50\x45\x52"
)lc li::ll().l739();lr lb(l50=="\x58\x4c\x57\x5f\x57\x53\x54\x52")lc
li::ll().l619();lr lb(l50=="\x58\x4c\x57\x5f\x46\x50")lc li::ll().
l507();lr lc l50;}l10 lu l8;l105 l206+(la l60&l578,la l60&l415){lc
l105(l578)+l415;}l10 lu l25;l10 lu l8;l70::l70(la ld&l30,la ld&l23,la
ld&l58,la ld&l82,la ld&l465,lq l536):l92(l30,l23,l58),l69(l82),l141(
l465),l599(l536),l100(l136){}l70::~l70(){}lq l70::l636(){lc!l69.l48();
}lf l70::l575(la lt*l82,la lt*l385){lb(l82)l69=l82;lb(l385)l141=l385;
lb(l69.l48()||l141.l48())lc 0;le l89(10);le l163;le l64;le l337(l69);
lf lh=li::ll().l22(l200,l163,3,l89,l337,le(0));lb(lh||l163.l251()){lf
l186(1);le l221;lh=li::ll().l22(l200,l221,3,l89,le(l186+1),le(0));
l246(!lh&&!l221.l251()){++l186;lh=li::ll().l22(l200,l221,3,l89,le(
l186+1),le(0));}le l76(2,5);l76(0,0)=l69;l76(0,1)="";l76(0,2)="";l76(
0,3)="";l76(0,4)="";l76(1,0)=l141;l76(1,1)=l23;l76(1,2)="";l76(1,3)=
l58;l76(1,4)="";lh=li::ll().l22(l799,0,3,l89,l76,le(l186));lb(lh!=l11
)l4<<l24<<"\x41\x64\x64\x20\x4d\x65\x6e\x75\x20"<<l69.l27()<<"\x20"
"\x66\x61\x69\x6c\x65\x64"<<lg;}lr{le l170(1,4);l170(0,0)=l141;l170(0
,1)=l23;l170(0,2)="";l170(0,3)=l58;lh=li::ll().l22(l814,0,3,l89,l337,
l170);lb(lh!=l11)l4<<l24<<"\x41\x64\x64\x20\x63\x6f\x6d\x6d\x61\x6e"
"\x64\x20"<<l30.l27()<<"\x20\x74\x6f\x20"<<l69.l27()<<"\x20\x66\x61"
"\x69\x6c\x65\x64"<<lg;}lc lh;}lf l70::l819(lq l556)la{lb(l69.l48()){
l4<<l24<<"\x4e\x6f\x20\x6d\x65\x6e\x75\x20\x73\x70\x65\x63\x69\x66"
"\x69\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61"
"\x6e\x64\x20\""<<l30.l27()<<"\""<<lg;lc l281;}lf lh=li::ll().l22(
l609,0,4,le(10),le(l69),le(l141),le(l556));lb(lh!=l11){l4<<l24<<"\x52"
"\x65\x67\x69\x73\x74\x72\x61\x74\x69\x6f\x6e\x20\x6f\x66\x20"<<l23.
l27()<<"\x20\x66\x61\x69\x6c\x65\x64"<<lg;lc lh;}lc l11;}lj l70::l433
(){le l89(10);le l82(l69);le l163;lf lh=li::ll().l22(l200,l163,3,l89,
l82,le(0));lb(!lh&&!l163.l251()){lh=li::ll().l22(l639,0,3,l89,l82,le(
l141));lb(lh!=l11)l4<<l24<<"\x44\x65\x6c\x65\x74\x65\x20\x43\x6f\x6d"
"\x6d\x61\x6e\x64\x20"<<l30.l27()<<"\x20\x66\x72\x6f\x6d\x20"<<l69.
l27()<<"\x20\x66\x61\x69\x6c\x65\x64"<<lg;le l370;lh=li::ll().l22(
l200,l370,3,le(10),l82,le(1));lb(!lh&&l370.l251()){lh=li::ll().l22(
l692,0,2,l89,l82);lb(lh!=l11)l4<<l24<<"\x44\x65\x6c\x65\x74\x65\x20"
"\x4d\x65\x6e\x75\x20"<<l69.l27()<<"\x20\x66\x61\x69\x6c\x65\x64"<<lg
;}}}lf l70::l324(la ld&l66,la ld&l128)la{l105 l39=l54;l3 l35=l599?0:2
;lf l52=l109<lf>(l39.l51());ld l54("\x41");ld l47;l105::l450 l20=l39.
l211();l246(l20!=l39.l103()){l47+=( *l20).l123();l54+=( *l20).l367();
++l20;lb(l20!=l39.l103())l47+="\x2c\x20";}lb(l47.l172()>255)l47="\x54"
"\x6f\x6f\x20\x6d\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73"
"\x20\x66\x6f\x72\x20\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a"
"\x61\x72\x64";l43<lw>l174(10+l52);lw*l14=&l174[0];( *l14++)=le(l66);
( *l14++)=le(l30);( *l14++)=le(l54);( *l14++)=le(l23);( *l14++)=le(
l47);( *l14++)=le(l35);( *l14++)=le("");( *l14++)=le("");( *l14++)=le
("");( *l14++)=le(l58);lf l26(0);l0(l20=l39.l211();l20!=l39.l103();++
l20){++l26;lb(l26<l52)( *l14++)=le(( *l20).l157());lr( *l14++)=le(( *
l20).l157()+"\x2e\x20");}lb(li::ll().l346())l52=l190(l52,245);lr l52=
l190(l52,20);le l1;lf lh=li::ll().l31(l515,l1,10+l52,&l174[0]);lb(lh
==l11&&l1.l586())l100=l1.l147();lr l100=l136;lc lh;}lf l70::l327(la ld
&l66)la{lb(l100!=l136){li::ll().l22(l420,l78,1,le(l23));le l226;lf lh
=li::ll().l22(l585,l226,1,le(l100));lc lh;}lr lc l11;}lj l70::l394(
l526&l13)la{l13<<"\x3c\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69\x6f"
"\x6e\x3e"<<lg;l13<<"\x3c\x70\x61\x72\x61\x3e"<<l58<<"\x3c\x2f\x70"
"\x61\x72\x61\x3e"<<lg;l13<<"\x3c\x2f\x69\x6e\x74\x72\x6f\x64\x75\x63"
"\x74\x69\x6f\x6e\x3e"<<lg;}l10 lu l25;lu{lq l388(la ld&l159){l127
l363(l824(l159.l27()));lc((l363!=l787)&&((l363&l808)==0));}}l143 l8::
l323{l323():l330(0){}l290 l330;};l10 lu l8;li*li::l130=0;li&li::ll(){
lb(!l130){l130=l108 li;l130->l558();}lc*l130;}lj li::l533(){l392 l130
;l130=0;}lq li::l771()la{le l176;l22(l618,l176,1,le(l36));lc l176.
l104<lq>();}lu{l277 l143{l222 l122;l335 l409 l497;}l255;l522 l544 l477
(l222 l122,l380 l469){l255*l199=(l255* )l469;lb(l710(l122)==l199->
l497){lt l312[7];lb(l479(l122,l312,7)!=0){lb(!l700(l312,"\x58\x4c\x4d"
"\x41\x49\x4e")){l199->l122=l122;lc l410;}}}lc l543;}}l222 li::l476(){
l595 l176;lb(l22(l651,&l176,0)==l11){l255 l244={l78,(l335 l409)l176.
l152.l227};l617(l477,(l380)&l244);lb(l244.l122!=l78)lc l244.l122;lr l2
("\x78\x6c\x47\x65\x74\x48\x77\x6e\x64\x20\x6e\x6f\x20\x6d\x61\x74"
"\x63\x68\x20\x66\x6f\x72\x20\x70\x61\x72\x74\x69\x61\x6c\x20\x68\x61"
"\x6e\x64\x6c\x65");}lr l2("\x78\x6c\x47\x65\x74\x48\x77\x6e\x64\x20"
"\x63\x61\x6c\x6c\x20\x66\x61\x69\x6c\x65\x64");}l290 li::l820(){lc(
l290)l826(l476(),l821);}li::li():l53(0){l53=l108 l8::l323();lc;}li::~
li(){l392 l53;l130=0;lc;}lf l401(){lf l181(10);l595 l158,l225,l274,
l273;l274.l91=l273.l91=l259;l274.l152.l227=2;l273.l152.l227=l259;l248
(l474,&l158,1,&l274);l248(l638,&l225,2,&l158,&l273);lb(l225.l91==l259
){l181=l225.l152.l227;}lr lb(l158.l91==l320){l181=l825(l158.l152.l116
+1);}l248(l679,0,1,&l158);lc l181;}lj li::l558(){l290 l355=l719("\x58"
"\x4c\x43\x41\x4c\x4c\x33\x32\x2e\x44\x4c\x4c");lb(l355==0)l2("\x43"
"\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x6c\x69\x62"
"\x72\x61\x72\x79\x20\x58\x4c\x43\x41\x4c\x4c\x33\x32\x2e\x44\x4c\x4c"
);l737=l401();l765="\x51";l761="\x55";l745="\x43\x25";l642="\x4b\x25"
;l53->l330=l355;le l365;lf lh=l22(l474,(l74)l365,1,le(37));lb(lh==l11
)l487=(l365(0,0).l104<lf>()==1);lr{l487=l65;l4<<l24<<"\x43\x6f\x75"
"\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x69\x6e\x74\x65\x72\x6e"
"\x61\x74\x69\x6f\x6e\x61\x6c\x20\x69\x6e\x66\x6f\x2c\x20\x67\x75\x65"
"\x73\x73\x69\x6e\x67\x20\x45\x6e\x67\x6c\x69\x73\x68"<<lg;}le l347;
lh=l22(l759,(l74)l347,0);lb(lh==l11)l144=l347.l104<ld>();lr l4<<l24<<""
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x44\x4c\x4c"
"\x20\x6e\x61\x6d\x65"<<lg;l439();l431=l485();}la ld&li::l123()la{lc
l144;}la ld&li::l540()la{lc l232;}ld li::l673()la{l28 l146(l144.l332(""
"\\\x2f"));lb(l146==ld::l501)lc"\x2e";lr lc l144.l296(0,l146);}lj li
::l439(){l232.l119();l28 l161(l144.l172());lb(l161<5||l144[l161-4]!=
'.')lc;ld l77=l144;l77[l161-3]='c';l77[l161-2]='h';l77[l161-1]='m';lb
(l388(l77)){l232=l77;lc;}l28 l146(l77.l332("\\\x2f"));lb(l146==ld::
l501)lc;l77=l77.l296(0,l146)+"\\\x2e\x2e"+l77.l296(l146);lb(l388(l77))l232
=l77;}lf li::l22(lf ly,lw l41,lf l19)la{l165(l19==0);lc l31(ly,l41,0,
0);}lf li::l22(lf ly,lw l41,lf l19,la lw l15)la{l165(l19==1);lc l31(
ly,l41,1,&l15);}lf li::l22(lf ly,lw l41,lf l19,la lw l15,la lw l34)la
{l165(l19==2);la lw l131[2]={l15,l34};lc l31(ly,l41,2,l131);}lf li::
l22(lf ly,lw l41,lf l19,la lw l15,la lw l34,la lw l68)la{l165(l19==3);
la lw l131[3]={l15,l34,l68};lc l31(ly,l41,3,l131);}lf li::l22(lf ly,
lw l41,lf l19,la lw l15,la lw l34,la lw l68,la lw l134)la{l165(l19==4
);la lw l131[4]={l15,l34,l68,l134};lc l31(ly,l41,4,l131);}lf li::l22(
lf ly,lw l41,lf l19,la lw l15,la lw l34,la lw l68,la lw l134,la lw
l551,la lw l542,la lw l561,la lw l571,la lw l537,la lw l524)la{l165(
l19>=5&&l19<=10);la lw l131[10]={l15,l34,l68,l134,l551,l542,l561,l571
,l537,l524};lc l31(ly,l41,l19,l131);}lf li::l31(lf ly,lw l41,lf l19,
la lw l357[])la{l0(lf lo=0;lo<l19;++lo)lb(!l357[lo]){lb(ly&l775)l4<<
l24<<"\x78\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x7c\x20"<<(ly&0x0FFF)<<
lg;lb(ly&l698)l4<<"\x78\x6c\x53\x70\x65\x63\x69\x61\x6c\x20\x7c\x20"
<<(ly&0x0FFF)<<lg;lb(ly&l269)l4<<"\x78\x6c\x49\x6e\x74\x6c\x20\x7c"
"\x20"<<(ly&0x0FFF)<<lg;lb(ly&l792)l4<<"\x78\x6c\x50\x72\x6f\x6d\x70"
"\x74\x20\x7c\x20"<<(ly&0x0FFF)<<lg;l4<<"\x30\x20\x70\x6f\x69\x6e\x74"
"\x65\x72\x20\x70\x61\x73\x73\x65\x64\x20\x61\x73\x20\x61\x72\x67\x75"
"\x6d\x65\x6e\x74\x20\x23"<<lo<<lg;}lf l83=l407(ly,l41,l19,l357);lb(
l41){lf l35=l41->l91;lq l444=(l35&l320||((l35&l549)&&l41->l152.l809.
l827)||l35&l535||l35&l605);lb(l444)l41->l91|=l264::l670;}lc l83;}lu{
l277 l143 l644{lq l283;}l434,l713*l361;lq l544 l466(l222 l356,l361
l199){la l28 l214=256;lt l149[l214];l479(l356,(l301)l149,l214);lb(2==
l818(l666(l758(l640,l685),l624),l634,(l301)l149,(l352((l301)l149)>
l352("\x62\x6f\x73\x61\x5f\x73\x64\x6d\x5f\x58\x4c"))?l352("\x62\x6f"
"\x73\x61\x5f\x73\x64\x6d\x5f\x58\x4c"):-1,"\x62\x6f\x73\x61\x5f\x73"
"\x64\x6d\x5f\x58\x4c",-1)){lb(l805(l356,l149,l214)){lb(!l495(l149,""
"\x52\x65\x70\x6c\x61\x63\x65")&&!l495(l149,"\x50\x61\x73\x74\x65")){
l199->l283=l543;lc l36;}lr{lc l36;}}}lc l65;}}lq li::l627()la{l434
l270;l270.l283=l36;l744(l431,(l743)l466,(l380)((l361)&l270));lc l270.
l283;}l10 lu l8;l10 lu l25;l67::l67(la ld&l30,la ld&l23,la ld&l58,la
ld&l589,l730 l590,lq l213,la ld&l267,la ld&l155,lq l262,lq l234,lq
l216):l92(l30,l23,l58),l279(l155),l209(l267),l53(l108 l648(l590,l213,
l589,l262,l234,l216)),l100(l136){}l67::~l67(){}lj l67::l511(la l105&
l39){l53->l322=l39;}lf l67::l324(la ld&l66,la ld&l128)la{lb(l209.l48(
))l209=li::ll().l398(l36);lb(l209=="\x58\x4c\x57\x5f\x46\x50")l209=li
::ll().l507();lc l503(l66,l128,1);}lf l67::l327(la ld&l66)la{lb(l100
!=l136){li::ll().l22(l420,l78,1,le(l23));le l226;lf lh=li::ll().l22(
l585,l226,1,le(l100));lc lh;}lr lc l11;}lf l67::l503(la ld&l66,la ld&
l128,l3 l509)la{l105&l39=l53->l322;lf l52=(lf)l39.l51();ld l54="\x51"
;ld l47;lb(li::ll().l247()&&l53->l210)l54="\x3e";l0(l9&l118:l39){l47
+=l118.l123()+"\x2c\x20";l54+=l118.l367();}lb(l52>0){l47.l300();l47.
l300();}lb(l47.l172()>255)l47="\x54\x6f\x6f\x20\x6d\x61\x6e\x79\x20"
"\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f\x72\x20\x46\x75\x6e"
"\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a\x61\x72\x64";lb(li::ll().l247()&&
l53->l210)l54+="\x58";lb(l53->l766==l67::l240)l54+="\x21";lb(li::ll().
l346()&&l53->l386)l54+="\x24";lb(li::ll().l247()&&l53->l316)l54+=""
"\x26";lb(l53->l313)l54+="\x23";l43<lw>l174(10+l52);lw*l14=&l174[0];
l9 l344=l30;lb(li::ll().l247()&&l53->l210)l344+="\x53\x79\x6e\x63";( *
l14++)=le(l66);( *l14++)=le(l344);( *l14++)=le(l54);( *l14++)=le(l23);
( *l14++)=le(l47);( *l14++)=le(l509);( *l14++)=le(l53->l748);( *l14++
)=le("");lb(!l279.l48()&&l279!="\x61\x75\x74\x6f")( *l14++)=le(l279);
lr( *l14++)=le(l128);( *l14++)=le(l58);lf l26=0;l0(l9&l118:l39){++l26
;lb(l26<l52)( *l14++)=le(l118.l157());lr( *l14++)=le(l118.l157()+""
"\x2e\x20");}lb(li::ll().l346())l52=l190(l52,245);lr l52=l190(l52,20);
le l1;lf lh=li::ll().l31(l515,l1,10+l52,&l174[0]);lb(lh==l11&&l1.l586
())l100=l1.l104<l3>();lr l100=l136;lc lh;}lj l67::l394(l526&l13)la{
l13<<"\x3c\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e\x3e"<<lg;
l105&l39=l53->l322;l13<<"\x3c\x70\x61\x72\x61\x3e"<<l58<<"\x3c\x2f"
"\x70\x61\x72\x61\x3e"<<lg;ld l47;l105::l450 l20=l39.l211();l246(l20
!=l39.l103()){l47+=( *l20).l123();++l20;lb(l20!=l39.l103())l47+="\x2c"
"\x20";}l13<<"\x3c\x63\x6f\x64\x65\x3e\x3d"<<l23<<"\x28"<<l47<<"\x29"
"\x3c\x2f\x63\x6f\x64\x65\x3e"<<lg;l13<<"\x3c\x2f\x69\x6e\x74\x72\x6f"
"\x64\x75\x63\x74\x69\x6f\x6e\x3e"<<lg;l13<<"\x3c\x73\x65\x63\x74\x69"
"\x6f\x6e\x3e"<<lg;l13<<"\x20\x20\x3c\x74\x69\x74\x6c\x65\x3e\x50\x61"
"\x72\x61\x6d\x65\x74\x65\x72\x73\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<
lg;l13<<"\x20\x20\x3c\x63\x6f\x6e\x74\x65\x6e\x74\x3e"<<lg;l0(l20=l39
.l211();l20!=l39.l103();++l20){l13<<"\x20\x20\x20\x20\x3c\x70\x61\x72"
"\x61\x3e";l13<<( *l20).l123()<<"\x3a\x20"<<( *l20).l157();l13<<"\x3c"
"\x2f\x70\x61\x72\x61\x3e"<<lg;}l13<<"\x20\x20\x3c\x2f\x63\x6f\x6e"
"\x74\x65\x6e\x74\x3e"<<lg;l13<<"\x3c\x2f\x73\x65\x63\x74\x69\x6f\x6e"
"\x3e"<<lg;}l10 lu l25;lu{ld l94(la lt*l461,la lt*l61,la lt*l96){ld lk
(l461);lb(l61){lk+="\x2c\x20";lk+=l61;}lb(l96){lk+="\x20";lk+=l96;}lc
lk;}}lu l8{lj l264::l529(lf l83,la lt*l61,la lt*l96){lb(l83&l654)l2""
"\x75\x6e\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x64";lb(l83&l635)l2""
"\x61\x62\x6f\x72\x74";lb(l83&l816)l2"\x73\x74\x61\x63\x6b\x20\x6f"
"\x76\x65\x72\x66\x6c\x6f\x77";lb(l83&l443)l2(l94("\x69\x6e\x76\x61"
"\x6c\x69\x64\x20\x4f\x50\x45\x52\x20\x73\x74\x72\x75\x63\x74\x75\x72"
"\x65\x20\x28\x6d\x65\x6d\x6f\x72\x79\x20\x63\x6f\x75\x6c\x64\x20\x62"
"\x65\x20\x65\x78\x68\x61\x75\x73\x74\x65\x64\x29",l61,l96));lb(l83&
l281)l2(l94("\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x61\x69\x6c\x65\x64"
,l61,l96));lb(l83&l442)l2(l94("\x69\x6e\x76\x61\x6c\x69\x64\x20\x6e"
"\x75\x6d\x62\x65\x72\x20\x6f\x66\x20\x61\x72\x67\x75\x6d\x65\x6e\x74"
"\x73",l61,l96));lb(l83&l828)l2(l94("\x69\x6e\x76\x61\x6c\x69\x64\x20"
"\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x75\x6d\x62\x65\x72",l61,
l96));lb(l83&l630)l2(l94("\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x73"
"\x79\x6e\x63\x68\x20\x63\x6f\x6e\x65\x78\x74",l61,l96));lb(l83&l817)l2
(l94("\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x63\x6c"
"\x75\x73\x74\x65\x72\x20\x73\x61\x66\x65",l61,l96));}lj l264::l717(
lf l91,la lt*l61,la lt*l195){lb(l91==l565)l2(l94("\x70\x61\x72\x61"
"\x6d\x65\x74\x65\x72\x20\x69\x73\x20\x6d\x69\x73\x73\x69\x6e\x67",
l61,l195));lb(l91==l429)l2(l94("\x70\x61\x72\x61\x6d\x65\x74\x65\x72"
"\x20\x69\x73\x20\x65\x72\x72\x6f\x72",l61,l195));lb(l91==l468)l2(l94
("\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x73\x20\x6e\x69\x6c",
l61,l195));l529(l443,l61,l195);}ld l264::l815(lf l464){l127 l35=l464&
0xFFF;lb(l35==l656)lc"\x78\x6c\x74\x79\x70\x65\x4e\x75\x6d";lr lb(l35
==l320)lc"\x78\x6c\x74\x79\x70\x65\x53\x74\x72";lr lb(l35==l643)lc""
"\x78\x6c\x74\x79\x70\x65\x42\x6f\x6f\x6c";lr lb(l35==l549)lc"\x78"
"\x6c\x74\x79\x70\x65\x52\x65\x66";lr lb(l35==l429)lc"\x78\x6c\x74"
"\x79\x70\x65\x45\x72\x72";lr lb(l35==l535)lc"\x78\x6c\x74\x79\x70"
"\x65\x4d\x75\x6c\x74\x69";lr lb(l35==l565)lc"\x78\x6c\x74\x79\x70"
"\x65\x4d\x69\x73\x73\x69\x6e\x67";lr lb(l35==l468)lc"\x78\x6c\x74"
"\x79\x70\x65\x4e\x69\x6c";lr lb(l35==l734)lc"\x78\x6c\x74\x79\x70"
"\x65\x53\x52\x65\x66";lr lb(l35==l259)lc"\x78\x6c\x74\x79\x70\x65"
"\x49\x6e\x74";lr lc"\x75\x6e\x6b\x6e\x6f\x77\x6e";}}l10 lu l25;lu{ld
l395(l604 l425,l563 l239){l256 l13;l563 l180=l239;lb(l239>26*26){lt
l153='A'+l180/(26*26)-1;l180%=(26*26);l13<<l153;}lb(l239>26){lt l153=
'A'+l180/26-1;l180%=26;l13<<l153;}{lt l153='A'+l180;l13<<l153;}l13<<
l425+1;lc l13.l116();}}lu l8{ld l523::l712(){ld lk=l395(l236,l230);lb
(l231>l230+1||l271>l236+1){lk+="\x3a";lk+=l395(l271-1,l231-1);}lc lk;
}ld l523::l794(){l256 l13;l13<<"\x52"<<l236+1<<"\x43"<<l230+1;lb(l231
>l230+1||l271>l236+1)l13<<"\x3a"<<"\x52"<<l271<<"\x43"<<l231;lc l13.
l116();}}l10 lu l25;lu l8{l143 l655 l88;lu{l12 le lz(lf ly,la lt*l33){
le lk;lf lh=li::ll().l31(ly,lk,0,0);lb(lh!=l11)l2(ld(l33)+ld("\x20"
"\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c"
"\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));lc lk;}l12 le lz(lf ly,la le
&l15,la lt*l33){le lk;la l74 l40[]={l15};lf lh=li::ll().l31(ly,lk,1,
l40);lb(lh!=l11)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77"
"\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
l42(lh));lc lk;}l12 le lz(lf ly,la le&l15,la le&l34,la lt*l33){le lk;
la l74 l40[]={l15,l34};lf lh=li::ll().l31(ly,lk,2,l40);lb(lh!=l11)l2(
ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72"
"\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));lc lk;}l12 le
lz(lf ly,la le&l15,la le&l34,la le&l68,la lt*l33){le lk;la l74 l40[]=
{l15,l34,l68};lf lh=li::ll().l31(ly,lk,3,l40);lb(lh!=l11)l2(ld(l33)+
ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73"
"\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));lc lk;}l12 le lz(lf
ly,la le&l15,la le&l34,la le&l68,la le&l134,la lt*l33){le lk;la l74
l40[]={l15,l34,l68,l134};lf lh=li::ll().l31(ly,lk,4,l40);lb(lh!=l11)l2
(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72"
"\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));lc lk;}l12 lj
l17(lf l90,la lt*l33){le lk;lf lh=li::ll().l31(l90,lk,0,0);lb(lh!=l11
)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20"
"\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));}l12 lj
l17(lf l90,la le&l15,la lt*l33){le lk;la l74 l40[]={l15};lf lh=li::ll
().l31(l90,lk,1,l40);lb(lh!=l11)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c"
"\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f"
"\x64\x65\x20")+l42(lh));}l12 lj l17(lf l90,la le&l15,la le&l34,la lt
 *l33){le lk;la l74 l40[]={l15,l34};lf lh=li::ll().l31(l90,lk,2,l40);
lb(lh!=l11)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(
lh));}l12 lj l17(lf l90,la le&l15,la le&l34,la le&l68,la lt*l33){le lk
;la l74 l40[]={l15,l34,l68};lf lh=li::ll().l31(l90,lk,3,l40);lb(lh!=
l11)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68"
"\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(lh));}l12
lj l17(lf l90,la le&l15,la le&l34,la le&l68,la le&l134,la lt*l33){le
lk;la l74 l40[]={l15,l34,l68,l134};lf lh=li::ll().l31(l90,lk,4,l40);
lb(lh!=l11)l2(ld(l33)+ld("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+l42(
lh));}}l349&l349::l206=(la ld&l55){l17(l577,l65,l55,"\x53\x65\x74\x20"
"\x53\x74\x61\x74\x75\x73\x20\x42\x61\x72");lc*l80;}lj l349::l119(){
l17(l577,0,l36,"\x43\x6c\x65\x61\x72\x20\x53\x74\x61\x74\x75\x73\x20"
"\x42\x61\x72");}le l321::l829(la le&l111,lf l393,lf l318){lb(l318==0
){lc lz(l424,l111,l393+1,"\x47\x65\x74\x20\x4e\x6f\x74\x65");}lr{lc lz
(l424,l111,l393+1,l318,"\x47\x65\x74\x20\x4e\x6f\x74\x65");}}lj l321
::l686(la le&l111,la ld&l600){l17(l408,l600,l111,"\x53\x65\x74\x20"
"\x4e\x6f\x74\x65");}lj l321::l683(la le&l111){l17(l408,le(),l111,""
"\x43\x6c\x65\x61\x72\x20\x4e\x6f\x74\x65");}l3 l63::l441(){lc lz(
l791,"\x47\x65\x74\x20\x4e\x6f\x77").l147();}le l63::l695(){lc lz(
l757,"\x43\x61\x6c\x6c\x69\x6e\x67\x20\x43\x65\x6c\x6c");}le l63::
l520(){lc lz(l706,"\x47\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20\x43"
"\x65\x6c\x6c");}le l63::l733(){lc lz(l684,"\x47\x65\x74\x20\x41\x63"
"\x74\x69\x76\x65\x20\x52\x61\x6e\x67\x65");}lj l63::l682(la le&lv){
l17(l446,lv,"\x53\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20\x43\x65\x6c"
"\x6c");}ld l63::l788(la le&l111){lf l167=(li::ll().l314()?0:l269);lc
lz(l587|l167,l111,"\x47\x65\x74\x20\x46\x6f\x72\x6d\x75\x6c\x61").l99
();}ld l63::l622(ld l518){lc lz(l413,l518,l65,l36,1,"\x46\x6f\x72\x6d"
"\x75\x6c\x61\x20\x43\x6f\x6e\x76\x65\x72\x74").l99();}ld l63::l715(
ld l513,lq l452,lq l594){lf l475(4-l452?2:0-l594?1:0);lc lz(l413,l513
,l36,l65,l475,"\x46\x6f\x72\x6d\x75\x6c\x61\x20\x43\x6f\x6e\x76\x65"
"\x72\x74").l99();}le l63::l623(ld l440){lc lz(l438,l440,l65,"\x54"
"\x65\x78\x74\x20\x52\x65\x66");}le l63::l592(ld l570){lc lz(l438,
l570,l36,"\x54\x65\x78\x74\x20\x52\x65\x66");}le l63::l592(le l514,ld
l494){lc lz(l749,l494,l514,"\x41\x62\x73\x20\x52\x65\x66");}ld l63::
l769(la le&lv){lc lz(l432,lv,l65,"\x52\x65\x66\x20\x54\x65\x78\x74").
l99();}ld l63::l641(la le&lv){lc lz(l432,lv,l36,"\x52\x65\x66\x20\x54"
"\x65\x78\x74").l99();}ld l63::l645(la le&lv){lc lz(l650,lv,"\x47\x65"
"\x74\x20\x53\x68\x65\x65\x74\x20\x4e\x61\x6d\x65").l99();}l810 l63::
l657(){le lk;lf lh=li::ll().l31(l779,(l74)&lk,0,0);lb(lh!=l11)l2(ld(""
"\x78\x6c\x53\x68\x65\x65\x74\x49\x64\x20\x66\x61\x69\x6c\x65\x64\x20"
"\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20"
)+l42(lh));lc lk.l689();}le l72::l768(la le&lv){lf l167=(li::ll().
l314()?0:l269);lc lz(l587|l167,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20"
"\x46\x6f\x72\x6d\x75\x6c\x61");}lj l72::l740(la le&lv,la le&l463){lf
l167=(li::ll().l314()?0:l269);l17(l735|l167,l463,lv,"\x53\x65\x74\x20"
"\x43\x65\x6c\x6c\x20\x43\x6f\x6e\x74\x65\x6e\x74\x73");}l3 l72::l662
(la le&lv){lc lz(l177,17,lv,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x48"
"\x65\x69\x67\x68\x74").l147();}lj l72::l830(la le&lv,l3 l266){l17(
l703,l266,"\x53\x65\x74\x20\x52\x6f\x77\x20\x48\x65\x69\x67\x68\x74");
}l3 l72::l626(la le&lv){l3 l423(lz(l177,44,lv,"\x47\x65\x74\x20\x52"
"\x69\x67\x68\x74\x20\x50\x6f\x73\x69\x74\x69\x6f\x6e").l147());l3
l478(lz(l177,42,lv,"\x47\x65\x74\x20\x4c\x65\x66\x74\x20\x50\x6f\x73"
"\x69\x74\x69\x6f\x6e").l147());lc l423-l478;}lj l72::l796(la le&lv,
l3 l266){l17(l615,l266,"\x53\x65\x74\x20\x43\x65\x6c\x6c\x20\x57\x69"
"\x64\x74\x68");}ld l72::l611(la le&lv){lc lz(l177,18,lv,"\x47\x65"
"\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x6e\x74").l99();}lu{lj l396(la
le&lv,la le&l470,la le&l428){le l490(l88.l581.l520());l88.l81.l215(lv
);le l64;la l74 l40[]={l470,l64,l428,l64,l64,l64,l64,l64,l64,l64,l64,
l64,l64,l64};lf lh=li::ll().l31(l610,0,14,l40);l88.l81.l215(l490);lb(
lh!=l11)l2(ld("\x53\x65\x74\x20\x46\x6f\x6e\x74\x20\x50\x72\x6f\x70"
"\x65\x72\x74\x69\x65\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74"
"\x68\x20\x63\x6f\x64\x65\x20")+l42(lh));}}lj l72::l694(la le&lv,la ld
&l406){l396(lv,l406,le());}l3 l72::l746(la le&lv){lc lz(l177,19,lv,""
"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x6e\x74").l147();}lj l72
::l688(la le&lv,l3 l484){l396(lv,le(),l484);}ld l72::l781(la le&lv){
l9 l1=lz(l177,7,lv,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x72"
"\x6d\x61\x74");lc l1.l762()?l1.l99():"";}lj l72::l720(la le&lv,la ld
&l532){l88.l81.l215(lv);le l185=l532;l17(l671,l185,"\x53\x65\x74\x20"
"\x43\x65\x6c\x6c\x20\x46\x6f\x72\x6d\x61\x74");}lj l45::l807(la ld&
l55){l17(l725,l55,"\x41\x6c\x65\x72\x74\x20\x43\x6f\x6d\x6d\x61\x6e"
"\x64");}ld l45::l738(la ld&l55,la ld&l79,la ld&l114){lc lz(l166,l55,
0,l79,l114,"\x49\x6e\x70\x75\x74\x20\x46\x6f\x72\x6d\x75\x6c\x61").
l99();}l3 l45::l674(la ld&l55,la ld&l79,l3 l114){lc lz(l166,l55,1,l79
,l114,"\x49\x6e\x70\x75\x74\x20\x4e\x75\x6d\x62\x65\x72").l147();}ld
l45::l664(la ld&l55,la ld&l79,la ld&l114){lc lz(l166,l55,2,l79,l114,""
"\x49\x6e\x70\x75\x74\x20\x54\x65\x78\x74").l99();}lq l45::l691(la ld
&l55,la ld&l79){lc lz(l166,l55,4,l79,"\x49\x6e\x70\x75\x74\x20\x42"
"\x6f\x6f\x6c").l736();}le l45::l721(la ld&l55,la ld&l79,la ld&l114){
lc lz(l166,l55,8,l79,l114,"\x49\x6e\x70\x75\x74\x20\x52\x65\x66\x65"
"\x72\x65\x6e\x63\x65");}le l45::l822(la ld&l55,la ld&l79){lc lz(l166
,l55,64,l79,"\x49\x6e\x70\x75\x74\x20\x41\x72\x72\x61\x79");}lj l45::
l215(la le&lv){l17(l446,lv,"\x53\x65\x6c\x65\x63\x74\x20\x52\x61\x6e"
"\x67\x65");}le l45::l602(la le&l580){lc lz(l709,l580,"\x53\x68\x6f"
"\x77\x20\x44\x69\x61\x6c\x6f\x67\x20\x42\x6f\x78");}lj l45::l763(){
l17(l568,1,"\x57\x6f\x72\x6b\x73\x68\x65\x65\x74\x20\x49\x6e\x73\x65"
"\x72\x74");}lj l45::l786(){l17(l568,3,"\x49\x6e\x73\x65\x72\x74\x20"
"\x4d\x61\x63\x72\x6f\x20\x53\x68\x65\x65\x74");}lj l45::l668(){l17(
l625,"\x53\x65\x6c\x65\x63\x74\x20\x50\x72\x65\x76\x69\x6f\x75\x73"
"\x20\x53\x68\x65\x65\x74");}lj l45::l647(){l17(l613,"\x53\x65\x6c"
"\x65\x63\x74\x20\x4e\x65\x78\x74\x20\x53\x68\x65\x65\x74");}lj l45::
l782(lq l555){l17(l723,l555,"\x45\x63\x68\x6f");}lj l45::l421(l3 l220
,la ld&l171){l17(l620,l220,l171,"\x4f\x6e\x20\x54\x69\x6d\x65");}lj
l45::l633(l3 l220,la ld&l171){l9 l204=l88.l581.l441();l88.l81.l421(
l204+l220/(60.*60.*24.),l171);}lj l45::l422(la ld&l171){l17(l774,le(),
l171,"\x4f\x6e\x20\x52\x65\x63\x61\x6c\x63");}l250::l250(){l275=lz(
l729,14,"\x47\x65\x74\x20\x44\x6f\x63\x75\x6d\x65\x6e\x74\x20\x70\x72"
"\x6f\x70\x65\x72\x69\x65\x73\x20\x66\x6f\x72\x20\x63\x61\x6c\x63\x75"
"\x6c\x61\x74\x69\x6f\x6e").l753();lb(l275<3){l17(l449,3,"\x53\x65"
"\x74\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6f\x6e\x20\x6f\x70\x74"
"\x69\x6f\x73\x6e");}}l250::~l250(){lb(l275<3){l17(l449,l275,"\x53"
"\x65\x74\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6f\x6e\x20\x6f\x70"
"\x74\x69\x6f\x73\x6e");}}}l10 lu l8;l10 lu l25;l10 lu l282;l261::
l261(la ld&l404,la ld&l596,la ld&l435,la ld&l502,la l399 l583[],lf
l455,lq l516,lq l386,la ld&l548,la ld&l447,lq l210,lq l313,lq l316):
l30(l404),l191(l596),l430(l435),l278(l502),l294(l455),l418(l516),l576
(l386),l460(l548),l155(l447),l557(l210),l562(l313),l417(l316){l54.
l397(l294);l0(lf lo=0;lo<l294;lo++)l54.l336(l583[lo]);}l528::l528(la
ld&l564,la ld&l547,la ld&l456,la ld&l403,la l399 l588[],lf l402,lq
l240,lq l213,la ld&l267,la ld&l155,lq l262,lq l234,lq l216){l261 l151
(l564,l547,l456,l403,l588,l402,l240,l213,l267,l155,l262,l234,l216);
l84::ll().l457(l151);}l448::l448(la ld&l412,la ld&l519,la ld&l416,la
ld&l496,la ld&l483){l389 l151(l412,l519,l416,l496,l483);l84::ll().
l341(l151);}l208*l789(la l29*l116){l28 l62=l724(l116);l208*l288=l108
l208[l62+2];l288[0]=l109<l208>(l62);l663(&l288[1],l62+1,l116);lc l288
;}lj l84::l400()la{lf l26=1;l0(l9&[l97,l85]:l137){l85->l368(l26);++
l26;}l0(l9&[l97,l21]:l81){l21->l368(l26);l21->l575();++l26;}}lj l84::
l482()la{l0(l9&[l97,l85]:l137)l85->l304();l0(l9&[l97,l21]:l81){l21->
l433();l21->l304();}}lj l84::l457(la l261&l7){l9 l573=l7.l418?l67::
l240:l67::l750;l315<l67>l359(l108 l67(l7.l30,l7.l191,l7.l430,l7.l278,
l573,l7.l576,l7.l460,l7.l155,l7.l557,l7.l562,l7.l417));l105 l309;l0(
lf lo=0;lo<l7.l294;++lo){l60 l118(l7.l54[lo]);l309+l118;}l359->l511(
l309);l137[l7.l191]=l359;}lj l84::l341(la l389&l7){l315<l70>l538(l108
l70(l7.l30,l7.l191,l7.l58,l7.l82,l7.l653,!l7.l82.l48()));l81[l7.l191]
=l538;}lj l84::l559(la ld&l159){l307 lp(l159.l27());lp<<"\x3c\x3f\x78"
"\x6d\x6c\x20\x76\x65\x72\x73\x69\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65"
"\x6e\x63\x6f\x64\x69\x6e\x67\x3d\"\x75\x74\x66\x2d\x38\"\x20\x3f\x3e"
<<lg;lp<<"\x3c\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
"\x3e"<<lg;lp<<"\x3c\x6c\x61\x6e\x67\x75\x61\x67\x65\x73\x3e"<<lg;lp
<<"\x3c\x6c\x61\x6e\x67\x75\x61\x67\x65\x20\x69\x64\x3d\"\x31\x30\x33"
"\x33\"\x20\x63\x6f\x64\x65\x70\x61\x67\x65\x3d\"\x36\x35\x30\x30\x31"
"\"\x20\x6e\x61\x6d\x65\x3d\"\x30\x78\x34\x30\x39\x20\x45\x6e\x67\x6c"
"\x69\x73\x68\x20" "\x28\x55\x6e\x69\x74\x65\x64\x20\x53\x74\x61\x74"
"\x65\x73\x29\"\x20\x2f\x3e"<<lg;lp<<"\x3c\x2f\x6c\x61\x6e\x67\x75"
"\x61\x67\x65\x73\x3e"<<lg;lp<<"\x3c\x63\x68\x6d\x54\x69\x74\x6c\x65"
"\x73\x3e"<<lg;lp<<"\x3c\x74\x69\x74\x6c\x65\x20\x70\x72\x6f\x6a\x65"
"\x63\x74\x4e\x61\x6d\x65\x3d\"\x58\x6c\x77\"\x3e\x41\x64\x64\x2d\x69"
"\x6e\x20\x48\x65\x6c\x70\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<lg;lp<<""
"\x3c\x2f\x63\x68\x6d\x54\x69\x74\x6c\x65\x73\x3e"<<lg;lp<<"\x3c\x68"
"\x68\x70\x54\x65\x6d\x70\x6c\x61\x74\x65\x3e"<<lg;lp<<"\x3c\x6c\x69"
"\x6e\x65\x3e\x5b\x4f\x50\x54\x49\x4f\x4e\x53\x5d\x3c\x2f\x6c\x69\x6e"
"\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x43\x6f\x6d\x70\x61\x74"
"\x69\x62\x69\x6c\x69\x74\x79\x3d\x31\x2e\x31\x20\x6f\x72\x20\x6c\x61"
"\x74\x65\x72\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e"
"\x65\x3e\x43\x6f\x6d\x70\x69\x6c\x65\x64\x20\x66\x69\x6c\x65\x3d\x7b"
"\x30\x7d\x2e\x63\x68\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c"
"\x6c\x69\x6e\x65\x3e\x43\x6f\x6e\x74\x65\x6e\x74\x73\x20\x66\x69\x6c"
"\x65\x3d\x7b\x30\x7d\x2e\x68\x68\x63\x3c\x2f\x6c\x69\x6e\x65\x3e"<<
lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x44\x65\x66\x61\x75\x6c\x74\x20\x54"
"\x6f\x70\x69\x63\x3d\x7b\x31\x7d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp
<<"\x3c\x6c\x69\x6e\x65\x3e\x46\x75\x6c\x6c\x2d\x74\x65\x78\x74\x20"
"\x73\x65\x61\x72\x63\x68\x3d\x59\x65\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"
<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x4c\x61\x6e\x67\x75\x61\x67\x65"
"\x3d\x7b\x32\x7d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69"
"\x6e\x65\x3e\x54\x69\x74\x6c\x65\x3d\x7b\x33\x7d\x3c\x2f\x6c\x69\x6e"
"\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x46\x49\x4c\x45\x53"
"\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e"
"\x69\x63\x6f\x6e\x73\\\x2a\x2e\x67\x69\x66\x3c\x2f\x6c\x69\x6e\x65"
"\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x61\x72\x74\\\x2a\x2e\x67"
"\x69\x66\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65"
"\x3e\x6d\x65\x64\x69\x61\\\x2a\x2e\x67\x69\x66\x3c\x2f\x6c\x69\x6e"
"\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x73\x63\x72\x69\x70\x74"
"\x73\\\x2a\x2e\x6a\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c"
"\x6c\x69\x6e\x65\x3e\x73\x74\x79\x6c\x65\x73\\\x2a\x2e\x63\x73\x73"
"\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x68"
"\x74\x6d\x6c\\\x2a\x2e\x68\x74\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;
lp<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x41\x4c\x49\x41\x53\x5d\x3c\x2f\x6c"
"\x69\x6e\x65\x3e"<<lg;lf l26=1;l0(l9&[l97,l85]:l137){lp<<"\x3c\x6c"
"\x69\x6e\x65\x3e\x41"<<l26<<"\x3d\x68\x74\x6d\x6c\\"<<l85->l23<<""
"\x2e\x68\x74\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;++l26;}l0(l9&[l97,
l21]:l81){lp<<"\x3c\x6c\x69\x6e\x65\x3e\x41"<<l26<<"\x3d\x68\x74\x6d"
"\x6c\\"<<l21->l23<<"\x2e\x68\x74\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<
lg;++l26;}lp<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x4d\x41\x50\x5d\x3c\x2f"
"\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x23\x69\x6e"
"\x63\x6c\x75\x64\x65\x20\x61\x6c\x69\x61\x73\x2e\x68\x3c\x2f\x6c\x69"
"\x6e\x65\x3e"<<lg;lp<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x49\x4e\x46\x4f"
"\x54\x59\x50\x45\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<lg;lp<<"\x3c"
"\x2f\x68\x68\x70\x54\x65\x6d\x70\x6c\x61\x74\x65\x3e"<<lg;lp<<"\x3c"
"\x2f\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3e"<<lg;}
lj l84::l471(la ld&l159){l307 lp(l159.l27());lp<<"\x3c\x3f\x78\x6d"
"\x6c\x20\x76\x65\x72\x73\x69\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e"
"\x63\x6f\x64\x69\x6e\x67\x3d\"\x75\x74\x66\x2d\x38\"\x3f\x3e"<<lg;lp
<<"\x3c\x74\x6f\x70\x69\x63\x73\x3e"<<lg;lf l26=1;lb(l137.l51()>0){lp
<<"\x3c\x74\x6f\x70\x69\x63\x20\x69\x64\x3d\"\x46\x75\x6e\x63\x74\x69"
"\x6f\x6e\x73\"\x20\x66\x69\x6c\x65\x3d\"\x46\x75\x6e\x63\x74\x69\x6f"
"\x6e\x73\"\x3e"<<lg;l0(l9&[l97,l85]:l137){lp<<"\x3c\x74\x6f\x70\x69"
"\x63\x20\x69\x64\x3d\""<<l85->l23<<"\"\x20\x66\x69\x6c\x65\x3d\""<<
l85->l23<<"\"\x20\x2f\x3e"<<lg;++l26;}lp<<"\x3c\x2f\x74\x6f\x70\x69"
"\x63\x3e"<<lg;}lb(l81.l51()>0){lp<<"\x3c\x74\x6f\x70\x69\x63\x20\x69"
"\x64\x3d\"\x43\x6f\x6d\x6d\x61\x6e\x64\x73\"\x20\x66\x69\x6c\x65\x3d"
"\"\x43\x6f\x6d\x6d\x61\x6e\x64\x73\"\x3e"<<lg;l0(l9&[l97,l21]:l81){
lp<<"\x3c\x74\x6f\x70\x69\x63\x20\x69\x64\x3d\""<<l21->l23<<"\"\x20"
"\x66\x69\x6c\x65\x3d\""<<l21->l23<<"\"\x20\x2f\x3e"<<lg;++l26;}lp<<""
"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<lg;}lp<<"\x3c\x2f\x74\x6f\x70\x69"
"\x63\x73\x3e"<<lg;}lj l84::l498(la ld&l107){l559(l107+"\\\x43\x68"
"\x6d\x42\x75\x69\x6c\x64\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67");l471(
l107+"\\\x74\x6f\x63\x2e\x78\x6d\x6c");lf l26=1;l0(l9&[l97,l85]:l137){
l85->l325(l107,l26);++l26;}l0(l9&[l97,l21]:l81){l21->l325(l107,l26);
++l26;}}l387"\x43"{lj l198 l701(la lt*l107){l84::ll().l498(l107);}}
l10 lu l8;l10 lu l25;l37 l12 l6 l493(la le&ls){lb(ls.l126<l3>())lc l6
::l179;lb(ls.l126<ld>())lc l6::l178;lb(ls.l126<lq>())lc l6::l189;lc l6
::l124;}l49<l138 l38>l12 l6 l182(){lc l6::l124;}l49<>l12 l6 l182<l3>(
){lc l6::l179;}l49<>l12 l6 l182<ld>(){lc l6::l178;}l49<>l12 l6 l182<
lq>(){lc l6::l189;}l143 l197{lf l129;lf l95;lf l132;lf l102;};l37 l12
l197 l381(la le&l56,lf lo,lf l32,lq l437){lb(l437)lc{l32,l56.l135()-
l32,lo,lo>=l56.l73()?0:1};lc{lo,lo>=l56.l135()?0:1,l32,l56.l73()-l32}
;}l37 l12 l6 l488(la le&l56,la l197&l16){l0(lf l121=l16.l129;l121<l16
.l129+l16.l95;++l121)l0(lf l21=l16.l132;l21<l16.l132+l16.l102;++l21){
l9 l369=l493(l56(l121,l21));lb(l369!=l6::l124)lc l369;}lc l6::l124;}
l37 l12 ld l705(l3 ls){lb(l658(l506(ls))==l506(ls))lc l42((lf)ls);lc
l42(ls);}l37 l12 lj l205(lx&lm){lm.l50=l6::l124;lm.l202.l119();lm.
l175.l119();lm.l280.l119();lm.l192.l119();}l49<l138 l38>lj l87(lx&lm){
l205(lm);lm.l50=l182<l38>();}l49<l138 l38>lj l276(la lx&lm,le&ls,la
l197&l44,lf ln){lf l133=0;la l9&l480=lm.l86<l38>();l0(lf lo=l44.l129;
lo<l44.l129+l44.l95;++lo)l0(lf l46=l44.l132;l46<l44.l132+l44.l102;++
l46){lb(l133>=ln)lc;ls(lo,l46)=l480[l133];++l133;}lb(l44.l95==1){l0(
l9 lo:lm.l192){lb(lo>=ln)l217;ls(l44.l129,l44.l132+lo).l331(l362);}}
lr{l0(l9 lo:lm.l192){lb(lo>=ln)l217;ls(l44.l129+lo,l44.l132).l331(
l362);}}lc;}l49<l138 l38>lj l233(lx&lm,la le&l56,la l197&l16){l87<l38
>(lm);l9&l329=lm.l86<l38>();l329.l184(l16.l95*l16.l102);lf l133=0;l0(
lf l121=0;l121<l16.l95;++l121)l0(lf l21=0;l21<l16.l102;++l21){l265{
l329[l133]=l56(l16.l129+l121,l16.l132+l21).l104<l38>();}l242(...){lm.
l192.l545(l133);}++l133;}}l37 l12 lf l168(la lx&lm,le&ls,lf lo,lf l32
=1,lq l98=l65){lb(lm.l50==l6::l124)lc 0;l9 l44=l381(ls,lo,l32,l98);lf
l383=lm.l62();lf ln=l190(l44.l102*l44.l95,l383);l328(lm.l50){l93 l6::
l179:l276<l3>(lm,ls,l44,ln);l223;l93 l6::l178:l276<ld>(lm,ls,l44,ln);
l223;l93 l6::l189:l276<lq>(lm,ls,l44,ln);l223;l353:l223;}lc l560(l383
-ln,0);}l37 l12 le l168(la lx&lm,lq l98=l65){le l334(l98?lm.l62():1,
l98?1:lm.l62());l168(lm,l334,0,0,l98);lc l334;}l37 l12 lj l453(lx&lm){
l0(lf lo=0;lo<lm.l62();++lo)lm.l192.l545(lo);}l37 l12 l28 l339(la lx&
lm){l328(lm.l50){l93 l6::l179:lc lm.l202.l51();l93 l6::l178:lc lm.
l175.l51();l93 l6::l189:lc lm.l280.l51();l353:lc 0;}}l37 lj l87(lx&lm
,la le&l56,lf lo,lf l32=1,lq l98=l65,lf ln=-1){lb(ln==0||l56.l126<lj>
()){l205(lm);lc;}l9 l16=l381(l56,lo,l32,l98);lb(ln>0){lb(l16.l102!=1){
lb(l16.l102>ln)l16.l102=ln;}lr{lb(l16.l95>ln)l16.l95=ln;}}lm.l50=l488
(l56,l16);l328(lm.l50){l93 l6::l179:l233<l3>(lm,l56,l16);lc;l93 l6::
l178:l233<ld>(lm,l56,l16);lc;l93 l6::l189:l233<lq>(lm,l56,l16);lc;l93
l6::l124:lm.l50=l6::l178;lm.l175.l119();lm.l175.l184(l16.l95*l16.l102
,"");l453(lm);lc;l353:l205(lm);lc;}}l37 l12 lj l87(lx&lm,lf ln,l3 ls=
0.0){l205(lm);lm.l50=l6::l179;lm.l202.l184(ln,ls);}l49<l138 l38>lj l87
(lx&lm,la l43<l38>&l120){lm.l50=l182<l38>();lm.l86<l38>()=l120;}l37
l12 lj l87(lx&lm,la lx&l405){lm=l405;}lx::lx(la le&ls,lf lo,lf l32,lq
l98,lf ln){l87( *l80,ls,lo,l32,l98,ln);}lx::lx(lf ln,l3 ls){l87( *l80
,ln,ls);}lx::lx(la l43<l3>&l120){l87( *l80,l120);}lx::lx(la l43<ld>&
l120){l87( *l80,l120);}lx::lx(la l43<lq>&l120){l87( *l80,l120);}lq lx
::l48()la{lc l50==l6::l124||l339( *l80)==0;}lf lx::l62()la{lc(lf)l339
( *l80);}l49<l138 l38>la l43<l38>&lx::l86()la{l2("\x23\x20\x62\x61"
"\x64\x20\x74\x79\x70\x65");}l49<>la l43<l3>&lx::l86()la{lc l202;}l49
<>la l43<ld>&lx::l86()la{lc l175;}l49<>la l43<lq>&lx::l86()la{lc l280
;}l49<l138 l38>l43<l38>&lx::l86(){l2("\x23\x20\x62\x61\x64\x20\x74"
"\x79\x70\x65");}l49<>l43<l3>&lx::l86(){lc l202;}l49<>l43<ld>&lx::l86
(){lc l175;}l49<>l43<lq>&lx::l86(){lc l280;}l360::l360(la le&ls,la lx
 *l73,la lx*l164){lf l101=l73?0:1;lf l32=l164?0:1;lb(l73&&l73->l62()!=
ls.l73()-l32)l2 l530("\x63\x6f\x6c\x75\x6d\x6e\x73\x20\x6c\x65\x6e"
"\x67\x74\x68\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63"
"\x68\x20\x64\x61\x74\x61");lb(l164&&l164->l62()!=ls.l135()-l101)l2
l530("\x69\x6e\x64\x65\x78\x20\x6c\x65\x6e\x67\x74\x68\x20\x64\x6f"
"\x65\x73\x20\x6e\x6f\x74\x20\x6d\x61\x74\x63\x68\x20\x64\x61\x74\x61"
);lb(l73)l125= *l73;lr l125=lx(ls,0,l32,l36);lb(l164)l228= *l164;lr
l228=lx(ls,0,l101);lb(l125.l62()==0)lc;l7.l459(ls,l32,l101);l0(lf lo=
1;lo<l125.l62();++lo)l7.l459(ls,lo+l32,l101);}le l360::l693(l169 l173
)la{lf l372=l228.l62();lf l293=l125.l62();lf l101=l173==l169::l458||
l173==l169::l731?0:1;lf l32=l173==l169::l458||l173==l169::l608?0:1;le
l1(l372+l101,l293+l32);lb(l173==l169::l732)l1(0,0)=l780;lb(l101==1)l168
(l125,l1,0,1,l36);lb(l32==1)l168(l228,l1,0);lb(l7.l48()){l0(lf lo=0;
lo<l372;++lo)l0(lf l46=0;l46<l293;++l46)l1(lo+l101,l46+l32).l331(l362
);lc l1;}l0(lf l46=0;l46<l293;++l46)l168(l7[l46],l1,l46+l32,l101);lc
l1;}
