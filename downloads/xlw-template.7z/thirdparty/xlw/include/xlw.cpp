#include<xlw/HiResTimer.h>
#include<xlw/NCmatrices.h>
#include<algorithm>
#include<cctype>
#include<iostream>
#include<locale>
#include<vector>
#include<xlw/PascalStringConversions.h>
#include<xlw/TempMemory.h>
#include<xlw/macros.h>
#include<memory>
#include<string>
#include<xlw/XlFunctionRegistration.h>
#include<xlw/XlOpenClose.h>
#include<xlw/XlfServices.h>
#include<xlw/XlfWindows.h>
#include<xlw/CriticalSection.h>
#include<xlw/ThreadLocalStorage.h>
#include<xlw/xl.h>
#include<ctime>
#include<sys/stat.h>
#include<xlw/xl_log.h>
#include<xlw/xlcall32.h>
#include<fstream>
#include<sstream>
#include<stdexcept>
#include<xlw/XlfAbstractCmdDesc.h>
#include<xlw/XlfExcel.h>
#include<xlw/XlfArgDesc.h>
#include<xlw/XlfArgDescList.h>
#include<xlw/XlfCmdDesc.h>
#include<xlw/XlfOper.h>
#include<assert.h>
#include<cstdio>
#include<cstdlib>
#include<xlw/XlfFuncDesc.h>
#include<xlw/XlfRef.h>
#include<stdio.h>
#include<xlw/xlfArgDescList.h>
#include<xlw/xlfCmdDesc.h>
#include<xlw/xlfFuncDesc.h>

#define lg xlw
#define l157 HiResTimer
#define l540 QueryPerformanceCounter
#define l369 m_start
#define l16 double
#define l704 elapsed
#define lb const
#define l511 LARGE_INTEGER
#define l643 QueryPerformanceFrequency
#define le return
#define l264 QuadPart
#define l68 NCMatrix
#define l310 theData
#define l646 copy
#define l18 size_t
#define l85 new
#define l757 NCMatrixData
#define l254 resize
#define l165 rows
#define l398 columns
#define l434 swap
#define l129 this
#define l142 operator
#define ld if
#define lp char
#define l143 PascalStringConversions
#define l663 WPascalStringToString
#define l15 wchar_t
#define ly TempMemory
#define l244 GetMemory
#define l552 WideCharToMultiByte
#define l500 CP_ACP
#define lh int
#define l72 NULL
#define la std
#define l300 wstring
#define l734 WPascalStringToWString
#define l722 StringToWPascalString
#define lc string
#define l136 length
#define lx cerr
#define l8 XLW__HERE__
#define li endl
#define l595 MultiByteToWideChar
#define l13 c_str
#define l86 static_cast
#define l160 XCHAR
#define l587 WStringToWPascalString
#define l648 wcsncpy_s
#define l752 WPascalStringCopy
#define l407 memcpy
#define l156 sizeof
#define l608 WPascalStringCopyUsingNew
#define l674 GetMemoryUsingNew
#define l278 StringUtilities
#define l537 getEnvironmentVariable
#define l90 DWORD
#define l119 vector
#define l447 GetEnvironmentVariable
#define l740 getCurrentDirectory
#define l472 GetCurrentDirectory
#define l26 namespace
#define l185 class
#define l225 public
#define l432 streambuf
#define l656 protected
#define l506 int_type
#define l621 overflow
#define l211 traits_type
#define l647 eq_int_type
#define l606 eof
#define l670 append
#define l730 to_char_type
#define lq else
#define l532 sync
#define l681 not_eof
#define l522 erase
#define l513 private
#define lm void
#define l233 CerrBufferRedirector
#define l471 rdbuf
#define l109 static
#define l531 MEMORY_BASIC_INFORMATION
#define l253 HMODULE
#define l467 MAX_PATH
#define lt bool
#define l45 empty
#define l581 VirtualQuery
#define l738 LPCVOID
#define l623 AllocationBase
#define l688 GetModuleFileName
#define l79 XlfServices
#define l282 StatusBar
#define l34 false
#define l720 size_type
#define l298 find_last_of
#define l236 substr
#define l721 SetEnvironmentVariable
#define l412 extern
#define l279 long
#define l222 EXCEL_EXPORT
#define l637 xlAutoOpen
#define l311 try
#define lk XlfExcel
#define ln Instance
#define l541 InitializeProcess
#define l283 XLRegistration
#define l69 ExcelFunctionRegistrationRegistry
#define l359 DoTheRegistrations
#define l262 clear
#define l301 MacroCache
#define l549 Open
#define l318 ExecuteMacros
#define l284 catch
#define l616 xlAutoClose
#define l726 Close
#define l440 DoTheDeregistrations
#define l479 DeleteInstance
#define l349 TerminateProcess
#define l759 xlAutoRemove
#define l579 Remove
#define l75 true
#define l242 typedef
#define l275 shared_ptr
#define l639 ThreadLocalStorage
#define l712 CriticalSection
#define l382 isThreadDead
#define l593 template
#define l137 struct
#define l323 delete
#define l729 GetBytes
#define l228 GetValue
#define l270 CreateTempMemory
#define l503 InternalGetMemory
#define l703 EnterExportedFunction
#define l374 InternalEnterExportedFunction
#define l551 LeaveExportedFunction
#define l466 InternalLeaveExportedFunction
#define l96 offset_
#define l381 threadId_
#define l443 GetCurrentThreadId
#define l227 depth_
#define l239 InternalFreeMemory
#define l196 while
#define l118 freeList_
#define l42 size
#define l478 pop_back
#define l449 ProtectInScope
#define l746 remove_if
#define l92 begin
#define l60 end
#define l150 get
#define l702 SetValue
#define l155 push_back
#define l329 PushNewBuffer
#define l509 XlfBuffer
#define l149 start
#define l571 shared_char_ptr
#define l568 push_front
#define l294 unsigned
#define l258 front
#define l754 max
#define l343 memset
#define l17 for
#define l573 HANDLE
#define l544 OpenThread
#define l602 THREAD_QUERY_INFORMATION
#define l371 FALSE
#define l482 BOOL
#define l676 GetExitCodeThread
#define l716 CloseHandle
#define l742 STILL_ACTIVE
#define l200 using
#define l333 map
#define l400 num_fmt
#define l563 get_fmts
#define lf XlfOper
#define l357 reserve
#define l28 auto
#define l295 cols
#define l362 continue
#define l731 find
#define l596 second
#define l39 to_string
#define l66 inline
#define l27 name
#define l379 stat
#define l164 FILE
#define l247 is
#define l48 fprintf
#define l95 as
#define l642 flog_init
#define l230 lib
#define l202 nullptr
#define l715 time_t
#define l737 time
#define l395 tm
#define l662 fopen_s
#define l750 localtime_s
#define l655 fopen
#define l572 localtime
#define l519 strftime
#define l620 log_xlf
#define l640 xltypeName
#define l592 IsMulti
#define l626 PASCAL
#define l285 EXCEL12PROC
#define ls LPXLOPER12
#define l293 FetchExcel12EntryPt
#define l594 GetModuleHandle
#define l685 GetProcAddress
#define l686 _cdecl
#define l209 Excel12
#define l736 va_list
#define l234 xlretFailed
#define l402 xlretInvCount
#define l630 va_start
#define l744 va_arg
#define l760 va_end
#define l629 pascal
#define l373 Excel12v
#define l30 XlfAbstractCmdDesc
#define l107 InvalidFunctionId
#define l57 comment
#define l97 name_
#define l277 alias_
#define l121 comment_
#define l325 Register
#define l52 GetName
#define lz throw
#define l494 GetHelpName
#define l170 ostringstream
#define l105 str
#define l299 DoRegister
#define l1 xlretSuccess
#define l25 GetAlias
#define l268 Unregister
#define l308 DoUnregister
#define l383 SetName
#define l696 SetAlias
#define l468 SetComment
#define l58 GetComment
#define l305 SetArguments
#define l0 XlfArgDescList
#define l54 arguments_
#define l441 GetArguments
#define l313 GenerateMamlDocs
#define l331 ofstream
#define l251 DoMamlDocs
#define l33 XlfArgDesc
#define l280 CheckNameLength
#define l140 type_
#define l257 GetType
#define l358 xlfOperType
#define l691 xlfXloperType
#define l584 wStrType
#define l463 fpType
#define l424 iterator
#define l199 const_iterator
#define l61 XlfCmdDesc
#define l62 menu
#define l59 menu_
#define l116 text_
#define l535 hidden_
#define l82 funcId_
#define l601 IsAddedToMenuBar
#define l408 AddToMenuBar
#define l9 Call12
#define l154 xlfGetBar
#define l203 IsError
#define l756 xlfAddMenu
#define l553 xlfAddCommand
#define l558 Check
#define l570 xlfCheckCommand
#define l512 RemoveFromMenuBar
#define l605 xlfDeleteCommand
#define l659 xlfDeleteMenu
#define l46 args
#define l292 excel12
#define l186 min
#define l21 Call12v
#define l475 xlfRegister
#define l345 IsNumber
#define l114 AsDouble
#define l491 xlfSetName
#define l401 xlfUnregister
#define l481 ostream
#define l564 GetFileAttributes
#define l745 INVALID_FILE_ATTRIBUTES
#define l546 FILE_ATTRIBUTE_DIRECTORY
#define l104 this_
#define l287 XlfExcelImpl
#define l290 handle_
#define l175 HINSTANCE
#define l523 InitLibrary
#define l728 IsEscPressed
#define l582 xlAbort
#define l223 HWND
#define l101 hWnd
#define l372 short
#define l439 loWord
#define l498 CALLBACK
#define l316 LPARAM
#define l671 LOWORD
#define l444 GetClassName
#define l660 lstrcmpi
#define l504 TRUE
#define l435 GetMainWindow
#define l352 XLOPER12
#define l617 xlGetHwnd
#define l133 val
#define l193 w
#define l575 EnumWindows
#define l560 GetExcelInstance
#define l566 GetWindowLongPtr
#define l561 GWLP_HINSTANCE
#define l38 impl_
#define l361 get_excel_version
#define l76 xltype
#define l174 xltypeInt
#define l433 xlfGetWorkspace
#define l604 xlCoerce
#define l307 xltypeStr
#define l559 _wtoi
#define l714 xlFree
#define l668 LoadLibrary
#define l693 excelVersion_
#define l727 xlfOperType_
#define l718 xlfXloperType_
#define l705 wStrType_
#define l609 fpArrayType_
#define l67 LPXLFOPER
#define l543 isEnglish_
#define l719 xlGetName
#define l111 xllFileName_
#define l396 LookForHelp
#define l390 m_mainExcelThread
#define l206 helpFileName_
#define l638 GetXllDirectory
#define l457 npos
#define l134 assert
#define l735 xlCommand
#define l664 xlSpecial
#define l220 xlIntl
#define l751 xlPrompt
#define l529 xltypeRef
#define l547 mref
#define l577 lpmref
#define l495 xltypeMulti
#define l569 xltypeBigData
#define l182 XlfOperImpl
#define l632 xlbitFreeAuxMem
#define l168 bFuncWiz
#define l673 FAR
#define l286 LPEnumStruct
#define l446 EnumProc
#define l259 LPSTR
#define l556 CompareString
#define l635 MAKELCID
#define l713 MAKELANGID
#define l603 LANG_ENGLISH
#define l645 SUBLANG_ENGLISH_US
#define l589 SORT_DEFAULT
#define l598 NORM_IGNORECASE
#define l291 lstrlen
#define l545 GetWindowText
#define l456 strstr
#define l591 IsCalledByFuncWiz
#define l708 EnumThreadWindows
#define l700 WNDENUMPROC
#define l55 XlfFuncDesc
#define l689 RecalcPolicy
#define l126 helpID
#define l169 helpID_
#define l162 returnTypeCode_
#define l634 XlfFuncDescImpl
#define l462 RegisterAs
#define l210 excel14
#define l151 Asynchronous_
#define l753 recalcPolicy_
#define l204 Volatile
#define l336 Threadsafe_
#define l312 ClusterSafe_
#define l266 MacroSheetEquivalent_
#define l707 category_
#define l490 ThrowOnError
#define l625 xlretUncalced
#define l600 xlretAbort
#define l557 xlretStackOvfl
#define l404 xlretInvXloper
#define l761 xlretInvXlfn
#define l597 xlRetInvAsynchronousContext
#define l555 xlretNotClusterSafe
#define l680 MissingOrEmptyError
#define l530 xltypeMissing
#define l458 xltypeErr
#define l429 xltypeNil
#define l554 XlTypeToString
#define l611 xltypeNum
#define l613 xltypeBool
#define l649 xltypeSRef
#define l565 RW
#define l527 COL
#define l480 XlfRef
#define l658 GetTextA1
#define l192 rowbegin_
#define l219 colbegin_
#define l197 colend_
#define l173 rowend_
#define l749 GetTextR1C1
#define l619 Services_t
#define l281 StatusBar_t
#define l539 xlcMessage
#define l306 Notes_t
#define l762 GetNote
#define l386 xlfGetNote
#define l652 SetNote
#define l370 xlcNote
#define l644 ClearNote
#define l47 Information_t
#define l405 GetNow
#define l748 xlfNow
#define l661 GetCallingCell
#define l717 xlfCaller
#define l487 GetActiveCell
#define l665 xlfActiveCell
#define l697 GetActiveRange
#define l651 xlfSelection
#define l650 SetActiveCell
#define l485 xlcSelect
#define l747 GetFormula
#define l276 isEnglish
#define l492 xlfGetFormula
#define l83 AsString
#define l586 ConvertA1FormulaToR1C1
#define l376 xlfFormulaConvert
#define l675 ConvertR1C1FormulaToA1
#define l588 GetCellRefA1
#define l399 xlfTextref
#define l350 GetCellRefR1C1
#define l710 xlfAbsref
#define l725 GetRefTextA1
#define l394 xlfReftext
#define l607 GetRefTextR1C1
#define l614 GetSheetName
#define l615 xlSheetNm
#define l548 IDSHEET
#define l622 GetCurrentSheetId
#define l733 xlSheetId
#define l694 AsShort
#define l63 Cell_t
#define l699 GetContents
#define l701 SetContents
#define l690 xlcFormula
#define l624 GetHeight
#define l145 xlfGetCell
#define l764 SetHeight
#define l669 xlcRowHeight
#define l633 GetWidth
#define l755 SetWidth
#define l580 xlcColumnWidth
#define l578 GetFont
#define l344 Information
#define l73 Commands
#define l213 Select
#define l574 xlcFontProperties
#define l654 SetFont
#define l706 GetFontSize
#define l653 SetFontSize
#define l732 GetFormat
#define l723 IsString
#define l677 SetFormat
#define l636 xlcFormatNumber
#define l40 Commands_t
#define l550 Alert
#define l683 xlcAlert
#define l695 InputFormula
#define l132 xlfInput
#define l641 InputNumber
#define l628 InputText
#define l657 InputBool
#define l692 AsBool
#define l678 InputReference
#define l562 InputArray
#define l567 ShowDialogBox
#define l666 xlfDialogBox
#define l724 InsertWorkSheet
#define l525 xlcWorkbookInsert
#define l743 InsertMacroWorkSheet
#define l631 SelectPreviousSheet
#define l612 xlcWorkbookPrev
#define l590 SelectNextSheet
#define l576 xlcWorkbookNext
#define l741 SetScreenUpdates
#define l682 xlcEcho
#define l384 SetOnTime
#define l583 xlcOnTime
#define l599 SetOnTimer
#define l214 DisableCalculation
#define l241 calulationState_
#define l687 xlfGetDocument
#define l709 AsInt
#define l413 xlcOptionsCalculation
#define l201 XLFunctionRegistrationData
#define l356 Arg
#define l161 excel_name
#define l391 descr
#define l176 nargs
#define l380 volat
#define l354 threadsafe
#define l460 ret_type_code
#define l521 asynch
#define l526 macro_sheet_equiv
#define l378 claster_safe
#define l489 XLFunctionRegistrationHelper
#define l465 AddFunction
#define l410 XLCommandRegistrationHelper
#define l499 XLCommandRegistrationData
#define l428 AddCommand
#define l739 to_xl_str
#define l180 len
#define l684 wcslen
#define l627 wcscpy_s
#define l112 Functions
#define l14 data
#define l711 NotVolatile
#define l618 menu_text
#define l516 GenerateChmBuilderConfig
#define l430 GenerateToc
#define l459 GenerateDocumentation
#define l667 xlwGenDoc
lg::l157::l157(){l540(&l369);}lg::l157::~l157(){}l16 lg::l157::l704()lb
{l511 l260;l540(&l260);l511 l334;l643(&l334);le l16(l260.l264-l369.
l264)/l16(l334.l264);}
lg::l68::l68(lb l68&l163):l310(l163.l310.l646()){}lg::l68::l68(l18
l454,l18 l473):l310(l85 l757(l454,l473)){}lg::l68&lg::l68::l254(l18
l165,l18 l398){l68 l115(l165,l398);l434(l115);le*l129;}lg::l68&lg::
l68::l142=(lb l68&l163){ld(l129!=&l163){l68 l115(l163);l434(l115);}le
 *l129;}
lp*lg::l143::l663(lb l15*l56){l18 lw=l56[0];lp*ll=ly::l244<lp>(lw+1);
ll[lw]=0;ld(lw>0){l552(l500,0x00000400,l56+1,(lh)lw,ll,(lh)lw,l72,l72
);}le ll;}la::l300 lg::l143::l734(lb l15*l56){l18 lw=l56[0];la::l300
ll(l56+1,l56+1+lw);le ll;}l15*lg::l143::l722(lb la::lc&l122){l18 lw(
l122.l136());ld(lw>32767){la::lx<<l8<<"\x53\x74\x72\x69\x6e\x67\x20"
"\x74\x72\x75\x6e\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36"
"\x37\x20\x62\x79\x74\x65\x73"<<la::li;lw=32767;}l15*ll=ly::l244<l15>
(lw+2);l595(l500,0,l122.l13(),(lh)lw,ll+1,(lh)lw);ll[lw+1]=0;ll[0]=
l86<l160>(lw);le ll;}l15*lg::l143::l587(lb la::l300&l122){l18 lw(l122
.l136());ld(lw>32766){la::lx<<l8<<"\x53\x74\x72\x69\x6e\x67\x20\x74"
"\x72\x75\x6e\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x33\x32\x37\x36\x36"
"\x20\x62\x79\x74\x65\x73"<<la::li;lw=32766;}l15*ll=ly::l244<l15>(lw+
2);l648(ll+1,lw+1,l122.l13(),lw);ll[lw+1]='\0';ll[0]=l86<l15>(lw);le
ll;}l15*lg::l143::l752(lb l15*l56){l18 lw=l86<l15>(l56[0]);l15*ll=ly
::l244<l15>(lw+2);l407(ll,l56,(lw+1) *l156(l15));ll[lw+1]=0;le ll;}
l15*lg::l143::l608(lb l15*l56){l18 lw=l86<l15>(l56[0]);l15*ll=ly::
l674<l15>(lw+2);l407(ll,l56,(lw+1) *l156(l15));ll[lw+1]=0;le ll;}la::
lc lg::l278::l537(lb la::lc&l190){lb l90 l172=4096;la::l119<lp>ll(
l172);l90 l44=l447(l190.l13(),&ll[0],l172);ld(l172<l44){ll.l254(l44);
l44=l447(l190.l13(),&ll[0],l44);}ld(!l44){la::lx<<l8<<"\x20\x43\x6f"
"\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x62\x74\x61\x69\x6e\x20"<<l190
<<"\x20\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x20\x76\x61\x72"
"\x69\x61\x62\x6c\x65\x20"<<la::li;le"";}le&ll[0];}la::lc lg::l278::
l740(){la::l119<lp>ll;l90 l44=l472(0,0);ld(l44){ll.l254(l44);l44=l472
(l44,&ll[0]);}ld(!l44){la::lx<<l8<<"\x20\x43\x6f\x75\x6c\x64\x20\x6e"
"\x6f\x74\x20\x6f\x62\x74\x61\x69\x6e\x20\x43\x75\x72\x72\x65\x6e\x74"
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"<<la::li;le"";}le&ll[0]
;}
l26 lg{l185 l98:l225 la::l432{l225:l98(){}~l98(){}l656:l506 l621(l506
l243){ld(!l211::l647(l211::l606(),l243)){l297.l670(1,l211::l730(l243));
}lq{le l532();}le l211::l681(l243);}lh l532(){l397();l297.l522();le 0
;}l513:lm l397(){}la::lc l297;l98(lb l98&);l98&l142=(lb l98&);};l185
l233{l225:l233(){l289=la::lx.l471(&l365);la::lx<<l8<<"\x53\x74\x72"
"\x65\x61\x6d\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f"
"\x20\x4d\x53\x56\x43\x20\x64\x65\x62\x75\x67\x67\x65\x72"<<la::li;}~
l233(){la::lx.l471(l289);}l513:la::l432*l289;l98 l365;};}l109 lg::
l233 l763;l26 lg{l185 l167{l225:l167(){l531 l309;l253 l265=l72;lp l178
[l467+1]="";l90 l44=0;la::lc l326(l278::l537("\x50\x41\x54\x48"));lt
l146(!l326.l45());l44=l86<l90>(l581(((l738)l129),&l309,(l86<l90>(l156
(l531)))));ld(l44){l265=((l253)(l309.l623));l688(l265,l178,l467);lg::
l79.l282=l178;}lq{l146=l34;la::lx<<l8<<"\x20\x43\x6f\x75\x6c\x64\x20"
"\x6e\x6f\x74\x20\x61\x74\x74\x61\x69\x6e\x20\x70\x61\x74\x68\x20\x6f"
"\x66\x20\x44\x4c\x4c"<<la::li;}ld(l146){la::lc l327(l178);la::lc l303
(l326);la::lc::l720 l353=l327.l298("\\");l303+="\x3b"+l327.l236(0,
l353);ld(!l721("\x50\x61\x74\x68",l303.l13())){la::lx<<l8<<"\x20\x53"
"\x65\x74\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x56\x61\x72\x69"
"\x61\x62\x6c\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x73\x65"
"\x74\x20\x50\x41\x54\x48"<<la::li;l146=l34;}lq{la::lx<<l8<<"\x20\x50"
"\x41\x54\x48\x20\x73\x65\x74\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75"
"\x6c\x6c\x79\x20"<<la::li;}}ld(!l146){la::lx<<l8<<"\x20\x57\x61\x72"
"\x6e\x69\x6e\x67\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x69"
"\x6e\x69\x74\x69\x61\x6c\x69\x73\x65\x20\x50\x41\x54\x48\x20\x74\x6f"
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x6f\x66\x20\x6c\x69\x62"
"\x72\x61\x72\x79\x20"<<la::li;}}~l167(){}};}l412"\x43"{l279 l222 l637
(){l311{lg::lk::ln();lg::ly::l541();l109 lg::l167 l585;lg::l79.l282=""
"\x52\x65\x67\x69\x73\x74\x65\x72\x69\x6e\x67\x20\x6c\x69\x62\x72\x61"
"\x72\x79\x2e\x2e\x2e";lg::l283::l69::ln().l359();lg::l79.l282.l262();
lg::l301<lg::l549>::ln().l318();le 1;}l284(...){le 0;}}l109 lt l261=
l34;l279 l222 l616(){l311{la::lx<<l8<<"\x52\x65\x6c\x65\x61\x73\x69"
"\x6e\x67\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73"<<la::li;lg::l301<
lg::l726>::ln().l318();ld(l261){lg::l283::l69::ln().l440();}lq{}lg::
lk::l479();lg::ly::l349();}l284(...){la::lx<<l8<<"\x53\x6f\x6d\x65"
"\x74\x68\x69\x6e\x67\x20\x62\x61\x64\x20\x68\x61\x70\x70\x65\x6e\x65"
"\x64\x20\x69\x6e\x20\x78\x6c\x41\x75\x74\x6f\x43\x6c\x6f\x73\x65"<<
la::li;}le 1;}l279 l222 l759(){l311{la::lx<<l8<<"\x41\x64\x64\x69\x6e"
"\x20\x62\x65\x69\x6e\x67\x20\x75\x6e\x6c\x6f\x61\x64\x65\x64"<<la::
li;lg::l301<lg::l579>::ln().l318();l261=l75;}l284(...){la::lx<<l8<<""
"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x62\x61\x64\x20\x68\x61\x70"
"\x70\x65\x6e\x65\x64\x20\x69\x6e\x20\x78\x6c\x41\x75\x74\x6f\x52\x65"
"\x6d\x6f\x76\x65"<<la::li;}le 1;}}
l242 la::l275<lg::ly>l179;l26{lg::l639<lg::ly>l125;lg::l712 l335;la::
l119<l179>l100;}l26{lt l436(lb l179&l484){le l484->l382();}}l26 lg{
l593<l185 l416>l137 l415{lm l142()(l416*l476)lb{l323[]l476;}};lp*ly::
l729(l18 l88){ly*l37=l125.l228();ld(!l37)l37=l270();le l37->l503(l88);
}lm ly::l703(){ly*l37=l125.l228();ld(!l37)l37=l270();l37->l374();}lm
ly::l551(){ly*l37=l125.l228();ld(l37)l37->l466();}ly::ly():l96(0),
l381(l443()),l227(0){}ly::~ly(){l239(l75);}lm ly::l239(lt l421){l18
l332=1;ld(l421)l332=0;l196(l118.l42()>l332)l118.l478();l96=0;}lm ly::
l374(){ld(l227==0)l239(l34);++l227;}lm ly::l466(){--l227;}ly*ly::l270
(){l449 l507(l335);ly*l37=l125.l228();ld(!l37){l100.l522(la::l746(
l100.l92(),l100.l60(),l436),l100.l60());l179 l319(l85 ly);l37=l319.
l150();l125.l702(l37);l100.l155(l319);}le l37;}lm ly::l329(l18 l42){
l509 l195;l195.l42=l42;l195.l149=l571(l85 lp[l42],l415<lp>());;l118.
l568(l195);l96=0;la::lx<<"\x78\x6c\x77\x20\x69\x73\x20\x61\x6c\x6c"
"\x6f\x63\x61\x74\x69\x6e\x67\x20\x61\x20\x6e\x65\x77\x20\x62\x75\x66"
"\x66\x65\x72\x20\x6f\x66\x20"<<l86<l294 lh>(l42)<<"\x20\x62\x79\x74"
"\x65\x73"<<la::li;le;}lp*ly::l503(l18 l88){ld(l118.l45())l329(8192);
l509&l108=l118.l258();ld(l96+l88>l108.l42){l329(la::l754((l108.l42*3)/
2,(l96+l88)+4096));l343(l118.l258().l149.l150(),0,l88);l96=l88;le l118
.l258().l149.l150();}lq{l18 l115=l96;l343(l108.l149.l150()+l115,0,l88
);l96+=l88;le l108.l149.l150()+l115;}}lm ly::l541(){}lm ly::l349(){
l449 l507(l335);l17(l18 l19(0);l19<l100.l42();++l19){l100[l19]->l239(
l75);}}lt ly::l382()lb{l573 l207(l544(l602,l371,l381));ld(l207){l90
l271(0);l482 ll=l676(l207,&l271);l716(l207);ld(ll!=0){ld(l271==l742)le
l34;lq le l75;}lq le l34;}lq le l34;}}
l200 l26 la;l200 l26 lg;l109 l333<lc,lc>l171;l109 la::l333<la::lc,la
::lc>&l328(){ld(l171.l45()){l171={{"\x64\x61\x74\x65","\x79\x79\x79"
"\x79\x2d\x6d\x6d\x2d\x64\x64"},{"\x74\x69\x6d\x65","\x68\x68\x3a\x6d"
"\x6d\x3a\x73\x73"},{"\x64\x61\x74\x65\x74\x69\x6d\x65","\x79\x79\x79"
"\x79\x2d\x6d\x6d\x2d\x64\x64\x20\x68\x68\x3a\x6d\x6d\x3a\x73\x73"},{""
"\x24","\x24\x23\x2c\x23\x23\x30\x2e\x30\x30"},{"\x24\x33","\x24\x23"
"\x2c\x23\x23\x30\x2e\x30\x30\x30"},{"\x24\x34","\x24\x23\x2c\x23\x23"
"\x30\x2e\x30\x30\x30\x30"},{"\x25","\x30\x25"},{"\x25\x31","\x30\x2e"
"\x30\x25"},{"\x25\x32","\x30\x2e\x30\x30\x25"},{"\x67\x65\x6e\x65"
"\x72\x61\x6c","\x47\x65\x6e\x65\x72\x61\x6c"},{"\x6e\x6f\x6e\x65",""
"\x47\x65\x6e\x65\x72\x61\x6c"},{"\x73\x74\x72","\x47\x65\x6e\x65\x72"
"\x61\x6c"},{"\x69\x6e\x74","\x47\x65\x6e\x65\x72\x61\x6c"},{"\x6e"
"\x75\x6d","\x47\x65\x6e\x65\x72\x61\x6c"}};};le l171;}l119<l400>lg::
l563(lb lf&l41,lb lc&l315,lh l212,lh l217,lb l333<lh,lc>&l340,lt l418
){ld(l212<=0||l217<=0)le{};l119<l400>l3;l3.l357(l340.l42());l17(l28&[
l184,l153]:l340){ld(l184>=l41.l295())le{};ld(l153.l45())l362;l28 l10=
l328().l731(l153);ld(l10==l328().l60())l362;l28 l355=l10->l596;lc lr=
l315.l45()?"\x52":l315+"\x21\x52";lr+=l39(l212+(l418?1:0));lr+="\x43"
;lr+=l39(l217+l184);lr+="\x3a\x52";lr+=l39(l212+l41.l165()-1);lr+=""
"\x43";lr+=l39(l217+l184);l3.l155({lr,l355});}le l3;}
l109 l66 lt l453(lb lp*l27){l137 l379 l108;le(l379(l27,&l108)==0);}
l109 l66 lm l288(l164*l7,lb lg::lf&l29){ld(l29.l247<l16>())l48(l7,""
"\x25\x67",l29.l95<l16>());lq ld(l29.l247<lh>())l48(l7,"\x25\x64",l29
.l95<lh>());lq ld(l29.l247<lt>())l48(l7,l29.l95<lt>()?"\x54\x52\x55"
"\x45":"\x46\x41\x4c\x53\x45");lq ld(l29.l247<la::lc>())l48(l7,"\x25"
"\x73",l29.l95<la::lc>().l13());lq l48(l7,"\x4e\x41");}l26 lg{l164*
l642(lb lp*l194,lb lp*l230,lb lp*l461,lb lp*l120){ld(!l453(l194))le
l202;la::l715 l159=la::l737(0);la::l395*l166=l202;
#ifdef _MSC_VER
l164*l7=l202;l662(&l7,l194,"\x61\x2b");la::l395 l322;l750(&l322,&l159
);l166=&l322;
#else
l164*l7=l655(l194,"\x61\x2b");l166=l572(&l159);
#endif
ld(!l7)le l202;lp l229[128],l205[128];l519(l229,l156(l229),"\x25\x59"
"\x2d\x25\x6d\x2d\x25\x64",l166);l519(l205,l156(l205),"\x25\x48\x3a"
"\x25\x4d\x3a\x25\x53",l166);la::lc l3="\n\x2d\x2d\x2d";l3+=l461;l3+=""
"\x3d";l3+=l229;l3+="\x3d";l3+=l205;l3+="\x3d";l3+=l230;l3+="\x3a";l3
+=l120;l3+="\n";l48(l7,l3.l13());le l7;}lm l620(l164*l7,lb lg::lf&l29
,lb lp*l27){ld(!l7)le;l48(l7,"\x25\x73\x3c\x25\x73\x3e\x20\x3d\x20",
l27,l29.l640().l13());ld(!l29.l592()){l288(l7,l29);l48(l7,"\n");le;}
l48(l7,"\x28\x25\x64\x2c\x25\x64\x29",l29.l165(),l29.l295());l48(l7,""
"\x7b");lb lp*l321="";lb lp*l486="\x2c";lb lp*l368="\x2c\n";lb lp*
l269=l321;l17(lh l19=0;l19<l29.l165();++l19){l48(l7,l269);lb lp*l263=
l321;l48(l7,"\x7b");l17(lh l189=0;l189<l29.l295();++l189){l48(l7,l263
);l288(l7,l29(l19,l189));l263=l486;}l48(l7,"\x7d");l269=l368;}l48(l7,""
"\x7d\n");}}
l242 lh(l626*l285)(lh lu,lh l758,lb ls*l679,ls l698);l253 l215;l285
l117;lm l293(lm){ld(l117==l72){l215=l594(l72);ld(l215!=l72){l117=(
l285)l685(l215,"\x4d\x64\x43\x61\x6c\x6c\x42\x61\x63\x6b\x31\x32");}}
}lh l686 l209(lh lu,ls l221,lh l6,...){ls l256[255];l736 l188;lh l158
;lh l87;l293();ld(l117==l72)l87=l234;lq{l87=l402;ld((l6>=0)&&(l6<=255
)){l630(l188,l6);l17(l158=0;l158<l6;l158++){l256[l158]=l744(l188,ls);
}l760(l188);l87=(l117)(lu,l6,&l256[0],l221);}}le(l87);}lh l629 l373(
lh lu,ls l221,lh l6,lb ls l406[]){lh l87;l293();ld(l117==l72){l87=
l234;}lq{l87=(l117)(lu,l6,&l406[0],l221);}le(l87);}
lb l16 lg::l30::l107=-1.0;lg::l30::l30(lb la::lc&l27,lb la::lc&l94,lb
la::lc&l57):l97(l27),l277(l94),l121(l57){}lg::l30::~l30(){}lm lg::l30
::l325(lh l426)lb{la::lc l51=lk::ln().l52();ld(l51.l45())lz("\x43\x6f"
"\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x6c\x69\x62\x72\x61"
"\x72\x79\x20\x6e\x61\x6d\x65");la::lc l330=lk::ln().l494();la::lc
l106;ld(!l330.l45()){la::l170 l138;l138<<l330<<"\x21"<<l426;l106=l138
.l105();}lh lj=l299(l51,l106);ld(lj!=l1){la::lx<<l8<<"\x45\x72\x72"
"\x6f\x72\x20"<<lj<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67\x69\x73"
"\x74\x65\x72\x69\x6e\x67\x20"<<l25().l13()<<la::li;}le;}lm lg::l30::
l268()lb{la::lc l51=lk::ln().l52();ld(l51.l45())lz("\x43\x6f\x75\x6c"
"\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x6c\x69\x62\x72\x61\x72\x79"
"\x20\x6e\x61\x6d\x65");lh lj=l308(l51);ld(lj!=l1)la::lx<<l8<<"\x45"
"\x72\x72\x6f\x72\x20"<<lj<<"\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x67"
"\x69\x73\x74\x65\x72\x69\x6e\x67\x20"<<l25().l13()<<la::li;le;}lm lg
::l30::l383(lb la::lc&l27){l97=l27;}lb la::lc&lg::l30::l52()lb{le l97
;}lm lg::l30::l696(lb la::lc&l94){l277=l94;}lb la::lc&lg::l30::l25()lb
{le l277;}lm lg::l30::l468(lb la::lc&l57){l121=l57;}lb la::lc&lg::l30
::l58()lb{le l121;}lm lg::l30::l305(lb l0&l20){l54=l20;}lb lg::l0&lg
::l30::l441()lb{le l54;}lm lg::l30::l313(lb la::lc l91,lh l672)lb{la
::l170 l138;l138<<l91<<"\\"<<l25()<<"\x2e\x6d\x61\x6d\x6c";la::l331 lo
(l138.l105().l13());lo<<"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73\x69"
"\x6f\x6e\x3d\"\x31\x2e\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67\x3d"
"\"\x75\x74\x66\x2d\x38\"\x3f\x3e"<<la::li;lo<<"\x3c\x74\x6f\x70\x69"
"\x63\x20\x69\x64\x3d\""<<l25()<<"\"\x20\x72\x65\x76\x69\x73\x69\x6f"
"\x6e\x4e\x75\x6d\x62\x65\x72\x3d\"\x39\"\x3e"<<la::li;lo<<"\x3c\x64"
"\x65\x76\x65\x6c\x6f\x70\x65\x72\x52\x65\x66\x65\x72\x65\x6e\x63\x65"
"\x57\x69\x74\x68\x53\x79\x6e\x74\x61\x78\x44\x6f\x63\x75\x6d\x65\x6e"
"\x74\x20" "\x78\x6d\x6c\x6e\x73\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f"
"\x64\x64\x75\x65\x2e\x73\x63\x68\x65\x6d\x61\x73\x2e\x6d\x69\x63\x72"
"\x6f\x73\x6f\x66\x74\x2e\x63\x6f\x6d\x2f\x61\x75\x74\x68\x6f\x72\x69"
"\x6e\x67\x2f\x32\x30\x30\x33\x2f\x35\"\x20" "\x78\x6d\x6c\x6e\x73"
"\x3a\x78\x6c\x69\x6e\x6b\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77"
"\x77\x2e\x77\x33\x2e\x6f\x72\x67\x2f\x31\x39\x39\x39\x2f\x78\x6c\x69"
"\x6e\x6b\"\x3e"<<la::li;lo<<"\x3c\x74\x69\x74\x6c\x65\x3e"<<l25()<<""
"\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<la::li;l251(lo);lo<<"\x3c\x72\x65"
"\x6c\x61\x74\x65\x64\x54\x6f\x70\x69\x63\x73\x3e\x3c\x2f\x72\x65\x6c"
"\x61\x74\x65\x64\x54\x6f\x70\x69\x63\x73\x3e"<<la::li;lo<<"\x3c\x2f"
"\x64\x65\x76\x65\x6c\x6f\x70\x65\x72\x52\x65\x66\x65\x72\x65\x6e\x63"
"\x65\x57\x69\x74\x68\x53\x79\x6e\x74\x61\x78\x44\x6f\x63\x75\x6d\x65"
"\x6e\x74\x3e"<<la::li;lo<<"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<la::li
;}
lm lg::l33::l280(){ld(l97.l136()>=19)la::lx<<l8<<"\x41\x72\x67\x75"
"\x6d\x65\x6e\x74\x20\x6e\x61\x6d\x65\x20\""<<l97.l13()<<"\"\x20\x6d"
"\x61\x79\x20\x62\x65\x20\x74\x6f\x6f\x20\x6c\x6f\x6e\x67\x20\x74\x6f"
"\x20\x66\x69\x74\x20\x74\x68\x65\x20\x69\x6e\x20\x74\x68\x65\x20\x66"
"\x75\x6e\x63\x74\x69\x6f\x6e\x20\x77\x69\x7a\x61\x72\x64"<<la::li;};
lg::l33::l33(){}lg::l33::l33(lb la::lc&l27,lb la::lc&l57,lb la::lc&
l24):l97(l27),l121(l57),l140(l24){l280();}lg::l33::~l33(){}lm lg::l33
::l383(lb la::lc&l27){l97=l27;l280();}lb la::lc&lg::l33::l52()lb{le
l97;}lm lg::l33::l468(lb la::lc&l57){l121=l57;}lb la::lc&lg::l33::l58
()lb{le l121;}la::lc lg::l33::l257()lb{ld(l140=="\x58\x4c\x46\x5f\x4f"
"\x50\x45\x52"){le lk::ln().l358();}lq ld(l140=="\x58\x4c\x46\x5f\x58"
"\x4c\x4f\x50\x45\x52"){le lk::ln().l691();}lq ld(l140=="\x58\x4c\x57"
"\x5f\x57\x53\x54\x52"){le lk::ln().l584();}lq ld(l140=="\x58\x4c\x57"
"\x5f\x46\x50"){le lk::ln().l463();}lq{le l140;}}
lg::l0::l0(){}lg::l0::l0(lb l0&l533){l54=l533.l54;}lg::l0::l0(lb l33&
l528){l54.l155(l528);}lg::l0&lg::l0::l142+(lb l33&l360){l54.l155(l360
);le*l129;}lg::l0::l424 lg::l0::l92(){le l54.l92();}lg::l0::l199 lg::
l0::l92()lb{le l54.l92();}lg::l0::l424 lg::l0::l60(){le l54.l60();}lg
::l0::l199 lg::l0::l60()lb{le l54.l60();}l18 lg::l0::l42()lb{le l54.
l42();}lg::l0 lg::l142+(lb lg::l33&l538,lb lg::l33&l377){le l0(l538)+
l377;}
lg::l61::l61(lb la::lc&l27,lb la::lc&l94,lb la::lc&l57,lb la::lc&l62,
lb la::lc&l422,lt l496):l30(l27,l94,l57),l59(l62),l116(l422),l535(
l496),l82(l107){}lg::l61::~l61(){}lt lg::l61::l601(){le!l59.l45();}lh
lg::l61::l408(lb lp*l62,lb lp*l338){ld(l62){l59=l62;}ld(l338){l116=
l338;}ld(l59.l45()||l116.l45()){le 0;}lf l84(10);lf l135;lf l50;lf
l296(l59);lh lj=lk::ln().l9(l154,l135,3,l84,l296,lf(0));ld(lj||l135.
l203()){lh l147(1);lf l183;lj=lk::ln().l9(l154,l183,3,l84,lf(l147+1),
lf(0));l196(!lj&&!l183.l203()){++l147;lj=lk::ln().l9(l154,l183,3,l84,
lf(l147+1),lf(0));}lf l70(2,5);l70(0,0)=l59;l70(0,1)="";l70(0,2)="";
l70(0,3)="";l70(0,4)="";l70(1,0)=l116;l70(1,1)=l25();l70(1,2)="";l70(
1,3)=l58();l70(1,4)="";lj=lk::ln().l9(l756,0,3,l84,l70,lf(l147));ld(
lj!=l1){la::lx<<l8<<"\x41\x64\x64\x20\x4d\x65\x6e\x75\x20"<<l59.l13()<<""
"\x20\x66\x61\x69\x6c\x65\x64"<<la::li;}}lq{lf l123(1,4);l123(0,0)=
l116;l123(0,1)=l25();l123(0,2)="";l123(0,3)=l58();lj=lk::ln().l9(l553
,0,3,l84,l296,l123);ld(lj!=l1){la::lx<<l8<<"\x41\x64\x64\x20\x63\x6f"
"\x6d\x6d\x61\x6e\x64\x20"<<l52().l13()<<"\x20\x74\x6f\x20"<<l59.l13(
)<<"\x20\x66\x61\x69\x6c\x65\x64"<<la::li;}}le lj;}lh lg::l61::l558(
lt l520)lb{ld(l59.l45()){la::lx<<l8<<"\x4e\x6f\x20\x6d\x65\x6e\x75"
"\x20\x73\x70\x65\x63\x69\x66\x69\x65\x64\x20\x66\x6f\x72\x20\x74\x68"
"\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\""<<l52().l13()<<"\""<<la::
li;le l234;}lh lj=lk::ln().l9(l570,0,4,lf(10),lf(l59),lf(l116),lf(
l520));ld(lj!=l1){la::lx<<l8<<"\x52\x65\x67\x69\x73\x74\x72\x61\x74"
"\x69\x6f\x6e\x20\x6f\x66\x20"<<l25().l13()<<"\x20\x66\x61\x69\x6c"
"\x65\x64"<<la::li;le lj;}le l1;}lm lg::l61::l512(){lf l84(10);lf l62
(l59);lf l135;lh lj=lk::ln().l9(l154,l135,3,l84,l62,lf(0));ld(!lj&&!
l135.l203()){lj=lk::ln().l9(l605,0,3,l84,l62,lf(l116));ld(lj!=l1)la::
lx<<l8<<"\x44\x65\x6c\x65\x74\x65\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20"
<<l52().l13()<<"\x20\x66\x72\x6f\x6d\x20"<<l59.l13()<<"\x20\x66\x61"
"\x69\x6c\x65\x64"<<la::li;lf l339;lj=lk::ln().l9(l154,l339,3,lf(10),
l62,lf(1));ld(!lj&&l339.l203()){lj=lk::ln().l9(l659,0,2,l84,l62);ld(
lj!=l1)la::lx<<l8<<"\x44\x65\x6c\x65\x74\x65\x20\x4d\x65\x6e\x75\x20"
<<l59.l13()<<"\x20\x66\x61\x69\x6c\x65\x64"<<la::li;}}}lh lg::l61::
l299(lb la::lc&l51,lb la::lc&l106)lb{l0 l20=l441();l16 l24=l535?0:2;
lh l35=l86<lh>(l20.l42());la::lc l46("\x41");la::lc l36;l0::l199 l10=
l20.l92();l196(l10!=l20.l60()){l36+=( *l10).l52();l46+=( *l10).l257();
++l10;ld(l10!=l20.l60())l36+="\x2c\x20";}ld(l36.l136()>255){l36="\x54"
"\x6f\x6f\x20\x6d\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73"
"\x20\x66\x6f\x72\x20\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a"
"\x61\x72\x64";}la::l119<ls>l130(10+l35);ls*l2=&l130[0];( *l2++)=lf(
l51);( *l2++)=lf(l52());( *l2++)=lf(l46);( *l2++)=lf(l25());( *l2++)=
lf(l36);( *l2++)=lf(l24);( *l2++)=lf("");( *l2++)=lf("");( *l2++)=lf(""
);( *l2++)=lf(l58());lh l11(0);l17(l10=l20.l92();l10!=l20.l60();++l10
){++l11;ld(l11<l35){( *l2++)=lf(( *l10).l58());}lq{( *l2++)=lf(( *l10
).l58()+"\x2e\x20");}}ld(lk::ln().l292()){l35=la::l186(l35,245);}lq{
l35=la::l186(l35,20);}lf l3;lh lj=lk::ln().l21(l475,l3,10+l35,&l130[0
]);ld(lj==l1&&l3.l345()){l82=l3.l114();}lq{l82=l107;}le lj;}lh lg::
l61::l308(lb la::lc&l51)lb{ld(l82!=l107){lk::ln().l9(l491,l72,1,lf(
l25()));lf l246;lh lj=lk::ln().l9(l401,l246,1,lf(l82));le lj;}lq{le l1
;}}lm lg::l61::l251(la::l481&l4)lb{l4<<"\x3c\x69\x6e\x74\x72\x6f\x64"
"\x75\x63\x74\x69\x6f\x6e\x3e"<<la::li;l4<<"\x3c\x70\x61\x72\x61\x3e"
<<l58()<<"\x3c\x2f\x70\x61\x72\x61\x3e"<<la::li;l4<<"\x3c\x2f\x69\x6e"
"\x74\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e\x3e"<<la::li;}
l26{lt l249(lb la::lc&l141){l90 l317(l564(l141.l13()));le((l317!=l745
)&&((l317&l546)==0));}}lg::lk*lg::lk::l104=0;l137 lg::l287{l287():
l290(0){}l175 l290;};lg::lk&lg::lk::ln(){ld(!l104){l104=l85 lk;l104->
l523();}le*l104;}lm lg::lk::l479(){l323 l104;l104=0;}lt lg::lk::l728(
)lb{lf l144;l9(l582,l144,1,lf(l34));le l144.l95<lt>();}l26{l242 l137{
l223 l101;l294 l372 l439;}l208;l482 l498 l437(l223 l101,l316 l427){
l208*l152=(l208* )l427;ld(l671(l101)==l152->l439){lp l272[7];ld(l444(
l101,l272,7)!=0){ld(!l660(l272,"\x58\x4c\x4d\x41\x49\x4e")){l152->
l101=l101;le l371;}}}le l504;}}l223 lg::lk::l435(){l352 l144;ld(l9(
l617,&l144,0)==l1){l208 l231={l72,(l294 l372)l144.l133.l193};l575(
l437,(l316)&l231);ld(l231.l101!=l72)le l231.l101;lq lz("\x78\x6c\x47"
"\x65\x74\x48\x77\x6e\x64\x20\x6e\x6f\x20\x6d\x61\x74\x63\x68\x20\x66"
"\x6f\x72\x20\x70\x61\x72\x74\x69\x61\x6c\x20\x68\x61\x6e\x64\x6c\x65"
);}lq lz("\x78\x6c\x47\x65\x74\x48\x77\x6e\x64\x20\x63\x61\x6c\x6c"
"\x20\x66\x61\x69\x6c\x65\x64");}l175 lg::lk::l560(){le(l175)l566(
l435(),l561);}lg::lk::lk():l38(0){l38=l85 l287();le;}lg::lk::~lk(){
l323 l38;l104=0;le;}lh l361(){lh l120(10);l352 l124,l187,l245,l240;
l245.l76=l240.l76=l174;l245.l133.l193=2;l240.l133.l193=l174;l209(l433
,&l124,1,&l245);l209(l604,&l187,2,&l124,&l240);ld(l187.l76==l174){
l120=l187.l133.l193;}lq ld(l124.l76==l307){l120=l559(l124.l133.l105+1
);}l209(l714,0,1,&l124);le l120;}lm lg::lk::l523(){l175 l314=l668(""
"\x58\x4c\x43\x41\x4c\x4c\x33\x32\x2e\x44\x4c\x4c");ld(l314==0)lz(""
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x6c\x69"
"\x62\x72\x61\x72\x79\x20\x58\x4c\x43\x41\x4c\x4c\x33\x32\x2e\x44\x4c"
"\x4c");l693=l361();l727="\x51";l718="\x55";l705="\x43\x25";l609=""
"\x4b\x25";l38->l290=l314;lf l324;lh lj=l9(l433,(l67)l324,1,lf(37));
ld(lj==l1)l543=(l324(0,0).l95<lh>()==1);lq{l543=l75;la::lx<<l8<<"\x43"
"\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x69\x6e\x74\x65"
"\x72\x6e\x61\x74\x69\x6f\x6e\x61\x6c\x20\x69\x6e\x66\x6f\x2c\x20\x67"
"\x75\x65\x73\x73\x69\x6e\x67\x20\x45\x6e\x67\x6c\x69\x73\x68"<<la::
li;}lf l274;lj=l9(l719,(l67)l274,0);ld(lj==l1)l111=l274.l95<la::lc>();
lq la::lx<<l8<<"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74"
"\x20\x44\x4c\x4c\x20\x6e\x61\x6d\x65"<<la::li;l396();l390=l443();}lb
la::lc&lg::lk::l52()lb{le l111;}lb la::lc&lg::lk::l494()lb{le l206;}
la::lc lg::lk::l638()lb{l18 l113(l111.l298("\\\x2f"));ld(l113==la::lc
::l457)le"\x2e";lq le l111.l236(0,l113);}lm lg::lk::l396(){l206.l262(
);l18 l131(l111.l136());ld(l131<5||l111[l131-4]!='.')le;la::lc l71=
l111;l71[l131-3]='c';l71[l131-2]='h';l71[l131-1]='m';ld(l249(l71)){
l206=l71;le;}l18 l113(l71.l298("\\\x2f"));ld(l113==la::lc::l457)le;
l71=l71.l236(0,l113)+"\\\x2e\x2e"+l71.l236(l113);ld(l249(l71))l206=
l71;}lh lg::lk::l9(lh lu,ls l32,lh l6)lb{l134(l6==0);le l21(lu,l32,0,
0);}lh lg::lk::l9(lh lu,ls l32,lh l6,lb ls l5)lb{l134(l6==1);le l21(
lu,l32,1,&l5);}lh lg::lk::l9(lh lu,ls l32,lh l6,lb ls l5,lb ls l22)lb
{l134(l6==2);lb ls l103[2]={l5,l22};le l21(lu,l32,2,l103);}lh lg::lk
::l9(lh lu,ls l32,lh l6,lb ls l5,lb ls l22,lb ls l53)lb{l134(l6==3);
lb ls l103[3]={l5,l22,l53};le l21(lu,l32,3,l103);}lh lg::lk::l9(lh lu
,ls l32,lh l6,lb ls l5,lb ls l22,lb ls l53,lb ls l99)lb{l134(l6==4);
lb ls l103[4]={l5,l22,l53,l99};le l21(lu,l32,4,l103);}lh lg::lk::l9(
lh lu,ls l32,lh l6,lb ls l5,lb ls l22,lb ls l53,lb ls l99,lb ls l517,
lb ls l524,lb ls l510,lb ls l505,lb ls l515,lb ls l417)lb{l134(l6>=5
&&l6<=10);lb ls l103[10]={l5,l22,l53,l99,l517,l524,l510,l505,l515,
l417};le l21(lu,l32,l6,l103);}lh lg::lk::l21(lh lu,ls l32,lh l6,lb ls
l302[])lb{l17(lh l19=0;l19<l6;++l19)ld(!l302[l19]){ld(lu&l735)la::lx
<<l8<<"\x78\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x7c\x20"<<(lu&0x0FFF)<<
la::li;ld(lu&l664)la::lx<<"\x78\x6c\x53\x70\x65\x63\x69\x61\x6c\x20"
"\x7c\x20"<<(lu&0x0FFF)<<la::li;ld(lu&l220)la::lx<<"\x78\x6c\x49\x6e"
"\x74\x6c\x20\x7c\x20"<<(lu&0x0FFF)<<la::li;ld(lu&l751)la::lx<<"\x78"
"\x6c\x50\x72\x6f\x6d\x70\x74\x20\x7c\x20"<<(lu&0x0FFF)<<la::li;la::
lx<<"\x30\x20\x70\x6f\x69\x6e\x74\x65\x72\x20\x70\x61\x73\x73\x65\x64"
"\x20\x61\x73\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x23"<<l19<<la::
li;}lh l64=l373(lu,l32,l6,l302);ld(l32){lh l24=l32->l76;lt l409=(l24&
l307||((l24&l529)&&l32->l133.l547.l577)||l24&l495||l24&l569);ld(l409)l32
->l76|=l182::l632;}le l64;}l26{l242 l137 l610{lt l168;}l375,l673*l286
;lt l498 l446(l223 l267,l286 l152){lb l18 l191=256;lp l110[l191];l444
(l267,(l259)l110,l191);ld(2==l556(l635(l713(l603,l645),l589),l598,(
l259)l110,(l291((l259)l110)>l291("\x62\x6f\x73\x61\x5f\x73\x64\x6d"
"\x5f\x58\x4c"))?l291("\x62\x6f\x73\x61\x5f\x73\x64\x6d\x5f\x58\x4c"):
-1,"\x62\x6f\x73\x61\x5f\x73\x64\x6d\x5f\x58\x4c",-1)){ld(l545(l267,
l110,l191)){ld(!l456(l110,"\x52\x65\x70\x6c\x61\x63\x65")&&!l456(l110
,"\x50\x61\x73\x74\x65")){l152->l168=l504;le l34;}lq{le l34;}}}le l75
;}}lt lg::lk::l591()lb{l375 l232;l232.l168=l34;l708(l390,(l700)l446,(
l316)((l286)&l232));le l232.l168;}
lg::l55::l55(lb la::lc&l27,lb la::lc&l94,lb la::lc&l57,lb la::lc&l347
,l689 l348,lt l216,lb la::lc&l238,lb la::lc&l126,lt l224,lt l237,lt
l177):l30(l27,l94,l57),l169(l126),l162(l238),l38(l85 l634(l348,l216,
l347,l224,l237,l177)),l82(l107){}lg::l55::~l55(){}lm lg::l55::l305(lb
l0&l20){l38->l54=l20;}lh lg::l55::l299(lb la::lc&l51,lb la::lc&l106)lb
{ld(l162.l45())l162=lk::ln().l358(l34);ld(l162=="\x58\x4c\x57\x5f\x46"
"\x50")l162=lk::ln().l463();le l462(l51,l106,1);}lh lg::l55::l308(lb
la::lc&l51)lb{ld(l82!=l107){lk::ln().l9(l491,l72,1,lf(l25()));lf l246
;lh lj=lk::ln().l9(l401,l246,1,lf(l82));le lj;}lq{le l1;}}lh lg::l55
::l462(lb la::lc&l51,lb la::lc&l106,l16 l464)lb{l0&l20=l38->l54;lh l35
=(lh)l20.l42();la::lc l46="\x51";la::lc l36;ld(lk::ln().l210()&&l38->
l151)l46="\x3e";l17(l28&l93:l20){l36+=l93.l52()+"\x2c\x20";l46+=l93.
l257();}ld(l35>0)l36.l478();ld(l36.l136()>255)l36="\x54\x6f\x6f\x20"
"\x6d\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f"
"\x72\x20\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x57\x69\x7a\x61\x72\x64"
;ld(lk::ln().l210()&&l38->l151)l46+="\x58";ld(l38->l753==lg::l55::
l204)l46+="\x21";ld(lk::ln().l292()&&l38->l336)l46+="\x24";ld(lk::ln(
).l210()&&l38->l312)l46+="\x26";ld(l38->l266)l46+="\x23";la::l119<ls>
l130(10+l35);ls*l2=&l130[0];l28 l304=l52();ld(lk::ln().l210()&&l38->
l151)l304+="\x53\x79\x6e\x63";( *l2++)=lf(l51);( *l2++)=lf(l304);( *
l2++)=lf(l46);( *l2++)=lf(l25());( *l2++)=lf(l36);( *l2++)=lf(l464);(
 *l2++)=lf(l38->l707);( *l2++)=lf("");ld(!l169.l45()&&l169!="\x61\x75"
"\x74\x6f")( *l2++)=lf(l169);lq( *l2++)=lf(l106);( *l2++)=lf(l58());
lh l11=0;l17(l28&l93:l20){++l11;ld(l11<l35){( *l2++)=lf(l93.l58());}
lq{( *l2++)=lf(l93.l58()+"\x2e\x20");}}ld(lk::ln().l292()){l35=la::
l186(l35,245);}lq{l35=la::l186(l35,20);}lf l3;lh lj=lk::ln().l21(l475
,l3,10+l35,&l130[0]);ld(lj==l1&&l3.l345()){l82=l3.l95<l16>();}lq{l82=
l107;}le lj;}lm lg::l55::l251(la::l481&l4)lb{l4<<"\x3c\x69\x6e\x74"
"\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e\x3e"<<la::li;l0&l20=l38->l54;l4
<<"\x3c\x70\x61\x72\x61\x3e"<<l58()<<"\x3c\x2f\x70\x61\x72\x61\x3e"<<
la::li;la::lc l36;l0::l199 l10=l20.l92();l196(l10!=l20.l60()){l36+=( *
l10).l52();++l10;ld(l10!=l20.l60())l36+="\x2c\x20";}l4<<"\x3c\x63\x6f"
"\x64\x65\x3e\x3d"<<l25()<<"\x28"<<l36<<"\x29\x3c\x2f\x63\x6f\x64\x65"
"\x3e"<<la::li;l4<<"\x3c\x2f\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69"
"\x6f\x6e\x3e"<<la::li;l4<<"\x3c\x73\x65\x63\x74\x69\x6f\x6e\x3e"<<la
::li;l4<<"\x20\x20\x3c\x74\x69\x74\x6c\x65\x3e\x50\x61\x72\x61\x6d"
"\x65\x74\x65\x72\x73\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<la::li;l4<<""
"\x20\x20\x3c\x63\x6f\x6e\x74\x65\x6e\x74\x3e"<<la::li;l17(l10=l20.
l92();l10!=l20.l60();++l10){l4<<"\x20\x20\x20\x20\x3c\x70\x61\x72\x61"
"\x3e";l4<<( *l10).l52()<<"\x3a\x20"<<( *l10).l58();l4<<"\x3c\x2f\x70"
"\x61\x72\x61\x3e"<<la::li;}l4<<"\x20\x20\x3c\x2f\x63\x6f\x6e\x74\x65"
"\x6e\x74\x3e"<<la::li;l4<<"\x3c\x2f\x73\x65\x63\x74\x69\x6f\x6e\x3e"
<<la::li;}
l26{la::lc l77(lb lp*l419,lb lp*l49,lb lp*l78){la::lc ll(l419);ld(l49
){ll+="\x2c\x20";ll+=l49;}ld(l78){ll+="\x20";ll+=l78;}le ll;}}l26 lg{
lm l182::l490(lh l64,lb lp*l49,lb lp*l78){ld(l64&l625)lz"\x75\x6e\x63"
"\x61\x6c\x63\x75\x6c\x61\x74\x65\x64";ld(l64&l600)lz"\x61\x62\x6f"
"\x72\x74";ld(l64&l557)lz"\x73\x74\x61\x63\x6b\x20\x6f\x76\x65\x72"
"\x66\x6c\x6f\x77";ld(l64&l404)lz(l77("\x69\x6e\x76\x61\x6c\x69\x64"
"\x20\x4f\x50\x45\x52\x20\x73\x74\x72\x75\x63\x74\x75\x72\x65\x20\x28"
"\x6d\x65\x6d\x6f\x72\x79\x20\x63\x6f\x75\x6c\x64\x20\x62\x65\x20\x65"
"\x78\x68\x61\x75\x73\x74\x65\x64\x29",l49,l78));ld(l64&l234)lz(l77(""
"\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x61\x69\x6c\x65\x64",l49,l78));
ld(l64&l402)lz(l77("\x69\x6e\x76\x61\x6c\x69\x64\x20\x6e\x75\x6d\x62"
"\x65\x72\x20\x6f\x66\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73",l49,
l78));ld(l64&l761)lz(l77("\x69\x6e\x76\x61\x6c\x69\x64\x20\x66\x75"
"\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x75\x6d\x62\x65\x72",l49,l78));ld(
l64&l597)lz(l77("\x69\x6e\x76\x61\x6c\x69\x64\x20\x61\x73\x79\x6e\x63"
"\x68\x20\x63\x6f\x6e\x65\x78\x74",l49,l78));ld(l64&l555)lz(l77("\x66"
"\x75\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x63\x6c\x75\x73\x74"
"\x65\x72\x20\x73\x61\x66\x65",l49,l78));}lm l182::l680(lh l76,lb lp*
l49,lb lp*l148){ld(l76==l530)lz(l77("\x70\x61\x72\x61\x6d\x65\x74\x65"
"\x72\x20\x69\x73\x20\x6d\x69\x73\x73\x69\x6e\x67",l49,l148));ld(l76
==l458)lz(l77("\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x73\x20"
"\x65\x72\x72\x6f\x72",l49,l148));ld(l76==l429)lz(l77("\x70\x61\x72"
"\x61\x6d\x65\x74\x65\x72\x20\x69\x73\x20\x6e\x69\x6c",l49,l148));
l490(l404,l49,l148);}la::lc l182::l554(lh l488){l90 l24=l488&0xFFF;ld
(l24==l611)le"\x78\x6c\x74\x79\x70\x65\x4e\x75\x6d";lq ld(l24==l307)le""
"\x78\x6c\x74\x79\x70\x65\x53\x74\x72";lq ld(l24==l613)le"\x78\x6c"
"\x74\x79\x70\x65\x42\x6f\x6f\x6c";lq ld(l24==l529)le"\x78\x6c\x74"
"\x79\x70\x65\x52\x65\x66";lq ld(l24==l458)le"\x78\x6c\x74\x79\x70"
"\x65\x45\x72\x72";lq ld(l24==l495)le"\x78\x6c\x74\x79\x70\x65\x4d"
"\x75\x6c\x74\x69";lq ld(l24==l530)le"\x78\x6c\x74\x79\x70\x65\x4d"
"\x69\x73\x73\x69\x6e\x67";lq ld(l24==l429)le"\x78\x6c\x74\x79\x70"
"\x65\x4e\x69\x6c";lq ld(l24==l649)le"\x78\x6c\x74\x79\x70\x65\x53"
"\x52\x65\x66";lq ld(l24==l174)le"\x78\x6c\x74\x79\x70\x65\x49\x6e"
"\x74";lq le"\x75\x6e\x6b\x6e\x6f\x77\x6e";}}
l26{la::lc l252(l565 l388,l527 l218){la::l170 l4;l527 l139=l218;ld(
l218>26*26){lp l127='A'+l139/(26*26)-1;l139%=(26*26);l4<<l127;}ld(
l218>26){lp l127='A'+l139/26-1;l139%=26;l4<<l127;}{lp l127='A'+l139;
l4<<l127;}l4<<l388+1;le l4.l105();}}l26 lg{la::lc l480::l658(){la::lc
ll=l252(l192,l219);ld(l197>l219+1||l173>l192+1){ll+="\x3a";ll+=l252(
l173-1,l197-1);}le ll;}la::lc l480::l749(){la::l170 l4;l4<<"\x52"<<
l192+1<<"\x43"<<l219+1;ld(l197>l219+1||l173>l192+1){l4<<"\x3a"<<"\x52"
<<l173<<"\x43"<<l197;}le l4.l105();}}
l26 lg{l137 l619 l79;l26{l66 lf lv(lh lu,lb lp*l23){lf ll;lh lj=lk::
ln().l21(lu,ll,0,0);ld(lj!=l1)lz(la::lc(l23)+la::lc("\x20\x66\x61\x69"
"\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63"
"\x6f\x64\x65\x20")+la::l39(lj));le ll;}l66 lf lv(lh lu,lb lf&l5,lb lp
 *l23){lf ll;lb l67 l31[]={l5};lh lj=lk::ln().l21(lu,ll,1,l31);ld(lj
!=l1)lz(la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::
l39(lj));le ll;}l66 lf lv(lh lu,lb lf&l5,lb lf&l22,lb lp*l23){lf ll;
lb l67 l31[]={l5,l22};lh lj=lk::ln().l21(lu,ll,2,l31);ld(lj!=l1)lz(la
::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68"
"\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::l39(lj));
le ll;}l66 lf lv(lh lu,lb lf&l5,lb lf&l22,lb lf&l53,lb lp*l23){lf ll;
lb l67 l31[]={l5,l22,l53};lh lj=lk::ln().l21(lu,ll,3,l31);ld(lj!=l1)lz
(la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68"
"\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::l39(lj));
le ll;}l66 lf lv(lh lu,lb lf&l5,lb lf&l22,lb lf&l53,lb lf&l99,lb lp*
l23){lf ll;lb l67 l31[]={l5,l22,l53,l99};lh lj=lk::ln().l21(lu,ll,4,
l31);ld(lj!=l1)lz(la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64"
"\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65"
"\x20")+la::l39(lj));le ll;}l66 lm l12(lh l80,lb lp*l23){lf ll;lh lj=
lk::ln().l21(l80,ll,0,0);ld(lj!=l1)lz(la::lc(l23)+la::lc("\x20\x66"
"\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74"
"\x20\x63\x6f\x64\x65\x20")+la::l39(lj));}l66 lm l12(lh l80,lb lf&l5,
lb lp*l23){lf ll;lb l67 l31[]={l5};lh lj=lk::ln().l21(l80,ll,1,l31);
ld(lj!=l1)lz(la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77"
"\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
la::l39(lj));}l66 lm l12(lh l80,lb lf&l5,lb lf&l22,lb lp*l23){lf ll;
lb l67 l31[]={l5,l22};lh lj=lk::ln().l21(l80,ll,2,l31);ld(lj!=l1)lz(
la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68"
"\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::l39(lj));
}l66 lm l12(lh l80,lb lf&l5,lb lf&l22,lb lf&l53,lb lp*l23){lf ll;lb
l67 l31[]={l5,l22,l53};lh lj=lk::ln().l21(l80,ll,3,l31);ld(lj!=l1)lz(
la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68"
"\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::l39(lj));
}l66 lm l12(lh l80,lb lf&l5,lb lf&l22,lb lf&l53,lb lf&l99,lb lp*l23){
lf ll;lb l67 l31[]={l5,l22,l53,l99};lh lj=lk::ln().l21(l80,ll,4,l31);
ld(lj!=l1)lz(la::lc(l23)+la::lc("\x20\x66\x61\x69\x6c\x65\x64\x20\x77"
"\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+
la::l39(lj));}}l281&l281::l142=(lb la::lc&l43){l12(l539,l75,l43,"\x53"
"\x65\x74\x20\x53\x74\x61\x74\x75\x73\x20\x42\x61\x72");le*l129;}lm
l281::l262(){l12(l539,0,l34,"\x43\x6c\x65\x61\x72\x20\x53\x74\x61\x74"
"\x75\x73\x20\x42\x61\x72");}lf l306::l762(lb lf&l89,lh l250,lh l337){
ld(l337==0){le lv(l386,l89,l250+1,"\x47\x65\x74\x20\x4e\x6f\x74\x65");
}lq{le lv(l386,l89,l250+1,l337,"\x47\x65\x74\x20\x4e\x6f\x74\x65");}}
lm l306::l652(lb lf&l89,lb la::lc&l392){l12(l370,l392,l89,"\x53\x65"
"\x74\x20\x4e\x6f\x74\x65");}lm l306::l644(lb lf&l89){l12(l370,lf(),
l89,"\x43\x6c\x65\x61\x72\x20\x4e\x6f\x74\x65");}l16 l47::l405(){le lv
(l748,"\x47\x65\x74\x20\x4e\x6f\x77").l114();}lf l47::l661(){le lv(
l717,"\x43\x61\x6c\x6c\x69\x6e\x67\x20\x43\x65\x6c\x6c");}lf l47::
l487(){le lv(l665,"\x47\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20\x43"
"\x65\x6c\x6c");}lf l47::l697(){le lv(l651,"\x47\x65\x74\x20\x41\x63"
"\x74\x69\x76\x65\x20\x52\x61\x6e\x67\x65");}lm l47::l650(lb lf&lr){
l12(l485,lr,"\x53\x65\x74\x20\x41\x63\x74\x69\x76\x65\x20\x43\x65\x6c"
"\x6c");}la::lc l47::l747(lb lf&l89){lh l128=(lk::ln().l276()?0:l220);
le lv(l492|l128,l89,"\x47\x65\x74\x20\x46\x6f\x72\x6d\x75\x6c\x61").
l83();}la::lc l47::l586(la::lc l420){le lv(l376,l420,l75,l34,1,"\x46"
"\x6f\x72\x6d\x75\x6c\x61\x20\x43\x6f\x6e\x76\x65\x72\x74").l83();}la
::lc l47::l675(la::lc l470,lt l477,lt l502){lh l431(4-l477?2:0-l502?1
:0);le lv(l376,l470,l34,l75,l431,"\x46\x6f\x72\x6d\x75\x6c\x61\x20"
"\x43\x6f\x6e\x76\x65\x72\x74").l83();}lf l47::l588(la::lc l542){le lv
(l399,l542,l75,"\x54\x65\x78\x74\x20\x52\x65\x66");}lf l47::l350(la::
lc l534){le lv(l399,l534,l34,"\x54\x65\x78\x74\x20\x52\x65\x66");}lf
l47::l350(lf l452,la::lc l448){le lv(l710,l448,l452,"\x41\x62\x73\x20"
"\x52\x65\x66");}la::lc l47::l725(lb lf&lr){le lv(l394,lr,l75,"\x52"
"\x65\x66\x20\x54\x65\x78\x74").l83();}la::lc l47::l607(lb lf&lr){le
lv(l394,lr,l34,"\x52\x65\x66\x20\x54\x65\x78\x74").l83();}la::lc l47
::l614(lb lf&lr){le lv(l615,lr,"\x47\x65\x74\x20\x53\x68\x65\x65\x74"
"\x20\x4e\x61\x6d\x65").l83();}l548 l47::l622(){lf ll;lh lj=lk::ln().
l21(l733,(l67)&ll,0,0);ld(lj!=l1)lz(la::lc("\x78\x6c\x53\x68\x65\x65"
"\x74\x49\x64\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x72"
"\x65\x73\x75\x6c\x74\x20\x63\x6f\x64\x65\x20")+la::l39(lj));le ll.
l694();}lf l63::l699(lb lf&lr){lh l128=(lk::ln().l276()?0:l220);le lv
(l492|l128,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x72\x6d\x75"
"\x6c\x61");}lm l63::l701(lb lf&lr,lb lf&l455){lh l128=(lk::ln().l276
()?0:l220);l12(l690|l128,l455,lr,"\x53\x65\x74\x20\x43\x65\x6c\x6c"
"\x20\x43\x6f\x6e\x74\x65\x6e\x74\x73");}l16 l63::l624(lb lf&lr){le lv
(l145,17,lr,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x48\x65\x69\x67\x68"
"\x74").l114();}lm l63::l764(lb lf&lr,l16 l235){l12(l669,l235,"\x53"
"\x65\x74\x20\x52\x6f\x77\x20\x48\x65\x69\x67\x68\x74");}l16 l63::
l633(lb lf&lr){l16 l385(lv(l145,44,lr,"\x47\x65\x74\x20\x52\x69\x67"
"\x68\x74\x20\x50\x6f\x73\x69\x74\x69\x6f\x6e").l114());l16 l438(lv(
l145,42,lr,"\x47\x65\x74\x20\x4c\x65\x66\x74\x20\x50\x6f\x73\x69\x74"
"\x69\x6f\x6e").l114());le l385-l438;}lm l63::l755(lb lf&lr,l16 l235){
l12(l580,l235,"\x53\x65\x74\x20\x43\x65\x6c\x6c\x20\x57\x69\x64\x74"
"\x68");}la::lc l63::l578(lb lf&lr){le lv(l145,18,lr,"\x47\x65\x74"
"\x20\x43\x65\x6c\x6c\x20\x46\x6f\x6e\x74").l83();}l26{lm l320(lb lf&
lr,lb lf&l425,lb lf&l389){lf l450(l79.l344.l487());l79.l73.l213(lr);
lf l50;lb l67 l31[]={l425,l50,l389,l50,l50,l50,l50,l50,l50,l50,l50,
l50,l50,l50};lh lj=lk::ln().l21(l574,0,14,l31);l79.l73.l213(l450);ld(
lj!=l1)lz(la::lc("\x53\x65\x74\x20\x46\x6f\x6e\x74\x20\x50\x72\x6f"
"\x70\x65\x72\x74\x69\x65\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69"
"\x74\x68\x20\x63\x6f\x64\x65\x20")+la::l39(lj));}}lm l63::l654(lb lf
&lr,lb la::lc&l367){l320(lr,l367,lf());}l16 l63::l706(lb lf&lr){le lv
(l145,19,lr,"\x47\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x6e\x74").
l114();}lm l63::l653(lb lf&lr,l16 l445){l320(lr,lf(),l445);}la::lc l63
::l732(lb lf&lr){l28 l3=lv(l145,7,lr,"\x47\x65\x74\x20\x43\x65\x6c"
"\x6c\x20\x46\x6f\x72\x6d\x61\x74");le l3.l723()?l3.l83():"";}lm l63
::l677(lb lf&lr,lb la::lc&l493){l79.l73.l213(lr);lf l153=l493;l12(
l636,l153,"\x53\x65\x74\x20\x43\x65\x6c\x6c\x20\x46\x6f\x72\x6d\x61"
"\x74");}lm l40::l550(lb la::lc&l43){l12(l683,l43,"\x41\x6c\x65\x72"
"\x74\x20\x43\x6f\x6d\x6d\x61\x6e\x64");}la::lc l40::l695(lb la::lc&
l43,lb la::lc&l65,lb la::lc&l102){le lv(l132,l43,0,l65,l102,"\x49\x6e"
"\x70\x75\x74\x20\x46\x6f\x72\x6d\x75\x6c\x61").l83();}l16 l40::l641(
lb la::lc&l43,lb la::lc&l65,l16 l102){le lv(l132,l43,1,l65,l102,"\x49"
"\x6e\x70\x75\x74\x20\x4e\x75\x6d\x62\x65\x72").l114();}la::lc l40::
l628(lb la::lc&l43,lb la::lc&l65,lb la::lc&l102){le lv(l132,l43,2,l65
,l102,"\x49\x6e\x70\x75\x74\x20\x54\x65\x78\x74").l83();}lt l40::l657
(lb la::lc&l43,lb la::lc&l65){le lv(l132,l43,4,l65,"\x49\x6e\x70\x75"
"\x74\x20\x42\x6f\x6f\x6c").l692();}lf l40::l678(lb la::lc&l43,lb la
::lc&l65,lb la::lc&l102){le lv(l132,l43,8,l65,l102,"\x49\x6e\x70\x75"
"\x74\x20\x52\x65\x66\x65\x72\x65\x6e\x63\x65");}lf l40::l562(lb la::
lc&l43,lb la::lc&l65){le lv(l132,l43,64,l65,"\x49\x6e\x70\x75\x74\x20"
"\x41\x72\x72\x61\x79");}lm l40::l213(lb lf&lr){l12(l485,lr,"\x53\x65"
"\x6c\x65\x63\x74\x20\x52\x61\x6e\x67\x65");}lf l40::l567(lb lf&l342){
le lv(l666,l342,"\x53\x68\x6f\x77\x20\x44\x69\x61\x6c\x6f\x67\x20\x42"
"\x6f\x78");}lm l40::l724(){l12(l525,1,"\x57\x6f\x72\x6b\x73\x68\x65"
"\x65\x74\x20\x49\x6e\x73\x65\x72\x74");}lm l40::l743(){l12(l525,3,""
"\x49\x6e\x73\x65\x72\x74\x20\x4d\x61\x63\x72\x6f\x20\x53\x68\x65\x65"
"\x74");}lm l40::l631(){l12(l612,"\x53\x65\x6c\x65\x63\x74\x20\x50"
"\x72\x65\x76\x69\x6f\x75\x73\x20\x53\x68\x65\x65\x74");}lm l40::l590
(){l12(l576,"\x53\x65\x6c\x65\x63\x74\x20\x4e\x65\x78\x74\x20\x53\x68"
"\x65\x65\x74");}lm l40::l741(lt l518){l12(l682,l518,"\x45\x63\x68"
"\x6f");}lm l40::l384(l16 l181,lb la::lc&l198){l12(l583,l181,l198,""
"\x4f\x6e\x20\x54\x69\x6d\x65");}lm l40::l599(l16 l181,lb la::lc&l198
){l28 l159=l79.l344.l405();l79.l73.l384(l159+l181/(60.*60.*24.),l198);
}l214::l214(){l241=lv(l687,14,"\x47\x65\x74\x20\x44\x6f\x63\x75\x6d"
"\x65\x6e\x74\x20\x70\x72\x6f\x70\x65\x72\x69\x65\x73\x20\x66\x6f\x72"
"\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6f\x6e").l709();ld(l241<3){
l12(l413,3,"\x53\x65\x74\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69\x6f"
"\x6e\x20\x6f\x70\x74\x69\x6f\x73\x6e");}}l214::~l214(){ld(l241<3){
l12(l413,l241,"\x53\x65\x74\x20\x63\x61\x6c\x63\x75\x6c\x61\x74\x69"
"\x6f\x6e\x20\x6f\x70\x74\x69\x6f\x73\x6e");}}}
l200 l26 lg;l200 l26 l283;l201::l201(lb la::lc&l364,lb la::lc&l351,lb
la::lc&l393,lb la::lc&l423,lb l356 l341[],lh l414,lt l474,lt l336,lb
la::lc&l508,lb la::lc&l411,lt l151,lt l266,lt l312):l27(l364),l161(
l351),l391(l393),l230(l423),l176(l414),l380(l474),l354(l336),l460(
l508),l126(l411),l521(l151),l526(l266),l378(l312){l46.l357(l176);l17(
lh l19=0;l19<l176;l19++)l46.l155(l341[l19]);}l489::l489(lb la::lc&
l514,lb la::lc&l501,lb la::lc&l403,lb la::lc&l366,lb l356 l346[],lh
l363,lt l204,lt l216,lb la::lc&l238,lb la::lc&l126,lt l224,lt l237,lt
l177){l201 l226(l514,l501,l403,l366,l346,l363,l204,l216,l238,l126,
l224,l237,l177);l69::ln().l465(l226);}l410::l410(lb la::lc&l387,lb la
::lc&l483,lb la::lc&l469,lb la::lc&l451,lb la::lc&l442){l499 l226(
l387,l483,l469,l451,l442);l69::ln().l428(l226);}l160*l739(lb l15*l105
){l18 l180=l684(l105);l160*l248=l85 l160[l180+2];l248[0]=l86<l160>(
l180);l627(&l248[1],l180+1,l105);le l248;}lm l69::l359()lb{lh l11=1;
l17(l28&[l81,l74]:l112){l74->l325(l11);++l11;}l17(l28&[l81,l41]:l73){
l41->l325(l11);l41->l408();++l11;}}lm l69::l440()lb{l17(l28&[l81,l74]
:l112)l74->l268();l17(l28&[l81,l41]:l73){l41->l512();l41->l268();}}lm
l69::l465(lb l201&l14){l28 l536=l14.l380?l55::l204:l55::l711;la::l275
<l55>l255(l85 l55(l14.l27,l14.l161,l14.l391,l14.l230,l536,l14.l354,
l14.l460,l14.l126,l14.l521,l14.l526,l14.l378));l0 l273;l17(lh l19=0;
l19<l14.l176;++l19){l33 l93(l14.l46[l19]);l273+l93;}l255->l305(l273);
l112[l14.l161]=l255;}lm l69::l428(lb l499&l14){la::l275<l61>l497(l85
l61(l14.l27,l14.l161,l14.l57,l14.l62,l14.l618,!l14.l62.l45()));l73[
l14.l161]=l497;}lm l69::l516(lb la::lc&l141){la::l331 lo(l141.l13());
lo<<"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73\x69\x6f\x6e\x3d\"\x31"
"\x2e\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67\x3d\"\x75\x74\x66\x2d"
"\x38\"\x20\x3f\x3e"<<la::li;lo<<"\x3c\x63\x6f\x6e\x66\x69\x67\x75"
"\x72\x61\x74\x69\x6f\x6e\x3e"<<la::li;lo<<"\x3c\x6c\x61\x6e\x67\x75"
"\x61\x67\x65\x73\x3e"<<la::li;lo<<"\x3c\x6c\x61\x6e\x67\x75\x61\x67"
"\x65\x20\x69\x64\x3d\"\x31\x30\x33\x33\"\x20\x63\x6f\x64\x65\x70\x61"
"\x67\x65\x3d\"\x36\x35\x30\x30\x31\"\x20\x6e\x61\x6d\x65\x3d\"\x30"
"\x78\x34\x30\x39\x20\x45\x6e\x67\x6c\x69\x73\x68\x20" "\x28\x55\x6e"
"\x69\x74\x65\x64\x20\x53\x74\x61\x74\x65\x73\x29\"\x20\x2f\x3e"<<la
::li;lo<<"\x3c\x2f\x6c\x61\x6e\x67\x75\x61\x67\x65\x73\x3e"<<la::li;
lo<<"\x3c\x63\x68\x6d\x54\x69\x74\x6c\x65\x73\x3e"<<la::li;lo<<"\x3c"
"\x74\x69\x74\x6c\x65\x20\x70\x72\x6f\x6a\x65\x63\x74\x4e\x61\x6d\x65"
"\x3d\"\x58\x6c\x77\"\x3e\x41\x64\x64\x2d\x69\x6e\x20\x48\x65\x6c\x70"
"\x3c\x2f\x74\x69\x74\x6c\x65\x3e"<<la::li;lo<<"\x3c\x2f\x63\x68\x6d"
"\x54\x69\x74\x6c\x65\x73\x3e"<<la::li;lo<<"\x3c\x68\x68\x70\x54\x65"
"\x6d\x70\x6c\x61\x74\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e"
"\x5b\x4f\x50\x54\x49\x4f\x4e\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<
la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x43\x6f\x6d\x70\x61\x74\x69\x62"
"\x69\x6c\x69\x74\x79\x3d\x31\x2e\x31\x20\x6f\x72\x20\x6c\x61\x74\x65"
"\x72\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65"
"\x3e\x43\x6f\x6d\x70\x69\x6c\x65\x64\x20\x66\x69\x6c\x65\x3d\x7b\x30"
"\x7d\x2e\x63\x68\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c"
"\x6c\x69\x6e\x65\x3e\x43\x6f\x6e\x74\x65\x6e\x74\x73\x20\x66\x69\x6c"
"\x65\x3d\x7b\x30\x7d\x2e\x68\x68\x63\x3c\x2f\x6c\x69\x6e\x65\x3e"<<
la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x44\x65\x66\x61\x75\x6c\x74\x20"
"\x54\x6f\x70\x69\x63\x3d\x7b\x31\x7d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<
la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x46\x75\x6c\x6c\x2d\x74\x65\x78"
"\x74\x20\x73\x65\x61\x72\x63\x68\x3d\x59\x65\x73\x3c\x2f\x6c\x69\x6e"
"\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x4c\x61\x6e\x67\x75"
"\x61\x67\x65\x3d\x7b\x32\x7d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo
<<"\x3c\x6c\x69\x6e\x65\x3e\x54\x69\x74\x6c\x65\x3d\x7b\x33\x7d\x3c"
"\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x5b"
"\x46\x49\x4c\x45\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<""
"\x3c\x6c\x69\x6e\x65\x3e\x69\x63\x6f\x6e\x73\\\x2a\x2e\x67\x69\x66"
"\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e"
"\x61\x72\x74\\\x2a\x2e\x67\x69\x66\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la
::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x6d\x65\x64\x69\x61\\\x2a\x2e\x67"
"\x69\x66\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e"
"\x65\x3e\x73\x63\x72\x69\x70\x74\x73\\\x2a\x2e\x6a\x73\x3c\x2f\x6c"
"\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x73\x74\x79"
"\x6c\x65\x73\\\x2a\x2e\x63\x73\x73\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la
::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x68\x74\x6d\x6c\\\x2a\x2e\x68\x74"
"\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65"
"\x3e\x5b\x41\x4c\x49\x41\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::
li;lh l11=1;l17(l28&[l81,l74]:l112){lo<<"\x3c\x6c\x69\x6e\x65\x3e\x41"
<<l11<<"\x3d\x68\x74\x6d\x6c\\"<<l74->l25()<<"\x2e\x68\x74\x6d\x3c"
"\x2f\x6c\x69\x6e\x65\x3e"<<la::li;++l11;}l17(l28&[l81,l41]:l73){lo<<""
"\x3c\x6c\x69\x6e\x65\x3e\x41"<<l11<<"\x3d\x68\x74\x6d\x6c\\"<<l41->
l25()<<"\x2e\x68\x74\x6d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;++l11;}
lo<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x4d\x41\x50\x5d\x3c\x2f\x6c\x69\x6e"
"\x65\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x23\x69\x6e\x63\x6c"
"\x75\x64\x65\x20\x61\x6c\x69\x61\x73\x2e\x68\x3c\x2f\x6c\x69\x6e\x65"
"\x3e"<<la::li;lo<<"\x3c\x6c\x69\x6e\x65\x3e\x5b\x49\x4e\x46\x4f\x54"
"\x59\x50\x45\x53\x5d\x3c\x2f\x6c\x69\x6e\x65\x3e"<<la::li;lo<<"\x3c"
"\x2f\x68\x68\x70\x54\x65\x6d\x70\x6c\x61\x74\x65\x3e"<<la::li;lo<<""
"\x3c\x2f\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3e"<<
la::li;}lm l69::l430(lb la::lc&l141){la::l331 lo(l141.l13());lo<<""
"\x3c\x3f\x78\x6d\x6c\x20\x76\x65\x72\x73\x69\x6f\x6e\x3d\"\x31\x2e"
"\x30\"\x20\x65\x6e\x63\x6f\x64\x69\x6e\x67\x3d\"\x75\x74\x66\x2d\x38"
"\"\x3f\x3e"<<la::li;lo<<"\x3c\x74\x6f\x70\x69\x63\x73\x3e"<<la::li;
lh l11=1;ld(l112.l42()>0){lo<<"\x3c\x74\x6f\x70\x69\x63\x20\x69\x64"
"\x3d\"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\"\x20\x66\x69\x6c\x65\x3d"
"\"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\"\x3e"<<la::li;l17(l28&[l81,
l74]:l112){lo<<"\x3c\x74\x6f\x70\x69\x63\x20\x69\x64\x3d\""<<l74->l25
()<<"\"\x20\x66\x69\x6c\x65\x3d\""<<l74->l25()<<"\"\x20\x2f\x3e"<<la
::li;++l11;}lo<<"\x3c\x2f\x74\x6f\x70\x69\x63\x3e"<<la::li;}ld(l73.
l42()>0){lo<<"\x3c\x74\x6f\x70\x69\x63\x20\x69\x64\x3d\"\x43\x6f\x6d"
"\x6d\x61\x6e\x64\x73\"\x20\x66\x69\x6c\x65\x3d\"\x43\x6f\x6d\x6d\x61"
"\x6e\x64\x73\"\x3e"<<la::li;l17(l28&[l81,l41]:l73){lo<<"\x3c\x74\x6f"
"\x70\x69\x63\x20\x69\x64\x3d\""<<l41->l25()<<"\"\x20\x66\x69\x6c\x65"
"\x3d\""<<l41->l25()<<"\"\x20\x2f\x3e"<<la::li;++l11;}lo<<"\x3c\x2f"
"\x74\x6f\x70\x69\x63\x3e"<<la::li;}lo<<"\x3c\x2f\x74\x6f\x70\x69\x63"
"\x73\x3e"<<la::li;}lm l69::l459(lb la::lc&l91){l516(l91+"\\\x43\x68"
"\x6d\x42\x75\x69\x6c\x64\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67");l430(
l91+"\\\x74\x6f\x63\x2e\x78\x6d\x6c");lh l11=1;l17(l28&[l81,l74]:l112
){l74->l313(l91,l11);++l11;}l17(l28&[l81,l41]:l73){l41->l313(l91,l11);
++l11;}}l412"\x43"{lm l222 l667(lb lp*l91){l69::ln().l459(l91);}}
