xl.h
If have Eigen, define WITH_EIGEN before including <xlw/xl.h>
For Python (or any other use that requires xlw-mock.h) define PY
Include df.cpp in Python compilation.
Include xlw.cpp and df.cpp in xll compilation (don't need to link to any libraries)