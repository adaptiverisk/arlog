#pragma once

#include <xlw/xl.h>

using namespace xlw;

/*
Limitations:

For now skipping anything related to multi-indexes and datetime.
Many datetime related functionality will work automatically
since in Excel dates are represented as doubles.
*/

//<xlw:libraryname=xlw

// XlfOper // test function
// arx_testing(const XlfOper& x);

XlfOper                // Transpose dataframe
df_T(const XlfOper& df // dataframe to transpose
);

XlfOper                        // Transpose dataframe
df_transpose(const XlfOper& df // dataframe to transpose
);

XlfOper                    // Get index (row labels) column
df_index(const XlfOper& df // dataframe
);

XlfOper                      // Get columns (col labels) row
df_columns(const XlfOper& df // datafarame
);

XlfOper // Summary of a DataFame
df_info(
    const XlfOper& df,      // dataframe
    const XlfOper& verbose, // (true/false) whether to output the full summary.
                            // (optional: if not specified, verbose if number of
                            // columns small)
    const XlfOper&
        max_cols // (optional: default = 100)
                 // When to switch from the verbose to the truncated output
);

XlfOper // Return or assign to a single value for a row/column label pair.
df_at(
    const XlfOper& df,        // dataframe
    const XlfOper& row,       // row label
    const XlfOper& col,       // col label
    const XlfOper& assign_op, // (optional default '=') assignment operator
                              // ('=', '+=', '-=',
                              // '/=', '*=', '%=', '**=') Used only when value
                              // is specified.
    const XlfOper&
        value // optional. If specified, set the value at the specified
              // location and return whole dataframe. If not specified,
              // return the value at the specified location.
);

XlfOper // Access a single value for a row/column pair by integer position.
df_iat(
    const XlfOper& df,        // dataframe
    const XlfOper& irow,      // row index (starts with 0)
    const XlfOper& icol,      // col index (starts with 0)
    const XlfOper& assign_op, // (optional default '=') assignment operator
                              // ('=', '+=', '-=',
                              // '/=', '*=', '%=', '**=') Used only when value
                              // is specified.
    const XlfOper&
        value // optional. If specified, set the value at the specified
              // location and return whole dataframe. If not specified,
              // return the value at the specified location.
);

XlfOper // Purely integer-location based indexing for selection by position.
df_iloc(
    const XlfOper& df,   // dataframe
    const XlfOper& rows, // idx: 0, list of idx [0, 1], slice: ":3", boolean
                         // mask: [True, False, True]
    const XlfOper& cols, // optional. Similar to rows.
    const XlfOper& assign_op, // (optional default '=') assignment operator
                              // ('=', '+=', '-=',
                              // '/=', '*=', '%=', '**=') Used only when value
                              // is specified.
    const XlfOper&
        value // optional. If specified set the value at the
              // loc and return whole dataframe. If not specified,
              // return the val at the loc.
              // scalar, column, row, 2d range, dataframe (align): if
              // single row * - align by col, single col * - align by row
);

XlfOper // Access a group of rows and columns by label(s) or a boolean array.
df_loc(
    const XlfOper& df,   // dataframe
    const XlfOper& rows, // lbl, list of lbls, slice with lbls: 'a':'f', boolean
                         // mask, alignable boolean mask (df)
    const XlfOper& cols, // optional. Similar to rows
    const XlfOper& assign_op, // (optional default '=') assignment operator
    // ('=', '+=', '-=',
    // '/=', '*=', '%=', '**=') Used only when value
    // is specified.
    const XlfOper&
        value // optional. If specified set the value at the
              // loc and return whole dataframe. If not specified,
              // return the val at the loc.
              // scalar, column, row, 2d range, dataframe (align): if
              // single row * - align by col, single col * - align by row
);

XlfOper                    // Shape: rows, columns (not including labels)
df_shape(const XlfOper& df // dataframe
);

XlfOper // Return the first n rows.
df_head(
    const XlfOper& df, // dataframe
    const XlfOper& n   // int, default 5
);

XlfOper // Return the last n rows.
df_tail(
    const XlfOper& df, // dataframe
    const XlfOper& n   // int, default 5
);

XlfOper // Return a subset of the dataframe's columns based on data types
df_select_dtypes(
    const XlfOper& df, // dataframe
    const XlfOper&
        include, // include type or types (from number, string, boolean)
    const XlfOper&
        exclude // exclude type or types (from number, string, boolean)
);

XlfOper                   // Return number of elements (not including labels)
df_size(const XlfOper& df // dataframe
);

XlfOper // True if is entirely empty (no items) - any of the axes have size = 0
df_empty(const XlfOper& df // dataframe
);

XlfOper // Insert column into dataframe at specified location
df_insert(
    const XlfOper& df,              // dataframe
    const XlfOper& iloc,            // insertion index (start at 0)
    const XlfOper& column,          // column name
    const XlfOper& value,           // scalar or array (can be row or column)
    const XlfOper& allow_duplicates // optional (default: false)
);

XlfOper // Whether each element in the dataframe is contained in values
df_isin(
    const XlfOper& df,    // dataframe
    const XlfOper& values // - single val;
                          // - list of vals: 1d range, first el should be "*"
                          // - cols: el col name should match col name and
                          //   el val should be one of the vals in the col
                          // - dataframe: also should match indexes (can have
                          // single col '*' to use if for all columns in df)
);

XlfOper // Replace values where the condition is False (opposite of df_mask)
df_where(
    const XlfOper& df, // dataframe
    const XlfOper&
        cond, // bool dataframe (same size as df)
              // or 1d range (first el should be "*") - same size
              // as df.rows (if axis=0 or missing) or df.cols if axis=1
    const XlfOper& other, // optional. If not specified, all elements where cond
                          // is false will be set to NA. Otherwise set according
                          // to other: scalar, dataframe (same size as df), 1d
                          // range specifying values for each col. Value from
                          // other is converted to column type.
    const XlfOper& axis   // optional (see description of cond)
);

XlfOper // Replace values where the condition is True. (opposite of df_where)
df_mask(
    const XlfOper& df, // dataframe
    const XlfOper&
        cond, // bool dataframe (same size as df)
              // or 1d range (first el should be "*") - same size
              // as df.rows (if axis=0 or missing) or df.cols if axis=1
    const XlfOper& other, // optional. If not specified, all elements where cond
                          // is true will be set to NA. Otherwise set according
                          // to other: scalar, dataframe (same size as df), 1d
                          // range specifying values for each col. Value from
                          // other is converted to column type.
    const XlfOper& axis   // optional (see description of cond)
);

XlfOper // Return a new DataFrame with rows where query is false removed.
df_query(
    const XlfOper& df,       // dataframe
    const std::string& query // query string
);

XlfOper // add to dataframe (elementwise)
df_add(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // subtract from dataframe (elementwise)
df_sub(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // subtract dataframe from x (elementwise)
df_rsub(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // multiply dataframe and x (elementwise)
df_mul(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // divide dataframe by x (elementwise)
df_div(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // divide x by dataframe (elementwise)
df_rdiv(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // modulo of dataframe and x (elementwise)
df_mod(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // modulo of x and dataframe (elementwise)
df_rmod(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // dataframe taken to power of x (elementwise)
df_pow(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // x taken to dataframe power of x (elementwise)
df_rpow(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // or between dataframe and x (elementwise)
df_or(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // or between dataframe and x (elementwise)
df_and(
    const XlfOper& df,   // dataframe
    const XlfOper& x,    // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& fill_value // optional (default: None)
);

XlfOper // calculates dot product of two dataframes
df_dot(
    const XlfOper& df,   // dataframe
    const XlfOper& other // dataframe
);

XlfOper // df < x (elementwise)
df_lt(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // df > x (elementwise)
df_gt(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // df <= x (elementwise)
df_le(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // df >= x (elementwise)
df_ge(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // df != x (elementwise)
df_ne(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // df == x (elementwise)
df_eq(
    const XlfOper& df,  // dataframe
    const XlfOper& x,   // dataframe, scalar, columns, rows (align with df)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // fill missing values in dataframe from x. Extend rows and columns to
        // include both df and x
df_combine_first(
    const XlfOper& df, // dataframe
    const XlfOper& x   // scalar or dataframe
);

XlfOper                  // takes absolute value numeric elements
df_abs(const XlfOper& df // dataframe
);

XlfOper // return whether all elements are True, potentially over an axis
df_all(
    const XlfOper& df,        // dataframe
    const XlfOper& axis,      // optional (default: 0) - 1 for columns,
                              // 0 for rows, -1 for both
    const XlfOper& bool_only, // optional (default: false) if keep only boolean
                              // columns (rows)
    const XlfOper& skipna     // optional (default: True) skip missing values
);

XlfOper // return whether any element is True, potentially over an axis
df_any(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns,
    // 0 for rows, -1 for both
    const XlfOper& bool_only, // optional (default: false) if keep only boolean
    // columns (rows)
    const XlfOper& skipna // optional (default: True) skip missing values
);

XlfOper // trim values at input threshold(s)
df_clip(
    const XlfOper& df,    // dataframe
    const XlfOper& lower, // optional: minimum threshold value (dataframe,
                          // scalar, columns, rows)
    const XlfOper& upper, // optional: maximum threshold value (dataframe,
                          // scalar, columns, rows)
    const XlfOper& axis   // optional (default: 0) - 1 for columns,
                          // 0 for rows, -1 for both
);

XlfOper // return correlation between columns of the dataframe
df_corr(
    const XlfOper& df,     // dataframe
    const XlfOper& method, // optional (default: pearson) - pearson, spearman,
                           // kendall (only pearson is currently implemented)
    const XlfOper&
        min_periods, // optional (default: 1) - minimum number of observations
                     // required per pair of columns to have a valid result
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // return correlations between columns of same name in both dataframes
df_corrwith(
    const XlfOper& df,    // dataframe
    const XlfOper& other, // dataframe
    const XlfOper& axis,  // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        drop, // optional (default: false) - if true, drop missing values
    const XlfOper&
        method, // optional (default: pearson) - pearson, spearman, kendall
    // (only pearson is currently implemented)
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // count non-NA cells for each column or row
df_count(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // return covariance between columns of the dataframe
df_cov(
    const XlfOper& df, // dataframe
    const XlfOper&
        min_periods, // optional (default: 1) - minimum number of observations
    // required per pair of columns to have a valid result
    const XlfOper&
        ddof, // optional (default: 1) - degrees of freedom correction
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // return cumulative maximum over the dataframe
df_cummax(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        skipna // optional (default: true) - if true, skip missing values
);

XlfOper // return cumulative minimum over the dataframe
df_cummin(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        skipna // optional (default: true) - if true, skip missing values
);

XlfOper // return cumulative product over the dataframe
df_cumprod(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        skipna // optional (default: true) - if true, skip missing values
);

XlfOper // return cumulative sum over the dataframe
df_cumsum(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        skipna // optional (default: true) - if true, skip missing values
);

XlfOper // generate descriptive statistics
df_describe(
    const XlfOper& df,          // dataframe
    const XlfOper& percentiles, // optional (default: {0.25, 0.5, 0.75}) - list
                                // of percentiles to be computed
    const XlfOper& include, // optional (default: numeric) - list of data types
                            // to be included: (a)ll, or range or comma sep list
                            // of: (n)umber, (s)tring, (b)oolean, (a)ll
    const XlfOper& exclude  // optional: list of data types to be
                            // excluded
);

XlfOper // first discrete difference of element
df_diff(
    const XlfOper& df, // dataframe
    const XlfOper&
        periods, // optional (default: 1) - number of periods to shift for
                 // calculating difference (positive - shift back)
    const XlfOper& axis // optional (default: 0) - 1 for columns, 0 for rows
);

XlfOper // evaluate a string describing operations on DataFrame columns
df_eval(
    const XlfOper& df,  // dataframe
    const XlfOper& expr // string expression
);

XlfOper // compute unbiased kurtosis (Fisher) over requested axis (same as
        // df_kurtosis)
df_kurt(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
                           // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // compute unbiased kurtosis (Fisher) over requested axis (same as
        // df_kurt)
df_kurtosis(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
                           // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include
                                // float, int, boolean columns
);

XlfOper // max over requested axis
df_max(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // min over requested axis
df_min(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // mean over requested axis
df_mean(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // median over requested axis
df_median(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // product over requested axis
df_prod(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only, // optional (default: false) - if true, only
    // include float, int, boolean columns
    const XlfOper& min_count // optional (default: 0) - minimum number of values
);

XlfOper // product over requested axis
df_product(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only, // optional (default: false) - if true, only
    // include float, int, boolean columns
    const XlfOper& min_count // optional (default: 0) - minimum number of values
);

XlfOper // unbiased standard error of the mean over requested axis
df_sem(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& ddof,        // optional (default: 1) - degrees of freedom
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // skew over requested axis
df_skew(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // sum over requested axis
df_sum(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only, // optional (default: false) - if true, only
    // include float, int, boolean columns
    const XlfOper& min_count // optional (default: 0) - minimum number of values
);

XlfOper // sample standard deviation over requested axis
df_std(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& ddof,        // optional (default: 1) - degrees of freedom
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // unbiased variance over requested axis
df_var(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& ddof,        // optional (default: 1) - degrees of freedom
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // return index of first occurence of maximum over requested axis
df_idxmax(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // return index of first occurence of minimum over requested axis
df_idxmin(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0) - 1 for columns, 0 for rows, -1 for all
    const XlfOper& skipna, // optional (default: true) - if true, skip missing
    // values
    const XlfOper& numeric_only // optional (default: false) - if true, only
                                // include float, int, boolean columns
);

XlfOper // get the mode(s) of each element along the selected axis
df_mode(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& numeric_only, // optional (default: false) - if true, only
    // include float, int, boolean columns
    const XlfOper& dropna // optional (default: true) - if true, missing values
                          // are ignored else NA is treated as a value
);

XlfOper // percentage change between the current and a prior element
df_pct_change(
    const XlfOper& df,          // dataframe
    const XlfOper& periods,     // optional (default: 1) - number of periods to
                                // shift for forming percent change
    const XlfOper& fill_method, // optional (default: "pad") - how to handle NAs
                                // before computing percent change
    const XlfOper& limit        // optional (default: 0) - maximum number of
                                // consecutive NAs to fill before stopping
);

XlfOper // Return values at the given quantile over requested axis
df_quantile(
    const XlfOper& df,   // dataframe
    const XlfOper& q,    // optional (default: 0.5) quantile or sequence of
                         // quantiles to compute
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& numeric_only, // optional (default: false) - if true, only
    // include float, int, boolean columns
    const XlfOper& interpolation, // optional (default: "linear") -
                                  // interpolation method ('linear', 'lower',
                                  // 'higher', 'midpoint','nearest')
    const XlfOper&
        method // optional (default: "single") - whether to compute
               // quantile over entire dataframe or each column separately
               // ("single", "table")
);

XlfOper // Compute numerical data ranks (1 through n) along axis
df_rank(
    const XlfOper& df,     // dataframe
    const XlfOper& axis,   // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& method, // optional (default: "average") - ranking method
                           // ("average", "min", "max", "first", "dense")
    const XlfOper& numeric_only, // optional (default: false) - if true, only
                                 // include float, int, boolean columns
    const XlfOper&
        na_option, // optional (default: "keep") - how to handle NA values
                   // ("keep", "top", "bottom")
    const XlfOper& ascending, // optional (default: true) - if true, rank in
                              // ascending order
    const XlfOper&
        pct // optional (default: false) - if true, compute percentage rank
);

XlfOper // Roudn dataframe to a variable number of decimal places
df_round(
    const XlfOper& df,      // dataframe
    const XlfOper& decimals // optional (default: 0) - number of decimal places
                            // to round to. Can be a number, list or dataframe
);

XlfOper // Return the number of unique elements along the selected axis
df_nunique(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        dropna // optional (default: true) - if true, ignore missing values
);

XlfOper // Add prefix to column or row names
df_add_prefix(
    const XlfOper& df,     // dataframe
    const XlfOper& prefix, // prefix to add
    const XlfOper& axis    // optional (default: 1) - 1 for columns, 0 for rows
);

XlfOper // Add suffix to column or row names
df_add_suffix(
    const XlfOper& df,     // dataframe
    const XlfOper& suffix, // suffix to add
    const XlfOper& axis    // optional (default: 1) - 1 for columns, 0 for rows
);

XlfOper // Select values at particular time of day (e.g., 9:30AM, 1:00PM,
        // 4:45PM)
df_at_time(
    const XlfOper& df,   // dataframe
    const XlfOper& time, // time to select
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& dt    // optional (default: 1 second: 1/24/60/60) - select
                      // values that deviate less than this amount from the time
);

XlfOper // Select values between particular times of the day (e.g., 9:30AM,
        // 1:00PM, 4:45PM)
df_between_time(
    const XlfOper& df,        // dataframe
    const XlfOper& start,     // start time to select
    const XlfOper& end,       // end time to select
    const XlfOper& inclusive, // optional (default: 'both'). Include boundaries:
                              // 'both', 'neither', 'left', 'right'
    const XlfOper& axis, // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper&
        dt // optional (default: 1 second: 1/24/60/60) - how strict bounds are
);

XlfOper // Drop specified labels from rows and/or columns
df_drop(
    const XlfOper& df,      // dataframe
    const XlfOper& labels,  // optional. labels to drop
    const XlfOper& axis,    // optional (default: 0) - 1 for columns, 0 for rows
    const XlfOper& index,   // optional. Alternative to labels and axis=0
    const XlfOper& columns, // optional. Alternative to labels and axis=1
    const XlfOper& errors // optional (default: 'raise'). If 'ignore', suppress
                          // error and only existing labels are dropped
);

XlfOper // Remove duplicate rows
df_drop_duplicates(
    const XlfOper& df, // dataframe
    const XlfOper&
        subset, // optional. Only consider certain columns for identifying
                // duplicates, by default use all of the columns
    const XlfOper& keep, // optional (default: 'first'). Which duplicates (if
                         // any) to keep. 'first', 'last', False
    const XlfOper& ignore_index // optional (default: False). If True, the
                                // resulting axis will be labeled 0, 1, �, n - 1
);

XlfOper // Return true for each duplicated row
df_duplicated(
    const XlfOper& df, // dataframe
    const XlfOper&
        subset, // optional. Only consider certain columns for identifying
                // duplicates, by default use all of the columns
    const XlfOper& keep // optional (default: 'first'). Which duplicates (if
                        // any) to keep. 'first', 'last', False
);

XlfOper // Test whether two dataframes are equal (index, columns and values)
df_equals(
    const XlfOper& df1, // dataframe
    const XlfOper& df2  // other dataframe
);

XlfOper // Subset the dataframe rows or columns according to the specified
        // filter. Only one of items, like, or regex may be specified.
df_filter(
    const XlfOper& df,    // dataframe
    const XlfOper& items, // optional. List of rows/columns to keep
    const XlfOper& like,  // optional. Keep labels that have like as a substring
    const XlfOper& regex, // optional. Keep labels that match regex
    const XlfOper& axis   // optional (default: 1). 1 for columns, 0 for rows
);

XlfOper // Conform dataframe to new index/columns with optional filling logic.
// Either should specify labels and axis or index and columns
df_reindex(
    const XlfOper& df, // dataframe
    const XlfOper&
        labels, // optional. New labels for the axis specified with axis
    const XlfOper& index,   // optional. new index
    const XlfOper& columns, // optional. new columns
    const XlfOper& axis,    // optional (default: 0). 1 for columns, 0 for rows
    const XlfOper&
        method, // optional. Method to fill holes (ffill, bfill, nearest)
    const XlfOper& fill_value, // optional. Value to use for missing values
    const XlfOper& limit,      // optional not implemented
    const XlfOper& tolerance // optional (default: 0). Maximum distance between
                             // original and new labels for inexact matches
                             // Not implemented.
);

XlfOper // Reindexes df1 with matching index/columns from df2
df_reindex_like(
    const XlfOper& df1, // dataframe
    const XlfOper& df2, // dataframe to match
    const XlfOper&
        method, // optional. Method to fill holes (ffill, bfill, nearest)
    const XlfOper& limit,    // optional not implemented
    const XlfOper& tolerance // optional (default: 0). Maximum distance between
                             // original and new labels for inexact matches
                             // Not implemented.
);

XlfOper // Rneame index or columns labels. Should either specify
        // mapper and axis or index and/or columns
df_rename(
    const XlfOper& df,     // dataframe
    const XlfOper& mapper, // optional. two columns (if axis=0 - to rename rows)
                           // or rows (if axis=1 to rename columns) first: keys
                           // to rename, second: new names
    const XlfOper& index,  // optional. two columns: first keys to rename,
                           // second: new names for rows
    const XlfOper& columns, // optional. two rows: first keys to rename, second:
                            // new names for columns
    const XlfOper& axis,    // optional (default: 0). 1 for columns, 0 for rows
    const XlfOper&
        errors // optional (default: 'ignore'). If 'raise' produce error
               // if any of the keys is not found. If 'ignore', existing
               // keys will be renamed and extra keys will be ignored.
);

XlfOper // Reset the index to use the default one.
df_reset_index(
    const XlfOper& df,   // dataframe
    const XlfOper& drop, // optional (default: False). Do not try to insert
                         // index into dataframe columns.
    const XlfOper& allow_duplicates, // optional (default: True) Allow duplicate
                                     // column labels to be created.
    const XlfOper& name // optional (default: "index") old index is added as
                        // column with this name
);

XlfOper // Return a random sample of items from an axis of object.
df_sample(
    const XlfOper& df, // dataframe
    const XlfOper& n,  // optional (default: 0). Number of rows (cols if axis=1)
                       // to return. Should be 0 if frac is specified.
    const XlfOper& frac, // optional (default: None). Fraction of axis items to
                         // return. Should be 0 if n > 0 is specified.
    const XlfOper& replace, // optional (default: False). Sample with or without
                            // replacement.
    const XlfOper& weights, // optional (default: equal weights). Can be:
    // string: col name in df to use as weights (axis should be 0)
    // dataframe with a single column of weights (align with axis, all NAs
    // replaced with 0) vector of weights (length must be same as axis being
    // sampled)
    const XlfOper& random_state, // optional (default: 0). Seed for the random
                                 // number generator (if int)
    const XlfOper& axis, // optional (default: 0). Axis to sample. 0 for rows,
    // 1 for columns
    const XlfOper& ignore_index // optional (default: False). If True, the
                                // resulting axis will be labeled 0, 1, �, n - 1
);

XlfOper // asign desired index to given axis
df_set_index(
    const XlfOper& df,     // dataframe
    const XlfOper& labels, // vector to use as new index (if axis = 0) or column
                           // names (if axis = 1)
    const XlfOper& axis    // optional (default: 0). 0 for index, 1 for columns
);

XlfOper // return the rows (if axis = 0) or columns (if axis = 1) in the
        // given positions (i.e. do not align)
df_take(
    const XlfOper& df,    // dataframe
    const XlfOper& items, // vector of positions to take (can be negative to
                          // count from back: -1 is last)
    const XlfOper& axis   // optional (default: 0). 0 for rows, 1 for columns
);

XlfOper // Truncate before and after some index value
df_truncate(
    const XlfOper& df,     // dataframe
    const XlfOper& before, // optional. Truncate before this value
    const XlfOper& after,  // optional. Truncate after this value
    const XlfOper& axis    // optional (default: 0). 0 for rows, 1 for columns
);

XlfOper // Remove rows or columns with missing values
df_dropna(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0). 0 for rows, 1 for columns
    const XlfOper& how, // optional (default: 'any'). 'any' to drop if any value
                        // is NaN, 'all' to drop if all values are NaN
    const XlfOper& thresh, // optional (default: 0). Require that many non-NA
                           // values to keep the row/column
    const XlfOper&
        subset, // optional (default: None). Only consider certain columns/rows
    const XlfOper& ignore_index // optional (default: False). If True, the
                                // resulting axis will be labeled 0, 1, �, n - 1
);

XlfOper // Synonym of df_fillna with method='bfill'
df_bfill(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0). 0 for rows, 1 for columns
    const XlfOper& limit // optional (default: 0). Maximum number of consecutive
                         // NaNs to fill
);

XlfOper // Synonym of df_fillna with method='ffill'
df_ffill(
    const XlfOper& df,   // dataframe
    const XlfOper& axis, // optional (default: 0). 0 for rows, 1 for columns
    const XlfOper& limit // optional (default: 0). Maximum number of consecutive
                         // NaNs to fill
);

XlfOper // Fill NA/NaN values using the specified method
df_fillna(
    const XlfOper& df,    // dataframe
    const XlfOper& value, // optional. Scalar value to fill missing values. Or
                          // single row - value for each column.
    // Or two rows of (column: values) pairs. Columns not in value will not be
    // filled.
    const XlfOper& method, // optional (default: 'ffill'). Method to use for
                           // filling holes in reindexed Series ffill: propagate
                           // last valid observation forward to next valid.
                           // bfill: use next valid observation to fill gap
    const XlfOper& axis,   // optional (default: 0). 0 for rows, 1 for columns
    const XlfOper& limit // optional (default: 0). Maximum number of consecutive
                         // NaNs to fill
);

// TODO: skipped df_interpolate

XlfOper                   // Return mask of na values. Same as df_isnull
df_isna(const XlfOper& df // dataframe
);

XlfOper                     // Return mask of non-na values. Same as df_isna
df_isnull(const XlfOper& df // dataframe
);

XlfOper                    // Return mask of non-na values. Same as df_notnull
df_notna(const XlfOper& df // dataframe
);

XlfOper                      // Return mask of non-na values. Same as df_notna
df_notnull(const XlfOper& df // dataframe
);

XlfOper // Replace values given in 'to_replace' with 'value'
df_replace(
    const XlfOper& df,         // dataframe
    const XlfOper& to_replace, // how to find the values that will be replaced.
                               // scalar, vector - applied to each element to
                               // see if replace 2 rows: columns and scalars to
                               // replace with unless value is empty, then first
                               // row - to_replace and second row - value.
    const XlfOper& value, // similar to to_replace. if vec should be same length
                          // as to_replace
    const XlfOper& limit, // optional (default: 0). Maximum size gap to forward
                          // or backward fill (when method is not None)
    const XlfOper& regex, // optional (default: False). If True, 'to_replace' is
                          // treated as a regular expressions
    const XlfOper& method // optional (default: None). If specified, value is
                          // ignored. Method to use when for replacement.
                          // 'ffill': propagate last valid observation forward
                          // to next valid. 'bfill': use next valid observation
                          // to fill gap.
);

XlfOper // Sort by the values along either axis.
df_sort_values(
    const XlfOper& df, // dataframe
    const XlfOper& by, // column or row (if axis=1) name or vector of column
                       // names to sort by
    const XlfOper&
        axis, // optional (default: 0). 0 to rearrange rows, 1 columns
    const XlfOper&
        ascending, // optional (default: True). Sort ascending vs. descending
    const XlfOper& kind, // optional (default: 'quicksort'). Choice of sorting
                         // algorithm. 'quicksort' or 'stable'
    const XlfOper& na_position, // optional (default: 'last'). 'first' puts NaNs
                                // at the beginning, 'last' puts NaNs at the end
    const XlfOper& ignore_index // optional (default: False). If True, the
                                // resulting axis will be labeled 0, 1, �, n - 1
);

XlfOper // Sort by the index along either axis.
df_sort_index(
    const XlfOper& df, // dataframe
    const XlfOper&
        axis, // optional (default: 0). 0 to rearrange rows, 1 columns
    const XlfOper&
        ascending, // optional (default: True). Sort ascending vs. descending
    const XlfOper& kind, // optional (default: 'quicksort'). Choice of sorting
    // algorithm. 'quicksort' or 'stable'
    const XlfOper&
        na_position, // optional (default: 'last'). 'first' puts NaNs at
    // the beginning, 'last' puts NaNs at the end
    const XlfOper& ignore_index // optional (default: False). If True, the
                                // resulting axis will be labeled 0, 1, �, n - 1
);

XlfOper // Return the first n rows with the largest values in columns, in
        // descending order. The columns that are not specified are returned as
        // well, but not used for ordering.
df_nlargest(
    const XlfOper& df,      // dataframe
    const XlfOper& n,       // number of rows to return
    const XlfOper& columns, // Vector of column names to sort by
    const XlfOper& keep // optional (default: 'first'). If there are multiple
                        // rows for a given row/column pair, keep the first or
                        // last occurrence found
);

XlfOper // Return the first n rows with the smallest values in columns, in
        // descending order. The columns that are not specified are returned as
        // well, but not used for ordering.
df_nsmallest(
    const XlfOper& df,      // dataframe
    const XlfOper& n,       // number of rows to return
    const XlfOper& columns, // Vector of column names to sort by
    const XlfOper& keep // optional (default: 'first'). If there are multiple
                        // rows for a given row/column pair, keep the first or
                        // last occurrence found
);

XlfOper // Join columns with other DataFrame either on index or on a key column.
df_join(
    const XlfOper& df,    // dataframe
    const XlfOper& other, // dataframe to join with
    const XlfOper& on,    // optional. Column name from left to join on.
                          // If not specified uses index.
    const XlfOper& how,   // optional (default: 'left'). Type of join to be
                        // performed: 'left', 'right', 'outer', 'inner', 'cross'
    const XlfOper& lsuffix, // optional. Suffix to use from left dataframe's
                            // overlapping columns
    const XlfOper& rsuffix, // optional. Suffix to use from right dataframe's
                            // overlapping columns
    const XlfOper&
        sort // optional (default: False). Sort the result dataframe by
             // the join keys in lexicographical order. Defaults to False,
             // preserve the index order of the left dataframe.
);

XlfOper // Merge DataFrame objects by performing a database-style join
df_merge(
    const XlfOper& df,    // dataframe
    const XlfOper& right, // dataframe to join with
    const XlfOper&
        how, // optional (default: 'inner'). Type of join to be performed:
    // 'left', 'right', 'outer', 'inner', 'cross'
    const XlfOper& on, // optional. Column names to join on.
    // Must be found in both dataframes. If not specified and no
    // mergin on indexes then this defaults to the intersection of the columns
    // in both dataframes.
    const XlfOper& left_on, // optional. Column name from left to join on.
    // Can also be a vector of column names.
    const XlfOper& right_on, // optional. Column name from right to join on.
    // Can also be a vector of column names.
    const XlfOper& left_index, // optional (default: False). Use the index from
                               // the left dataframe as the join key(s)
    const XlfOper&
        right_index, // optional (default: False). Use the index from the
    // right dataframe as the join key
    const XlfOper&
        sort, // optional (default: False). Sort the result dataframe by the
    // join keys in lexicographical order. Defaults to False,
    // preserve the index order of the left dataframe.
    const XlfOper& suffixes // optional (default: ('_x', '_y')). Suffix to apply
                            // to overlapping column names in the left and right
                            // side, respectively
);

XlfOper // Use non-NA aligned values from other to update df
df_update(
    const XlfOper& df,    // dataframe
    const XlfOper& other, // dataframe to join with
    const XlfOper&
        overwrite // optional (default: True). If true - overwrite values
                  // in df with values from other (if other is not NA). If
                  // false - only update NA values in df with other.
);

XlfOper // Return the last row(s) whithout any NaNs before where
df_asof(
    const XlfOper& df,         // dataframe
    const XlfOper& where_vals, // vector of values
    const XlfOper& subset // optional. Vector of column names to check for NaNs
);

XlfOper // Shift index by desired number of periods
df_shift(
    const XlfOper& df, // dataframe
    const XlfOper&
        periods,         // optional (default: 1). Number of periods to shift.
    const XlfOper& axis, // optional (default: 0). Shift direction.
    const XlfOper& fill_value // optional (default: None). The scalar value to
                              // use for newly introduced missing values.
);

XlfOper // bracket ([]) function operator for dataframe
df_B(
    const XlfOper& df,  // dataframe
    const XlfOper& key, // column name or vector of column names, slice string
                        // for rows (like df_iloc), boolean array for rows,
                        // boolean dataframe (sets false locations to NA)
    const XlfOper&
        op, // optional. operation to perform on the result of the key with:
    // '+', '-', '*', '/', '%', '**'; '=' or previous followed by '=' - assign
    // after operation; comparison operators: '==', '!=', '>', '<', '>=', '<='
    const XlfOper&
        value // optional. value to use in the operation. Can be scalar,
              // array (not aligned operation) or dataframe (aligned operation)
              // or evaluated expression (see df_eval)
);

XlfOper // bracket ([]) function operator for dataframe (same as df_B)
df(const XlfOper& d_f, // dataframe
   const XlfOper& key, // column name or vector of column names, slice string
   // for rows (like df_iloc), boolean array for rows,
   // boolean dataframe (sets false locations to NA)
   const XlfOper&
       op, // optional. operation to perform on the result of the key with:
   // '+', '-', '*', '/', '%', '**'; '=' or previous followed by '=' - assign
   // after operation; comparison operators: '==', '!=', '>', '<', '>=', '<='
   const XlfOper&
       value // optional. value to use in the operation. Can be scalar,
             // array (not aligned operation) or dataframe (aligned operation)
);

XlfOper // Returns just data of the dataframe (drops index and columns labels)
df_to_numpy(const XlfOper& df // dataframe
);
