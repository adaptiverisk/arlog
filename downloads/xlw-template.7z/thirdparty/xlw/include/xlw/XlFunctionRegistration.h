
/*
 Copyright (C) 2006 Mark Joshi
 Copyright (C) 2007, 2008 Eric Ehlers
 Copyright (C) 2011 Narinder S Claire

 This file is part of XLW, a free-software/open-source C++ wrapper of the
 Excel C API - https://xlw.github.io/

 XLW is free software: you can redistribute it and/or modify it under the
 terms of the XLW license.  You should have received a copy of the
 license along with this program; if not, please email xlw-users@lists.sf.net

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#pragma once

#include <list>
#include <string>
#include <vector>
#include <xlw/Singleton.h>
#include <xlw/XlfCmdDesc.h>
#include <xlw/XlfExcel.h>
#include <xlw/XlfFuncDesc.h>
#include <xlw/eshared_ptr.h>

namespace xlw
{

namespace XLRegistration
{

  class XLCommandRegistrationData
  {
  public:
    XLCommandRegistrationData(
        const std::string& CommandName_, const std::string& ExcelCommandName_,
        const std::string& Comment_, const std::string& Menu_,
        const std::string& MenuText_) :
        name(CommandName_),
        excel_name(ExcelCommandName_), comment(Comment_), menu(Menu_),
        menu_text(MenuText_)
    {
    }

    std::string name;
    std::string excel_name;
    std::string comment;
    std::string menu;
    std::string menu_text;
  };

  class XLFunctionRegistrationData
  {
  public:
    XLFunctionRegistrationData(
        const std::string& FunctionName_, const std::string& ExcelFunctionName_,
        const std::string& FunctionDescription_, const std::string& Library_,
        const Arg Arguments[], int NoOfArguments_, bool Volatile_,
        bool Threadsafe_, const std::string& ReturnTypeCode_,
        const std::string& HelpID_, bool Asynchronous_,
        bool MacroSheetEquivalent_, bool ClusterSafe_);

    std::string name;
    std::string excel_name;
    std::string descr;
    std::string lib;
    int nargs;
    std::vector<Arg> args;
    bool volat;
    bool threadsafe;
    std::string ret_type_code;
    std::string helpID;
    bool asynch;
    bool macro_sheet_equiv;
    bool claster_safe;
  };

  class XLFunctionRegistrationHelper
  {
  public:
    XLFunctionRegistrationHelper(
        const std::string& FunctionName, const std::string& ExcelFunctionName,
        const std::string& FunctionDescription, const std::string& Library,
        const Arg Args[] = 0, int NoOfArguments = 0, bool Volatile = false,
        bool Threadsafe = false, const std::string& ReturnTypeCode_ = "",
        const std::string& HelpID = "", bool Asynchronous = false,
        bool MacroSheetEquivalent = false, bool ClusterSafe = false);
  };

  class XLCommandRegistrationHelper
  {
  public:
    XLCommandRegistrationHelper(
        const std::string& CommandName_, const std::string& ExcelCommandName_,
        const std::string& Comment_, const std::string& Menu_,
        const std::string& MenuText_);
  };

  // singleton pattern, cf the Factory
  class ExcelFunctionRegistrationRegistry:
      public singleton<ExcelFunctionRegistrationRegistry>
  {
    friend class singleton<ExcelFunctionRegistrationRegistry>;

  public:
    void DoTheRegistrations() const;
    void DoTheDeregistrations() const;
    void AddFunction(const XLFunctionRegistrationData&);
    void AddCommand(const XLCommandRegistrationData&);
    void GenerateDocumentation(const std::string& outputDir);

  private:
    typedef std::map<std::string, std::shared_ptr<xlw::XlfFuncDesc>>
        functionCache;
    typedef std::map<std::string, std::shared_ptr<XlfCmdDesc>> commandCache;
    ExcelFunctionRegistrationRegistry() {}
    void GenerateChmBuilderConfig(const std::string& fileName);
    void GenerateToc(const std::string& outputDir);
    std::map<std::string, std::shared_ptr<XlfFuncDesc>> Functions;
    std::map<std::string, std::shared_ptr<XlfCmdDesc>> Commands;
  };

} // namespace XLRegistration

} // namespace xlw
