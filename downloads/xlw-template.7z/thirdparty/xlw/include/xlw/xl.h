#pragma once

// #define WITH_EIGEN

#include <algorithm>
#include <cmath>
#include <map>
#include <sstream>
#include <stdio.h>
#include <vector>

#ifdef PY
#include <xlw/xlw-mock.h>
#else
#include <xlw/xlw.h>
#endif

#ifdef WITH_EIGEN
#include <Eigen/Dense>
#endif

namespace xlw
{
struct num_fmt
{
  std::string rng;
  std::string fmt;
};

// get formats to schedule
// c - returning value
// fmts 0-indexed column to format
// for df doesn't get formatting of headers - they are usually just strings
// anyways
std::vector<xlw::num_fmt> get_fmts(
    const xlw::XlfOper& c, const std::string& sheet_name, int row0, int col0,
    const std::map<int, std::string>& fmts, bool is_df = false);

typedef double ddate;
static inline std::string type_name(int) { return "int"; }
static inline std::string type_name(const std::string&) { return "str"; }
static inline std::string type_name(double) { return "num"; }
static inline std::string type_name(bool) { return "bool"; }

// describes type that can also be NA
template<typename T>
class EXCEL32_API or_na
{
  T value_;
  bool is_na_;

public:
  or_na() : value_(), is_na_(true) {}
  or_na(T value) : value_(value), is_na_(false) {}
  or_na(const xlw::XlfOper& x) : value_(), is_na_(true)
  {
    if (x.is<T>())
    {
      value_ = x.as<T>();
      is_na_ = false;
    }
  }

  void set_na()
  {
    is_na_ = true;
    value_ = T();
  }

  bool is_na() const { return is_na_; }
  T value() const
  {
    if (is_na_)
      throw "# NA";
    return value_;
  }
  void log(FILE* flog, const char* argname) const
  {
    if (!flog)
      return;
    std::stringstream ss;
    ss << value_;
    fprintf(
        flog, "%s<%s> = %s\n", argname, type_name(T()).c_str(),
        is_na_ ? "na" : ss.str().c_str());
  }
};

// describes listable data type
// can be None, scalar or vector
template<typename T>
class EXCEL32_API or_vec
{
  std::vector<T> value_;

public:
  or_vec() : value_() {}
  or_vec(T value) : value_(1, value) {}
  or_vec(const xlw::XlfOper& x) : value_()
  {
    if (x.is<void>())
      return;
    if (x.is<T>())
    {
      value_ = std::vector<T>(1, x.as<T>());
      return;
    }
    if (x.IsMulti())
    {
      value_.reserve(x.rows() * x.cols());
      for (int i = 0; i < x.rows(); ++i)
        for (int j = 0; j < x.cols(); ++j)
          if (x(i, j).is<T>())
            value_.push_back(x(i, j).as<T>());
          else
            return;
    }
  }
  void set_na() { value_.clear(); }
  bool is_na() const { return value_.empty(); }
  std::vector<T>& vec() { return value_; }
  const std::vector<T>& vec() const { return value_; }
  bool is_scalar() const { return value_.size() == 1; }
  T value() const
  {
    if (value_.empty())
      return T();
    else
      return value_[0];
  }

  // if scalar, replicate to fill vector of size n
  // if vec, extend with last value, or trim to n
  // return true, if successful
  bool extend(int n)
  {
    if (value_.empty())
      return false;
    value_.resize(n, value_.back());
    return true;
  }

  void log(FILE* flog, const char* argname) const
  {
    std::stringstream ss;
    ss << "{";
    if (!value_.empty())
    {
      ss << value_[0];
      for (size_t i = 1; i < value_.size(); ++i) ss << ", " << value_[i];
    }
    ss << "}";
    fprintf(
        flog, "%s<vec[%s]> = %s\n", argname, type_name(T()).c_str(),
        ss.str().c_str());
  }
};

template<typename T>
using vec = or_vec<T>;

// matrix class - stores only non-NAs. Drops tails after first NA
template<bool col_major, typename T>
class EXCEL32_API Mat
{
public:
  std::vector<std::vector<T>> data;

  Mat() {}
  Mat(const xlw::XlfOper& x)
  {
    if (x.is<void>())
      return;
    if (x.is<T>())
    {
      data.resize(1);
      data[0].resize(1, x.as<T>());
      return;
    }
    if (x.IsMulti())
    {
      if constexpr (col_major) // columns
      {
        std::vector<T> col;
        col.reserve(x.rows());
        data.reserve(x.cols());
        for (int j = 0; j < x.cols(); ++j)
        {
          col.clear();
          for (int i = 0; i < x.rows(); ++i)
          {
            if (!x(i, j).is<T>())
              break;
            auto val = x(i, j).as<T>();
            if constexpr (std::is_same<T, double>::value)
              if (std::isnan(val))
                break;
            col.push_back(val);
          }
          if (col.empty())
            break;
          data.push_back(col);
        }
      }
      else // rows
      {
        std::vector<T> row;
        row.reserve(x.cols());
        data.reserve(x.rows());
        for (int i = 0; i < x.rows(); ++i)
        {
          row.clear();
          for (int j = 0; j < x.cols(); ++j)
          {
            if (!x(i, j).is<T>())
              break;
            auto val = x(i, j).as<T>();
            if constexpr (std::is_same<T, double>::value)
              if (std::isnan(val))
                break;
            row.push_back(val);
          }
          if (row.empty())
            break;
          data.push_back(row);
        }
      }
    }
  }

  // make sure to run trim before
  int cols() const
  {
    if constexpr (col_major)
      return (int)data.size();
    else
      return data.empty() ? 0 : (int)data[0].size();
  }

  // make sure to run trim before
  int rows() const
  {
    if constexpr (col_major)
      return data.empty() ? 0 : (int)data[0].size();
    else
      return (int)data.size();
  }

  // int i'th col (if col major) or row
  std::vector<int> int_data(int i) const
  {
    if (i < 0 || i >= (int)data.size())
      return {};
    std::vector<int> res(data[i].size());
    for (size_t j = 0; j < res.size(); ++j) res[j] = (int)data[i][j];
    return res;
  }

  // trims columns/rows to have same length
  void trim()
  {
    if (data.empty())
      return;
    auto n = data[0].size();
    for (auto& x: data) n = std::min(n, x.size());
    for (auto& x: data) x.resize(n);
  }

  void log(FILE* flog, const char* argname) const
  {
    std::string rname = "rows";
    if constexpr (col_major)
      rname = "cols";
    fprintf(flog, "%s<mat%s> = [%d:", argname, rname.c_str(), (int)data.size());
    for (size_t i = 0; i < data.size(); ++i)
    {
      fprintf(flog, "%d", (int)data[i].size());
      if (i < data.size() - 1)
        fprintf(flog, ",");
    }
    fprintf(flog, "]");
    if (data.empty())
      fprintf(flog, "%s", "{}");
    else
    {
      std::stringstream ss;
      ss << "{\n";
      for (size_t i = 0; i < data.size(); ++i)
      {
        ss << "  {";
        for (size_t j = 0; j < data[i].size(); ++j)
        {
          // Choose the correct format: comma if it's not the last element,
          // newline and brace otherwise
          j < data[i].size() - 1 ? ss << data[i][j] << ", "
                                 : ss << data[i][j] << "}";
        }
        i < data.size() ? ss << ",\n" : ss << "\n";
      }
      ss << "}";
      fprintf(flog, "%s", ss.str().c_str());
    }
    fprintf(flog, "\n");
  }

#ifdef WITH_EIGEN
  Eigen::MatrixXd to_eigen() const
  {
    if (data.empty())
      return Eigen::MatrixXd();
    // Find the size of the smallest vector
    int smallest_size = (int)data[0].size();
    for (const auto& arr: data)
      smallest_size = std::min(smallest_size, (int)arr.size());

    if constexpr (col_major)
    {
      Eigen::MatrixXd matrix(smallest_size, data.size());
      for (int i = 0; i < (int)matrix.cols(); ++i)
        for (int j = 0; j < smallest_size; ++j)
          matrix(j, i) = (double)data[i][j];
      return matrix;
    }
    else
    {
      Eigen::MatrixXd matrix(data.size(), smallest_size);
      for (int i = 0; i < (int)matrix.rows(); ++i)
        for (int j = 0; j < smallest_size; ++j)
          matrix(i, j) = (double)data[i][j];
      return matrix;
    }
  }
#endif
};

typedef Mat<true, double> MatCols;
typedef Mat<false, double> MatRows;
typedef Mat<true, int> MatColsInt;

} // namespace xlw