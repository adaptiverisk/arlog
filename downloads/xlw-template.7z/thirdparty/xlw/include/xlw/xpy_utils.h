#pragma once

// utilities for xlw and py interface
// these functions have to be in header and inlined
// otherwise PyArray calls will crash as numpy is not initialized

#ifdef _DEBUG
#define _DEBUG_WAS_DEFINED
#undef _DEBUG
#endif
#include <Python.h>
#include <datetime.h>
#ifdef _DEBUG_WAS_DEFINED
#define _DEBUG
#endif

#include <cassert>
#include <cmath>
#include <string>
#include <vector>
#include <xlw/DataFrame.h>
#include <xlw/xlw-mock.h>

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>

// =================== dates =================

typedef double ddate;

// excel serial to day, month, year
void es2dmy(int t, int& d, int& m, int& y)
{
  if (t == 60)
  {
    d = 29;
    m = 2;
    y = 1900;

    return;
  }
  else if (t < 60)
    t++;

  int l = t + 68569 + 2415019;
  int n = int((4 * l) / 146097);
  l = l - int((146097 * n + 3) / 4);
  int i = int((4000 * (l + 1)) / 1461001);
  l = l - int((1461 * i) / 4) + 31;
  int j = int((80 * l) / 2447);
  d = l - int((2447 * j) / 80);
  l = int(j / 11);
  m = j + 2 - (12 * l);
  y = 100 * (n - 49) + i + l;
}

// day, month, year to excel serial
static inline int dmy2es(int d, int m, int y)
{
  if (d == 29 && m == 02 && y == 1900)
    return 60;

  long t = int((1461 * (y + 4800 + int((m - 14) / 12))) / 4)
           + int((367 * (m - 2 - 12 * ((m - 14) / 12))) / 12)
           - int((3 * (int((y + 4900 + int((m - 14) / 12)) / 100))) / 4) + d
           - 2415019 - 32075;

  if (t < 60)
    t--;

  return (int)t;
}

static inline std::vector<std::string> split_str(const std::string& s, char c)
{
  std::string buff = "";
  std::vector<std::string> v;
  for (auto n: s)
  {
    if (n != c)
      buff += n;
    else if (n == c)
    {
      v.push_back(buff);
      buff = "";
    }
  }
  if (buff != "")
    v.push_back(buff);
  else if (!s.empty() && s.back() == c)
    v.push_back(buff);
  return v;
}

static inline ddate datetime2excel(PyObject* a)
{
  if (!a)
    return -1;
  PyDateTime_IMPORT;

  if (PyDateTime_Check(a))
  {
    PyDateTime_DateTime* datetime = reinterpret_cast<PyDateTime_DateTime*>(a);

    int year = PyDateTime_GET_YEAR(datetime);
    int month = PyDateTime_GET_MONTH(datetime);
    int day = PyDateTime_GET_DAY(datetime);
    int hour = PyDateTime_DATE_GET_HOUR(datetime);
    int minute = PyDateTime_DATE_GET_MINUTE(datetime);
    int second = PyDateTime_DATE_GET_SECOND(datetime);
    int microsecond = PyDateTime_DATE_GET_MICROSECOND(datetime);

    double excel_serial = dmy2es(day, month, year);
    excel_serial +=
        (hour * 3600 + minute * 60 + second + microsecond / 1e6) / 86400.0;
    return excel_serial;
  }

  if (PyDate_Check(a))
  {
    PyDateTime_Date* datetime = reinterpret_cast<PyDateTime_Date*>(a);

    int year = PyDateTime_GET_YEAR(datetime);
    int month = PyDateTime_GET_MONTH(datetime);
    int day = PyDateTime_GET_DAY(datetime);

    double excel_serial = dmy2es(day, month, year);
    return excel_serial;
  }

  // PyErr_SetString(PyExc_TypeError, "Expected a datetime object");
  return -1;
}

static inline ddate timestamp2excel(PyObject* a)
{
  if (!a)
    return -1;
  assert(std::string(Py_TYPE(a)->tp_name) == "Timestamp"); // pd.Timestamp
  auto np_date = PyObject_CallMethod(a, "to_pydatetime", nullptr);
  auto xl_date = datetime2excel(np_date);
  Py_DECREF(np_date);
  return xl_date;
}

// returns -1 if not a date
static inline ddate get_excel_serial(PyObject* a)
{
  if (!a)
    return -1;
  if (PyObject_HasAttrString(a, "to_pydatetime"))
    return timestamp2excel(a);
  return datetime2excel(a);
}

// convert excel serial to 'YYYY-MM-DD'
static inline PyObject* excel2date_str(ddate t)
{
  if (t < 0)
    Py_RETURN_NONE;
  int d, m, y;
  es2dmy((int)t, d, m, y);
  char buff[11];
  snprintf(buff, sizeof(buff), "%04d-%02d-%02d", y, m, d);
  return PyUnicode_FromString(buff);
}

// 0 <= dt < 1
static inline void dt2parts(double dt, int& h, int& m, int& s, int& u)
{
  assert(dt >= 0 && dt < 1);
  s = int(dt * 86400);
  u = int((dt * 86400 - s) * 1e6);
  m = s / 60;
  s %= 60;
  h = m / 60;
  m %= 60;
}

// convert excel serial to 'YYYY-MM-DD hh:mm:ss:uuu'
static inline PyObject* excel2datetime_str(ddate t)
{
  if (t < 0)
    Py_RETURN_NONE;
  int d, m, y;
  es2dmy((int)t, d, m, y);
  double dt = t - (int)t;
  int h, min, sec, microsec;
  dt2parts(dt, h, min, sec, microsec);
  char buff[24];
  snprintf(
      buff, sizeof(buff), "%04d-%02d-%02d %02d:%02d:%02d.%03d", y, m, d, h, min,
      sec, microsec);
  return PyUnicode_FromString(buff);
}

// fmt - for getting date timestamp (releases str)
static inline PyObject* str2timestamp(PyObject* str)
{
  if (!str)
    return nullptr;
  // Import the pandas module
  auto pandas = PyImport_ImportModule("pandas");
  if (!pandas)
  {
    Py_DECREF(str);
    return nullptr;
  }

  auto ts_constructor = PyObject_GetAttrString(pandas, "Timestamp");
  Py_DECREF(pandas);
  if (!ts_constructor)
  {
    Py_DECREF(str);
    return NULL;
  }

  // Create the Timestamp object
  auto args = PyTuple_Pack(1, str);
  Py_DECREF(str);
  if (!args)
  {
    Py_DECREF(ts_constructor);
    return NULL;
  }

  auto timestamp = PyObject_CallObject(ts_constructor, args);
  Py_DECREF(args);
  Py_DECREF(ts_constructor);

  return timestamp;
}

// ==== string ====
// convert python object to string - also releases a
static inline std::string py2str(PyObject* a, bool& err)
{
  err = false;
  if (!a || !PyUnicode_Check(a))
  {
    Py_XDECREF(a);
    err = true;
    return "";
  }
  auto encoded = PyUnicode_AsUTF8String(a);
  Py_DECREF(a);
  if (!encoded)
  {
    err = true;
    return "";
  }
  auto s = PyBytes_AsString(encoded);
  Py_DECREF(encoded);
  if (s)
    return s;
  err = true;
  return "";
}

// =========== numpy ============

enum NpResolution
{
  Y,  // year
  M,  // month
  W,  // weak
  D,  // day
  h,  // hour
  m,  // minute
  s,  // second
  ms, // millisecond
  us, // microsecond
  ns, // nanosecond
  unknown
};

// must be numpy array with datetime
static inline NpResolution get_resolution(PyObject* a)
{
  auto dtype = PyObject_GetAttrString(a, "dtype");
  if (!dtype)
    return unknown;
  bool err;
  auto type_str = py2str(PyObject_GetAttrString(dtype, "str"), err);
  Py_DECREF(dtype);
  if (err)
    return unknown;
  // type_str should look like: '<M8[D]'
  auto ss = split_str(type_str, '[');
  if (ss.size() != 2 || ss[1].back() != ']')
    return unknown;
  type_str = ss[1];
  type_str.pop_back();
  if (type_str.empty() || type_str.size() > 2)
    return unknown;
  if (type_str.size() == 1)
  {
    switch (type_str[0])
    {
      case 'Y': return Y;
      case 'M': return M;
      case 'W': return W;
      case 'D': return D;
      case 'h': return h;
      case 'm': return m;
      case 's': return s;
      default: return unknown;
    }
  }
  else
  {
    if (type_str[1] != 's')
      return unknown;
    switch (type_str[0])
    {
      case 'm': return ms;
      case 'u': return us;
      case 'n': return ns;
      default: return unknown;
    }
  }
  return unknown;
}

static inline ddate dt64_excel(npy_datetime t, NpResolution r)
{
  const int y0 = 1970;
  double t0 = 25569;
  switch (r)
  {
    case Y: return dmy2es(1, 1, y0 + (int)t);
    case M: return dmy2es(1, 1 + int(t % 12), y0 + int(t / 12));
    case W: return t0 + double(t * 7);
    case D: return t0 + double(t);
    case h: return t / 24. + t0;
    case m: return t / 1440. + t0;
    case s: return t / 86400. + t0;
    case ms: return t / 86400000. + t0;
    case us: return t / 86400000000. + t0;
    case ns: return t / 86400000000000. + t0;
    default: return -1;
  }
  return -1;
}

template<typename T>
xlw::XlfOper
num_arr2xlw(int di, int nrows, int ncols, PyArrayObject* arr, bool row_major)
{
  if (!arr)
    return {};
  assert(PyArray_ISNUMBER(arr));
  xlw::XlfOper res(nrows + di, ncols + di);
  auto* data = reinterpret_cast<T*>(PyArray_DATA(arr));
  if (row_major)
    for (int i = 0; i < nrows; ++i)
      for (int j = 0; j < ncols; ++j)
        res(i + di, j + di) = (double)data[i * ncols + j];
  else
    for (int i = 0; i < nrows; ++i)
      for (int j = 0; j < ncols; ++j)
        res(i + di, j + di) = (double)data[i + j * nrows];
  return res;
}

xlw::XlfOper pyscalar2xlw(PyObject* a);
xlw::XlfOper pylist2xlw(PyObject* a);

// convert numpy array to xlw
static inline xlw::XlfOper np2xlw(PyObject* a, bool add_headers = false)
{
  if (!a)
    return "# np2xlw got null pointer";
  if (!PyArray_Check(a))
    return "# np2xlw got bad array object";

  auto* arr = reinterpret_cast<PyArrayObject*>(a);
  int ndims = PyArray_NDIM(arr);
  if (ndims < 1 || ndims > 2)
    return "# np2xlw can convert only 1 or 2 dim numpy arrays";
  int nrows = 1, ncols = 1;
  if (ndims == 1)
    ncols = (int)PyArray_DIMS(arr)[0];
  else
  {
    nrows = (int)PyArray_DIMS(arr)[0];
    ncols = (int)PyArray_DIMS(arr)[1];
  }
  int di = (add_headers ? 1 : 0);
  auto row_major = PyArray_IS_C_CONTIGUOUS(arr);

  if (PyArray_ISNUMBER(arr))
  {
    switch (PyArray_DESCR(arr)->type_num)
    {
      case NPY_FLOAT:
        return num_arr2xlw<npy_float>(di, nrows, ncols, arr, row_major);
      case NPY_DOUBLE:
        return num_arr2xlw<npy_double>(di, nrows, ncols, arr, row_major);
      case NPY_LONGDOUBLE:
        return num_arr2xlw<npy_longdouble>(di, nrows, ncols, arr, row_major);
      case NPY_INT8:
        return num_arr2xlw<npy_int8>(di, nrows, ncols, arr, row_major);
      case NPY_UINT8:
        return num_arr2xlw<npy_uint8>(di, nrows, ncols, arr, row_major);
      case NPY_INT16:
        return num_arr2xlw<npy_int16>(di, nrows, ncols, arr, row_major);
      case NPY_UINT16:
        return num_arr2xlw<npy_uint16>(di, nrows, ncols, arr, row_major);
      case NPY_INT32:
        return num_arr2xlw<npy_int32>(di, nrows, ncols, arr, row_major);
      case NPY_UINT32:
        return num_arr2xlw<npy_uint32>(di, nrows, ncols, arr, row_major);
      case NPY_INT64:
        return num_arr2xlw<npy_int64>(di, nrows, ncols, arr, row_major);
      case NPY_UINT64:
        return num_arr2xlw<npy_uint64>(di, nrows, ncols, arr, row_major);
      default: return "# unknown data type";
    }
  }
  xlw::XlfOper res(nrows + di, ncols + di);
  if (PyArray_ISSTRING(arr))
  {
    for (int i = 0; i < nrows; ++i)
      for (int j = 0; j < ncols; ++j)
      {
        void* s = ndims == 1 ? PyArray_GETPTR1(
                      arr, row_major ? i * ncols + j : i + j * nrows)
                             : PyArray_GETPTR2(arr, i, j);
        bool err;
        auto ss = py2str(PyArray_GETITEM(arr, (char*)s), err);
        if (err)
          return "# invalid array element";
        res(i + di, j + di) = ss;
      }
    return res;
  }
  else if (PyArray_ISDATETIME(arr))
  {
    auto resol = get_resolution(a);
    auto data = (npy_datetime*)PyArray_DATA(arr);
    if (row_major)
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res(i + di, j + di) = dt64_excel(data[i * ncols + j], resol);
    else
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res(i + di, j + di) = dt64_excel(data[i + j * nrows], resol);
    return res;
  }
  else if (PyArray_ISOBJECT(arr))
  {
    auto data = static_cast<PyObject**>(PyArray_DATA(arr));
    if (row_major)
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res(i + di, j + di) = pyscalar2xlw(data[i * ncols + j]);
    else
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res(i + di, j + di) = pyscalar2xlw(data[i + j * nrows]);
    return res;
  }

  return "# cannot convert array of this type to XlfOper";
}

// convert python object to xlw, does not release a
// if full is true, then convert full pandas dataframe, otherwise only df.value
static inline xlw::XlfOper py2xlw(PyObject* a, bool full = true)
{
  if (!a)
    return {};
  auto res = pyscalar2xlw(a);
  if (res.as<std::string>() != "#xlwErr")
    return res;
  std::string a_type = Py_TYPE(a)->tp_name;

  if (a_type == "DataFrame") // pandas dataframe
  {
    auto vals = PyObject_GetAttrString(a, "values");
    if (vals)
    {
      auto res = np2xlw(vals, full);
      Py_DECREF(vals);
      if (!full)
        return res;
    }
    auto cols = PyObject_GetAttrString(a, "columns");
    if (cols)
    {
      auto vals = PyObject_GetAttrString(cols, "values");
      if (vals)
      {
        auto xcol = np2xlw(vals); // row array
        Py_DECREF(vals);
        for (int i = 0; i < xcol.cols(); ++i) res(0, i + 1) = xcol(0, i);
      }
      Py_DECREF(cols);
    }
    auto rows = PyObject_GetAttrString(a, "index");
    if (rows)
    {
      auto vals = PyObject_GetAttrString(rows, "values");
      if (vals)
      {
        auto xrow = np2xlw(vals);
        Py_DECREF(vals);
        for (int i = 0; i < xrow.cols(); ++i) res(i + 1, 0) = xrow(0, i);
      }
      Py_DECREF(rows);
    }
    return res;
  }
  if (PyArray_Check(a))
    return np2xlw(a); // numpy array
  if (PyList_Check(a))
    return pylist2xlw(a); // list

  std::string err = "# don't know how to convert ";
  err += Py_TYPE(a)->tp_name;
  err += " to XlfOper";
  return err;
}

// don't need to DECREF scalar a's
inline xlw::XlfOper pyscalar2xlw(PyObject* a)
{
  if (!a)
    return xlw::XlfOper();
  if (PyFloat_Check(a))
    return PyFloat_AsDouble(a);
  if (PyLong_Check(a))
    return (int)PyLong_AsLong(a);
  if (PyUnicode_Check(a)) // string
  {
    auto encoded = PyUnicode_AsUTF8String(a);
    xlw::XlfOper res(PyBytes_AsString(encoded));
    Py_DECREF(encoded);
    return res;
  }
  auto dd = get_excel_serial(a);
  if (dd >= 0)
    return dd;
  return "#xlwErr";
}

// can handle only 1d or 2d objects
// in 1d case returns a row
// does not release a since might have borrowed a when iterating 2d list
inline void pylist2row(PyObject* a, xlw::XlfOper& x, int irow)
{
  if (!a)
    return;
  assert(PyList_Check(a));
  assert(x.rows() > irow);
  auto n = PyList_Size(a);
  if ((int)n != x.cols())
  {
    x(irow, 0) = "# row length should be equal to number of cols";
    return;
  }
  for (Py_ssize_t i = 0; i < n; ++i)
  {
    auto ai = PyList_GetItem(a, i); // don't need to DECREF ai
    x(irow, (int)i) = pyscalar2xlw(ai);
  }
}

inline xlw::XlfOper pylist2xlw(PyObject* a)
{
  if (!a)
    return {};
  assert(PyList_Check(a));
  auto n = PyList_Size(a);
  Py_ssize_t m = 1;
  if (n == 0)
    return {};
  auto ai = PyList_GetItem(a, 0);
  if (!PyList_Check(ai)) // 1d
  {
    xlw::XlfOper res(1, (int)n);
    pylist2row(a, res, 0);
    return res;
  }
  // 2d
  m = PyList_Size(ai);
  xlw::XlfOper res((int)n, (int)m);
  for (Py_ssize_t i = 0; i < n; ++i)
  {
    ai = PyList_GetItem(a, i);
    pylist2row(ai, res, (int)i);
  }
  return res;
}

// do not release a s it can be applied on borrowed references when iterating
static inline std::vector<ddate> get_excel_serials(PyObject* a)
{
  if (!a)
    return {};
  auto s = get_excel_serial(a);
  if (s >= 0)
    return {s};
  std::vector<ddate> res;
  if (PyList_Check(a)) // list
  {
    auto n = PyList_Size(a);
    if (n == 0)
      return {};
    auto ai = PyList_GetItem(a, 0);
    if (PyList_Check(ai)) // 2d
    {
      Py_ssize_t m = PyList_Size(ai);
      res.reserve(n * m);
      for (Py_ssize_t i = 0; i < n; ++i)
      {
        auto d = get_excel_serials(PyList_GetItem(a, i));
        if (d.empty())
          return res;
        res.insert(res.end(), d.begin(), d.end());
      }
      return res;
    }
    // 1d
    res.reserve(n);
    for (Py_ssize_t i = 0; i < n; ++i)
    {
      ai = PyList_GetItem(a, i);
      auto d = get_excel_serial(ai);
      if (d < 0)
        return res;
      res.push_back(d);
    }
    return res;
  }
  if (PyArray_Check(a)) // numpy array
  {
    auto* arr = reinterpret_cast<PyArrayObject*>(a);
    if (!PyArray_ISDATETIME(arr))
      return {};
    int ndims = PyArray_NDIM(arr);
    if (ndims < 1 || ndims > 2)
      return {};
    int nrows = 1, ncols = 1;
    if (ndims == 1)
      ncols = (int)PyArray_DIMS(arr)[0];
    else
    {
      nrows = (int)PyArray_DIMS(arr)[0];
      ncols = (int)PyArray_DIMS(arr)[1];
    }
    res.reserve(nrows * ncols);
    auto row_major = PyArray_IS_C_CONTIGUOUS(arr);
    auto resol = get_resolution(a);
    auto data = (npy_datetime*)PyArray_DATA(arr);
    if (row_major)
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res.push_back(dt64_excel(data[i * ncols + j], resol));
    else
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
          res.push_back(dt64_excel(data[i + j * nrows], resol));
    return res;
  }
  return {};
}

static inline PyObject* convert_dbl_array(xlw::XlfOper& x)
{
  int nrows = x.rows();
  int ncols = x.cols();
  npy_intp dims[2] = {nrows, ncols};
  auto* result = PyArray_SimpleNew(2, dims, NPY_DOUBLE);

  double* result_data = (double*)(PyArray_DATA((PyArrayObject*)result));
  for (int i = 0; i < nrows; ++i)
    for (int j = 0; j < ncols; ++j)
      result_data[i * ncols + j] =
          x(i, j).IsNumber() ? x(i, j).AsDouble() : nan("");
  return (PyObject*)result;
}

// function for debugging
#ifndef _DEBUG
static inline void print_obj(PyObject* /*obj*/) {}
#else
#include <iostream>
static inline void print_obj(PyObject* obj)
{
  if (obj == nullptr)
  {
    std::cerr << "Null Python Object" << std::endl;
    return;
  }
  bool err;
  auto str = py2str(PyObject_Repr(obj), err);
  if (err)
  {
    std::cerr << "Failed to convert Python object to string" << std::endl;
    return;
  }
  std::cout << str << std::endl; // Print to stdout
}
#endif

// convert xlw::Series to PyList
static inline PyObject*
series2list(const xlw::Series& s, const std::string& fmt)
{
  auto lst = PyList_New(s.len());
  if (!lst)
    return lst;
  // print_obj(lst);
  if (fmt == "date" && s.type_ == xlw::df_type::t_num)
  {
    for (int i = 0; i < s.len(); ++i)
    {
      auto v = str2timestamp(excel2date_str(s.num_[i]));
      PyList_SetItem(lst, i, v); // steals reference, don't need to DECREF v
    }
  }
  else if (
      (fmt == "datetime" || fmt == "time") && s.type_ == xlw::df_type::t_num)
  {
    for (int i = 0; i < s.len(); ++i)
    {
      auto v = str2timestamp(excel2datetime_str(s.num_[i]));
      PyList_SetItem(lst, i, v); // steals reference, don't need to DECREF v
    }
  }
  else
  {
    switch (s.type_)
    {
      case xlw::df_type::t_num:
        if (fmt == "int")
          for (int i = 0; i < s.len(); ++i)
            PyList_SetItem(lst, i, PyLong_FromLong((long)s.num_[i]));
        else
          for (int i = 0; i < s.len(); ++i)
            PyList_SetItem(lst, i, PyFloat_FromDouble(s.num_[i]));
        break;
      case xlw::df_type::t_str:
        for (int i = 0; i < s.len(); ++i)
        {
          auto v = PyUnicode_FromString(s.str_[i].c_str());
          PyList_SetItem(lst, i, v); // steals reference, don't need to DECREF v
        }
        break;
      case xlw::df_type::t_bool:
        for (int i = 0; i < s.len(); ++i)
          PyList_SetItem(lst, i, PyBool_FromLong((long)s.bol_[i]));
        break;
      default: break;
    }
  }
  // print_obj(lst);

  return lst;
}

// convert DataFrame to pd.DataFrame
// dtypes are formatting strings (starting with index) from function model:
// the list of possible values of dtypes is in: fmt_map in xl.cpp
// here it is important to note date, datetime and time types to correctly
// convert numbers to datetime
// the rest are taken from types of dataframe columns
// convert column by column
static inline PyObject*
df2pandas(const xlw::DataFrame& df, const std::vector<std::string>& dtypes)
{
  auto pandas = PyImport_ImportModule("pandas");
  if (!pandas)
    return nullptr;
  auto pd = PyObject_GetAttrString(pandas, "DataFrame");
  Py_DECREF(pandas);
  if (!pd)
    return nullptr;

  auto cols = series2list(df.columns, "");
  if (!cols)
  {
    Py_DECREF(pd);
    return nullptr;
  }

  // data is a dictionary of columns with key types same as in cols
  auto data = PyDict_New();
  if (!data)
  {
    Py_DECREF(cols);
    Py_DECREF(pd);
    return nullptr;
  }
  for (int i = 0; i < (int)df.data.size(); ++i)
  {
    auto col = series2list(
        df.data[i], (int)dtypes.size() > i + 1 ? dtypes[i + 1] : "");
    PyDict_SetItem(data, PyList_GetItem(cols, i), col);
    Py_DECREF(col);
  }
  Py_DECREF(cols);

  auto idx = series2list(df.index, dtypes.empty() ? "" : dtypes[0]);
  if (!idx)
  {
    Py_DECREF(data);
    Py_DECREF(pd);
    return nullptr;
  }
  // print_obj(idx);

  auto args = PyTuple_New(2);
  if (!args)
  {
    // Clean up and return nullptr
    Py_DECREF(data);
    Py_DECREF(idx);
    Py_DECREF(pd);
    return nullptr;
  }
  PyTuple_SetItem(args, 0, data); // args[0] = data
  PyTuple_SetItem(args, 1, idx);  // args[1] = idx
  // Create the DataFrame
  auto res = PyObject_CallObject(pd, args);
  Py_DECREF(args);
  Py_DECREF(pd);
  return res;
}

// also releases array
template<typename T>
xlw::Series num_arr2series(int n, PyArrayObject* arr)
{
  if (!arr)
    return {};
  assert(PyArray_ISNUMBER(arr));
  // assert(nrows == 1 || ncols == 1); // only can handle row or column
  xlw::Series res;
  res.type_ = xlw::df_type::t_num;
  res.num_.resize(n);
  auto* data = reinterpret_cast<T*>(PyArray_DATA(arr));
  // since 1d should work for both row and column major data
  for (int i = 0; i < n; ++i) res.num_[i] = (double)data[i];
  Py_DECREF(arr);
  return res;
}

// convert numpy array to xlw, also releases a
static inline xlw::Series np2series(PyObject* a)
{
  if (!a)
    return {};
  assert(PyArray_Check(a));
  auto* arr = reinterpret_cast<PyArrayObject*>(a);
  int ndims = PyArray_NDIM(arr);
  if (ndims < 1 || ndims > 2)
    return {};
  int nrows = 1, ncols = 1;
  if (ndims == 1)
    ncols = (int)PyArray_DIMS(arr)[0];
  else
  {
    nrows = (int)PyArray_DIMS(arr)[0];
    ncols = (int)PyArray_DIMS(arr)[1];
  }
  if (nrows != 1 && ncols != 1)
  {
    Py_DECREF(a);
    return {};
  }
  int n = nrows * ncols;

  if (PyArray_ISBOOL(arr))
  {
    xlw::Series res;
    res.type_ = xlw::df_type::t_bool;
    res.bol_.reserve(n);
    if (ndims == 1)
    {
      for (int i = 0; i < n; ++i)
      {
        auto itm = PyArray_GETITEM(arr, (char*)PyArray_GETPTR1(arr, i));
        if (!itm)
          return {};
        res.bol_.push_back(PyObject_IsTrue(itm) != 0);
        Py_DECREF(itm);
      }
    }
    else
    {
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
        {
          auto itm = PyArray_GETITEM(arr, (char*)PyArray_GETPTR2(arr, i, j));
          if (!itm)
            return {};
          res.bol_.push_back(PyObject_IsTrue(itm) != 0);
          Py_DECREF(itm);
        }
    }
    Py_DECREF(a);
    return res;
  }
  if (PyArray_ISNUMBER(arr))
  {
    auto typ = PyArray_DESCR(arr)->type_num;
    switch (PyArray_DESCR(arr)->type_num)
    {
      case NPY_FLOAT: return num_arr2series<npy_float>(n, arr);
      case NPY_DOUBLE: return num_arr2series<npy_double>(n, arr);
      case NPY_LONGDOUBLE: return num_arr2series<npy_longdouble>(n, arr);
      case NPY_INT8: return num_arr2series<npy_int8>(n, arr);
      case NPY_UINT8: return num_arr2series<npy_uint8>(n, arr);
      case NPY_INT16: return num_arr2series<npy_int16>(n, arr);
      case NPY_UINT16: return num_arr2series<npy_uint16>(n, arr);
      case NPY_INT32: return num_arr2series<npy_int32>(n, arr);
      case NPY_UINT32: return num_arr2series<npy_uint32>(n, arr);
      case NPY_INT64: return num_arr2series<npy_int64>(n, arr);
      case NPY_UINT64: return num_arr2series<npy_uint64>(n, arr);
      default: Py_DECREF(a); return {};
    }
  }
  xlw::Series res;
  if (PyArray_ISSTRING(arr))
  {
    res.type_ = xlw::df_type::t_str;
    res.str_.reserve(n);
    bool err;
    if (ndims == 1)
    {
      for (int i = 0; i < n; ++i)
      {
        auto str =
            py2str(PyArray_GETITEM(arr, (char*)PyArray_GETPTR1(arr, i)), err);
        if (err)
        {
          Py_DECREF(a);
          return {};
        }
        res.str_.push_back(str);
      }
    }
    else
    {
      for (int i = 0; i < nrows; ++i)
        for (int j = 0; j < ncols; ++j)
        {
          auto str = py2str(
              PyArray_GETITEM(arr, (char*)PyArray_GETPTR2(arr, i, j)), err);
          if (err)
          {
            Py_DECREF(a);
            return {};
          }
          res.str_.push_back(str);
        }
    }

    Py_DECREF(a);
    return res;
  }
  if (PyArray_ISDATETIME(arr))
  {
    res.type_ = xlw::df_type::t_num;
    res.is_date_ = true;
    res.num_.reserve(n);
    auto resol = get_resolution(a);
    auto data = (npy_datetime*)PyArray_DATA(arr);
    for (int i = 0; i < n; ++i) res.num_.push_back(dt64_excel(data[i], resol));
    Py_DECREF(a);
    return res;
  }
  if (PyArray_ISOBJECT(arr))
  {
    auto data = static_cast<PyObject**>(PyArray_DATA(arr));

    res.type_ = xlw::df_type::t_str;
    res.str_.reserve(n);
    bool err;
    for (int i = 0; i < n; ++i)
    {
      res.str_.push_back(py2str(PyObject_Str(data[i]), err));
      // if (err) PyErr_Clear();
    }
    Py_DECREF(a);
    return res;
  }
  Py_DECREF(a);
  return {};
}

// get values of i'th column of pandas dataframe
// does not release x
static inline PyObject* df_col_values(PyObject* df, int i)
{
  // Get the 'iloc' attribute
  auto iloc = PyObject_GetAttrString(df, "iloc");
  if (!iloc)
    return NULL; // Error check

  // Create a slice for all rows
  auto all_rows = PySlice_New(NULL, NULL, NULL);
  if (!all_rows)
  {
    Py_DECREF(iloc);
    return NULL;
  }

  // Create a PyLong object for the column index
  auto col_index = PyLong_FromSsize_t(i);
  if (!col_index)
  {
    Py_DECREF(all_rows);
    Py_DECREF(iloc);
    return NULL;
  }

  // Create a tuple for slicing: [:, i]
  auto slice_tuple = PyTuple_Pack(2, all_rows, col_index);
  Py_DECREF(all_rows);
  Py_DECREF(col_index);
  if (!slice_tuple)
  {
    Py_DECREF(iloc);
    return NULL;
  }

  // Get the i'th column using iloc
  auto ith_column = PyObject_GetItem(iloc, slice_tuple);
  ;
  Py_DECREF(slice_tuple);
  Py_DECREF(iloc);
  if (!ith_column)
  {
    // if (PyErr_Occurred())
    //   PyErr_Print(); // Print the error to stderr
    return NULL; // Error check
  }

  // Get the 'values' attribute to obtain the numpy array
  auto col_values = PyObject_GetAttrString(ith_column, "values");
  Py_DECREF(ith_column); // Done with 'ith_column'

  return col_values; // Remember to DECREF this in the caller}
}

static inline xlw::DataFrame pandas2df(PyObject* x)
{
  if (!x)
    return {};

  xlw::DataFrame res;

  auto cols = PyObject_GetAttrString(x, "columns");
  res.columns = np2series(PyObject_GetAttrString(cols, "values"));
  Py_XDECREF(cols);
  if (res.columns.empty())
    return {};

  auto idx = PyObject_GetAttrString(x, "index");
  bool err;
  res.idx_name = py2str(PyObject_GetAttrString(idx, "name"), err);
  res.index = np2series(PyObject_GetAttrString(idx, "values"));
  Py_XDECREF(idx);
  if (res.index.empty())
    return {};

  res.data.reserve(res.columns.len());

  for (int i = 0; i < res.columns.len(); ++i)
  {
    res.data.push_back(np2series(df_col_values(x, i)));
    if (res.data.back().len() != res.index.len())
      return {};
  }

  return res;
}

// type hint: s - string, f - float, t - datetime. FIXME - implement
static inline PyObject* xlw2py(xlw::XlfOper& x, std::string type = "")
{
  if (!type.empty())
    return nullptr; // not implemented
  if (x.is<double>())
    return PyFloat_FromDouble(x.as<double>());
  if (x.is<std::string>())
    return PyUnicode_FromString(x.as<std::string>().c_str());
  if (x.is<void>())
    Py_RETURN_NONE;
  if (x.IsMulti())
    return convert_dbl_array(x);

  return nullptr;
}