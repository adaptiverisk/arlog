#pragma once

// lightweight implementation of XlfOper
// to be able to use XlfOper and functions that use it in
// regular c++ projects

#include <cmath>
#include <string>
#include <vector>

#define EXCEL32_API

#define xlerrNull 0
#define xlerrDiv0 7
#define xlerrValue 15
#define xlerrRef 23
#define xlerrName 29
#define xlerrNum 36
#define xlerrNA 42

namespace xlw
{
enum xlf_type
{
  nil,
  str,
  num,
  bol,
  mult
};

class XlfOper
{
public:
  XlfOper() {}
  XlfOper(double x) : typ_(num), num_(x) {}
  XlfOper(int x) : typ_(num), num_(x) {}
  XlfOper(bool x) : typ_(bol), bol_(x) {}
  XlfOper(const char* x) : typ_(str), str_(x) {}
  XlfOper(const std::string& x) : typ_(str), str_(x) {}
  XlfOper(int nrows, int ncols) : typ_(nrows > 1 || ncols > 1 ? mult : nil)
  {
    if (typ_ == mult)
    {
      mult_.clear();
      mult_.resize(nrows, std::vector<XlfOper>(ncols));
    }
  }
  template<typename T>
  XlfOper(const std::vector<T>& values)
  {
    if (values.empty())
      return;
    int nrows = (int)values.size();
    typ_ = mult;
    mult_.resize(nrows, std::vector<XlfOper>(1));
    for (int i = 0; i < nrows; ++i)
    {
      mult_[i].resize(1);
      mult_[i][0] = values[i];
    }
  }

  int rows() const
  {
    return typ_ == mult ? (int)mult_.size() : (typ_ == nil ? 0 : 1);
  }
  int cols() const
  {
    return typ_ == mult ? (mult_.empty() ? 0 : (int)mult_[0].size())
                        : (typ_ == nil ? 0 : 1);
  }

  template<bool row_major = true>
  int major_size() const
  {
    if constexpr (row_major)
    {
      return rows();
    }
    else
    {
      return cols();
    }
  }

  template<bool row_major = true>
  int minor_size() const
  {
    if constexpr (row_major)
    {
      return cols();
    }
    else
    {
      return rows();
    }
  }

  template<bool row_major = true>
  XlfOper& el(int major_idx, int minor_idx)
  {
    if (typ_ == mult)
    {
      if constexpr (row_major)
      {
        return mult_[major_idx][minor_idx];
      }
      else
      {
        return mult_[minor_idx][major_idx];
      }
    }
    if (major_idx == 0 && minor_idx == 0)
      return *this;
    throw("# bad index");
  }

  XlfOper& operator()(int row, int col)
  {
    if (typ_ == mult)
      return mult_[row][col];
    if (row == 0 && col == 0)
      return *this;
    throw("# bad index");
  }

  const XlfOper& operator()(int row, int col) const
  {
    if (typ_ == mult)
      return mult_[row][col];
    if (row == 0 && col == 0)
      return *this;
    throw("# bad index");
  }

  bool IsNumber() const { return typ_ == num; }
  bool IsString() const { return typ_ == str; }
  bool IsMissing() const { return typ_ == nil; }
  bool IsNil() const { return typ_ == nil; }
  bool IsMulti() const { return typ_ == mult; }
  bool IsBool() const { return typ_ == bol; }
  bool IsError() const
  {
    return (typ_ == num && std::isnan(num_))
           || (typ_ == str && !str_.empty() && str_[0] == '#');
  }

  void SetError(int errCode)
  {
    typ_ = str;
    switch (errCode)
    {
      case xlerrNull: str_ = "#NULL!"; break;
      case xlerrDiv0: str_ = "#DIV/0!"; break;
      case xlerrValue: str_ = "#VALUE!"; break;
      case xlerrRef: str_ = "#REF!"; break;
      case xlerrName: str_ = "#NAME?"; break;
      case xlerrNum: str_ = "#NUM!"; break;
      case xlerrNA: str_ = "#N/A"; break;
      default: str_ = "#UNKNOWN!";
    }
  }

  std::string xltypeName()
  {
    switch (typ_)
    {
      case nil: return "xltypeMissing";
      case str: return "xltypeStr";
      case num: return "xltypeNum";
      case bol: return "xltypeBool";
      case mult: return "xltypeMulti";
      default: return "xltypeUnknown";
    }
  }

  double AsDouble() const { return num_; }
  int AsInt() const { return (int)num_; }
  std::string AsString() const { return str_; }
  bool AsBool() const { return bol_; }
  std::vector<double> AsDoubleVector(const char* msg = nullptr) const
  {
    if (!IsMulti())
      return std::vector<double>{AsDouble()};
    if (mult_.empty())
      return std::vector<double>();
    int nrows = (int)mult_.size();
    int ncols = (int)mult_[0].size();
    std::vector<double> res;
    res.reserve(nrows * ncols);
    for (int i = 0; i < nrows; ++i)
      for (int j = 0; j < ncols; ++j) res.push_back(mult_[i][j].AsDouble());
    return res;
  }

  // if do_transpose = true, i - column, j - row
  // otherwise: i - row, j - column
  XlfOper& tr(int i, int j, bool do_transpose = true)
  {
    if (do_transpose)
      return operator()(j, i);
    return operator()(i, j);
  }

  template<typename T>
  T as() const
  {
    return as_impl<T>::as(*this);
  }

  template<typename T>
  bool is() const
  {
    return is_impl<T>::is(*this);
  }

  XlfOper& operator=(double rhs)
  {
    typ_ = num;
    num_ = rhs;
    return *this;
  }

  XlfOper& operator=(int rhs)
  {
    typ_ = num;
    num_ = rhs;
    return *this;
  }

  XlfOper& operator=(const std::string& rhs)
  {
    typ_ = str;
    str_ = rhs;
    return *this;
  }

  XlfOper& operator=(const char* rhs)
  {
    typ_ = str;
    str_ = rhs;
    return *this;
  }

private:
  xlf_type typ_ = nil;
  double num_ = 0.;
  bool bol_ = false;
  std::string str_;
  std::vector<std::vector<XlfOper>> mult_;

  template<typename T>
  struct as_impl
  {
  };

  template<typename T>
  struct is_impl
  {
  };
};

template<>
struct XlfOper::as_impl<int>
{
  static int as(const XlfOper& x) { return x.AsInt(); }
};

template<>
struct XlfOper::as_impl<double>
{
  static double as(const XlfOper& x) { return x.AsDouble(); }
};

template<>
struct XlfOper::as_impl<std::string>
{
  static std::string as(const XlfOper& x) { return x.AsString(); }
};

template<>
struct XlfOper::as_impl<bool>
{
  static bool as(const XlfOper& x) { return x.AsBool(); }
};

template<>
struct XlfOper::as_impl<std::vector<double>>
{
  static std::vector<double> as(const XlfOper& x) { return x.AsDoubleVector(); }
};

template<>
struct XlfOper::is_impl<int>
{
  static bool is(const XlfOper& x) { return x.IsNumber(); }
};

template<>
struct XlfOper::is_impl<double>
{
  static bool is(const XlfOper& x) { return x.IsNumber(); }
};

template<>
struct XlfOper::is_impl<std::string>
{
  static bool is(const XlfOper& x) { return x.IsString(); }
};

template<>
struct XlfOper::is_impl<bool>
{
  static bool is(const XlfOper& x) { return x.IsBool(); }
};

template<>
struct XlfOper::is_impl<void>
{
  static bool is(const XlfOper& x) { return x.IsNil() || x.IsMissing(); }
};

} // namespace xlw