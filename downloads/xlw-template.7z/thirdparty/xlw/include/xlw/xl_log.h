#pragma once

#include <stdio.h>
#include <xlw/XlfOper.h>

namespace xlw
{
FILE* flog_init(
    const char* fpath, const char* lib, const char* func_name,
    const char* version);
void log_xlf(FILE* flog, const xlw::XlfOper& x, const char* name);
} // namespace xlw
