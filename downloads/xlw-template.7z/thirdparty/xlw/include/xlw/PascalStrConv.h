
/*
 Copyright (C) 2011  John Adcock

 This file is part of XLW, a free-software/open-source C++ wrapper of the
 Excel C API - https://xlw.github.io/

 XLW is free software: you can redistribute it and/or modify it under the
 terms of the XLW license.  You should have received a copy of the
 license along with this program; if not, please email xlw-users@lists.sf.net

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#pragma once
/*!
\file PascalStringConversions.h
\brief defines for conversion functions used when dealing with Excel strings
*/

// $Id$

#include <string>

namespace xlw
{

class PascalStrConv
{
public:
  static char* WPascalStr2Str(const wchar_t* pascalString);
  static std::wstring WPascalStr2WStr(const wchar_t* pascalString);
  static wchar_t* Str2WPascalStr(const std::string& cString);
  static wchar_t* WStr2WPascalStr(const std::wstring& cString);
  static wchar_t* WPascalStrCopy(const wchar_t* pascalString);
  static wchar_t* WPascalStrNewCopy(const wchar_t* pascalString);
};

class StringUtilities
{
public:
  static std::string getEnvVar(const std::string& variableName);
  // static std::string getCurrentDirectory();
};
} // namespace xlw
