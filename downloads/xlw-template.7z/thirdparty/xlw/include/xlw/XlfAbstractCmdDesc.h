
/*
 Copyright (C) 1998, 1999, 2001, 2002, 2003, 2004 J�r�me Lecomte

 This file is part of XLW, a free-software/open-source C++ wrapper of the
 Excel C API - https://xlw.github.io/

 XLW is free software: you can redistribute it and/or modify it under the
 terms of the XLW license.  You should have received a copy of the
 license along with this program; if not, please email xlw-users@lists.sf.net

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE.  See the license for more details.
*/

#pragma once

/*!
\file XlfAbstractCmdDesc.h
\brief Class XlfAbstractCmdDesc - Consolidate some properties common to multiple
command classes
*/

// $Id$

#include <ostream>
#include <string>
#include <xlw/EXCEL32_API.h>
#include <xlw/XlfArgDescList.h>

#if defined(_MSC_VER)
#pragma once
#endif

namespace xlw
{

//! Consolidate some properties common to multiple command classes.
class EXCEL32_API XlfAbstractCmdDesc
{
public:
  //! \name Structors
  //@{
  //! Ctor.
  XlfAbstractCmdDesc(
      const std::string& name, const std::string& alias,
      const std::string& comment);
  //! Dtor.
  virtual ~XlfAbstractCmdDesc();
  //@}

  //! \name Registration
  //@{
  //! Registers the command to Excel.
  void Register(int functionId) const;
  //! Unregister the command from Excel.
  void Unregister() const;
  //@}

  //! Generates the documentation in Sandcastle format
  void GenerateMamlDocs(const std::string outputDir, int itemId) const;
  //@}
  //! Name of the command in the XLL.
  std::string name;
  //! Alias for the command in Excel.
  std::string alias;
  //! Comment associated to the command.
  std::string comment;
  //! List of the argument descriptions of the function.
  XlfArgDescList args;

protected:
  //! Actually registers the command (see template method in \ref DP)
  virtual int DoRegister(
      const std::string& dllName, const std::string& suggestedHelpId) const = 0;
  //! Actually unregisters the command (see template method in \ref DP)
  virtual int DoUnregister(const std::string& dllName) const = 0;
  virtual void DoMamlDocs(std::ostream& ostream) const = 0;
  //! used to check if registation has happened
  static const double InvalidFunctionId;

private:
};

} // namespace xlw
