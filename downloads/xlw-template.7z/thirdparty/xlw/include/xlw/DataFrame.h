#pragma once

#ifdef PY
#include <xlw/xlw-mock.h>
#else
#include <xlw/xlw.h>
#endif
#include <stdexcept>
#include <unordered_set>

namespace xlw
{

// ====== df types ======

enum class df_type
{
  t_num,
  t_str,
  t_bool,
  t_unknown
};

// ====== pd.Series ======

struct Series
{
  df_type type_ = df_type::t_unknown;
  std::vector<std::string> str_;
  std::vector<double> num_;
  std::vector<bool> bol_;
  bool is_date_ = false; // true if num_ should be treated as dates

  // ---
  std::unordered_set<int> missing;

  Series() {}

  // creates data vector from i'th column (or row if is_column = false)
  // if n >= 0, only the first n elements are taken (if not enough - missing
  // values are added)
  Series(
      const xlw::XlfOper& x, int i, int j0 = 1, bool is_column = true,
      int n = -1);
  Series(int n, double x = 0);

  Series(const std::vector<double>& vec);
  Series(const std::vector<std::string>& vec);
  Series(const std::vector<bool>& vec);
  bool empty() const;
  int len() const;

  // get reference to underlying vector depending on type
  template<typename T>
  const std::vector<T>& v() const;

  template<typename T>
  std::vector<T>& v();
};

// ======= data frame =======

enum class ToXlMode
{
  All,        // full dataframe (is_df will return treu
  Data,       // just data (like to_numpy)
  DataIndex,  // data + index
  DataColumns // data + columns
};

class EXCEL32_API DataFrame
{
private:
public:
  std::vector<Series> data; // columns
  Series columns;           // column names
  Series index;             // index
  std::string idx_name;     // index name

  DataFrame() {}

  // culumns: if not null, assume x has no col names and use this vec instead
  // index: if not null, assume x has no index and use this vec instead
  DataFrame(
      const xlw::XlfOper& x, const Series* cols = nullptr,
      const Series* idx = nullptr);

  xlw::XlfOper to_xl(ToXlMode to_numpy = ToXlMode::All) const;
};

} // namespace xlw