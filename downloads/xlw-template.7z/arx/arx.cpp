#include "arx.h"

#include "doctest.h"

using namespace doctest;

double arx_testing(double x) { return 3.0 * x; }

TEST_CASE("arx_testing") { CHECK_EQ(arx_testing(2.), Approx(6.)); }

using namespace std;

XlfOper         // test dates
t_dates(ddate t // date
)
{
  return t + 1;
}

XlfOper // test or_na<ddate>
t_or_na_date(
    or_na<ddate>& t, // date
    or_na<ddate>& tb // [default:None] date
)
{
  if (t.is_na())
    return -1;
  return t.value() + 1;
}

XlfOper // test or_na<string>
t_or_na_string(
    or_na<std::string>& t,    // string
    const std::string& sdef,  // [default:"blue"] s
    or_na<std::string>& snone // [default:None] sn
)
{
  if (t.is_na())
    return -1;
  if (snone.is_na())
    return -2;
  return t.value() + " : " + sdef + " : " + snone.value();
}

XlfOper // test or_vec<ddate>
t_or_vec_date(
    or_vec<ddate>& t,    // dd
    or_vec<ddate>& tnone // [default:None] tn
)
{
  if (t.is_na())
    return -2;
  if (t.is_scalar())
    return t.value();
  if (tnone.is_na())
    return -1;
  auto res = t.vec();
  res.insert(res.end(), tnone.vec().begin(), tnone.vec().end());
  return res;
}

XlfOper // test or_vec<int>
t_or_vec_int(
    or_vec<int>& t,   // di
    or_vec<int>& tdef // [default:5] td
)
{
  if (t.is_na())
    return -2; // required
  auto res = t.vec();
  res.insert(res.end(), tdef.vec().begin(), tdef.vec().end());
  return res;
}

XlfOper // test vec<ddate>
t_vec_date(
    vec<ddate>& t,    // dd
    vec<ddate>& tnone // [default:None] tn
)
{
  if (t.is_na())
    return -2;
  if (t.is_scalar())
    return t.value();
  if (tnone.is_na())
    return -1;
  auto res = t.vec();
  res.insert(res.end(), tnone.vec().begin(), tnone.vec().end());
  return res;
}

XlfOper // test vec<int>
t_vec_int(
    vec<int>& t,   // di
    vec<int>& tdef // [default:5] td
)
{
  if (t.is_na())
    return -2; // required
  auto res = t.vec();
  res.insert(res.end(), tdef.vec().begin(), tdef.vec().end());
  return res;
}

XlfOper // test MatRows
t_mat_rows(
    MatRows& t,    // dd
    MatRows& tnone // [default:None] tn
)
{
  int n = 0;
  for (auto& r: t.data) { n += (int)r.size(); }

  for (auto& r: tnone.data) { n += (int)r.size(); }
  return n;
}

XlfOper                // test MatRows
t_mat_rows1(MatRows& t // dd
)
{
  return t.rows();
}

XlfOper // test MatCols
t_mat_cols(
    MatCols& t,    // dd
    MatCols& tnone // [default:None] tn
)
{
  int n = 0;
  for (auto& r: t.data) { n += (int)r.size(); }
  for (auto& r: tnone.data) { n += (int)r.size(); }
  return n;
}

DataFrame t_df(const DataFrame& df)
{
  DataFrame res;
  res.index.type_ = df_type::t_num;
  res.index.num_.resize(df.columns.len());
  for (int i = 0; i < res.index.len(); ++i) res.index.num_[i] = 40000. + i;
  res.columns.type_ = df_type::t_str;
  res.columns.str_ = {"dtype", "irow", "es"};
  res.data.resize(3);

  res.data[0].type_ = df_type::t_str;
  res.data[0].str_.resize(res.index.len());
  for (int i = 0; i < res.index.len(); ++i) switch (df.data[i].type_)
    {
      case df_type::t_num: res.data[0].str_[i] = "num"; break;
      case df_type::t_str: res.data[0].str_[i] = "str"; break;
      case df_type::t_bool: res.data[0].str_[i] = "bool"; break;
      default: res.data[0].str_[i] = "unknown"; break;
    }

  res.data[1].type_ = df_type::t_num;
  res.data[1].num_.resize(res.index.len());
  for (int i = 0; i < res.index.len(); ++i) res.data[1].num_[i] = i;

  res.data[2] = res.index;

  return res;
}