#pragma once
// generated file - do not edit
#define VERSION "82-b7ea"
#define VERSIONPY "0.1.82"
