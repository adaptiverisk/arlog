#pragma once
// generated file - do not edit
#define VERSION "80-c0d4"
#define VERSIONPY "0.1.80"
