#include "version.h"

#include <string>

using namespace std;

string
arx__help(int which //0 - help string, 1 - compilation timestamp, 2 - version
)
{
  if (which == 2) return VERSION;

  if (which == 1)
  {
    string date(__DATE__);
    string time(__TIME__);
    string res;
    res = date + " | " + time;
    return res;
  }

  return R"(help string)";
}
