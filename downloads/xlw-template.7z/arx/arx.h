#pragma once

#include <df.h>
#include <xlw/xl.h>

using namespace xlw;

//<xlw:libraryname=arx

double // test function
arx_testing(double x);

XlfOper         // test dates (adds 1 to the date)
t_dates(ddate t // date
);

XlfOper // test or_na<ddate>
        // <xlw:threadsafe
t_or_na_date(
    or_na<ddate>& t, // date
    or_na<ddate>& tb // [default:None] date
);

XlfOper // test or_na<string>
        // <xlw:volatile
t_or_na_string(
    or_na<std::string>& t,    // string
    const std::string& sdef,  // [default:"blue"] s
    or_na<std::string>& snone // [default:None] sn
);

XlfOper // test or_vec<ddate>
// <xlw:time
// <xlw:help="or_vec_date"
t_or_vec_date(
    or_vec<ddate>& t,    // dd
    or_vec<ddate>& tnone // [default:None] tn
);

XlfOper // test or_vec<int>
t_or_vec_int(
    or_vec<int>& t,   // di
    or_vec<int>& tdef // [default:5] td
);

XlfOper // test vec<ddate>
t_vec_date(
    vec<ddate>& t,    // dd
    vec<ddate>& tnone // [default:None] tn
);

XlfOper // test vec<int>
t_vec_int(
    vec<int>& t,   // di
    vec<int>& tdef // [default:5] td
);

XlfOper // test MatRows
t_mat_rows(
    MatRows& t,    // dd
    MatRows& tnone // [default:None] tn
);

XlfOper                // test MatRows
t_mat_rows1(MatRows& t // dd
);

XlfOper // test MatCols
t_mat_cols(
    MatCols& t,    // dd
    MatCols& tnone // [default:None] tn
);

DataFrame //  test DataFrame -> df[:date, dtype:str, irow:int, es:num]
t_df(const DataFrame& df // df - input frame
);
