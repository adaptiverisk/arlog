#pragma once

#include <xlw/xl.h>

//<xlw:libraryname=arx

std::string         // arx addin general info
arx__help(int which // 0 - help string, 1 - compilation timestamp, 2 - version
);